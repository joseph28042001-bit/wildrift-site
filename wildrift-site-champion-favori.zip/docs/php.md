# PHP — conventions et cycle de vie

PHP pur, sans framework, sans Composer. Cible : PHP 8.0+ avec les
extensions `pdo_mysql`, `mbstring`, `json`, `session`.

## Cycle de vie d'une page publique

1. Le point d'entrée (`index.php`, `champions.php`, etc., à la racine)
   inclut `includes/bootstrap.php`.
2. `includes/bootstrap.php` charge, dans cet ordre strict :
   1. `config/environment.php` (définit les constantes d'environnement,
      puis `checkProductionReadiness()` — voir `docs/configuration.md`) ;
   2. `config/app.php` (nom/version de l'app, `ROOT_PATH`, fuseau
      horaire, réglages d'affichage des erreurs) ;
   3. `config/site.php` (`url()` / `asset()`) ;
   4. `includes/error_handler.php` (filet de sécurité global) ;
   5. `config/session.php` puis `config/security.php` ;
   6. `config/uploads.php` ;
   7. `config/database.php` (connexion PDO) ;
   8. `config/riot.php` puis `config/wrchina.php` (constantes
      d'intégration externe uniquement, aucun appel réseau) ;
   9. `includes/functions.php` (helpers génériques) ;
   puis appelle `startSecureSession()` et `sendSecurityHeaders()`.
3. Le point d'entrée applique le layout (`includes/components/header.php`
   / `footer.php`) et inclut le contenu réel depuis `pages/<page>.php`.

L'espace admin suit le même principe avec `admin/includes/bootstrap.php`
(qui inclut `includes/bootstrap.php` puis prépare le contexte admin) et
`admin/includes/header.php` / `footer.php`.

> `admin/includes/bootstrap.php` contient actuellement un filet de
> diagnostic temporaire (affichage forcé des erreurs fatales PHP,
> indépendamment du réglage serveur) explicitement marqué « à retirer »
> dans son propre commentaire — à surveiller avant mise en production.

## Fonctions utilitaires partagées (`includes/functions.php`)

| Fonction | Rôle |
|---|---|
| `e(?string $value): string` | Échappe une chaîne pour un affichage HTML sûr (`htmlspecialchars`, `ENT_QUOTES`, UTF-8) |
| `redirect(string $path): void` | Redirige vers une URL relative au site (`BASE_URL`) et arrête l'exécution |
| `jsonResponse(array $data, int $statusCode = 200): void` | Réponse JSON standard (utilisée par l'API — voir `docs/api.md`) |

Autres helpers globaux, définis dans `config/site.php` : `url($path)`
(URL absolue, `SITE_URL` + `BASE_URL`) et `asset($path)` (URL relative,
`BASE_URL` seul — utilisée pour les liens internes et les fichiers
statiques).

## Accès base de données

`config/database.php` expose une connexion PDO singleton
(`getDbConnection()`) et des helpers systématiquement utilisés à la
place de PDO brut :

| Fonction | Usage |
|---|---|
| `dbQuery($sql, $params)` | Requête préparée, retourne le `PDOStatement` exécuté |
| `dbFetchOne($sql, $params)` | Une seule ligne (ou `null`) |
| `dbFetchAll($sql, $params)` | Toutes les lignes |
| `dbExecute($sql, $params)` | INSERT/UPDATE/DELETE — retourne le nombre de lignes affectées |
| `dbLastInsertId()` | ID de la dernière ligne insérée |

Règle stricte : aucune valeur n'est jamais concaténée dans une chaîne
SQL, toujours des requêtes préparées à marqueurs nommés ou positionnels.
Toute `PDOException` (connexion ou requête) est journalisée via
`error_log()` côté serveur puis remplacée par une `DatabaseException`
au message générique — jamais de SQL, d'identifiant ni de structure de
table renvoyé au visiteur.

```php
$champion = dbFetchOne(
    'SELECT * FROM champions WHERE slug = :slug',
    ['slug' => $slug]
);
```

## Organisation par ressource (API)

Chaque ressource de `api/` sépare strictement :
- `index.php` — routage (méthode HTTP + paramètres de requête),
  validation des entrées, appel du repository, réponse JSON ;
- `repository.php` — tout l'accès aux données (PDO, requêtes préparées)
  pour cette ressource, jamais de SQL ailleurs.

Voir `docs/api.md` pour le détail du socle commun (`api/core/`) et de
chaque endpoint.

## Gestion des erreurs (plusieurs niveaux)

1. **Base de données** (`config/database.php`) — voir ci-dessus.
2. **Filet global PHP** (`includes/error_handler.php`) — capture toute
   exception/erreur PHP non interceptée ailleurs, journalise le détail,
   affiche un message générique au visiteur.
3. **Affichage des erreurs** (`config/app.php`) — piloté par
   `APP_DEBUG` (= `ENVIRONMENT === 'development'`) : erreurs visibles en
   développement, totalement masquées en production
   (`display_errors=0`, `E_ALL & ~E_DEPRECATED & ~E_NOTICE`).
4. **Pages d'erreur** (`errors/403.php`, `404.php`, `500.php`) —
   volontairement autonomes (aucune dépendance à `bootstrap.php`, à la
   config ou à la base de données) pour rester fiables même si le reste
   de l'application est cassé.

## Intégrations externes (`includes/riot/`, `includes/wrchina/`)

- **Riot** (`includes/riot/`) : `RiotApiClient` récupère les données de
  champions/objets depuis **Data Dragon**, le CDN statique et public de
  Riot (aucune clé requise) — pas depuis l'API Riot authentifiée
  (`RIOT_API_BASE_URL`), réservée aux données de joueur/partie et
  inutilisée ici. `RiotCache` gère un cache disque
  (`RIOT_API_CACHE_TTL_MINUTES`). `RiotRepository` fait le lien avec la
  base locale. `RiotApiNotConnectedException` / `RiotApiRequestException`
  pour les cas d'erreur.
- **WRChina.gg** (`includes/wrchina/`) : architecture symétrique à Riot,
  mais **aucune méthode d'accès autorisée n'a été identifiée** à ce
  jour — `WrChinaApiClient` lève systématiquement une exception pour
  toute ressource. `WrChinaPatchImporter` lit à la place un fichier
  local tenu à jour manuellement (`data/wrchina/patches.json`, voir
  `docs/configuration.md`), ce qui n'est pas une connexion à l'API.

Les deux clients sont chargés à la demande par le code qui en a besoin,
jamais dans `bootstrap.php` (seules les constantes de configuration y
sont chargées, sans requête réseau).

## Tests (`tests/`)

Scripts PHP autonomes (un par fonctionnalité), exécutables en ligne de
commande (`php tests/test-builds-search.php`) ou via navigateur. Ils
n'utilisent aucun framework de test (pas de PHPUnit) : chaque script
assert ses propres cas et affiche un résultat lisible. Couvrent
principalement l'API Builds (recherche, pagination, filtres par rôle et
par patch, relations, erreurs), l'API Tier List (filtre par champion,
erreurs) et l'import de patchs WRChina.

## Front-end (JS statique, sans build)

`assets/js/` contient un script par page ou fonctionnalité (pas de
bundler, pas de framework JS). Convention commune à tous les scripts
consommant l'API :
- `window.API_BASE_URL` (défini dans `includes/components/footer.php`
  via `asset('api')`) donne une base d'URL valide quel que soit le
  sous-dossier d'installation ;
- chaque ressource a sa fonction `fetchXxx()` basée sur `fetch()`, qui
  lit l'enveloppe JSON standard (voir `docs/api.md`) et rejette avec une
  erreur typée distinguant échec réseau, réponse non-JSON et erreur
  applicative (ex. `NewsApiError`, sur le modèle utilisé par
  `assets/js/news.js`) ;
- un script n'est chargé que sur la ou les pages qui en ont besoin (ex.
  `champions.js` sur `/champions.php` uniquement), à l'exception des
  scripts partagés (`main.js`, chargé globalement pour le design
  system).
