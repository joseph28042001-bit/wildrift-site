# Configuration

Pas de fichier `.env` : toute la configuration passe par des constantes
PHP (`define()`), centralisées dans `config/` et chargées dans un ordre
précis par `includes/bootstrap.php` (voir `docs/php.md`).

## Fichiers de configuration

| Fichier | Rôle |
|---|---|
| `config/environment.php` | Constantes d'environnement (voir tableau ci-dessous) + `checkProductionReadiness()` |
| `config/app.php` | `APP_NAME`, `APP_VERSION`, `ROOT_PATH`, `UPLOADS_PATH`, réglages d'affichage des erreurs (`APP_DEBUG`), fuseau horaire (`Europe/Paris`) |
| `config/site.php` | Helpers `url()` / `asset()`, basés sur `SITE_URL` / `BASE_URL` |
| `config/session.php` | `startSecureSession()`, `regenerateSessionId()`, `maybeRegenerateUserSession()`, `destroySession()` |
| `config/security.php` | `sendSecurityHeaders()`, `csrfToken()`, `verifyCsrfToken()`, `PASSWORD_HASH_OPTIONS` |
| `config/uploads.php` | `UPLOAD_MAX_SIZE_BYTES`, extensions autorisées, `generateSafeUploadFilename()` |
| `config/database.php` | Connexion PDO + helpers de requêtes (voir `docs/mysql.md`) |
| `config/riot.php` | Constantes d'intégration Data Dragon (Riot) — aucun appel réseau au chargement |
| `config/wrchina.php` | Constantes d'intégration WRChina.gg (non connectée) + chemin du fichier de patchs local |

Trois fichiers `.example` fournissent des modèles à copier (non
versionnés une fois copiés) :

- `config/config.local.php.example` → `config/config.local.php`
- `config/database.local.php.example` → `config/database.local.php`
- `config/riot.local.php.example` → `config/riot.local.php` (optionnel)
- `config/wrchina.local.php.example` → `config/wrchina.local.php` (optionnel)

`config/.htaccess` bloque tout accès HTTP direct à l'ensemble du
dossier `config/` (`Require all denied` / `Deny from all`).

## Variables d'environnement (constantes)

| Constante | Défaut développement | Production (à définir) |
|---|---|---|
| `ENVIRONMENT` | `development` | `production` |
| `SITE_URL` | `http://localhost` | doit commencer par `https://` |
| `BASE_URL` | `/` | `/` (ou `/sous-dossier/`) |
| `SESSION_COOKIE_SECURE` | `false` | `true` (obligatoire) |
| `SECURITY_APP_KEY` | clé de dev par défaut | chaîne aléatoire ≥ 32 caractères |
| `SECURITY_PASSWORD_COST` | `10` | — |
| `SECURITY_MAX_LOGIN_ATTEMPTS` | `5` | — |
| `SESSION_NAME` | `wildrift_session` | — |
| `SESSION_LIFETIME_MINUTES` | `120` | — |
| `SESSION_USER_KEY` | `user_id` | — |
| `SESSION_USER_REGENERATE_MINUTES` | `30` | — |
| `UPLOAD_MAX_SIZE_MB` | `5` | — |
| `UPLOAD_ALLOWED_EXTENSIONS` | `jpg,jpeg,png,webp,gif` | — |
| `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS` | valeurs locales | identifiants MySQL réels |

Génération d'une clé aléatoire :
```bash
php -r "echo bin2hex(random_bytes(32));"
```

### Patch actif (version du jeu)

La version du jeu utilisée par le site est définie à un seul endroit :
`CURRENT_PATCH` dans `config/patch.php` (valeur actuelle : `7.2e`).
Pour changer de patch, modifier uniquement cette valeur. Elle est
disponible en PHP (constante `CURRENT_PATCH`, chargée par
`includes/bootstrap.php`, donc aussi dans l'API et l'administration) et
en JavaScript (`window.CURRENT_PATCH`, définie dans le `<head>` des deux
layouts). Le format est celui de la colonne `patch` des tables `builds`
et `tier_list` (10 caractères maximum).

### Garde-fou de mise en production

`checkProductionReadiness()` (`config/environment.php`), appelée
automatiquement par `includes/bootstrap.php`, bloque le démarrage du
site (message générique affiché, détail journalisé côté serveur) si
`ENVIRONMENT=production` alors que l'une de ces conditions est vraie :
`SECURITY_APP_KEY` est restée par défaut ou fait moins de 32 caractères,
`SITE_URL` n'est pas en `https://`, ou `SESSION_COOKIE_SECURE` n'est pas
à `true`. Impossible donc de mettre en ligne accidentellement avec des
réglages de développement.

## Intégrations externes (Riot / WRChina)

| | Riot (Data Dragon) | WRChina.gg |
|---|---|---|
| Fichier config | `config/riot.php` | `config/wrchina.php` |
| Client | `includes/riot/RiotApiClient.php` | `includes/wrchina/WrChinaApiClient.php` |
| Statut | **Connecté** : données de champions/objets lues depuis Data Dragon, le CDN public de Riot (aucune clé requise) | **Non connecté** : aucune méthode d'accès autorisée identifiée — le client lève systématiquement une exception |
| Clé API | `RIOT_API_KEY` (vide par défaut, inutilisée pour champions/objets — seulement un interrupteur via `isRiotApiConfigured()`) | `WRCHINA_API_KEY` (vide, `isWrChinaConfigured()` ne débloque rien à lui seul) |
| Cache | Cache disque (`RiotCache`, `RIOT_API_CACHE_TTL_MINUTES`, `RIOT_CACHE_PATH`) | — |
| Alternative actuelle | — | `data/wrchina/patches.json` (`WRCHINA_PATCHES_STAGING_FILE`), tenu à jour manuellement, lu par `WrChinaPatchImporter`. Protégé par `data/wrchina/.htaccess` |

## Installation après mise en ligne

1. Copier `config/config.local.php.example` → `config/config.local.php`
   et renseigner `SITE_URL`, `BASE_URL`, `SECURITY_APP_KEY`, réglages de
   session et limites d'upload.
2. Copier `config/database.local.php.example` → `config/database.local.php`
   et renseigner les 4 identifiants MySQL fournis par l'hébergeur.
3. (Optionnel) `config/riot.local.php.example` → `config/riot.local.php`
   si une vraie clé d'API Riot devient nécessaire (actuellement
   inutilisée pour champions/objets).
4. Importer `database/schema.sql` (voir `docs/mysql.md`).

## Prérequis serveur

| Élément | Version / détail |
|---|---|
| PHP | 8.0 ou supérieur |
| Extensions PHP | `pdo_mysql`, `mbstring`, `json`, `session` |
| MySQL / MariaDB | 5.7+ / équivalent |
| Serveur web | Apache avec `mod_rewrite` et `mod_headers` |

Aucun outil de build (pas de Node.js, pas de Composer). `deploy/build.sh`
vérifie la syntaxe PHP (`php -l`), s'assure que les fichiers `*.local.php`
existent, puis empaquette le projet (hors `.git/`, `deploy/`, `*.example`)
dans `deploy/dist/wildrift-site-<horodatage>.zip`.

## HTTPS et en-têtes de sécurité

- `sendSecurityHeaders()` (`config/security.php`) envoie systématiquement
  `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`,
  `Referrer-Policy: strict-origin-when-cross-origin`, et ajoute
  `Strict-Transport-Security` (HSTS) une fois en production avec
  `SESSION_COOKIE_SECURE=true`.
- Cookie de session marqué `secure` (en prod) + `httponly` +
  `SameSite=Lax` (`config/session.php`).
- Un `.htaccess` racine forçant la redirection HTTP → HTTPS est
  documenté dans le `README.md` du projet mais absent de cet export
  (voir `docs/structure.md`) : à vérifier/recréer avant mise en
  production.

## Fichiers `.htaccess` présents

| Fichier | Effet |
|---|---|
| `admin/.htaccess` | `DirectoryIndex index.php` + `Options -Indexes` |
| `config/.htaccess` | Bloque tout accès direct au dossier |
| `data/wrchina/.htaccess` | Bloque tout accès direct au dossier |
