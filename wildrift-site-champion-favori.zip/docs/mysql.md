# Base de données (MySQL)

Schéma complet : `database/schema.sql`. Compatible MySQL 5.7+ / MariaDB
équivalent (hébergement mutualisé type InfinityFree). Toutes les tables
sont en `InnoDB`, `utf8mb4` / `utf8mb4_unicode_ci`. Le script utilise
`CREATE TABLE IF NOT EXISTS` : il peut être réimporté sans casser une
base déjà en place.

## Connexion (PDO)

`config/database.php` expose une connexion PDO unique (singleton),
initialisée en `PDO::ERRMODE_EXCEPTION`, `FETCH_ASSOC` par défaut, avec
les requêtes préparées natives (`EMULATE_PREPARES => false`). Identifiants
définis dans `config/database.local.php` (non versionné). Voir
`docs/php.md#accès-base-de-données` pour l'usage côté code.

## Vue d'ensemble des tables (24)

| Table | Rôle |
|---|---|
| `app_meta` | Clé/valeur interne (ex. `schema_version`) |
| `champions` | Les champions Wild Rift (141 actuellement en données de test — voir plus bas) |
| `champion_abilities` | Les 5 capacités (passive + Q/W/E/R) de chaque champion |
| `items` | Objets (armes, magie, défense, bottes, jungle, consommables, enchantements) |
| `item_recipes` | Composants d'un objet (auto-relation sur `items`) |
| `rune_trees` | Les 5 arbres de runes |
| `runes` | Runes individuelles (rattachées à un arbre) |
| `builds` | Un build = un champion + un rôle + un patch |
| `build_items` | Objets d'un build, par emplacement (départ/core/bottes/enchant./situationnel) |
| `build_runes` | Runes d'un build, par position |
| `build_skill_order` | Ordre de montée des sorts d'un build |
| `counters` | Matchups champion vs champion contré, avec conseils et difficulté |
| `counter_items` | Objets recommandés pour un counter donné |
| `synergies` | Paires de champions synergiques, avec explication |
| `tier_list` | Classement (tier) d'un champion, par rôle et par patch |
| `news` | Articles d'actualité |
| `riot_raw_payloads` / `riot_sync_log` | Journal brut / suivi des imports depuis Data Dragon (Riot) |
| `wrchina_raw_payloads` / `wrchina_sync_log` | Mêmes tables, pour une future source WRChina.gg (non connectée) |
| `wrchina_patches` | Informations de patch saisies manuellement depuis WRChina.gg |
| `patches` | Versions du jeu gérées par le site (7.2e, 7.3, 7.3a…), avec le patch actif |
| `users` | Comptes utilisateurs (pseudo, email, mot de passe, rôle, bio, avatar) |
| `user_favorite_builds` | Builds favoris d'un utilisateur (relation N-N `users` ↔ `builds`) |

## Détail des tables principales

### `champions`

| Colonne | Type | Détail |
|---|---|---|
| `id` | INT UNSIGNED AUTO_INCREMENT | PK |
| `slug` | VARCHAR(60) UNIQUE | Identifiant URL (ex. `lee-sin`) |
| `name` | VARCHAR(60) | Nom affiché |
| `title` | VARCHAR(120) NULL | Titre du champion |
| `role` | ENUM(`baron`,`jungle`,`mid`,`dragon`,`support`) | Rôle principal |
| `difficulty` | TINYINT UNSIGNED, défaut 1 | Difficulté (1 à 5 côté validation API) |
| `cc_level` | ENUM(`faible`,`moyen`,`fort`) | Niveau de contrôle de foule du kit |
| `engage_level` | ENUM(`faible`,`moyen`,`fort`) | Potentiel d'engagement |
| `disengage_level` | ENUM(`faible`,`moyen`,`fort`) | Potentiel de disengage/protection |
| `early_game_level` | ENUM(`faible`,`moyen`,`fort`) | Puissance en début de partie |
| `late_game_level` | ENUM(`faible`,`moyen`,`fort`) | Puissance en fin de partie |
| `image_url` | VARCHAR(255) NULL | |
| `patch_id` | INT UNSIGNED NULL | Patch de rattachement (clé vers `patches`) ; NULL = tous les patchs — voir « Rattachement des données aux patchs » plus bas |
| `created_at`, `updated_at` | TIMESTAMP | Gérés automatiquement par MySQL |

Index : `idx_champions_role`, `idx_champions_name`, `idx_champions_patch_id`. Les 5 champs de
jauge (`cc_level`…`late_game_level`) alimentent l'analyse d'équipe de
`pages/simulation.php` / `assets/js/simulation.js`. Les données de test
livrées avec `schema.sql` couvrent actuellement les 141 champions du
roster Wild Rift, à ajuster au cas par cas une fois l'administration
Champions pleinement fiabilisée.

### `patches`

| Colonne | Type | Détail |
|---|---|---|
| `id` | INT UNSIGNED AUTO_INCREMENT | PK |
| `version` | VARCHAR(10) UNIQUE | Numéro du patch (ex. `7.2e`, `7.3`, `7.3a`) — même format que `builds.patch` et `tier_list.patch` |
| `is_active` | TINYINT(1), défaut 0 | 1 = patch actif du site, 0 = inactif |
| `release_date` | DATE NULL | Date de sortie du patch (facultative) |
| `description` | VARCHAR(500) NULL | Note libre |
| `created_at`, `updated_at` | TIMESTAMP | Gérés automatiquement par MySQL |

Le patch `7.2e` est créé actif. Le site est censé n'avoir qu'un seul
patch actif : la base ne l'impose pas par contrainte, donc pour changer
de patch actif, désactiver l'ancien et activer le nouveau dans une même
transaction :

```sql
START TRANSACTION;
UPDATE patches SET is_active = 0 WHERE is_active = 1;
UPDATE patches SET is_active = 1 WHERE version = '7.3';
COMMIT;
```

Lire le patch actif : `SELECT version FROM patches WHERE is_active = 1;`.
Sur une base déjà en ligne, importer uniquement
`database/migration_patches.sql` (pas besoin de réimporter tout
`schema.sql`). Le rattachement des données à cette table est décrit
dans la section suivante.

### Rattachement des données aux patchs (`patch_id`)

Chaque table de données versionnable porte une colonne
`patch_id INT UNSIGNED NULL`, clé étrangère vers `patches.id`
(`ON DELETE SET NULL`, index `idx_<table>_patch_id`, contrainte
`fk_<table>_patch`) :

| Donnée | Table portant `patch_id` | Remarques |
|---|---|---|
| Champions | `champions` | Les capacités (`champion_abilities`) suivent leur champion |
| Objets | `items` | Les recettes (`item_recipes`) suivent leur objet |
| Runes | `runes` | |
| Builds | `builds` | Objets, runes et ordre de sorts (`build_items`, `build_runes`, `build_skill_order`) suivent leur build |
| Tier list | `tier_list` | |
| Statistiques | `tier_list` | Les taux `win_rate` / `pick_rate` / `ban_rate` sont des colonnes de la tier list : ils sont versionnés avec elle |
| Counters | `counters` | Les objets conseillés (`counter_items`) suivent leur counter |
| Recommandations | `synergies` (et `counters`) | Les objets recommandés dans un build sont ceux de `build_items` |

Règles :

- **`NULL` = non rattaché à un patch précis (valable pour tous les
  patchs).** C'est le cas de toutes les données existantes hors builds
  et tier list, jusqu'à ce qu'un patch leur soit attribué. Aucune
  ligne existante n'est modifiée ni supprimée par la migration, et le
  code qui ignore `patch_id` continue de fonctionner à l'identique.
- **`builds` et `tier_list` gardent leur colonne texte `patch`**, qui
  reste la référence : `patch_id` la suit (rattachement automatique par
  la migration, puis par `insertBuild()` / `updateBuild()`, voir
  `includes/patches.php`). Les versions déjà présentes dans ces deux
  tables mais absentes de `patches` y sont ajoutées, inactives ; le
  patch actif ne change pas.
- **Supprimer un patch ne supprime aucune donnée** : les lignes
  rattachées perdent seulement leur `patch_id` (`ON DELETE SET NULL`).
- **Les contraintes d'unicité existantes sont inchangées** (par
  exemple `champions.slug`, `counters` par couple de champions,
  `tier_list` par champion/rôle/`patch`). Conserver plusieurs
  versions d'une même donnée (ex. un même champion à deux patchs)
  demandera d'élargir ces contraintes : c'est une étape ultérieure,
  volontairement pas faite ici pour ne rien casser.

Mise en place :

- Base neuve : `database/schema.sql` contient déjà tout (fin du
  fichier).
- Base déjà en ligne : importer uniquement
  `database/migration_patch_links.sql` (après, ou sans,
  `migration_patches.sql`). Rejouable sans risque : elle n'ajoute que
  ce qui manque et recalcule le rattachement de `builds` et
  `tier_list`. À rejouer après l'import d'un seed
  (`seed_wildriftfire_builds.sql`, qui insère des builds sans
  `patch_id`). Elle affiche en dernier un tableau de contrôle
  (lignes sans patch par table ; attendu : 0 pour `builds` et
  `tier_list`).
- Côté PHP, `includes/patches.php` fournit `findActivePatch()`,
  `findPatchByVersion()`, `findAllPatches()`, `tableHasPatchLink()` et
  `linkRowToPatch()`. Tant que la migration n'est pas importée, ces
  fonctions se comportent comme si `patch_id` n'existait pas : déployer
  le code avant la base ne casse rien.

### Relations avec cascade (`ON DELETE CASCADE`)

Supprimer un champion supprime automatiquement, côté base, tout ce qui
le référence : ses capacités (`champion_abilities`), ses builds
(`builds`), les matchups où il apparaît (`counters`, dans les deux
sens), les entrées de tier list (`tier_list`) et les synergies
(`synergies`, dans les deux sens). Même principe pour un objet
(`items`) supprimé : ses recettes (`item_recipes`) et ses usages dans
des builds (`build_items`) ou des counters (`counter_items`) partent
avec lui. Un build supprimé entraîne la suppression de ses objets, ses
runes et son ordre de sorts (`build_items`, `build_runes`,
`build_skill_order`), ainsi que les entrées de favoris qui le
référencent (`user_favorite_builds`). Supprimer un compte utilisateur
(`users`) supprime de la même façon ses favoris. Les liens vers
`patches` (`patch_id`) font exception : ils sont en `ON DELETE SET NULL`,
donc supprimer un patch ne supprime jamais de données.

### Contraintes d'unicité notables

- `champions.slug`, `items.slug`, `runes.slug`, `rune_trees.slug`,
  `news.slug` : chacun unique.
- `counters` : une seule ligne par couple (`champion_id`,
  `counter_champion_id`).
- `synergies` : une seule ligne par couple (`champion_id`,
  `synergy_champion_id`).
- `tier_list` : une seule entrée par (`champion_id`, `role`, `patch`).
- `builds` : un nom de build unique par champion.
- `build_runes` : une position (1 à 6) unique par build.
- `users.pseudo`, `users.email` : chacun unique.
- `user_favorite_builds` : une seule ligne par couple (`user_id`,
  `build_id`) — un build ne peut pas être ajouté deux fois aux favoris
  d'un même utilisateur.

## Tables d'intégration externe

`riot_raw_payloads` / `riot_sync_log` et leurs équivalents `wrchina_*`
suivent le même schéma générique (type de ressource, ID externe, patch,
payload JSON brut, horodatages de récupération/traitement, statut de
synchronisation). Elles sont prêtes à recevoir des imports mais aucun
processus de synchronisation automatique n'est câblé à ce jour — voir
`docs/configuration.md#intégrations-externes-riot--wrchina` pour l'état
de ces deux intégrations. `wrchina_patches` est alimentée manuellement
via `WRCHINA_PATCHES_STAGING_FILE` (`data/wrchina/patches.json`), pas
par une connexion API.

## Import du schéma

1. Créer une base MySQL (panneau d'hébergement, ex. InfinityFree).
2. Ouvrir phpMyAdmin (ou équivalent) sur cette base.
3. Onglet SQL → coller/importer le contenu de `database/schema.sql` →
   exécuter.

Le script étant idempotent (`CREATE TABLE IF NOT EXISTS` +
`ON DUPLICATE KEY UPDATE` sur les données de test), le réimporter après
une mise à jour ne duplique rien et ne supprime aucune table existante.
Il ne supprime jamais de données : pour repartir de zéro, vider les
tables manuellement au préalable.
