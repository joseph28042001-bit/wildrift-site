# Documentation technique — Wild Rift Platform

Cette documentation décrit l'état actuel du projet, indépendamment de
l'historique des étapes de développement (voir `README.md` à la racine
pour ce dernier). Elle est organisée en six volets :

| Fichier | Contenu |
|---|---|
| [`structure.md`](./structure.md) | Arborescence complète du projet et rôle de chaque dossier |
| [`php.md`](./php.md) | Conventions PHP, cycle de vie d'une requête, helpers partagés |
| [`mysql.md`](./mysql.md) | Schéma de la base de données, table par table |
| [`api.md`](./api.md) | Référence de tous les endpoints REST, enveloppe JSON, erreurs |
| [`configuration.md`](./configuration.md) | Fichiers de config, variables d'environnement, déploiement |
| [`administration.md`](./administration.md) | Espace `/admin`, état de l'authentification, gestion de contenu |

**Prérequis techniques :** PHP 8.0+ (extensions `pdo_mysql`, `mbstring`,
`json`, `session`), MySQL 5.7+ / MariaDB équivalent, Apache avec
`mod_rewrite` et `mod_headers`. Aucun Node.js, aucun Composer, aucune
dépendance externe : le projet est du PHP pur, pensé pour de
l'hébergement mutualisé (InfinityFree).

> Cette documentation reflète l'état du code au moment de sa rédaction.
> Le projet évolue étape par étape (voir le journal dans `README.md`) ;
> en cas de doute sur un comportement précis, le code source et son
> docblock font foi.
