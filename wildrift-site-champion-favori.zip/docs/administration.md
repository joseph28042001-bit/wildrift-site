# Administration

L'espace d'administration vit sous `admin/`, isolé du site public mais
**pas encore protégé par une authentification fonctionnelle**. Ce
document décrit l'état réel du chantier — à lire avant toute mise en
production.

## ⚠️ État de l'authentification (important)

- `admin/login.php` + `admin/pages/login.php` affichent un formulaire de
  connexion (email, mot de passe, jeton CSRF déjà généré via
  `csrfToken()`), avec validation **côté navigateur uniquement**
  (`assets/js/admin-login.js`). **La soumission ne fait que recharger la
  page** : aucune vérification d'identifiants côté serveur n'est câblée.
- Il n'existe **aucune table `users`** dans `database/schema.sql`, ni
  côté comptes publics ni côté comptes administrateurs — rien à quoi
  comparer un email/mot de passe soumis.
- `admin/includes/bootstrap.php` le dit explicitement dans son
  commentaire : *« Aucune logique d'authentification n'est développée à
  cette étape »*. Aucune page de `admin/` (`index.php`, `champions.php`,
  `items.php`, `builds.php`, `runes.php`) ne vérifie de session admin
  avant d'afficher son contenu.
- Conséquence directe côté API : les méthodes d'écriture
  (`POST`/`PUT`/`DELETE`) de `champions`, `items`, `runes` et `builds`
  sont **accessibles sans connexion**, au même titre que le reste de
  l'espace admin (voir `api/champions/index.php` :
  *« Aucune authentification n'est vérifiée à cette étape [...] ces
  trois méthodes d'écriture sont donc, pour l'instant, accessibles sans
  connexion »*).
- Le socle est en revanche déjà prêt à recevoir une vraie connexion,
  sans rien casser une fois câblé :
  - `SESSION_USER_KEY` (`config/environment.php`) : clé de session
    réservée à un utilisateur connecté ;
  - `regenerateSessionId()` / `maybeRegenerateUserSession()` /
    `destroySession()` (`config/session.php`) : régénération de session
    à la connexion, déconnexion propre ;
  - `csrfToken()` / `verifyCsrfToken()` (`config/security.php`) : jeton
    déjà généré et affiché dans le formulaire, prêt à être vérifié ;
  - `SECURITY_MAX_LOGIN_ATTEMPTS` (`config/environment.php`) :
    limitation du nombre de tentatives, pas encore appliquée ;
  - `PASSWORD_HASH_OPTIONS` (`config/security.php`) : options prêtes
    pour `password_hash()` / `password_verify()`.
- **Reste à faire avant toute mise en ligne publique de l'admin :** une
  table de comptes (admin dédiés, ou colonne de rôle sur une future
  table `users`), le traitement serveur du formulaire de connexion, une
  vérification de session sur chaque page/point d'entrée de `admin/`,
  et une vérification d'authentification sur les endpoints d'écriture
  de l'API. `admin/.htaccess` ne fait que définir le fichier d'index et
  désactiver le listing de répertoire — il ne protège l'accès à aucune
  page.

Même situation côté comptes publics : `pages/login.php`,
`pages/register.php` et `pages/profile.php` sont des formulaires
fonctionnels côté affichage/validation navigateur uniquement (aucune
table `users`, aucun traitement serveur — voir leurs docblocks
respectifs).

## Pages disponibles

| Page | Point d'entrée | Contenu |
|---|---|---|
| Tableau de bord | `admin/index.php` | Cartes de statistiques en lecture seule (une par ressource), peuplées via `assets/js/admin-dashboard.js` en interrogeant les API publiques (`/api/champions/`, `/api/items/`, `/api/builds/`, `/api/counters/`, `/api/runes/`, `/api/tier-list/`, `/api/news/`). Chaque carte gère son propre état : l'échec d'une ressource n'empêche pas l'affichage des autres |
| Connexion | `admin/login.php` | Formulaire (voir avertissement ci-dessus) |
| Champions | `admin/champions.php` | Liste + gestion (CRUD complet, voir ci-dessous) |
| Objets | `admin/items.php` | Liste + gestion (CRUD complet) |
| Builds | `admin/builds.php` | Liste + gestion (CRUD complet) |
| Runes | `admin/runes.php` | Liste + gestion (CRUD complet) |

Sur le tableau de bord, seules les cartes Champions, Objets, Builds et
Runes pointent vers une page de gestion : Matchups, Tier List et
Actualités n'ont pas encore de page d'administration dédiée (compteur
seul, sans lien).

## Gestion de contenu (CRUD)

Les pages Champions, Objets, Builds et Runes suivent toutes le même
principe : une liste (cartes du design system) + un formulaire unique,
masqué par défaut et affiché via un bouton « Ajouter », réutilisé à la
fois pour la création et la modification (pré-rempli si on édite une
entrée existante). Chaque carte propose modification et suppression
(`DELETE /api/<ressource>/?id=`).

| Ressource | Formulaire | Champs non couverts (à gérer séparément) |
|---|---|---|
| Champions | `#admin-champion-form` | Capacités (`champion_abilities`) |
| Objets | `#admin-item-form` | Recettes (`item_recipes`) |
| Builds | `#admin-build-form` (champion choisi via `<select>` peuplé dynamiquement) | Ordre de montée des sorts (`build_skill_order`) |
| Runes | `#admin-rune-form` | Association aux builds (`build_runes`) |

Toute la logique d'écriture passe par les endpoints API correspondants
(voir `docs/api.md`) — le formulaire admin ne fait qu'appeler l'API en
`fetch()`, il n'écrit jamais directement en base.

Ressources **sans page d'administration dédiée** à ce jour : Matchups &
counters, Tier List, Actualités (`news`), Capacités (`abilities`),
Arbres de runes (`rune-trees`), Synergies — leur contenu ne peut être
géré qu'en base directement (phpMyAdmin) ou, pour celles qui exposent
des méthodes d'écriture côté API, via des appels HTTP manuels.

## Recommandations avant mise en production

1. Ajouter une table de comptes administrateurs (ou une colonne de rôle
   sur une future table `users`) à `database/schema.sql`.
2. Câbler le traitement serveur de `admin/login.php` : vérification des
   identifiants (`password_verify()`, `PASSWORD_HASH_OPTIONS`),
   limitation des tentatives (`SECURITY_MAX_LOGIN_ATTEMPTS`), connexion
   effective (`SESSION_USER_KEY`, `regenerateSessionId()`).
3. Protéger chaque point d'entrée de `admin/` (vérifier la session admin
   en tête de fichier, avant `header.php`).
4. Vérifier cette même session côté API sur les méthodes
   `POST`/`PUT`/`DELETE` de `champions`, `items`, `runes`, `builds`
   (`ApiException::unauthorized()` / `forbidden()` sont déjà prêtes dans
   `api/core/exceptions.php`, mais non appelées à ce jour).
5. Vérifier le jeton CSRF (`verifyCsrfToken()`) à la soumission de
   chaque formulaire admin.
