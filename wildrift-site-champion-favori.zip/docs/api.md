# API REST

Toute l'API vit sous `api/`. Chaque ressource a un point d'entrée unique
`api/<ressource>/index.php`, différencié par la méthode HTTP et les
paramètres de requête (pas de segments d'URL type `/api/champions/5/` à
ce stade). Toutes les réponses sont en JSON (`Content-Type:
application/json; charset=utf-8`).

## Socle commun (`api/core/`)

Jamais appelé directement (protégé de l'accès direct), toujours inclus
via `require_once __DIR__ . '/../core/bootstrap.php';` en première ligne
de chaque `index.php` de ressource.

| Fichier | Rôle |
|---|---|
| `bootstrap.php` | Charge le bootstrap général du site puis le socle API (exceptions, réponses, validation, exécution, en-têtes) ; force `Content-Type: application/json` |
| `response.php` | `apiSuccess()` / `apiError()` — enveloppe JSON standard |
| `exceptions.php` | `ApiException` — code HTTP + code d'erreur machine-readable |
| `validator.php` | `apiRequireMethod()`, `apiGetJsonBody()`, `apiRequireFields()`, `apiValidateInt()`, `apiValidateString()`, `apiValidateEnum()` |
| `runner.php` | `apiRun()` — capture toute exception, ne laisse jamais fuiter de détail technique |
| `headers.php` | `sendApiHeaders()` — en-têtes adaptés au JSON (`X-Content-Type-Options: nosniff`, `Cache-Control: no-store`, `X-Robots-Tag: noindex`), à la place des en-têtes génériques HTML |

Chaque `index.php` de ressource enveloppe toute sa logique dans
`apiRun(function () { ... })` : aucune exception (validation, base de
données, ou imprévue) ne peut donc jamais atteindre le client sans être
transformée en réponse JSON standard.

## Enveloppe JSON

**Succès :**
```json
{ "success": true, "data": ..., "meta": { "...": "..." } }
```
`meta` est omis s'il est vide (ex. compteur de résultats, filtres
appliqués).

**Erreur :**
```json
{ "success": false, "error": { "code": "...", "message": "...", "details": {} } }
```
`details` est omis s'il est vide.

### Codes d'erreur (`ApiException`)

| HTTP | `code` | Cas |
|---|---|---|
| 400 | `bad_request` | Requête mal formée (JSON invalide, paramètre inattendu) |
| 422 | `validation_error` | Validation des données échouée (champ manquant, type/valeur invalide) |
| 401 | `unauthorized` | Authentification requise ou invalide (défini, non utilisé actuellement — voir `docs/administration.md`) |
| 403 | `forbidden` | Authentifié mais accès refusé (défini, non utilisé actuellement) |
| 404 | `not_found` | Ressource introuvable |
| 405 | `method_not_allowed` | Méthode HTTP non autorisée pour cet endpoint (en-tête `Allow` renvoyé) |
| 501 | `not_implemented` | Endpoint prévu mais pas encore développé |
| 500 | `internal_error` / `database_error` | Erreur serveur générique (jamais de détail technique) |

## Ressources et endpoints

Sauf mention contraire, `search`/filtres sont cumulables entre eux, et
`?id=` est prioritaire et exclusif pour la lecture d'une ressource
précise. Toutes les données transitent par PDO en requêtes préparées
(`repository.php` de chaque ressource) — jamais de SQL concaténé.

### `champions` — CRUD complet

| Méthode | URL | Effet |
|---|---|---|
| GET | `/api/champions/` | Liste complète |
| GET | `/api/champions/?id=5` | Détail par ID |
| GET | `/api/champions/?search=lee` | Recherche par nom (LIKE) |
| GET | `/api/champions/?role=jungle` | Filtre par rôle (`baron`/`jungle`/`mid`/`dragon`/`support`) |
| POST | `/api/champions/` | Création (corps JSON, voir ci-dessous) |
| PUT | `/api/champions/?id=5` | Modification complète (remplace tous les champs, pas de patch partiel) |
| DELETE | `/api/champions/?id=5` | Suppression (cascade sur capacités, builds, counters, tier list, synergies) |

Corps JSON POST/PUT — champs requis : `slug` (minuscules/chiffres/tirets,
unique), `name`, `role` (enum), `difficulty` (entier 1–5), `cc_level`,
`engage_level`, `disengage_level`, `early_game_level`, `late_game_level`
(chacun `faible`/`moyen`/`fort`) ; optionnels : `title`, `image_url`.

### `items` — CRUD complet

| Méthode | URL | Effet |
|---|---|---|
| GET | `/api/items/` | Liste complète |
| GET | `/api/items/?id=5` | Détail par ID |
| GET | `/api/items/?search=lame` | Recherche par nom |
| GET | `/api/items/?category=attack` | Filtre (`attack`/`magic`/`defense`/`boots`/`jungle`/`consumable`/`enchantment`) |
| POST / PUT / DELETE | `/api/items/` (+ `?id=`) | Création / modification / suppression |

### `runes` — CRUD complet

| Méthode | URL | Effet |
|---|---|---|
| GET | `/api/runes/` | Liste complète |
| GET | `/api/runes/?id=5` | Détail par ID |
| GET | `/api/runes/?search=comet` | Recherche par nom |
| GET | `/api/runes/?tree=precision` | Filtre par arbre (`precision`/`domination`/`sorcery`/`resolve`/`inspiration`) |
| GET | `/api/runes/?slot=keystone` | Filtre par emplacement (`keystone`/`minor`) |
| POST / PUT / DELETE | `/api/runes/` (+ `?id=`) | Création / modification / suppression |

### `rune-trees` — lecture seule

| Méthode | URL | Effet |
|---|---|---|
| GET | `/api/rune-trees/` | Les 5 arbres, triés par nom |
| GET | `/api/rune-trees/?id=5` | Un arbre par ID |

### `builds` — CRUD complet

| Méthode | URL | Effet |
|---|---|---|
| GET | `/api/builds/` | Liste complète |
| GET | `/api/builds/?id=5` | Détail complet (objets, runes, ordre de sorts) |
| GET | `/api/builds/?search=carry` | Recherche par nom |
| GET | `/api/builds/?champion=jinx` | Filtre par champion (slug) |
| GET | `/api/builds/?role=dragon` | Filtre par rôle |
| GET | `/api/builds/?patch=5.2` | Filtre par patch |
| GET | `/api/builds/?page=2` | Pagination |
| POST / PUT / DELETE | `/api/builds/` (+ `?id=`) | Création / modification / suppression |

### `counters` (Matchups & counters)

| Méthode | URL | Effet |
|---|---|---|
| GET | `/api/counters/` | Liste complète |
| GET | `/api/counters/?id=7` | Un matchup précis par ID |
| GET | `/api/counters/?champion_id=1` | Counters concernant le champion contré |
| GET | `/api/counters/?champion_id=1&counter_champion_id=2` | Matchup précis entre deux champions |

Chaque counter inclut ses objets recommandés (`counter_items`, jointe à
`items`), avec `situation` optionnelle par objet. Erreurs : 422 si un ID
est invalide ou si `counter_champion_id` est fourni sans `champion_id` ;
404 si un champion ou le matchup n'existe pas.

### `tier-list`

| Méthode | URL | Effet |
|---|---|---|
| GET | `/api/tier-list/` | Toute la tier list |
| GET | `/api/tier-list/?id=5` | Détail complet (notes, dates) |
| GET | `/api/tier-list/?champion=malphite` | Filtre par champion (slug) |
| GET | `/api/tier-list/?role=baron` | Filtre par rôle |
| GET | `/api/tier-list/?patch=5.2` | Filtre par patch |
| GET | `/api/tier-list/?tier=S` | Filtre par tier (`S+`/`S`/`A`/`B`/`C`/`D`) |
| GET | `/api/tier-list/?search=lee` | Recherche par nom de champion |

Triée par patch (le plus récent d'abord) puis par tier (`S+` en tête).

### `news` (actualités)

| Méthode | URL | Effet |
|---|---|---|
| GET | `/api/news/` | Actualités publiées |
| GET | `/api/news/?search=patch` | Recherche par titre |
| GET | `/api/news/?category=esport` | Filtre (`patch`/`esport`/`evenement`/`communaute`) |
| GET | `/api/news/?limit=3` | Les N plus récentes (1 à 20) |
| GET | `/api/news/?id=5` | Détail complet (corps, dates) |

Un article non publié (`published_at` vide) n'est jamais renvoyé, quel
que soit le filtre. Erreurs 422 : `id` non entier ≥ 1, `search` > 150
caractères, `category` hors énumération, `limit` hors 1–20.

### `abilities` — lecture seule

| Méthode | URL | Effet |
|---|---|---|
| GET | `/api/abilities/` | Toutes les capacités |
| GET | `/api/abilities/?id=5` | Détail complet |
| GET | `/api/abilities/?champion=ahri` | Filtre par champion (slug) |
| GET | `/api/abilities/?slot=r` | Filtre par emplacement (`passive`/`q`/`w`/`e`/`r`) |

Un slug de champion inconnu renvoie une liste vide (pas une erreur).

### `synergies` — lecture seule

| Méthode | URL | Effet |
|---|---|---|
| GET | `/api/synergies/` | Toutes les synergies |
| GET | `/api/synergies/?champion_id=1` | Synergies du champion consulté |
| GET | `/api/synergies/?champion_id=1&synergy_champion_id=2` | Synergie précise entre deux champions |

Pas de difficulté ni d'objets recommandés associés, contrairement à
`counters` : chaque synergie ne renvoie que son explication.

## Sécurité et authentification

**Aucune authentification n'est actuellement vérifiée sur les
méthodes d'écriture** (`POST`/`PUT`/`DELETE` de `champions`, `items`,
`runes`, `builds`) : elles sont accessibles sans connexion, au même
titre que le reste de l'espace `/admin`. Les codes 401/403
(`ApiException::unauthorized()` / `forbidden()`) existent dans le socle
mais ne sont déclenchés par aucun endpoint actuel. Voir
`docs/administration.md` pour l'état complet de ce chantier avant toute
mise en production.

## Statut général

`GET /api/` (routeur `api/index.php`) renvoie un statut général,
aiguillé vers `api/routes/status.php` — utile comme simple vérification
que l'API répond, indépendamment des ressources ci-dessus.
