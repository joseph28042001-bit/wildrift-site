# Structure du projet

Architecture PHP/MySQL classique, sans framework et sans build (pas de
Node.js, pas de Composer). Chaque point d'entrée public (`index.php`,
`champions.php`, etc.) reste volontairement fin : il initialise,
applique un layout, puis inclut le contenu réel depuis `pages/`.

```
wildrift-site/
├── index.php, champions.php, champion.php, items.php, item.php,
│   runes.php, rune.php, builds.php, build.php, counters.php,
│   matchup.php, tier-list.php, news.php, article.php, simulation.php,
│   login.php, register.php, logout.php, profile.php, styleguide.php
│                                  Points d'entrée publics — un fichier
│                                  par page, sans logique métier
│
├── pages/                        Contenu réel de chaque page publique
│   └── <même liste que ci-dessus, un fichier par page>
│
├── api/                           API REST (voir docs/api.md)
│   ├── index.php                  Statut général (aiguille vers api/routes/)
│   ├── routes/status.php          Route de statut
│   ├── core/                      Socle commun (bootstrap, réponses, erreurs,
│   │                              validation, exécution) — jamais appelé
│   │                              directement, protégé de l'accès direct
│   ├── champions/                 index.php (routage) + repository.php (PDO)
│   ├── items/                     idem
│   ├── runes/                     idem
│   ├── rune-trees/                idem (lecture seule)
│   ├── builds/                    idem
│   ├── counters/                  idem
│   ├── tier-list/                 idem
│   ├── news/                      idem
│   ├── abilities/                 idem (lecture seule)
│   └── synergies/                 idem (lecture seule)
│
├── admin/                         Espace d'administration (voir docs/administration.md)
│   ├── index.php                  Tableau de bord
│   ├── login.php                  Connexion admin (UI seule, non câblée)
│   ├── champions.php, items.php, builds.php, runes.php
│   │                              Points d'entrée de gestion (un par ressource CRUD)
│   ├── includes/                  bootstrap.php, header.php, footer.php (admin)
│   ├── pages/                     Contenu de chaque page admin
│   └── .htaccess                  DirectoryIndex + désactivation du listing
│
├── config/                        Configuration (voir docs/configuration.md)
│   ├── environment.php, app.php, site.php, session.php, security.php,
│   │   uploads.php, database.php, riot.php, wrchina.php
│   ├── config.local.php.example, database.local.php.example,
│   │   riot.local.php.example, wrchina.local.php.example
│   │                              Modèles non versionnés (secrets réels)
│   └── .htaccess                  Bloque tout accès HTTP direct au dossier
│
├── database/
│   ├── schema.sql                 Schéma complet + données de test (voir docs/mysql.md)
│   ├── migration_patches.sql      Migration : table `patches` (base déjà en place)
│   └── migration_patch_links.sql  Migration : colonne `patch_id` sur les données (rejouable)
│
├── includes/                      Composants et fonctions partagées
│   ├── bootstrap.php               Point d'entrée commun (inclus en tête de page)
│   ├── error_handler.php           Filet de sécurité global
│   ├── functions.php               Fonctions utilitaires (dont jsonResponse())
│   ├── patches.php                 Patchs : patch actif, recherche par version, rattachement patch_id
│   ├── components/                 header.php / footer.php (layout public)
│   ├── riot/                       Client API Riot, cache, repository (intégration externe)
│   └── wrchina/                    Client API WR China, importeur de patchs, repository
│
├── data/wrchina/                  Données importées côté WR China (patches.json) + .htaccess
│
├── assets/
│   ├── css/style.css               Design system "Hextech" (thème par défaut + "premium")
│   ├── js/                         Un script par page/fonctionnalité (voir docs/php.md)
│   └── images/
│
├── errors/                        403.php, 404.php, 500.php — pages d'erreur Apache,
│                                   volontairement autonomes (aucune dépendance à bootstrap.php)
│
├── deploy/
│   ├── build.sh                    Script de validation + empaquetage (pas de compilation)
│   └── dist/                       Archives générées par build.sh
│
├── tests/                         Scripts de test PHP autonomes (un par fonctionnalité API)
│
└── uploads/                       Fichiers uploadés (non versionné)
```

## Convention des points d'entrée

- **`index.php`** (racine, admin) : initialise, applique le layout,
  inclut une page — jamais de logique métier.
- **`pages/*.php`** et **`admin/pages/*.php`** : contenu HTML/PHP d'une
  page, un fichier par page.
- **`includes/components/*.php`** : éléments de layout réutilisables
  (header, footer).
- **`api/index.php`** : routeur du statut général uniquement.
- **`api/<ressource>/index.php`** : un point d'entrée REST par
  ressource. Commence toujours par
  `require_once __DIR__ . '/../core/bootstrap.php';` puis enveloppe sa
  logique dans `apiRun(function () { ... })` (voir `docs/api.md`).
- **`api/<ressource>/repository.php`** : tout l'accès aux données de la
  ressource (PDO, requêtes préparées) — jamais de SQL en dehors de ce
  fichier pour une ressource donnée.

## Protection au niveau serveur

Trois fichiers `.htaccess` sont présents dans cette archive :

| Fichier | Rôle |
|---|---|
| `admin/.htaccess` | Force `DirectoryIndex index.php` et désactive le listing de répertoire (`Options -Indexes`) |
| `config/.htaccess` | Bloque tout accès HTTP direct au dossier `config/` (`Require all denied` / `Deny from all` selon la version d'Apache) — ces fichiers contiennent les identifiants MySQL et ne doivent être chargés que côté serveur via `require_once` |
| `data/wrchina/.htaccess` | Protège les données importées de WR China d'un accès direct |

Un `.htaccess` racine (redirection HTTPS, pages d'erreur `ErrorDocument`,
en-têtes de sécurité globaux, blocage des fichiers `*.local.php`/`*.sql`/
`*.md`/`*.log`) est documenté dans le `README.md` du projet mais n'est
pas présent dans cet export du site : à recréer avant mise en production
si le dossier de déploiement ne le contient pas non plus.
