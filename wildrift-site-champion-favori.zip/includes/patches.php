<?php
/**
 * Patchs du jeu (table `patches`) : lecture et rattachement des données.
 * ------------------------------------------------------------
 * Toutes les requêtes passent par dbFetchOne()/dbFetchAll()/dbExecute()
 * (config/database.php) : requêtes préparées PDO, aucune valeur
 * concaténée dans le SQL. Ce fichier ne charge rien tout seul : il est
 * inclus à la demande (require_once) par le code qui en a besoin, comme
 * includes/riot/ et includes/wrchina/.
 *
 * Deux notions à ne pas confondre :
 *   - CURRENT_PATCH (config/patch.php) : version de référence du site,
 *     source unique pour l'affichage ;
 *   - la table `patches` : liste des versions connues, avec un patch
 *     actif (is_active = 1), et cible de la colonne `patch_id` des
 *     tables listées dans PATCH_LINKED_TABLES.
 *
 * Compatibilité : `patch_id` est ajoutée par
 * database/migration_patch_links.sql (ou la fin de schema.sql). Tant
 * que cette migration n'est pas importée, tableHasPatchLink() renvoie
 * false et linkRowToPatch() ne fait rien : le code déployé avant la
 * migration continue de fonctionner à l'identique.
 */

/**
 * Tables qui portent une colonne `patch_id` (clé étrangère vers
 * `patches`, NULL autorisé). Sert aussi de liste blanche : c'est la
 * seule source des noms de table acceptés par linkRowToPatch(), car un
 * nom de table ne peut pas être lié comme paramètre d'une requête
 * préparée.
 */
const PATCH_LINKED_TABLES = [
    'champions',
    'items',
    'runes',
    'builds',
    'tier_list',
    'counters',
    'synergies',
];

/**
 * Colonnes d'un patch lues dans `patches` (jamais SELECT *).
 */
const PATCH_SELECT_COLUMNS = 'id, version, is_active, release_date, description';

/**
 * Normalise une ligne brute de `patches` : id en entier, is_active en
 * booléen, les autres champs tels quels (release_date et description
 * restent null si non renseignés).
 */
function normalizePatchRow(array $row): array
{
    return [
        'id'           => (int) $row['id'],
        'version'      => (string) $row['version'],
        'is_active'    => (int) $row['is_active'] === 1,
        'release_date' => $row['release_date'],
        'description'  => $row['description'],
    ];
}

/**
 * Retourne tous les patchs, le patch actif en premier puis les plus
 * récemment créés.
 */
function findAllPatches(): array
{
    $rows = dbFetchAll(
        'SELECT ' . PATCH_SELECT_COLUMNS . '
         FROM patches
         ORDER BY is_active DESC, id DESC'
    );

    return array_map('normalizePatchRow', $rows);
}

/**
 * Retourne le patch actif, ou null si aucun n'est actif. Le site est
 * censé n'en avoir qu'un seul (voir docs/mysql.md, section `patches`) ;
 * s'il y en avait plusieurs par erreur, le plus récemment créé gagne.
 */
function findActivePatch(): ?array
{
    $row = dbFetchOne(
        'SELECT ' . PATCH_SELECT_COLUMNS . '
         FROM patches
         WHERE is_active = 1
         ORDER BY id DESC
         LIMIT 1'
    );

    return $row !== null ? normalizePatchRow($row) : null;
}

/**
 * Retourne le patch portant cette version (ex. "7.2e"), ou null s'il
 * n'existe pas. La comparaison suit la collation de la table
 * (utf8mb4_unicode_ci) : insensible à la casse.
 */
function findPatchByVersion(string $version): ?array
{
    $row = dbFetchOne(
        'SELECT ' . PATCH_SELECT_COLUMNS . '
         FROM patches
         WHERE version = :version',
        ['version' => $version]
    );

    return $row !== null ? normalizePatchRow($row) : null;
}

/**
 * Retourne le patch portant cet ID, ou null s'il n'existe pas — utilisé
 * par l'espace admin (api/patches/) pour le détail, la modification et
 * l'activation/désactivation d'un patch précis.
 */
function findPatchById(int $id): ?array
{
    $row = dbFetchOne(
        'SELECT ' . PATCH_SELECT_COLUMNS . '
         FROM patches
         WHERE id = :id',
        ['id' => $id]
    );

    return $row !== null ? normalizePatchRow($row) : null;
}

/**
 * Retourne l'identifiant du patch portant cette version, ou null s'il
 * n'existe pas.
 */
function findPatchIdByVersion(string $version): ?int
{
    $patch = findPatchByVersion($version);

    return $patch !== null ? $patch['id'] : null;
}

/**
 * Indique si la table donnée possède bien la colonne `patch_id`
 * (c'est-à-dire si database/migration_patch_links.sql a été importée).
 * Le résultat est mémorisé pour la durée de la requête. Renvoie false
 * pour un nom de table hors de PATCH_LINKED_TABLES, et aussi si la
 * vérification elle-même échoue (l'erreur est déjà journalisée par
 * dbQuery()) : ne pas pouvoir la faire ne doit jamais bloquer le
 * code appelant.
 */
function tableHasPatchLink(string $table): bool
{
    static $cache = [];

    if (!in_array($table, PATCH_LINKED_TABLES, true)) {
        return false;
    }

    if (!array_key_exists($table, $cache)) {
        try {
            $row = dbFetchOne(
                "SELECT COUNT(*) AS total
                 FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = :table
                   AND COLUMN_NAME = 'patch_id'",
                ['table' => $table]
            );
            $cache[$table] = $row !== null && (int) $row['total'] > 0;
        } catch (DatabaseException $e) {
            return false;
        }
    }

    return $cache[$table];
}

/**
 * Rattache une ligne à un patch : renseigne sa colonne `patch_id` à
 * partir d'une version (ex. "7.2e"). Si la version est null ou ne
 * correspond à aucun patch de la table `patches`, `patch_id` est remis
 * à NULL (aucun patch n'est créé implicitement : une faute de frappe
 * ne doit pas polluer la liste des patchs ; migration_patch_links.sql
 * enregistre les versions manquantes à partir des données).
 *
 * Ne fait rien, et renvoie false, si la table n'est pas dans
 * PATCH_LINKED_TABLES, si la migration n'est pas encore importée, ou si
 * l'écriture échoue : le rattachement est un complément, il ne doit
 * jamais faire échouer l'opération principale de l'appelant.
 * Renvoie true si la colonne a été écrite.
 */
function linkRowToPatch(string $table, int $id, ?string $version): bool
{
    if (!tableHasPatchLink($table)) {
        return false;
    }

    try {
        $patchId = $version !== null ? findPatchIdByVersion($version) : null;

        // $table provient de PATCH_LINKED_TABLES (vérifié ci-dessus par
        // tableHasPatchLink()) : jamais d'une valeur utilisateur.
        dbExecute(
            'UPDATE ' . $table . ' SET patch_id = :patch_id WHERE id = :id',
            ['patch_id' => $patchId, 'id' => $id]
        );
    } catch (DatabaseException $e) {
        return false;
    }

    return true;
}

/**
 * ------------------------------------------------------------
 * Gestion des patchs (espace admin) : création, modification,
 * activation/désactivation — voir admin/pages/patches.php et
 * assets/js/admin-patches.js pour l'interface, api/patches/index.php
 * et api/patches/repository.php pour l'endpoint qui appelle ces
 * fonctions. $data est toujours supposé déjà validé par l'appelant
 * (voir validatePatchPayload(), api/patches/index.php).
 * ------------------------------------------------------------
 */

/**
 * Insère un nouveau patch et retourne son ID généré. Un patch nouvellement
 * créé est toujours inactif (is_active = 0) : l'activer est une action
 * distincte et explicite (voir setPatchActiveState()), pour ne jamais
 * changer le patch actif du site par effet de bord d'une simple création.
 * $data attend les clés 'version', 'release_date' (nullable) et
 * 'description' (nullable).
 */
function insertPatch(array $data): int
{
    dbExecute(
        'INSERT INTO patches (version, is_active, release_date, description)
         VALUES (:version, 0, :release_date, :description)',
        [
            'version'      => $data['version'],
            'release_date' => $data['release_date'],
            'description'  => $data['description'],
        ]
    );

    return (int) dbLastInsertId();
}

/**
 * Met à jour les informations d'un patch existant (version, date de
 * sortie, description). Ne touche jamais à is_active : l'activation/
 * désactivation passe exclusivement par setPatchActiveState() ci-dessous,
 * pour que le site n'ait jamais plus d'un patch actif par accident.
 * L'existence de $id est supposée déjà vérifiée par l'appelant (voir
 * api/patches/index.php).
 */
function updatePatch(int $id, array $data): void
{
    dbExecute(
        'UPDATE patches SET
            version = :version,
            release_date = :release_date,
            description = :description
        WHERE id = :id',
        [
            'id'           => $id,
            'version'      => $data['version'],
            'release_date' => $data['release_date'],
            'description'  => $data['description'],
        ]
    );
}

/**
 * Active ou désactive un patch.
 *
 * - Activer ($active = true) : bascule transactionnelle — désactive
 *   d'abord tout patch actuellement actif, puis active celui-ci. Le
 *   site n'a donc jamais plus d'un patch actif à la fois (voir
 *   docs/mysql.md, section `patches`), sans dépendre d'une contrainte
 *   MySQL. Réactiver le patch déjà actif ne fait rien d'anormal (la
 *   transaction le désactive puis le réactive, résultat identique).
 * - Désactiver ($active = false) : ne touche que ce patch (is_active
 *   mis à 0), sans en activer un autre à sa place — laisser le site
 *   temporairement sans patch actif est une décision de
 *   l'administrateur, pas une erreur à corriger automatiquement ici.
 *
 * L'existence de $id est supposée déjà vérifiée par l'appelant (voir
 * api/patches/index.php).
 */
function setPatchActiveState(int $id, bool $active): void
{
    if (!$active) {
        dbExecute('UPDATE patches SET is_active = 0 WHERE id = :id', ['id' => $id]);
        return;
    }

    $connection = getDbConnection();
    $connection->beginTransaction();

    try {
        dbExecute('UPDATE patches SET is_active = 0 WHERE is_active = 1');
        dbExecute('UPDATE patches SET is_active = 1 WHERE id = :id', ['id' => $id]);
        $connection->commit();
    } catch (DatabaseException $e) {
        $connection->rollBack();
        throw $e;
    }
}
