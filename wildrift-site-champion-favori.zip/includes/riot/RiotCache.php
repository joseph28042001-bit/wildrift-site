<?php
/**
 * Cache disque pour les données Riot (étape 21.6 : système de cache).
 * ---------------------------------------------------------------
 * Data Dragon est un CDN public, mais rien n'empêche ce site d'appeler
 * RiotApiClient bien plus souvent que les données n'évoluent réellement
 * (un patch ne change pas plusieurs fois par heure). Ce cache évite de
 * refaire un appel réseau à chaque requête : chaque réponse JSON reçue
 * avec succès est stockée sur disque, un fichier par clé (généralement
 * l'URL Data Dragon interrogée), avec un horodatage. Un fichier plus
 * vieux que sa durée de vie (RIOT_API_CACHE_TTL_MINUTES par défaut) est
 * considéré comme expiré et ignoré ; une nouvelle requête réseau est
 * alors faite, et son résultat réécrit le fichier.
 *
 * Volontairement simple (fichiers JSON, pas de dépendance externe) :
 * suffisant pour un CDN en lecture seule, sans les soucis
 * d'invalidation d'un cache partagé entre plusieurs types de données
 * mutables. Cette classe n'a aucune connaissance du contenu qu'elle
 * stocke : elle sait seulement mettre en cache un tableau associatif
 * sous une clé donnée, et le relire tant qu'il n'a pas expiré.
 *
 * Un souci de cache (répertoire non accessible en écriture, fichier
 * corrompu...) ne doit jamais empêcher une vraie requête réseau de se
 * faire : get() renvoie simplement null, set() échoue silencieusement.
 */

class RiotCache
{
    private string $directory;
    private int $ttlSeconds;

    public function __construct(?string $directory = null, ?int $ttlMinutes = null)
    {
        $this->directory = $directory ?? (defined('RIOT_CACHE_PATH') ? RIOT_CACHE_PATH : sys_get_temp_dir() . '/riot-cache');
        $resolvedTtlMinutes = $ttlMinutes ?? (defined('RIOT_API_CACHE_TTL_MINUTES') ? RIOT_API_CACHE_TTL_MINUTES : 60);
        $this->ttlSeconds = max(0, $resolvedTtlMinutes) * 60;
    }

    /**
     * Retourne la valeur en cache pour $key, ou null si elle est
     * absente, expirée, ou illisible (fichier corrompu, JSON invalide).
     */
    public function get(string $key): ?array
    {
        $path = $this->pathFor($key);

        if (!is_file($path)) {
            return null;
        }

        $modifiedAt = filemtime($path);
        if ($modifiedAt === false || (time() - $modifiedAt) > $this->ttlSeconds) {
            return null;
        }

        $contents = @file_get_contents($path);
        if ($contents === false) {
            return null;
        }

        $decoded = json_decode($contents, true);

        return is_array($decoded) ? $decoded : null;
    }

    /**
     * Enregistre $value en cache sous $key. Crée le répertoire de cache
     * s'il n'existe pas encore. N'échoue jamais bruyamment : si le
     * répertoire ne peut pas être créé ou n'est pas accessible en
     * écriture (ex. environnement en lecture seule), la donnée n'est
     * simplement pas mise en cache — le site continue de fonctionner en
     * interrogeant Data Dragon à chaque appel.
     */
    public function set(string $key, array $value): void
    {
        if (!is_dir($this->directory)) {
            @mkdir($this->directory, 0775, true);
        }

        if (!is_dir($this->directory) || !is_writable($this->directory)) {
            return;
        }

        $encoded = json_encode($value, JSON_UNESCAPED_UNICODE);
        if ($encoded === false) {
            return;
        }

        @file_put_contents($this->pathFor($key), $encoded);
    }

    /**
     * Supprime l'entrée en cache pour $key, si elle existe. Utile pour
     * forcer un rafraîchissement avant l'expiration naturelle du cache.
     */
    public function forget(string $key): void
    {
        $path = $this->pathFor($key);
        if (is_file($path)) {
            @unlink($path);
        }
    }

    /**
     * Chemin du fichier de cache pour une clé donnée. La clé (souvent
     * une URL Data Dragon, potentiellement longue) est hachée pour
     * obtenir un nom de fichier sûr et de longueur fixe.
     */
    private function pathFor(string $key): string
    {
        return rtrim($this->directory, '/') . '/' . sha1($key) . '.json';
    }
}
