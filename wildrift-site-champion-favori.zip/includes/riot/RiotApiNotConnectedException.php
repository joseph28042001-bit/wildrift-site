<?php
/**
 * Levée par RiotApiClient tant qu'une ressource donnée n'est pas
 * connectée à une vraie source de données (voir étape 21.1 :
 * architecture uniquement). Depuis l'étape 21.3 (champions) et
 * l'étape 21.4 (objets/items), seules fetchChampion(), fetchItem()
 * et fetchResourceList('champion'|'item') sont réellement implémentées
 * (via Data Dragon) ; tout le reste — y compris un appel à ces
 * méthodes tant qu'aucune clé Riot n'est configurée — lève encore
 * cette exception. Le message précise la méthode appelée, pour
 * distinguer un appel prématuré d'une vraie erreur une fois la
 * connexion en place.
 */
class RiotApiNotConnectedException extends RuntimeException
{
    public function __construct(string $method)
    {
        parent::__construct(
            "RiotApiClient::{$method}() n'est pas connecté à une source de données Riot pour cette ressource " .
            "(seules les données de champions et d'objets sont récupérées à ce stade, et seulement si une clé Riot est configurée — voir étapes 21.3 et 21.4)."
        );
    }
}
