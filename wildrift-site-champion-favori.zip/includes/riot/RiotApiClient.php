<?php
/**
 * Client Riot (étape 21.1 : squelette d'architecture ; étape 21.3 :
 * connexion réelle pour les données de champions ; étape 21.4 :
 * connexion réelle pour les données d'objets/items ; étape 21.5 :
 * gestion des erreurs Riot ; étape 21.6 : système de cache).
 * ---------------------------------------------------------------
 * fetchChampion(), fetchItem() et fetchResourceList('champion'|'item', ...)
 * appellent réellement Data Dragon (RIOT_DDRAGON_BASE_URL) — le CDN
 * statique et public de Riot destiné aux fan sites, qui ne nécessite
 * AUCUNE clé d'API. C'est la seule source de données de champions et
 * d'objets "autorisée" pour ce projet : les endpoints de l'API Riot
 * authentifiée (RIOT_API_BASE_URL) portent sur des données de
 * compte/partie et nécessitent, pour la plupart, une clé de production
 * que Riot n'a pas approuvée ici — ils restent donc hors périmètre.
 *
 * Ces méthodes exigent tout de même isRiotApiConfigured() (une clé
 * renseignée dans riot.local.php), non pas parce que Data Dragon en a
 * besoin, mais comme interrupteur global : tant qu'aucune clé n'est
 * configurée, aucune fonctionnalité Riot ne s'active sur ce site (voir
 * config/riot.php).
 *
 * Les autres types de ressources ne sont pas concernés par cette
 * étape : ils lèvent toujours RiotApiNotConnectedException, exactement
 * comme à l'étape 21.1.
 *
 * Gestion des erreurs (étape 21.5) : chaque échec réel d'appel réseau
 * (timeout, erreur de connexion, code HTTP inattendu, JSON invalide,
 * ressource absente de la réponse) est à la fois journalisé via
 * error_log() — sous le préfixe "[Riot]", jamais avec RIOT_API_KEY,
 * qui n'est de toute façon pas utilisée par Data Dragon — et signalé à
 * l'appelant via une RiotApiRequestException au message précis. Ce
 * client ne fait par contre aucune nouvelle tentative automatique
 * (pas de retry) : c'est à l'appelant de décider s'il retente l'appel.
 *
 * Cache (étape 21.6) : httpGetJson() est l'unique point de passage
 * réseau de ce client (fetchChampion(), fetchItem(), fetchResourceList()
 * et fetchLatestVersion() y passent toutes) ; le cache (RiotCache) y
 * est donc branché une seule fois, par URL complète, pour couvrir
 * toutes ces méthodes sans dupliquer la logique. Durée de vie : voir
 * RIOT_API_CACHE_TTL_MINUTES. Seules les réponses obtenues avec succès
 * sont mises en cache — jamais une erreur.
 */

require_once __DIR__ . '/RiotApiNotConnectedException.php';
require_once __DIR__ . '/RiotApiRequestException.php';
require_once __DIR__ . '/RiotCache.php';

class RiotApiClient
{
    private string $baseUrl;
    private string $apiKey;
    private string $region;
    private int $timeoutSeconds;
    private string $ddragonBaseUrl;
    private string $ddragonLocale;
    private RiotCache $cache;

    public function __construct(
        ?string $baseUrl = null,
        ?string $apiKey = null,
        ?string $region = null,
        ?int $timeoutSeconds = null,
        ?string $ddragonBaseUrl = null,
        ?string $ddragonLocale = null,
        ?RiotCache $cache = null
    ) {
        $this->baseUrl = $baseUrl ?? (defined('RIOT_API_BASE_URL') ? RIOT_API_BASE_URL : '');
        $this->apiKey = $apiKey ?? (defined('RIOT_API_KEY') ? RIOT_API_KEY : '');
        $this->region = $region ?? (defined('RIOT_API_REGION') ? RIOT_API_REGION : '');
        $this->timeoutSeconds = $timeoutSeconds ?? (defined('RIOT_API_TIMEOUT_SECONDS') ? RIOT_API_TIMEOUT_SECONDS : 10);
        $this->ddragonBaseUrl = $ddragonBaseUrl ?? (defined('RIOT_DDRAGON_BASE_URL') ? RIOT_DDRAGON_BASE_URL : 'https://ddragon.leagueoflegends.com');
        $this->ddragonLocale = $ddragonLocale ?? (defined('RIOT_DDRAGON_LOCALE') ? RIOT_DDRAGON_LOCALE : 'fr_FR');
        $this->cache = $cache ?? new RiotCache();
    }

    /**
     * Récupère les données brutes d'un champion depuis Data Dragon
     * (nom, titre, lore, sorts, statistiques de base...), dans la
     * langue RIOT_DDRAGON_LOCALE, pour la dernière version publiée.
     *
     * @param string $riotChampionId Identifiant Data Dragon du champion
     *                                (ex. 'Aatrox', 'MonkeyKing' pour Wukong)
     * @throws RiotApiNotConnectedException si aucune clé n'est configurée
     * @throws RiotApiRequestException si la requête échoue ou si le
     *                                  champion demandé n'existe pas
     */
    public function fetchChampion(string $riotChampionId): array
    {
        $this->assertConfigured(__FUNCTION__);

        $version = $this->fetchLatestVersion();
        $url = sprintf(
            '%s/cdn/%s/data/%s/champion/%s.json',
            $this->ddragonBaseUrl,
            $version,
            $this->ddragonLocale,
            rawurlencode($riotChampionId)
        );

        $json = $this->httpGetJson($url);

        if (!isset($json['data'][$riotChampionId])) {
            $message = "Champion Riot '{$riotChampionId}' introuvable dans Data Dragon (version {$version}).";
            $this->logRiotError('fetchChampion', $message);
            throw new RiotApiRequestException($message);
        }

        return $json['data'][$riotChampionId];
    }

    /**
     * Récupère les données brutes d'un objet depuis Data Dragon (nom,
     * description, statistiques, prix, recette...), dans la langue
     * RIOT_DDRAGON_LOCALE, pour la dernière version publiée.
     *
     * Contrairement aux champions, Data Dragon ne fournit pas un
     * fichier JSON par objet : tous les objets d'un patch sont
     * regroupés dans un seul fichier item.json (voir
     * fetchResourceList()). On récupère donc ce fichier complet et on
     * en extrait l'objet demandé.
     *
     * @param string $riotItemId Identifiant Data Dragon de l'objet
     *                            (ex. '1001' pour les Bottes)
     * @throws RiotApiNotConnectedException si aucune clé n'est configurée
     * @throws RiotApiRequestException si la requête échoue ou si l'objet
     *                                  demandé n'existe pas
     */
    public function fetchItem(string $riotItemId): array
    {
        $this->assertConfigured(__FUNCTION__);

        $items = $this->fetchResourceList('item');

        if (!isset($items[$riotItemId])) {
            $message = "Objet Riot '{$riotItemId}' introuvable dans Data Dragon.";
            $this->logRiotError('fetchItem', $message);
            throw new RiotApiRequestException($message);
        }

        return $items[$riotItemId];
    }

    /**
     * Récupère la liste brute des ressources publiées sur Data Dragon
     * pour un patch donné. Sans $patch, utilise la dernière version
     * publiée.
     *
     * - 'champion' : résumé par champion (nom, titre, tags,
     *   statistiques de base — pas le détail des sorts, voir
     *   fetchChampion() pour cela).
     * - 'item' : détail complet par objet (nom, description,
     *   statistiques, prix, recette...), Data Dragon ne proposant pas
     *   de résumé séparé pour les objets.
     *
     * Seuls $resourceType === 'champion' et 'item' sont implémentés :
     * tout autre type de ressource lève RiotApiNotConnectedException,
     * comme à l'étape 21.1.
     *
     * @return array Tableau associatif [identifiant Data Dragon => données]
     * @throws RiotApiNotConnectedException si aucune clé n'est configurée,
     *                                       ou si $resourceType n'est ni
     *                                       'champion' ni 'item'
     * @throws RiotApiRequestException si la requête échoue
     */
    public function fetchResourceList(string $resourceType, ?string $patch = null): array
    {
        if ($resourceType !== 'champion' && $resourceType !== 'item') {
            throw new RiotApiNotConnectedException('fetchResourceList');
        }

        $this->assertConfigured(__FUNCTION__);

        $version = $patch ?? $this->fetchLatestVersion();
        $fileName = $resourceType === 'champion' ? 'champion.json' : 'item.json';
        $url = sprintf(
            '%s/cdn/%s/data/%s/%s',
            $this->ddragonBaseUrl,
            $version,
            $this->ddragonLocale,
            $fileName
        );

        $json = $this->httpGetJson($url);

        return $json['data'] ?? [];
    }

    /**
     * Refuse d'appeler Data Dragon tant qu'aucune clé Riot n'est
     * configurée (interrupteur global, voir isRiotApiConfigured() dans
     * config/riot.php) — même si Data Dragon lui-même n'en a pas besoin.
     */
    private function assertConfigured(string $method): void
    {
        if (!function_exists('isRiotApiConfigured') || !isRiotApiConfigured()) {
            throw new RiotApiNotConnectedException($method);
        }
    }

    /**
     * Résout la dernière version publiée sur Data Dragon (ex. "14.18.1"),
     * utilisée quand aucun patch précis n'est demandé.
     */
    private function fetchLatestVersion(): string
    {
        $versions = $this->httpGetJson($this->ddragonBaseUrl . '/api/versions.json');

        if (!is_array($versions) || !isset($versions[0]) || !is_string($versions[0])) {
            $message = 'Réponse inattendue de Data Dragon pour la liste des versions.';
            $this->logRiotError('fetchLatestVersion', $message);
            throw new RiotApiRequestException($message);
        }

        return $versions[0];
    }

    /**
     * Effectue une requête HTTP GET vers une URL publique de Data
     * Dragon et retourne son corps décodé en JSON (tableau associatif).
     * Ne transmet jamais RIOT_API_KEY (inutile pour ce CDN public).
     *
     * Vérifie d'abord le cache (voir RiotCache) : si une réponse valide
     * et non expirée existe déjà pour cette URL, elle est retournée
     * directement, sans requête réseau. Sinon, la requête est faite
     * normalement et, en cas de succès, son résultat est mis en cache
     * avant d'être retourné (jamais en cas d'échec).
     *
     * Distingue, pour un message d'erreur plus utile, le dépassement de
     * délai (le service met trop de temps à répondre) des autres échecs
     * réseau (DNS, connexion refusée...), ainsi qu'un code HTTP 404
     * (ressource absente, ex. mauvaise version de patch) des autres
     * codes inattendus (ex. 5xx : service Data Dragon indisponible).
     * Chaque échec est journalisé via logRiotError() avant d'être levé.
     *
     * @throws RiotApiRequestException en cas d'échec réseau, de code
     *                                  HTTP inattendu ou de JSON invalide
     */
    private function httpGetJson(string $url): array
    {
        $cached = $this->cache->get($url);
        if ($cached !== null) {
            return $cached;
        }

        $handle = curl_init($url);
        if ($handle === false) {
            $message = "Impossible d'initialiser la requête HTTP vers Data Dragon.";
            $this->logRiotError('httpGetJson', "{$message} (URL : {$url})");
            throw new RiotApiRequestException($message);
        }

        curl_setopt_array($handle, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => $this->timeoutSeconds,
            CURLOPT_HTTPGET => true,
            CURLOPT_HTTPHEADER => ['Accept: application/json'],
        ]);

        $body = curl_exec($handle);
        $errorNumber = curl_errno($handle);
        $errorMessage = curl_error($handle);
        $statusCode = (int) curl_getinfo($handle, CURLINFO_HTTP_CODE);
        curl_close($handle);

        if ($errorNumber !== 0) {
            $message = $errorNumber === CURLE_OPERATION_TIMEDOUT
                ? "Délai d'attente dépassé en contactant Data Dragon (plus de {$this->timeoutSeconds}s)."
                : "Échec de la requête vers Data Dragon : {$errorMessage}";
            $this->logRiotError('httpGetJson', "{$message} (URL : {$url})");
            throw new RiotApiRequestException($message);
        }

        if ($statusCode !== 200) {
            $message = $statusCode === 404
                ? "Data Dragon indique que la ressource demandée n'existe pas (404) pour {$url}."
                : "Data Dragon a répondu avec le code HTTP {$statusCode} pour {$url}.";
            $this->logRiotError('httpGetJson', $message);
            throw new RiotApiRequestException($message);
        }

        $decoded = json_decode((string) $body, true);
        if (!is_array($decoded)) {
            $message = 'Réponse de Data Dragon invalide : JSON illisible.';
            $this->logRiotError('httpGetJson', "{$message} (URL : {$url})");
            throw new RiotApiRequestException($message);
        }

        $this->cache->set($url, $decoded);

        return $decoded;
    }

    /**
     * Journalise un échec réel d'appel Riot/Data Dragon, via error_log()
     * (même canal que le gestionnaire d'erreurs global, voir
     * includes/error_handler.php), sous un préfixe dédié "[Riot]" pour
     * les distinguer facilement dans les logs serveur. Ne journalise
     * jamais RIOT_API_KEY ni aucun secret : uniquement le nom de la
     * méthode d'origine et un message d'erreur déjà "propre" (URL
     * publique et nature de l'échec, jamais de donnée sensible).
     *
     * N'est appelée que pour de vrais échecs (RiotApiRequestException) :
     * un appel bloqué par isRiotApiConfigured() (RiotApiNotConnectedException)
     * n'est pas une erreur Riot à proprement parler — c'est une
     * fonctionnalité désactivée — et n'est donc pas journalisé ici.
     */
    private function logRiotError(string $method, string $message): void
    {
        error_log("[Riot] RiotApiClient::{$method}() : {$message}");
    }
}
