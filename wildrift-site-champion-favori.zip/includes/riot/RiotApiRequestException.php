<?php
/**
 * Levée par RiotApiClient quand une requête HTTP vers Data Dragon
 * échoue réellement : problème réseau, code HTTP inattendu, réponse
 * JSON invalide, ou ressource demandée absente de la réponse (ex.
 * identifiant de champion inconnu).
 *
 * Différent de RiotApiNotConnectedException : cette dernière signale
 * une méthode pas encore implémentée, alors que celle-ci signale
 * l'échec d'un appel qui, lui, est bien implémenté. Le message ne
 * contient jamais RIOT_API_KEY (Data Dragon n'en utilise d'ailleurs
 * aucune), uniquement l'URL publique appelée et la nature de l'échec.
 *
 * Depuis l'étape 21.5, chaque fois que RiotApiClient lève cette
 * exception, il journalise d'abord le même message via error_log()
 * sous le préfixe "[Riot]" (voir RiotApiClient::logRiotError()) : le
 * détail reste donc disponible côté serveur même si l'appelant se
 * contente d'un catch générique ou laisse l'exception remonter jusqu'au
 * gestionnaire global (includes/error_handler.php), qui n'affichera
 * de toute façon qu'un message générique au visiteur.
 */
class RiotApiRequestException extends RuntimeException
{
}
