<?php
/**
 * Couche de stockage des données Riot (étape 21.1 : architecture de
 * réception uniquement). Ces fonctions ne font aucun appel à l'API
 * Riot : elles savent seulement enregistrer, en base, une donnée déjà
 * reçue (payload) et le résultat d'une tentative de synchronisation.
 * Utilise les mêmes helpers PDO que le reste du projet (dbExecute,
 * dbFetchAll, dbFetchOne — voir config/database.php).
 *
 * Le rapprochement de ces données brutes avec les tables métier
 * (champions, items...) fera l'objet d'une étape ultérieure.
 */

/**
 * Enregistre un payload brut reçu depuis Riot (table riot_raw_payloads).
 * Retourne l'identifiant de la ligne créée.
 *
 * @param string      $resourceType Type de ressource (ex. 'champion', 'item')
 * @param string|null $externalId   Identifiant Riot de la ressource, si connu
 * @param string|null $patch        Version/patch concerné, si connu
 * @param array       $payload      Donnée brute reçue, sera stockée en JSON
 */
function storeRiotRawPayload(
    string $resourceType,
    ?string $externalId,
    ?string $patch,
    array $payload
): int {
    dbExecute(
        'INSERT INTO riot_raw_payloads (resource_type, external_id, patch, payload, fetched_at)
         VALUES (:resource_type, :external_id, :patch, :payload, NOW())',
        [
            'resource_type' => $resourceType,
            'external_id' => $externalId,
            'patch' => $patch,
            'payload' => json_encode($payload, JSON_UNESCAPED_UNICODE),
        ]
    );

    return (int) dbLastInsertId();
}

/**
 * Retourne les payloads bruts reçus pour un type de ressource donné,
 * les plus récents en premier. Pure lecture, ne déclenche aucun appel
 * à l'API Riot.
 */
function findRiotRawPayloads(string $resourceType, int $limit = 50): array
{
    return dbFetchAll(
        'SELECT * FROM riot_raw_payloads
         WHERE resource_type = :resource_type
         ORDER BY fetched_at DESC, id DESC
         LIMIT :limit',
        ['resource_type' => $resourceType, 'limit' => $limit]
    );
}

/**
 * Ouvre une nouvelle entrée de journal de synchronisation (statut
 * 'running') pour un type de ressource donné. Retourne l'identifiant
 * de la ligne créée, à réutiliser avec finishRiotSyncLog().
 */
function startRiotSyncLog(string $resourceType): int
{
    dbExecute(
        "INSERT INTO riot_sync_log (resource_type, status, started_at)
         VALUES (:resource_type, 'running', NOW())",
        ['resource_type' => $resourceType]
    );

    return (int) dbLastInsertId();
}

/**
 * Clôture une entrée de journal de synchronisation avec son statut
 * final ('success' ou 'failed') et un message optionnel.
 */
function finishRiotSyncLog(int $syncLogId, string $status, ?string $message = null): void
{
    dbExecute(
        'UPDATE riot_sync_log
         SET status = :status, message = :message, finished_at = NOW()
         WHERE id = :id',
        ['status' => $status, 'message' => $message, 'id' => $syncLogId]
    );
}

/**
 * Retourne les dernières entrées du journal de synchronisation pour un
 * type de ressource donné, les plus récentes en premier.
 */
function findRiotSyncLog(string $resourceType, int $limit = 20): array
{
    return dbFetchAll(
        'SELECT * FROM riot_sync_log
         WHERE resource_type = :resource_type
         ORDER BY created_at DESC, id DESC
         LIMIT :limit',
        ['resource_type' => $resourceType, 'limit' => $limit]
    );
}
