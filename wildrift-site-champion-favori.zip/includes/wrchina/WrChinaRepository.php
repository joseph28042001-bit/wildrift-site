<?php
/**
 * Couche de stockage des données WRChina.gg (étape 22.1 : architecture
 * de réception uniquement, exactement comme includes/riot/RiotRepository.php
 * à l'étape 21.1 ; étape 22.2 : fonctions d'import des patchs, voir
 * plus bas). Utilise les mêmes helpers PDO que le reste du projet
 * (dbExecute, dbFetchAll, dbFetchOne — voir config/database.php),
 * toujours en requêtes préparées.
 *
 * Le rapprochement des payloads bruts (wrchina_raw_payloads) avec les
 * tables métier comme tier_list fera l'objet d'une étape ultérieure.
 * Les patchs (wrchina_patches, étape 22.2) suivent un circuit distinct
 * et déjà structuré — voir importWrChinaPatch() plus bas et
 * includes/wrchina/WrChinaPatchImporter.php.
 */

/**
 * Enregistre un payload brut reçu depuis WRChina.gg (table
 * wrchina_raw_payloads). Retourne l'identifiant de la ligne créée.
 *
 * @param string      $resourceType Type de ressource (ex. 'tier-list', 'builds')
 * @param string|null $externalId   Identifiant WRChina.gg de la ressource, si connu
 * @param string|null $patch        Version/patch concerné, si connu
 * @param array       $payload      Donnée brute reçue, sera stockée en JSON
 */
function storeWrChinaRawPayload(
    string $resourceType,
    ?string $externalId,
    ?string $patch,
    array $payload
): int {
    dbExecute(
        'INSERT INTO wrchina_raw_payloads (resource_type, external_id, patch, payload, fetched_at)
         VALUES (:resource_type, :external_id, :patch, :payload, NOW())',
        [
            'resource_type' => $resourceType,
            'external_id' => $externalId,
            'patch' => $patch,
            'payload' => json_encode($payload, JSON_UNESCAPED_UNICODE),
        ]
    );

    return (int) dbLastInsertId();
}

/**
 * Retourne les payloads bruts reçus pour un type de ressource donné,
 * les plus récents en premier. Pure lecture, ne déclenche aucun appel
 * vers WRChina.gg.
 */
function findWrChinaRawPayloads(string $resourceType, int $limit = 50): array
{
    return dbFetchAll(
        'SELECT * FROM wrchina_raw_payloads
         WHERE resource_type = :resource_type
         ORDER BY fetched_at DESC, id DESC
         LIMIT :limit',
        ['resource_type' => $resourceType, 'limit' => $limit]
    );
}

/**
 * Ouvre une nouvelle entrée de journal de synchronisation (statut
 * 'running') pour un type de ressource donné. Retourne l'identifiant
 * de la ligne créée, à réutiliser avec finishWrChinaSyncLog().
 */
function startWrChinaSyncLog(string $resourceType): int
{
    dbExecute(
        "INSERT INTO wrchina_sync_log (resource_type, status, started_at)
         VALUES (:resource_type, 'running', NOW())",
        ['resource_type' => $resourceType]
    );

    return (int) dbLastInsertId();
}

/**
 * Clôture une entrée de journal de synchronisation avec son statut
 * final ('success' ou 'failed') et un message optionnel.
 */
function finishWrChinaSyncLog(int $syncLogId, string $status, ?string $message = null): void
{
    dbExecute(
        'UPDATE wrchina_sync_log
         SET status = :status, message = :message, finished_at = NOW()
         WHERE id = :id',
        ['status' => $status, 'message' => $message, 'id' => $syncLogId]
    );
}

/**
 * Retourne les dernières entrées du journal de synchronisation pour un
 * type de ressource donné, les plus récentes en premier.
 */
function findWrChinaSyncLog(string $resourceType, int $limit = 20): array
{
    return dbFetchAll(
        'SELECT * FROM wrchina_sync_log
         WHERE resource_type = :resource_type
         ORDER BY created_at DESC, id DESC
         LIMIT :limit',
        ['resource_type' => $resourceType, 'limit' => $limit]
    );
}

/**
 * Étape 22.2 : import d'un patch WRChina déjà validé (table
 * wrchina_patches, structurée — contrairement à storeWrChinaRawPayload()
 * qui ne garde qu'un JSON brut).
 *
 * Anti-doublons : patch_number est UNIQUE en base (voir
 * database/schema.sql). Si un patch avec ce numéro existe déjà, cette
 * fonction met à jour sa ligne (au cas où le nom, la date, le statut
 * ou l'URL source aurait changé depuis le dernier import) au lieu d'en
 * créer une nouvelle — jamais deux lignes pour le même patch_number.
 *
 * @param array $patch Doit contenir au moins 'patch_number' (déjà
 *                      validé par l'appelant — voir
 *                      WrChinaPatchImporter::validatePatch()). Les clés
 *                      'patch_name', 'patch_date', 'status', 'source' et
 *                      'source_url' sont facultatives (traitées comme
 *                      NULL si absentes, sauf 'source' qui retombe sur
 *                      'WRChina.gg').
 *
 * @return array ['status' => 'created'|'updated', 'id' => int]
 */
function importWrChinaPatch(array $patch): array
{
    $patchNumber = $patch['patch_number'];

    $existing = dbFetchOne(
        'SELECT id FROM wrchina_patches WHERE patch_number = :patch_number',
        ['patch_number' => $patchNumber]
    );

    $params = [
        'patch_number' => $patchNumber,
        'patch_name' => $patch['patch_name'] ?? null,
        'patch_date' => $patch['patch_date'] ?? null,
        'status' => $patch['status'] ?? null,
        'source' => $patch['source'] ?? 'WRChina.gg',
        'source_url' => $patch['source_url'] ?? null,
    ];

    if ($existing !== null) {
        dbExecute(
            'UPDATE wrchina_patches
             SET patch_name = :patch_name,
                 patch_date = :patch_date,
                 status = :status,
                 source = :source,
                 source_url = :source_url,
                 fetched_at = NOW()
             WHERE id = :id',
            $params + ['id' => (int) $existing['id']]
        );

        return ['status' => 'updated', 'id' => (int) $existing['id']];
    }

    dbExecute(
        'INSERT INTO wrchina_patches
            (patch_number, patch_name, patch_date, status, source, source_url, fetched_at)
         VALUES
            (:patch_number, :patch_name, :patch_date, :status, :source, :source_url, NOW())',
        $params
    );

    return ['status' => 'created', 'id' => (int) dbLastInsertId()];
}

/**
 * Retourne un patch WRChina par son numéro, ou null si aucun n'a
 * encore été importé sous ce numéro.
 */
function findWrChinaPatchByNumber(string $patchNumber): ?array
{
    return dbFetchOne(
        'SELECT * FROM wrchina_patches WHERE patch_number = :patch_number',
        ['patch_number' => $patchNumber]
    );
}

/**
 * Retourne les patchs WRChina importés, les plus récents en premier
 * (par date de patch, puis par identifiant à défaut de date connue).
 */
function findWrChinaPatches(int $limit = 100): array
{
    return dbFetchAll(
        'SELECT * FROM wrchina_patches
         ORDER BY patch_date DESC, id DESC
         LIMIT :limit',
        ['limit' => $limit]
    );
}

/**
 * Nombre total de patchs WRChina importés.
 */
function countWrChinaPatches(): int
{
    $row = dbFetchOne('SELECT COUNT(*) AS total FROM wrchina_patches');

    return $row !== null ? (int) $row['total'] : 0;
}
