<?php
/**
 * Réservée à un futur échec réel d'une requête vers une source de
 * données WRChina.gg (problème réseau, code HTTP inattendu, réponse
 * invalide, ressource absente...), une fois qu'une méthode d'accès
 * autorisée aura été identifiée et connectée (voir
 * WrChinaApiNotConnectedException).
 *
 * Non utilisée à l'étape 22.1 : aucune requête réelle n'existe encore
 * dans WrChinaApiClient, donc rien ne peut, à ce stade, échouer de
 * cette façon. Cette classe est créée par avance uniquement pour que
 * l'architecture (types d'exceptions, signatures de méthodes) soit
 * déjà en place, exactement comme RiotApiRequestException l'avait été
 * dès l'étape 21.1 pour Riot, avant sa première utilisation réelle à
 * l'étape 21.3.
 */
class WrChinaApiRequestException extends RuntimeException
{
}
