<?php
/**
 * Client WRChina.gg (étape 22.1 : squelette d'architecture uniquement ;
 * étape 22.2 : fetchPatches() lit un fichier local, voir plus bas —
 * toujours aucun appel réseau vers WRChina.gg).
 * ---------------------------------------------------------------
 * Objectif de cette étape : préparer la même forme d'architecture que
 * celle mise en place pour Riot (voir includes/riot/), pour une future
 * source de données supplémentaire, WRChina.gg — SANS implémenter la
 * moindre récupération de donnée réelle.
 *
 * Pourquoi aucune requête n'est faite ici, contrairement à Riot dès
 * l'étape 21.3 : Data Dragon est un CDN explicitement mis à disposition
 * par Riot pour les fan sites, sans authentification. Pour WRChina.gg,
 * en revanche, aucune méthode d'accès autorisée n'a été identifiée à ce
 * jour (pas d'API publique documentée, pas d'export de données ouvert,
 * pas d'accord de licence connu). Tant que ce n'est pas confirmé, ce
 * client :
 *   - ne fait AUCUN appel réseau (pas de curl_init, pas de httpGetJson) ;
 *   - n'implémente AUCUN scraping du HTML de WRChina.gg (une telle
 *     récupération, faite sans autorisation, pourrait violer les
 *     conditions d'utilisation du site et/ou la réglementation
 *     applicable — exactement le type de "méthode interdite" que
 *     cette étape doit explicitement éviter) ;
 *   - lève systématiquement WrChinaApiNotConnectedException, quelle
 *     que soit la ressource demandée et quelle que soit la
 *     configuration (voir config/wrchina.php).
 *
 * Une fois qu'une méthode d'accès légitime sera identifiée (API
 * publique documentée par WRChina.gg, export de données officiel, ou
 * accord explicite avec l'éditeur du site), une étape ultérieure
 * pourra implémenter une vraie requête ici, sur le même modèle que
 * RiotApiClient::httpGetJson() (cache, gestion des erreurs, journalisation).
 *
 * Les noms de méthodes ci-dessous anticipent les types de ressources
 * les plus probables pour ce site (classements/tier list communautaires,
 * builds, statistiques de champions) mais ne préjugent pas de la forme
 * exacte que prendra la connexion réelle : ils pourront être ajustés
 * une fois la méthode d'accès autorisée connue.
 */

require_once __DIR__ . '/WrChinaApiNotConnectedException.php';
require_once __DIR__ . '/WrChinaApiRequestException.php';

class WrChinaApiClient
{
    private string $baseUrl;
    private string $apiKey;
    private int $timeoutSeconds;
    private string $patchesStagingFile;

    public function __construct(
        ?string $baseUrl = null,
        ?string $apiKey = null,
        ?int $timeoutSeconds = null,
        ?string $patchesStagingFile = null
    ) {
        // Ces valeurs ne servent à rien de fonctionnel à ce stade
        // (aucune méthode ci-dessous ne les utilise, hormis
        // $patchesStagingFile depuis l'étape 22.2, voir fetchPatches())
        // : elles sont uniquement conservées pour que la forme du
        // constructeur soit déjà celle qu'aura le client une fois
        // réellement connecté, comme RiotApiClient (voir
        // includes/riot/RiotApiClient.php).
        $this->baseUrl = $baseUrl ?? (defined('WRCHINA_BASE_URL') ? WRCHINA_BASE_URL : '');
        $this->apiKey = $apiKey ?? (defined('WRCHINA_API_KEY') ? WRCHINA_API_KEY : '');
        $this->timeoutSeconds = $timeoutSeconds ?? (defined('WRCHINA_TIMEOUT_SECONDS') ? WRCHINA_TIMEOUT_SECONDS : 10);
        // $patchesStagingFile injectable (surtout utile pour les tests,
        // voir tests/test-wrchina-patch-import.php, qui pointe vers un
        // fichier fixture plutôt que data/wrchina/patches.json) ; sinon
        // retombe sur WRCHINA_PATCHES_STAGING_FILE (config/wrchina.php).
        $this->patchesStagingFile = $patchesStagingFile
            ?? (defined('WRCHINA_PATCHES_STAGING_FILE') ? WRCHINA_PATCHES_STAGING_FILE : '');
    }

    /**
     * Pas encore implémenté : aucune méthode d'accès autorisée à
     * WRChina.gg n'a été identifiée pour les classements de champions
     * (tier list). Lève systématiquement WrChinaApiNotConnectedException.
     */
    public function fetchTierList(?string $patch = null): array
    {
        throw new WrChinaApiNotConnectedException('fetchTierList');
    }

    /**
     * Pas encore implémenté : aucune méthode d'accès autorisée à
     * WRChina.gg n'a été identifiée pour les builds communautaires.
     * Lève systématiquement WrChinaApiNotConnectedException.
     */
    public function fetchBuilds(?string $championExternalId = null): array
    {
        throw new WrChinaApiNotConnectedException('fetchBuilds');
    }

    /**
     * Pas encore implémenté : aucune méthode d'accès autorisée à
     * WRChina.gg n'a été identifiée pour les statistiques de champion
     * (taux de victoire, de sélection, de bannissement...).
     * Lève systématiquement WrChinaApiNotConnectedException.
     */
    public function fetchChampionStats(string $championExternalId): array
    {
        throw new WrChinaApiNotConnectedException('fetchChampionStats');
    }

    /**
     * Point d'entrée générique pour tout autre type de ressource.
     * Comme les méthodes ci-dessus, lève systématiquement
     * WrChinaApiNotConnectedException : aucun type de ressource n'est
     * implémenté à cette étape.
     */
    public function fetchResource(string $resourceType, ?array $params = null): array
    {
        throw new WrChinaApiNotConnectedException('fetchResource');
    }

    /**
     * Étape 22.2 : récupère les informations de patch "disponibles sur
     * WRChina.gg" — mais PAS en interrogeant WRChina.gg en direct.
     *
     * Le constat de l'étape 22.1 n'a pas changé : aucune méthode
     * d'accès autorisée à WRChina.gg n'a été identifiée (pas d'API
     * publique documentée, pas d'export officiel). Faire une requête
     * HTTP vers le site et en analyser le HTML (scraping) sans
     * autorisation resterait le genre de "méthode interdite" que
     * WrChinaApiNotConnectedException existe justement pour éviter —
     * voir WrChinaApiNotConnectedException.php et config/wrchina.php.
     *
     * Cette méthode lit donc un fichier JSON local, tenu à jour à la
     * main (voir WRCHINA_PATCHES_STAGING_FILE dans config/wrchina.php,
     * et data/wrchina/patches.json pour le contenu d'exemple) : c'est
     * le webmaster qui consulte WRChina.gg et y recopie, pour chaque
     * patch, les informations demandées à cette étape. Aucun appel
     * réseau, aucun scraping — seulement une lecture de fichier local.
     * Le jour où une méthode d'accès autorisée existera, cette méthode
     * pourra être remplacée par un vrai appel HTTP (sur le modèle de
     * RiotApiClient::httpGetJson()) sans changer sa signature ni la
     * façon dont WrChinaPatchImporter l'utilise.
     *
     * @return array Liste de tableaux associatifs bruts (une entrée par
     *               patch), tels que lus dans le fichier JSON. Pas encore
     *               validés ici : voir WrChinaPatchImporter::validatePatch().
     *
     * @throws WrChinaApiRequestException si le fichier est absent, illisible,
     *                                    ou ne contient pas un JSON valide.
     */
    public function fetchPatches(): array
    {
        $path = $this->patchesStagingFile;

        if ($path === '' || !is_file($path)) {
            error_log('[WRChina] fetchPatches() : fichier de staging introuvable (' . $path . ').');
            throw new WrChinaApiRequestException(
                "Aucune donnée de patch WRChina disponible : le fichier de staging est introuvable."
            );
        }

        $raw = file_get_contents($path);
        if ($raw === false) {
            error_log('[WRChina] fetchPatches() : impossible de lire le fichier de staging (' . $path . ').');
            throw new WrChinaApiRequestException(
                "Impossible de lire le fichier de staging des patchs WRChina."
            );
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            error_log('[WRChina] fetchPatches() : JSON invalide dans le fichier de staging (' . $path . ').');
            throw new WrChinaApiRequestException(
                "Le fichier de staging des patchs WRChina ne contient pas un JSON valide."
            );
        }

        return $decoded;
    }
}
