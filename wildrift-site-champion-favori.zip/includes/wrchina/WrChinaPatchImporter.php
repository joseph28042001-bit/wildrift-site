<?php
/**
 * Étape 22.2 : import des informations de patch WRChina.
 * ---------------------------------------------------------------
 * Orchestre les trois étapes de l'import, sans les mélanger :
 *   1. récupération des données brutes — WrChinaApiClient::fetchPatches()
 *      (lecture du fichier de staging local, voir son commentaire ;
 *      AUCUN appel réseau vers WRChina.gg à ce stade — voir étape 22.1) ;
 *   2. validation de chaque entrée — validatePatch() ci-dessous ;
 *   3. enregistrement en base — importWrChinaPatch(), qui gère elle-même
 *      l'anti-doublons par patch_number (voir includes/wrchina/WrChinaRepository.php).
 *
 * Toute tentative d'import est journalisée dans wrchina_sync_log via
 * startWrChinaSyncLog()/finishWrChinaSyncLog(), même en cas d'échec.
 *
 * Ne concerne QUE les patchs. Ne touche ni aux builds, ni à la
 * tier-list, ni aux payloads bruts (wrchina_raw_payloads) — hors
 * périmètre de cette étape.
 */

require_once __DIR__ . '/WrChinaApiClient.php';
require_once __DIR__ . '/WrChinaRepository.php';
require_once __DIR__ . '/WrChinaApiRequestException.php';

/**
 * Valide une entrée brute de patch (telle que lue dans le fichier de
 * staging JSON, voir WrChinaApiClient::fetchPatches()).
 *
 * Règles :
 * - 'patch_number' est obligatoire, doit être une chaîne non vide d'au
 *   plus 20 caractères (même limite que la colonne patch_number en
 *   base, voir database/schema.sql) ;
 * - 'patch_name' et 'status', si présents et non null, doivent être
 *   des chaînes (respectivement ≤150 et ≤30 caractères) ;
 * - 'patch_date', si présente et non null, doit être une date valide
 *   au format YYYY-MM-DD ;
 * - 'source_url', si présente et non null, doit être une chaîne
 *   ≤255 caractères.
 *
 * @return string|null null si l'entrée est valide, sinon un message
 *                      expliquant pourquoi elle est rejetée.
 */
function validateWrChinaPatch(array $patch): ?string
{
    if (!isset($patch['patch_number']) || !is_string($patch['patch_number']) || trim($patch['patch_number']) === '') {
        return "champ 'patch_number' manquant ou vide";
    }

    if (mb_strlen($patch['patch_number']) > 20) {
        return "'patch_number' dépasse 20 caractères";
    }

    if (array_key_exists('patch_name', $patch) && $patch['patch_name'] !== null) {
        if (!is_string($patch['patch_name'])) {
            return "'patch_name' doit être une chaîne ou null";
        }
        if (mb_strlen($patch['patch_name']) > 150) {
            return "'patch_name' dépasse 150 caractères";
        }
    }

    if (array_key_exists('status', $patch) && $patch['status'] !== null) {
        if (!is_string($patch['status'])) {
            return "'status' doit être une chaîne ou null";
        }
        if (mb_strlen($patch['status']) > 30) {
            return "'status' dépasse 30 caractères";
        }
    }

    if (array_key_exists('source_url', $patch) && $patch['source_url'] !== null) {
        if (!is_string($patch['source_url'])) {
            return "'source_url' doit être une chaîne ou null";
        }
        if (mb_strlen($patch['source_url']) > 255) {
            return "'source_url' dépasse 255 caractères";
        }
    }

    if (array_key_exists('patch_date', $patch) && $patch['patch_date'] !== null) {
        if (!is_string($patch['patch_date'])) {
            return "'patch_date' doit être une chaîne (YYYY-MM-DD) ou null";
        }
        // Reformater la date obtenue et la comparer à la chaîne d'origine
        // rejette à la fois un format incorrect et une date qui n'existe
        // pas (ex. '2025-02-30'), sans dépendre de DateTime::getLastErrors()
        // (dépréciée depuis PHP 8.3).
        $date = DateTime::createFromFormat('Y-m-d', $patch['patch_date']);
        if ($date === false || $date->format('Y-m-d') !== $patch['patch_date']) {
            return "'patch_date' n'est pas une date valide au format YYYY-MM-DD";
        }
    }

    return null;
}

/**
 * Exécute l'import complet des patchs WRChina : récupération, validation
 * entrée par entrée, puis enregistrement des entrées valides. Une entrée
 * invalide ne bloque pas les autres : elle est simplement comptée à part
 * et journalisée (error_log), jamais silencieusement ignorée.
 *
 * @param WrChinaApiClient|null $client Permet d'injecter un client (ex.
 *                                      pointant vers un fichier de staging
 *                                      différent) pour les tests. Par
 *                                      défaut, un client standard.
 *
 * @return array{
 *     status: 'success'|'failed',
 *     created: int,
 *     updated: int,
 *     invalid: int,
 *     total: int,
 *     errors: string[],
 *     sync_log_id: int
 * }
 */
function importWrChinaPatches(?WrChinaApiClient $client = null): array
{
    $client = $client ?? new WrChinaApiClient();
    $syncLogId = startWrChinaSyncLog('patches');

    $created = 0;
    $updated = 0;
    $invalid = 0;
    $errors = [];

    try {
        $rawPatches = $client->fetchPatches();
    } catch (WrChinaApiRequestException $e) {
        finishWrChinaSyncLog($syncLogId, 'failed', $e->getMessage());

        return [
            'status' => 'failed',
            'created' => 0,
            'updated' => 0,
            'invalid' => 0,
            'total' => 0,
            'errors' => [$e->getMessage()],
            'sync_log_id' => $syncLogId,
        ];
    }

    foreach ($rawPatches as $index => $rawPatch) {
        if (!is_array($rawPatch)) {
            $invalid++;
            $message = "entrée #{$index} : n'est pas un objet";
            $errors[] = $message;
            error_log('[WRChina] importWrChinaPatches() : ' . $message);
            continue;
        }

        $validationError = validateWrChinaPatch($rawPatch);
        if ($validationError !== null) {
            $invalid++;
            $identifier = $rawPatch['patch_number'] ?? "entrée #{$index}";
            $message = "patch '{$identifier}' rejeté : {$validationError}";
            $errors[] = $message;
            error_log('[WRChina] importWrChinaPatches() : ' . $message);
            continue;
        }

        $result = importWrChinaPatch($rawPatch);
        if ($result['status'] === 'created') {
            $created++;
        } else {
            $updated++;
        }
    }

    $total = $created + $updated + $invalid;
    $summary = "patchs importés : {$created} créé(s), {$updated} mis à jour, {$invalid} rejeté(s) sur {$total} au total.";

    finishWrChinaSyncLog($syncLogId, $invalid > 0 && $created === 0 && $updated === 0 ? 'failed' : 'success', $summary);

    return [
        'status' => $invalid > 0 && $created === 0 && $updated === 0 ? 'failed' : 'success',
        'created' => $created,
        'updated' => $updated,
        'invalid' => $invalid,
        'total' => $total,
        'errors' => $errors,
        'sync_log_id' => $syncLogId,
    ];
}
