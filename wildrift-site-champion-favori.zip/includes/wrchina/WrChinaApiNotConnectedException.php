<?php
/**
 * Levée par WrChinaApiClient pour absolument toute ressource, à ce
 * stade (étape 22.1 : architecture uniquement — voir WrChinaApiClient.php
 * pour le détail de ce que "architecture uniquement" signifie ici).
 *
 * Contrairement à RiotApiClient (dont la connexion à Data Dragon a pu
 * être établie dès l'étape 21.3, ce CDN étant explicitement destiné
 * aux fan sites, sans clé), aucune méthode d'accès aux données de
 * WRChina.gg n'a été identifiée comme autorisée à ce jour : ni API
 * publique documentée, ni export de données, ni accord de licence.
 * Tant que ce n'est pas le cas, WrChinaApiClient ne doit récupérer
 * aucune donnée par une méthode non autorisée (scraping du HTML sans
 * permission, contournement d'une protection technique...) — cette
 * exception est donc levée systématiquement, indépendamment de toute
 * configuration (voir config/wrchina.php).
 */
class WrChinaApiNotConnectedException extends RuntimeException
{
    public function __construct(string $method)
    {
        parent::__construct(
            "WrChinaApiClient::{$method}() n'est pas connecté à une source de données WRChina.gg " .
            "(aucune méthode d'accès autorisée n'a encore été identifiée pour ce site — voir étape 22.1)."
        );
    }
}
