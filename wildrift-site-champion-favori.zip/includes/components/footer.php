    </main>
    <footer class="site-footer">
        <div class="container site-footer__grid">
            <div class="site-footer__brand">
                <a href="<?= asset('') ?>" class="site-footer__logo"><?= e(APP_NAME) ?></a>
                <p>Matchups, contre-picks, builds et simulations pour Wild Rift.</p>
            </div>

            <nav class="site-footer__col" aria-label="Navigation">
                <h4>Navigation</h4>
                <a href="<?= asset('') ?>">Accueil</a>
                <a href="<?= asset('champions.php') ?>">Champions</a>
                <a href="<?= asset('builds.php') ?>">Builds</a>
                <a href="<?= asset('tier-list.php') ?>">Tier List</a>
                <a href="<?= asset('counters.php') ?>">Counters</a>
            </nav>

            <nav class="site-footer__col" aria-label="Ressources">
                <h4>Ressources</h4>
                <a href="<?= asset('items.php') ?>">Objets</a>
                <a href="<?= asset('runes.php') ?>">Runes</a>
                <a href="<?= asset('simulation.php') ?>">Simulation</a>
                <a href="<?= asset('news.php') ?>">Actualités</a>
            </nav>

            <nav class="site-footer__col" aria-label="Compte">
                <h4>Compte</h4>
                <a href="<?= asset('login.php') ?>">Connexion</a>
                <a href="<?= asset('profile.php') ?>">Profil</a>
            </nav>
        </div>

        <div class="container site-footer__bottom">
            <p>&copy; <?= date('Y') ?> <?= e(APP_NAME) ?>. Tous droits réservés.</p>
            <p class="text-mono text-muted">Patch actuel : <span class="text-teal"><?= e(CURRENT_PATCH) ?></span></p>
            <p class="site-footer__disclaimer">
                <?= e(APP_NAME) ?> est un site non-officiel et n'est affilié ni approuvé par Riot Games.
                Wild Rift et les éléments associés sont des marques de Riot Games, Inc.
            </p>
        </div>
    </footer>
    <script>
        // Base des appels API pour les fichiers JS statiques (assets/js/*.js),
        // qui ne peuvent pas appeler directement la fonction PHP asset().
        // Reste valide quel que soit le sous-dossier d'installation du site.
        window.API_BASE_URL = <?= json_encode(asset('api')) ?>;

        // Base des liens internes (hors API) pour ces mêmes fichiers JS —
        // par exemple la navigation champion → /builds/<slug> (voir
        // assets/js/champions.js, assets/js/home.js). Même principe et
        // même raison d'être que API_BASE_URL ci-dessus.
        window.SITE_BASE_URL = <?= json_encode(asset('')) ?>;
    </script>
    <script src="<?= asset('assets/js/main.js') ?>"></script>
    <script src="<?= asset('assets/js/news.js') ?>"></script>
</body>
</html>
