<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? e($pageTitle) . ' — ' : '' ?><?= e(APP_NAME) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="<?= asset('assets/css/style.css') ?>">
    <link rel="stylesheet" href="<?= asset('assets/css/loader.css') ?>">
    <script>try { if (!sessionStorage.getItem('wrLoaderSeen')) document.documentElement.classList.add('wr-loading'); } catch (e) {}</script>
    <script>window.CURRENT_PATCH = <?= json_encode(CURRENT_PATCH) ?>;</script>
</head>
<body>
    <div class="wr-loader" id="wr-loader" role="status" aria-live="polite" aria-label="Chargement du site">
        <div class="wr-loader__veil"></div>
        <div class="wr-loader__center">
            <div class="wr-loader__brand"><?= e(APP_NAME) ?></div>
            <div class="wr-loader__bar"><div class="wr-loader__bar-fill"></div></div>
            <div class="wr-loader__label">Chargement</div>
        </div>
    </div>
    <script src="<?= asset('assets/js/loader.js') ?>"></script>
    <header class="site-header">
        <div class="container site-header__inner">
            <a href="<?= asset('') ?>" class="site-header__brand"><?= e(APP_NAME) ?></a>

            <button type="button" class="nav-toggle" data-nav-toggle aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="site-nav">
                <svg class="nav-toggle__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                    <line class="nav-toggle__bar nav-toggle__bar--top" x1="3" y1="6" x2="21" y2="6"></line>
                    <line class="nav-toggle__bar nav-toggle__bar--mid" x1="3" y1="12" x2="21" y2="12"></line>
                    <line class="nav-toggle__bar nav-toggle__bar--bottom" x1="3" y1="18" x2="21" y2="18"></line>
                </svg>
            </button>

            <?php
                // Les onglets "Builds" et "Objets/Runes" sont volontairement
                // masqués du menu principal public (demande produit) : les
                // pages (builds.php, pages/champion-build.php, items.php,
                // runes.php), leurs routes, l'API et les tables SQL
                // associées restent entièrement fonctionnelles et
                // accessibles directement par URL — voir builds.php,
                // items.php, runes.php. Seuls ces deux liens de nav sont
                // retirés de l'affichage ; rien n'est supprimé côté
                // système. La navigation champion → build (Accueil et
                // page Champions → builds.php?champion=<slug>) n'est pas
                // affectée par ce changement.
            ?>
            <nav class="site-header__nav" id="site-nav" data-nav>
                <a href="<?= asset('') ?>"<?= ($pageTitle ?? '') === 'Accueil' ? ' aria-current="page"' : '' ?>>Accueil</a>
                <a href="<?= asset('champions.php') ?>"<?= ($pageTitle ?? '') === 'Champions' ? ' aria-current="page"' : '' ?>>Champions</a>
                <a href="<?= asset('tier-list.php') ?>"<?= ($pageTitle ?? '') === 'Tier list' ? ' aria-current="page"' : '' ?>>Tier List</a>
                <a href="<?= asset('counters.php') ?>"<?= ($pageTitle ?? '') === 'Counters' ? ' aria-current="page"' : '' ?>>Counters</a>
                <a href="<?= asset('simulation.php') ?>"<?= ($pageTitle ?? '') === 'Simulation' ? ' aria-current="page"' : '' ?>>Simulation</a>
                <a href="<?= asset('news.php') ?>"<?= ($pageTitle ?? '') === 'Actualités' ? ' aria-current="page"' : '' ?>>Actualités</a>
            </nav>

            <?php
                // État de connexion du compte (voir SESSION_USER_KEY,
                // config/session.php) : connecté → icône Profil +
                // Déconnexion (formulaire POST protégé par jeton CSRF,
                // même principe que la section "Se déconnecter" de
                // pages/profile.php) ; non connecté → liens Connexion et
                // Inscription (login.php/register.php).
            ?>
            <?php if (!empty($_SESSION[SESSION_USER_KEY])): ?>
                <a href="<?= asset('profile.php') ?>" class="site-header__profile" aria-label="Profil"<?= ($pageTitle ?? '') === 'Profil' ? ' aria-current="page"' : '' ?>>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="8" r="4"></circle>
                        <path d="M4 20.5c0-4.14 3.58-7.5 8-7.5s8 3.36 8 7.5"></path>
                    </svg>
                </a>

                <form action="<?= asset('logout.php') ?>" method="post" class="site-header__logout">
                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                    <button type="submit" class="btn btn--secondary btn--sm">Déconnexion</button>
                </form>
            <?php else: ?>
                <a href="<?= asset('login.php') ?>" class="btn btn--secondary btn--sm site-header__login"<?= ($pageTitle ?? '') === 'Connexion' ? ' aria-current="page"' : '' ?>>Connexion</a>
                <a href="<?= asset('register.php') ?>" class="btn btn--sm site-header__register"<?= ($pageTitle ?? '') === 'Inscription' ? ' aria-current="page"' : '' ?>>Inscription</a>
            <?php endif; ?>
        </div>

        <div class="nav-overlay" data-nav-overlay data-open="false"></div>
    </header>
    <main class="site-main">
