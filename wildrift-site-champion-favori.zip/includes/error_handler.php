<?php
/**
 * Gestionnaire global d'erreurs et d'exceptions non interceptées.
 * -----------------------------------------------------------------
 * Filet de sécurité : même si une page oublie un try/catch autour d'un
 * appel base de données, aucun message technique (SQL, identifiants,
 * chemin serveur, stack trace) n'atteint jamais le visiteur. Le détail
 * complet est toujours journalisé côté serveur via error_log().
 */

set_exception_handler(function (Throwable $exception): void {
    error_log('[Exception non interceptée] ' . $exception->getMessage() . ' in ' . $exception->getFile() . ':' . $exception->getLine());

    if (!headers_sent()) {
        http_response_code(500);
    }

    // Message volontairement générique, quel que soit le type d'exception.
    echo 'Une erreur est survenue. Merci de réessayer plus tard.';
    exit;
});

set_error_handler(function (int $severity, string $message, string $file, int $line): bool {
    error_log("[Erreur PHP] $message in $file:$line");

    // Laisse le gestionnaire d'erreurs interne de PHP agir aussi
    // (utile en développement, où APP_DEBUG affiche les erreurs).
    return false;
});
