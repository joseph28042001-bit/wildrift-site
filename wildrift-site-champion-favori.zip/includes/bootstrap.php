<?php
/**
 * Bootstrap : point d'entrée commun à inclure en tête de chaque page PHP.
 * Charge la configuration dans l'ordre attendu, puis les fonctions partagées.
 */

// 1. Environnement (doit être chargé en premier : définit les constantes
//    utilisées par les autres fichiers de configuration).
require_once __DIR__ . '/../config/environment.php';

// 1bis. Bloque tout déploiement en production avec des réglages de dev
//       (clé de sécurité par défaut, URL non-HTTPS, cookie non sécurisé).
checkProductionReadiness();

// 2. Configuration générale et URL du site
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/site.php';

// 2bis. Version du jeu (patch) active : CURRENT_PATCH, source unique.
require_once __DIR__ . '/../config/patch.php';

// 3. Filet de sécurité global : aucune erreur/exception non interceptée
//    n'atteint jamais le visiteur avec un détail sensible.
require_once __DIR__ . '/error_handler.php';

// 4. Session et sécurité
require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/security.php';

// 5. Uploads
require_once __DIR__ . '/../config/uploads.php';

// 6. Base de données (connexion PDO + helpers de requêtes préparées)
require_once __DIR__ . '/../config/database.php';

// 6bis. Intégration Riot — constantes de configuration uniquement
//       (RIOT_API_KEY, RIOT_DDRAGON_BASE_URL, etc.) ; aucune requête
//       n'est faite ici. Depuis l'étape 21.3, includes/riot/RiotApiClient.php
//       sait récupérer les données de champions (Data Dragon), mais reste
//       chargé à la demande (pas ici) par le code qui en aura besoin.
require_once __DIR__ . '/../config/riot.php';

// 6ter. Intégration WRChina.gg — constantes de configuration uniquement
//       (étape 22.1 : architecture, comme Riot à l'étape 21.1) ; aucune
//       requête n'est faite ici, et includes/wrchina/WrChinaApiClient.php
//       ne sait encore récupérer aucune donnée réelle (aucune méthode
//       d'accès autorisée identifiée à ce jour pour ce site). Reste,
//       comme le client Riot, chargé à la demande par le code qui en
//       aura besoin.
require_once __DIR__ . '/../config/wrchina.php';

// 7. Fonctions utilitaires partagées
require_once __DIR__ . '/functions.php';

// Démarrage de session + en-têtes de sécurité
startSecureSession();
sendSecurityHeaders();

// Régénère périodiquement l'identifiant de session d'un compte connecté
// (voir maybeRegenerateUserSession(), config/session.php) : sans effet
// tant qu'aucun compte n'est connecté (SESSION_USER_KEY absent), donc
// sûr à appeler sur chaque requête, y compris les pages publiques.
maybeRegenerateUserSession();
