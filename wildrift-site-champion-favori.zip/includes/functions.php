<?php
/**
 * Fonctions utilitaires génériques pour l'ensemble du site.
 * Les fonctions spécifiques à Wild Rift (matchups, builds, etc.)
 * seront ajoutées dans des fichiers dédiés lors des prochaines étapes.
 */

/**
 * Échappe une chaîne pour un affichage HTML sûr.
 */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Redirige vers une URL relative au site et arrête l'exécution.
 */
function redirect(string $path): void
{
    header('Location: ' . BASE_URL . ltrim($path, '/'));
    exit;
}

/**
 * Retourne une réponse JSON standardisée (pour l'API).
 */
function jsonResponse(array $data, int $statusCode = 200): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
