<?php
/**
 * Point d'entrée public : Inscription.
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/register.php. Toute la logique/contenu vit dans pages/.
 */

require_once __DIR__ . '/includes/bootstrap.php';

/**
 * Traitement serveur du formulaire d'inscription (voir pages/register.php
 * pour le contenu affiché). Reste volontairement dans ce point d'entrée
 * plutôt que dans pages/ : pages/register.php ne fait qu'afficher le
 * résultat ($registerErrors / $registerSuccess / $oldPseudo / $oldEmail).
 */
$registerErrors = [];
$registerSuccess = false;
$oldPseudo = '';
$oldEmail = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        $registerErrors['global'] = 'Ta session a expiré ou la requête est invalide. Merci de réessayer.';
    } else {
        $pseudo = trim((string) ($_POST['pseudo'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $passwordConfirm = (string) ($_POST['password_confirm'] ?? '');
        $termsAccepted = isset($_POST['terms']);

        $oldPseudo = $pseudo;
        $oldEmail = $email;

        if ($pseudo === '' || mb_strlen($pseudo) < 3 || mb_strlen($pseudo) > 20 || !preg_match('/^[A-Za-z0-9_]+$/', $pseudo)) {
            $registerErrors['pseudo'] = "Choisis un pseudo de 3 à 20 caractères (lettres, chiffres, underscore).";
        }

        if ($email === '' || mb_strlen($email) > 190 || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            $registerErrors['email'] = 'Saisis une adresse email valide.';
        }

        if (mb_strlen($password) < 8) {
            $registerErrors['password'] = 'Le mot de passe doit contenir au moins 8 caractères.';
        } elseif (strlen($password) > 72) {
            // bcrypt (password_hash(), voir plus bas) ignore silencieusement
            // tout au-delà de 72 octets : sans cette limite, un mot de passe
            // plus long semblerait accepté alors que sa fin n'aurait aucun
            // effet réel sur la sécurité du compte. strlen() (octets), pas
            // mb_strlen() (caractères) : c'est la limite réelle de bcrypt.
            $registerErrors['password'] = 'Le mot de passe ne peut pas dépasser 72 caractères.';
        }

        if ($passwordConfirm === '' || $passwordConfirm !== $password) {
            $registerErrors['password_confirm'] = 'Les deux mots de passe ne correspondent pas.';
        }

        if (!$termsAccepted) {
            $registerErrors['terms'] = "Tu dois accepter les conditions d'utilisation pour créer un compte.";
        }

        // Unicité pseudo/email : vérifiée seulement si les deux champs sont
        // eux-mêmes valides (inutile d'interroger la base sur une valeur
        // qu'on va de toute façon rejeter).
        if (!isset($registerErrors['pseudo']) && !isset($registerErrors['email'])) {
            try {
                $existingUser = dbFetchOne(
                    'SELECT id FROM users WHERE pseudo = :pseudo OR email = :email LIMIT 1',
                    ['pseudo' => $pseudo, 'email' => $email]
                );

                if ($existingUser !== null) {
                    // Message volontairement générique : ne révèle pas lequel
                    // des deux (pseudo ou email) est déjà pris.
                    $registerErrors['global'] = 'Ce pseudo ou cet email est déjà associé à un compte.';
                }
            } catch (DatabaseException $exception) {
                $registerErrors['global'] = $exception->getMessage();
            }
        }

        if (empty($registerErrors)) {
            try {
                $passwordHash = password_hash($password, PASSWORD_BCRYPT, PASSWORD_HASH_OPTIONS);

                dbExecute(
                    'INSERT INTO users (pseudo, email, password_hash, role) VALUES (:pseudo, :email, :password_hash, :role)',
                    [
                        'pseudo' => $pseudo,
                        'email' => $email,
                        'password_hash' => $passwordHash,
                        'role' => 'user',
                    ]
                );

                $registerSuccess = true;
                $oldPseudo = '';
                $oldEmail = '';
            } catch (DatabaseException $exception) {
                // Filet pour une éventuelle contrainte UNIQUE déclenchée entre
                // la vérification ci-dessus et l'insertion (rare, cf. accès concurrents).
                $registerErrors['global'] = $exception->getMessage();
            }
        }
    }
}

$pageTitle = 'Inscription';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/register.php';
require __DIR__ . '/includes/components/footer.php';
