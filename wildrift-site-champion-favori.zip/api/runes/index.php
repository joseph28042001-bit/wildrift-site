<?php
/**
 * Endpoint : /api/runes/
 * Ressource : Runes
 *
 * Un seul point d'entrée, différencié par la méthode HTTP et les
 * paramètres de requête (pas de réécriture d'URL pour des segments
 * /api/runes/{id}/ à ce stade — voir .htaccess) :
 *
 *   GET  /api/runes/                    → toutes les runes
 *   GET  /api/runes/?id=5               → une rune par son ID
 *   GET  /api/runes/?search=comet       → recherche par nom (LIKE)
 *   GET  /api/runes/?tree=precision     → runes d'un arbre donné
 *   GET  /api/runes/?slot=keystone      → runes d'un emplacement donné
 *                                         (keystone = rune majeure, une
 *                                         seule par arbre ; minor = rune
 *                                         mineure)
 *   POST /api/runes/                    → créer une rune
 *   PUT  /api/runes/?id=5               → modifier une rune existante
 *   DELETE /api/runes/?id=5             → supprimer une rune
 *
 * ?search=, ?tree= et ?slot= sont tous combinables entre eux (GET liste
 * uniquement). ?id= est prioritaire et exclusif pour GET (détail), et
 * obligatoire pour PUT/DELETE (mêmes règles de validation que la
 * lecture).
 *
 * POST et PUT valident le corps JSON de la requête (voir
 * validateRunePayload() ci-dessous) : slug (unique, format
 * minuscules/chiffres/tirets), name et tree (enum, voir
 * getRuneTrees()) sont requis ; slot (enum, voir getRuneSlots())
 * vaut 'minor' par défaut si absent ; description et image_url sont
 * optionnels (null si absents/vides). PUT remplace l'ensemble de ces
 * champs (pas de modification partielle) — même principe que
 * /api/champions/ et /api/items/.
 *
 * DELETE supprime aussi, en cascade côté base de données, tout ce qui
 * référence cette rune (entrées de build — voir REFERENCES runes ...
 * ON DELETE CASCADE dans database/schema.sql) : aucune suppression
 * manuelle supplémentaire n'est faite ici.
 *
 * Nouveauté par rapport à l'étape précédente (liste en lecture seule
 * uniquement) : POST/PUT/DELETE, au service de la nouvelle gestion des
 * runes dans l'espace d'administration (voir admin/pages/runes.php et
 * assets/js/admin-runes.js) — même principe que l'étape équivalente sur
 * /api/champions/ et /api/items/. Aucune authentification n'est
 * vérifiée à cette étape (voir admin/login.php, dont la connexion
 * effective n'est pas encore câblée côté serveur) : ces trois méthodes
 * d'écriture sont donc, pour l'instant, accessibles sans connexion, au
 * même titre que le reste de l'espace admin.
 *
 * Données lues/écrites depuis MySQL via PDO en requêtes préparées
 * (voir repository.php et config/database.php) — jamais de valeur
 * utilisateur concaténée dans le SQL.
 */

require_once __DIR__ . '/../core/bootstrap.php';
require_once __DIR__ . '/repository.php';

/**
 * Valide le corps JSON d'une création ou d'une modification de rune et
 * retourne un tableau prêt à être passé à insertRune()/updateRune()
 * (mêmes clés que RUNE_SELECT_COLUMNS, hormis id/created_at/updated_at).
 * Lève une ApiException 422 au premier champ invalide — même principe
 * que validateChampionPayload()/validateItemPayload().
 */
function validateRunePayload(array $body): array
{
    apiRequireFields($body, ['slug', 'name', 'tree']);

    $slug = apiValidateString($body['slug'], 'slug', 1, 60);
    if (!preg_match('/^[a-z0-9]+(-[a-z0-9]+)*$/', $slug)) {
        throw ApiException::validation(
            "Le champ 'slug' doit être en minuscules, chiffres et tirets uniquement (ex. 'electrocute').",
            ['field' => 'slug']
        );
    }

    $name = apiValidateString($body['name'], 'name', 1, 60);
    $tree = apiValidateEnum($body['tree'], 'tree', getRuneTrees());

    $slot = 'minor';
    if (isset($body['slot']) && $body['slot'] !== '') {
        $slot = apiValidateEnum($body['slot'], 'slot', getRuneSlots());
    }

    $description = null;
    if (isset($body['description']) && $body['description'] !== '') {
        $description = apiValidateString($body['description'], 'description', 1, 255);
    }

    $imageUrl = null;
    if (isset($body['image_url']) && $body['image_url'] !== '') {
        $imageUrl = apiValidateString($body['image_url'], 'image_url', 1, 255);
    }

    return [
        'slug'        => $slug,
        'name'        => $name,
        'tree'        => $tree,
        'slot'        => $slot,
        'description' => $description,
        'image_url'   => $imageUrl,
    ];
}

apiRun(function (): void {
    apiRequireMethod(['GET', 'POST', 'PUT', 'DELETE']);

    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    // Écritures réservées à un administrateur connecté (voir api/core/auth.php).
    if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
        apiRequireAdmin();
    }

    // --- Création (POST) -------------------------------------------
    if ($method === 'POST') {
        $data = validateRunePayload(apiGetJsonBody());

        if (findRuneBySlug($data['slug']) !== null) {
            throw ApiException::validation(
                'Ce slug est déjà utilisé par une autre rune.',
                ['field' => 'slug']
            );
        }

        $id = insertRune($data);

        apiSuccess(findRuneById($id), 201);
        return;
    }

    // --- Modification et suppression (PUT/DELETE) : ?id= obligatoire
    if ($method === 'PUT' || $method === 'DELETE') {
        if (!isset($_GET['id']) || $_GET['id'] === '') {
            throw ApiException::badRequest("Le paramètre 'id' est requis pour cette méthode.");
        }

        $id = apiValidateInt($_GET['id'], 'id', 1);

        if (findRuneById($id) === null) {
            throw ApiException::notFound("Aucune rune trouvée avec l'ID $id.");
        }

        if ($method === 'DELETE') {
            deleteRune($id);
            apiSuccess(['id' => $id]);
            return;
        }

        $data = validateRunePayload(apiGetJsonBody());

        $existingWithSlug = findRuneBySlug($data['slug']);
        if ($existingWithSlug !== null && (int) $existingWithSlug['id'] !== $id) {
            throw ApiException::validation(
                'Ce slug est déjà utilisé par une autre rune.',
                ['field' => 'slug']
            );
        }

        updateRune($id, $data);

        apiSuccess(findRuneById($id));
        return;
    }

    // --- Détail par ID (GET) -----------------------------------------
    if (isset($_GET['id']) && $_GET['id'] !== '') {
        $id = apiValidateInt($_GET['id'], 'id', 1);

        $rune = findRuneById($id);

        if ($rune === null) {
            throw ApiException::notFound("Aucune rune trouvée avec l'ID $id.");
        }

        apiSuccess($rune);
        return;
    }

    // --- Liste, avec filtres optionnels (arbre, recherche, emplacement) -
    $tree = null;
    if (isset($_GET['tree']) && $_GET['tree'] !== '') {
        $tree = apiValidateEnum($_GET['tree'], 'tree', getRuneTrees());
    }

    $search = null;
    if (isset($_GET['search']) && $_GET['search'] !== '') {
        $search = apiValidateString($_GET['search'], 'search', 1, 60);
    }

    $slot = null;
    if (isset($_GET['slot']) && $_GET['slot'] !== '') {
        $slot = apiValidateEnum($_GET['slot'], 'slot', getRuneSlots());
    }

    // Filtre par arbre seul (sans recherche ni emplacement) : on passe
    // par findRunesByTree(), qui trie en mettant la rune majeure en
    // tête. Dès qu'un autre filtre s'y ajoute, findRunes() suffit (son
    // tri par nom reste correct, l'emplacement n'étant alors plus
    // ambigu — soit filtré explicitement, soit hors de propos pour une
    // recherche par nom).
    if ($tree !== null && $search === null && $slot === null) {
        $runes = findRunesByTree($tree);
    } else {
        $runes = findRunes($tree, $search, $slot);
    }

    apiSuccess($runes, 200, [
        'count'   => count($runes),
        'filters' => [
            'tree'   => $tree,
            'search' => $search,
            'slot'   => $slot,
        ],
    ]);
});
