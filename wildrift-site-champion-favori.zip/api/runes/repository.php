<?php
/**
 * Accès aux données pour la ressource "runes".
 * Toutes les requêtes passent par dbFetchAll()/dbFetchOne() (config/database.php),
 * qui utilisent PDO en requêtes préparées (aucune valeur n'est jamais concaténée
 * dans le SQL). Ce fichier ne fait aucune validation d'entrée : c'est le rôle
 * de index.php, avant d'appeler ces fonctions.
 */

/** Colonnes exposées par l'API pour une rune (jamais SELECT *). */
const RUNE_SELECT_COLUMNS = 'id, slug, name, tree, slot, description, image_url, created_at, updated_at';

/**
 * Liste des arbres de runes Wild Rift valides, utilisée pour valider le
 * filtre ?tree=.
 */
function getRuneTrees(): array
{
    return ['precision', 'domination', 'sorcery', 'resolve', 'inspiration'];
}

/**
 * Liste des emplacements de rune valides, utilisée pour valider le
 * filtre ?slot= — reprend l'ENUM `slot` de la table `runes` (voir
 * database/schema.sql) : une seule rune majeure ("keystone") par arbre,
 * les autres étant mineures.
 */
function getRuneSlots(): array
{
    return ['keystone', 'minor'];
}

/**
 * Retourne les runes correspondant aux filtres fournis, triées par arbre
 * puis par nom. $tree, $search et $slot sont supposés déjà validés par
 * l'appelant.
 */
function findRunes(?string $tree, ?string $search, ?string $slot = null): array
{
    $sql = 'SELECT ' . RUNE_SELECT_COLUMNS . ' FROM runes WHERE 1 = 1';
    $params = [];

    if ($tree !== null) {
        $sql .= ' AND tree = :tree';
        $params['tree'] = $tree;
    }

    if ($search !== null) {
        $sql .= ' AND name LIKE :search';
        $params['search'] = '%' . $search . '%';
    }

    if ($slot !== null) {
        $sql .= ' AND slot = :slot';
        $params['slot'] = $slot;
    }

    $sql .= ' ORDER BY tree ASC, name ASC';

    return dbFetchAll($sql, $params);
}

/**
 * Retourne une rune par son ID, ou null si elle n'existe pas.
 */
function findRuneById(int $id): ?array
{
    return dbFetchOne(
        'SELECT ' . RUNE_SELECT_COLUMNS . ' FROM runes WHERE id = :id',
        ['id' => $id]
    );
}

/**
 * Retourne une rune par son slug, ou null si elle n'existe pas. Sert à
 * vérifier l'unicité du slug en création/modification (voir index.php) —
 * même principe que findChampionBySlug() (api/champions/repository.php)
 * et findItemBySlug() (api/items/repository.php).
 */
function findRuneBySlug(string $slug): ?array
{
    return dbFetchOne(
        'SELECT ' . RUNE_SELECT_COLUMNS . ' FROM runes WHERE slug = :slug',
        ['slug' => $slug]
    );
}

/**
 * Insère une nouvelle rune et retourne son ID généré. $data doit déjà
 * être validé par l'appelant (voir validateRunePayload(), index.php) —
 * mêmes clés que RUNE_SELECT_COLUMNS hormis id/created_at/updated_at.
 */
function insertRune(array $data): int
{
    dbExecute(
        'INSERT INTO runes (slug, name, tree, slot, description, image_url)
         VALUES (:slug, :name, :tree, :slot, :description, :image_url)',
        [
            'slug'        => $data['slug'],
            'name'        => $data['name'],
            'tree'        => $data['tree'],
            'slot'        => $data['slot'],
            'description' => $data['description'],
            'image_url'   => $data['image_url'],
        ]
    );

    return (int) dbLastInsertId();
}

/**
 * Remplace l'ensemble des champs modifiables d'une rune existante (pas
 * de modification partielle). $id est supposé déjà validé et existant
 * par l'appelant (voir findRuneById()) ; $data déjà validé par
 * validateRunePayload() (index.php).
 */
function updateRune(int $id, array $data): void
{
    dbExecute(
        'UPDATE runes
         SET slug = :slug, name = :name, tree = :tree, slot = :slot,
             description = :description, image_url = :image_url
         WHERE id = :id',
        [
            'id'          => $id,
            'slug'        => $data['slug'],
            'name'        => $data['name'],
            'tree'        => $data['tree'],
            'slot'        => $data['slot'],
            'description' => $data['description'],
            'image_url'   => $data['image_url'],
        ]
    );
}

/**
 * Supprime une rune par son ID. La base de données supprime en cascade
 * tout ce qui la référence (entrées de build — voir REFERENCES runes
 * ... ON DELETE CASCADE dans database/schema.sql) : aucune suppression
 * manuelle supplémentaire n'est faite ici, même principe que
 * deleteChampion()/deleteItem().
 */
function deleteRune(int $id): void
{
    dbExecute('DELETE FROM runes WHERE id = :id', ['id' => $id]);
}

/**
 * Retourne toutes les runes d'un arbre donné, triées par emplacement
 * (majeure d'abord) puis par nom. $tree est supposé déjà validé par l'appelant.
 */
function findRunesByTree(string $tree): array
{
    return dbFetchAll(
        'SELECT ' . RUNE_SELECT_COLUMNS . ' FROM runes WHERE tree = :tree ORDER BY FIELD(slot, \'keystone\', \'minor\'), name ASC',
        ['tree' => $tree]
    );
}
