<?php
/**
 * Point d'entrée /api/ — statut général du service (santé, version).
 * Ce fichier ne contient aucune logique métier : il aiguille simplement
 * vers le fichier de route correspondant dans api/routes/.
 *
 * Les ressources Wild Rift (champions, items, runes, builds, counters,
 * tier-list, news) ne passent PAS par ce routeur : chacune a son propre
 * point d'entrée sous api/<ressource>/index.php, avec son propre socle
 * commun partagé depuis api/core/ (voir api/core/bootstrap.php). Aucune
 * de ces routes n'est encore fonctionnelle à cette étape — elles
 * renvoient toutes une erreur 501 "not_implemented".
 */

require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/core/headers.php';

// Toute réponse de ce routeur est du JSON : mêmes en-têtes que le reste de l'API.
sendApiHeaders();

$route = $_GET['route'] ?? 'status';

// Liste blanche des routes disponibles (sécurité : évite l'inclusion arbitraire)
$availableRoutes = [
    'status' => __DIR__ . '/routes/status.php',
];

if (isset($availableRoutes[$route])) {
    require $availableRoutes[$route];
} else {
    jsonResponse(['status' => 'error', 'message' => 'Route inconnue.'], 404);
}
