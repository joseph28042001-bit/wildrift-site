<?php
/**
 * Route API : statut du service.
 * Chaque route métier future vivra dans son propre fichier ici,
 * plutôt que dans api/index.php.
 */

require_once __DIR__ . '/../../includes/bootstrap.php';

jsonResponse([
    'status'  => 'ok',
    'message' => 'API initialisée. Aucune route métier disponible pour le moment.',
    'version' => APP_VERSION,
]);
