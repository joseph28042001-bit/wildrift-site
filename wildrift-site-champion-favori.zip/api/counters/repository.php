<?php
/**
 * Accès aux données pour la ressource "counters" (Matchups & counters).
 * Toutes les requêtes passent par dbFetchAll()/dbFetchOne() (config/database.php),
 * qui utilisent PDO en requêtes préparées (aucune valeur n'est jamais concaténée
 * dans le SQL). Ce fichier ne fait aucune validation d'entrée : c'est le rôle
 * de index.php, avant d'appeler ces fonctions.
 *
 * Connecté à la table "counters" (voir database/schema.sql) :
 *   - champion_id         : le champion contré
 *   - counter_champion_id : le champion qui le contre
 *   - explanation         : explication du contre (pas de lien vidéo,
 *                           conformément à la décision de retirer les
 *                           liens YouTube de Matchups & Counters)
 *   - tips                : conseils pratiques pour jouer le matchup
 *                           (timing, objets, positionnement...),
 *                           distincts de 'explanation'
 *   - difficulty          : difficulté du contre, facultatif
 *
 * Branché sur de vraies actions HTTP dans index.php (liste avec filtres
 * combinables ?champion_id= / ?counter_champion_id=, détail par ?id=,
 * objets recommandés associés via findCounterItems()) : voir
 * api/counters/index.php.
 */

/** Colonnes exposées par l'API pour un counter (jamais SELECT *). */
const COUNTER_SELECT_COLUMNS = 'id, champion_id, counter_champion_id, explanation, tips, difficulty, created_at, updated_at';

/**
 * Colonnes exposées par l'API pour un objet recommandé associé à un
 * counter : un sous-ensemble volontairement plus léger que
 * ITEM_SELECT_COLUMNS (items/repository.php) — pas de description ni
 * de dates, le détail complet d'un objet restant du ressort de
 * /api/items/?id=. Même logique d'allègement que
 * BUILD_ITEM_SELECT_COLUMNS (builds/repository.php).
 */
const COUNTER_ITEM_SELECT_COLUMNS = 'i.id AS id, i.slug AS slug, i.name AS name, i.category AS category, i.price AS price, i.image_url AS image_url';

/**
 * Retourne les counters correspondant aux filtres fournis, triés par ID.
 * $championId : ne garder que les counters concernant ce champion contré.
 * $counterChampionId : ne garder que les counters où ce champion contre.
 * Les deux filtres sont combinables. Valeurs supposées déjà validées
 * par l'appelant (index.php).
 */
function findCounters(?int $championId = null, ?int $counterChampionId = null): array
{
    $sql = 'SELECT ' . COUNTER_SELECT_COLUMNS . ' FROM counters WHERE 1 = 1';
    $params = [];

    if ($championId !== null) {
        $sql .= ' AND champion_id = :champion_id';
        $params['champion_id'] = $championId;
    }

    if ($counterChampionId !== null) {
        $sql .= ' AND counter_champion_id = :counter_champion_id';
        $params['counter_champion_id'] = $counterChampionId;
    }

    $sql .= ' ORDER BY id ASC';

    return dbFetchAll($sql, $params);
}

/**
 * Retourne un counter par son ID, ou null s'il n'existe pas.
 */
function findCounterById(int $id): ?array
{
    return dbFetchOne(
        'SELECT ' . COUNTER_SELECT_COLUMNS . ' FROM counters WHERE id = :id',
        ['id' => $id]
    );
}

/**
 * Retourne les objets recommandés pour un counter donné (table de
 * relation `counter_items`, jointe à `items`), triés par ordre d'achat
 * conseillé (les objets sans ordre en dernier), puis par nom. Le détail
 * complet de chaque objet (description, dates...) provient de `items`
 * elle-même, pas dupliqué dans counter_items. Inclut aussi
 * `situation` (colonne `counter_items.situation`, nullable) : quand
 * renseignée, l'objet est situationnel (contexte de jeu précis
 * justifiant l'achat) plutôt qu'un objet de base — voir
 * database/schema.sql pour le détail. $counterId est supposé déjà
 * validé par l'appelant ; ne vérifie pas que le counter existe.
 * Retourne un tableau vide si aucun objet n'est associé — ce n'est pas
 * une erreur.
 */
function findCounterItems(int $counterId): array
{
    $sql = 'SELECT ci.purchase_order AS purchase_order, ci.situation AS situation, '
        . COUNTER_ITEM_SELECT_COLUMNS . '
        FROM counter_items ci
        INNER JOIN items i ON i.id = ci.item_id
        WHERE ci.counter_id = :counter_id
        ORDER BY (ci.purchase_order IS NULL) ASC, ci.purchase_order ASC, i.name ASC';

    return dbFetchAll($sql, ['counter_id' => $counterId]);
}
