<?php
/**
 * Endpoint : /api/counters/
 * Ressource : Matchups & counters
 *
 * Étape actuelle : récupération de la liste des counters depuis MySQL,
 * avec filtres optionnels et combinables par champion contré et par
 * champion qui contre (via findCounters(), voir repository.php),
 * retournée en JSON par l'enveloppe standard de l'API (apiSuccess()).
 *
 *   GET /api/counters/                                        → tous les counters
 *   GET /api/counters/?id=7                                   → un matchup précis par son ID
 *                                                                 (pour la page de détail matchup.php)
 *   GET /api/counters/?champion_id=1                           → counters concernant le champion contré 1
 *                                                                 (ex. Aatrox → ses counters)
 *   GET /api/counters/?champion_id=1&counter_champion_id=2     → le matchup précis entre les deux
 *                                                                 (ex. Aatrox contre Mundo)
 *
 * ?id= est prioritaire et exclusif : s'il est présent, ?champion_id= et
 * ?counter_champion_id= sont ignorés — même convention que /api/items/
 * et /api/runes/ (voir api/items/index.php).
 *
 * Chaque counter renvoyé (que ce soit via ?id= ou via la liste) inclut
 * ses objets recommandés pour contrer le champion adverse (relation
 * `counter_items`, liée à `items` — voir repository.php,
 * findCounterItems()) : ex. Aatrox contre Mundo → objets anti-Mundo.
 * Tableau vide si aucun objet n'est encore associé.
 *
 * Gestion des erreurs :
 *   - ?id= non entier ou < 1 → 422 validation_error ;
 *   - ?id= valide mais ne correspondant à aucun counter existant →
 *     404 not_found ;
 *   - paramètre invalide (?champion_id= ou ?counter_champion_id= non
 *     entier, ou < 1) → 422 validation_error, via apiValidateInt()
 *     (voir core/validator.php) ;
 *   - paramètre manquant : ?counter_champion_id= fourni sans
 *     ?champion_id= n'a pas de sens (un matchup précis nécessite les
 *     deux champions) → 422 validation_error ;
 *   - champion inexistant : ?champion_id= ou ?counter_champion_id=
 *     valide mais ne correspondant à aucun champion existant (voir
 *     findChampionById(), champions/repository.php) → 404 not_found ;
 *   - matchup inexistant : ?champion_id= et ?counter_champion_id=
 *     tous deux valides et correspondant à des champions existants,
 *     mais aucun counter ne relie ce couple précis → 404 not_found.
 */

require_once __DIR__ . "/../core/bootstrap.php";
require_once __DIR__ . "/repository.php";
require_once __DIR__ . "/../champions/repository.php";

apiRun(function (): void {
    apiRequireMethod(['GET']);

    // --- Détail par ID ---------------------------------------------------
    // Utilisé par la page de détail matchup.php (voir assets/js/matchup.js).
    // Prioritaire et exclusif : ignore ?champion_id=/?counter_champion_id=
    // si présents en même temps, même convention que /api/items/?id=.
    if (isset($_GET['id']) && $_GET['id'] !== '') {
        $id = apiValidateInt($_GET['id'], 'id', 1);

        $counter = findCounterById($id);

        if ($counter === null) {
            throw ApiException::notFound("Aucun matchup trouvé avec l'ID $id.");
        }

        $counter['items'] = findCounterItems($id);

        apiSuccess($counter);
        return;
    }

    $championId = null;
    if (isset($_GET['champion_id']) && $_GET['champion_id'] !== '') {
        $championId = apiValidateInt($_GET['champion_id'], 'champion_id', 1);
    }

    $counterChampionId = null;
    if (isset($_GET['counter_champion_id']) && $_GET['counter_champion_id'] !== '') {
        $counterChampionId = apiValidateInt($_GET['counter_champion_id'], 'counter_champion_id', 1);
    }

    // --- Paramètre manquant ---------------------------------------------
    // ?counter_champion_id= seul n'a pas de sens : un matchup précis
    // nécessite de préciser aussi le champion contré (?champion_id=).
    if ($counterChampionId !== null && $championId === null) {
        throw ApiException::validation(
            "Le paramètre 'champion_id' est requis lorsque 'counter_champion_id' est fourni."
        );
    }

    // --- Champion inexistant ---------------------------------------------
    if ($championId !== null && findChampionById($championId) === null) {
        throw ApiException::notFound("Aucun champion trouvé avec l'ID $championId.");
    }

    if ($counterChampionId !== null && findChampionById($counterChampionId) === null) {
        throw ApiException::notFound("Aucun champion trouvé avec l'ID $counterChampionId.");
    }

    $counters = findCounters($championId, $counterChampionId);

    // --- Matchup inexistant ------------------------------------------------
    // Les deux champions existent, mais aucun counter ne relie ce couple précis.
    if ($championId !== null && $counterChampionId !== null && count($counters) === 0) {
        throw ApiException::notFound(
            "Aucun matchup trouvé entre les champions $championId et $counterChampionId."
        );
    }

    foreach ($counters as &$counter) {
        $counter['items'] = findCounterItems((int) $counter['id']);
    }
    unset($counter);

    apiSuccess($counters, 200, [
        'count'   => count($counters),
        'filters' => [
            'champion_id'         => $championId,
            'counter_champion_id' => $counterChampionId,
        ],
    ]);
});
