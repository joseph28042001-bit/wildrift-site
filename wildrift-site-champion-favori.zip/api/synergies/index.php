<?php
/**
 * Endpoint : /api/synergies/
 * Ressource : Synergies d'équipe
 *
 * Récupération de la liste des synergies depuis MySQL, avec filtres
 * optionnels et combinables par champion consulté et par champion
 * partenaire (via findSynergies(), voir repository.php), retournée en
 * JSON par l'enveloppe standard de l'API (apiSuccess()).
 *
 *   GET /api/synergies/                                        → toutes les synergies
 *   GET /api/synergies/?champion_id=1                          → synergies du champion 1
 *                                                                 (ex. Jinx → ses synergies)
 *   GET /api/synergies/?champion_id=1&synergy_champion_id=2    → la synergie précise entre les deux
 *                                                                 (ex. Jinx et Lulu)
 *
 * Contrairement à /api/counters/, pas d'objets recommandés associés ni
 * de difficulté : chaque synergie ne renvoie que son explication.
 *
 * Gestion des erreurs :
 *   - paramètre invalide (?champion_id= ou ?synergy_champion_id= non
 *     entier, ou < 1) → 422 validation_error, via apiValidateInt()
 *     (voir core/validator.php) ;
 *   - paramètre manquant : ?synergy_champion_id= fourni sans
 *     ?champion_id= n'a pas de sens (une synergie précise nécessite les
 *     deux champions) → 422 validation_error ;
 *   - champion inexistant : ?champion_id= ou ?synergy_champion_id=
 *     valide mais ne correspondant à aucun champion existant (voir
 *     findChampionById(), champions/repository.php) → 404 not_found ;
 *   - synergie inexistante : ?champion_id= et ?synergy_champion_id=
 *     tous deux valides et correspondant à des champions existants,
 *     mais aucune synergie ne relie ce couple précis → 404 not_found.
 *
 * Pas encore implémenté à cette étape (viendra ensuite, sur le
 * modèle de /api/items/ et /api/runes/) :
 *   - ?id=  → détail d'une synergie par son ID
 */

require_once __DIR__ . "/../core/bootstrap.php";
require_once __DIR__ . "/repository.php";
require_once __DIR__ . "/../champions/repository.php";

apiRun(function (): void {
    apiRequireMethod(['GET']);

    $championId = null;
    if (isset($_GET['champion_id']) && $_GET['champion_id'] !== '') {
        $championId = apiValidateInt($_GET['champion_id'], 'champion_id', 1);
    }

    $synergyChampionId = null;
    if (isset($_GET['synergy_champion_id']) && $_GET['synergy_champion_id'] !== '') {
        $synergyChampionId = apiValidateInt($_GET['synergy_champion_id'], 'synergy_champion_id', 1);
    }

    // --- Paramètre manquant ---------------------------------------------
    // ?synergy_champion_id= seul n'a pas de sens : une synergie précise
    // nécessite de préciser aussi le champion consulté (?champion_id=).
    if ($synergyChampionId !== null && $championId === null) {
        throw ApiException::validation(
            "Le paramètre 'champion_id' est requis lorsque 'synergy_champion_id' est fourni."
        );
    }

    // --- Champion inexistant ---------------------------------------------
    if ($championId !== null && findChampionById($championId) === null) {
        throw ApiException::notFound("Aucun champion trouvé avec l'ID $championId.");
    }

    if ($synergyChampionId !== null && findChampionById($synergyChampionId) === null) {
        throw ApiException::notFound("Aucun champion trouvé avec l'ID $synergyChampionId.");
    }

    $synergies = findSynergies($championId, $synergyChampionId);

    // --- Synergie inexistante ------------------------------------------------
    // Les deux champions existent, mais aucune synergie ne relie ce couple précis.
    if ($championId !== null && $synergyChampionId !== null && count($synergies) === 0) {
        throw ApiException::notFound(
            "Aucune synergie trouvée entre les champions $championId et $synergyChampionId."
        );
    }

    apiSuccess($synergies, 200, [
        'count'   => count($synergies),
        'filters' => [
            'champion_id'         => $championId,
            'synergy_champion_id' => $synergyChampionId,
        ],
    ]);
});
