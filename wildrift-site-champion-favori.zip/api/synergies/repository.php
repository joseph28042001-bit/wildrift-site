<?php
/**
 * Accès aux données pour la ressource "synergies" (synergies d'équipe).
 * Toutes les requêtes passent par dbFetchAll()/dbFetchOne() (config/database.php),
 * qui utilisent PDO en requêtes préparées (aucune valeur n'est jamais concaténée
 * dans le SQL). Ce fichier ne fait aucune validation d'entrée : c'est le rôle
 * de index.php, avant d'appeler ces fonctions.
 *
 * Connecté à la table "synergies" (voir database/schema.sql) :
 *   - champion_id         : le champion consulté
 *   - synergy_champion_id : le champion qui forme une bonne synergie avec lui
 *   - explanation         : explication de la synergie (combo, protection,
 *                           mise en place...), du point de vue de champion_id
 *
 * Contrairement à "counters" (api/counters/repository.php), pas de notion
 * de difficulté ni d'objets recommandés associés : une synergie est une
 * simple relation champion <-> champion avec son explication.
 *
 * Branché sur de vraies actions HTTP dans index.php (liste avec filtres
 * combinables ?champion_id= / ?synergy_champion_id=) : voir
 * api/synergies/index.php. Pas encore de détail par ?id= à cette étape
 * (findSynergyById() existe déjà, prête pour cette prochaine étape, mais
 * n'est pas encore appelée depuis index.php).
 */

/** Colonnes exposées par l'API pour une synergie (jamais SELECT *). */
const SYNERGY_SELECT_COLUMNS = 'id, champion_id, synergy_champion_id, explanation, created_at, updated_at';

/**
 * Retourne les synergies correspondant aux filtres fournis, triées par ID.
 * $championId : ne garder que les synergies concernant ce champion consulté.
 * $synergyChampionId : ne garder que les synergies où ce champion est le partenaire.
 * Les deux filtres sont combinables. Valeurs supposées déjà validées
 * par l'appelant (index.php).
 */
function findSynergies(?int $championId = null, ?int $synergyChampionId = null): array
{
    $sql = 'SELECT ' . SYNERGY_SELECT_COLUMNS . ' FROM synergies WHERE 1 = 1';
    $params = [];

    if ($championId !== null) {
        $sql .= ' AND champion_id = :champion_id';
        $params['champion_id'] = $championId;
    }

    if ($synergyChampionId !== null) {
        $sql .= ' AND synergy_champion_id = :synergy_champion_id';
        $params['synergy_champion_id'] = $synergyChampionId;
    }

    $sql .= ' ORDER BY id ASC';

    return dbFetchAll($sql, $params);
}

/**
 * Retourne une synergie par son ID, ou null si elle n'existe pas.
 */
function findSynergyById(int $id): ?array
{
    return dbFetchOne(
        'SELECT ' . SYNERGY_SELECT_COLUMNS . ' FROM synergies WHERE id = :id',
        ['id' => $id]
    );
}
