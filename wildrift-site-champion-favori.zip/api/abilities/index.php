<?php
/**
 * Endpoint : /api/abilities/
 * Ressource : Capacités des champions (passive + Q/W/E/R)
 *
 * Un seul point d'entrée, différencié par les paramètres de requête GET
 * — même convention que /api/champions/, /api/items/, /api/runes/ et
 * /api/tier-list/ :
 *
 *   GET /api/abilities/                    → toutes les capacités
 *   GET /api/abilities/?id=5               → une capacité par son ID (détail complet)
 *   GET /api/abilities/?champion=ahri      → filtre par champion (slug)
 *   GET /api/abilities/?slot=r             → filtre par emplacement (passive/q/w/e/r)
 *
 * ?champion= et ?slot= sont combinables entre eux (ET logique). ?id= est
 * prioritaire et exclusif : s'il est présent, les autres filtres sont
 * ignorés.
 *
 * En liste comme en détail, chaque capacité contient : id, champion
 * (résolu par jointure sur `champions`, jamais champion_id brut), slot,
 * name, description, image_url. Le détail par ?id= ajoute les dates de
 * création/mise à jour — voir repository.php.
 *
 * Triée par champion (nom), puis par emplacement dans l'ordre naturel du
 * kit (passive, q, w, e, r — voir findAbilities(), repository.php).
 *
 * Gestion des erreurs :
 *   - ?id= non entier ou < 1 → 422 validation_error (apiValidateInt()) ;
 *   - ?id= valide mais aucune capacité correspondante → 404 not_found ;
 *   - ?slot= hors énumération (passive/q/w/e/r) → 422 validation_error ;
 *   - ?champion= trop long (> 60 caractères) → 422 validation_error.
 *
 * Aucune vérification d'existence du champion pour ?champion= : un slug
 * inconnu renvoie simplement une liste vide, comme ?champion= sur
 * /api/tier-list/ — ce n'est pas une erreur.
 *
 * Données lues depuis MySQL via PDO en requêtes préparées
 * (voir repository.php et config/database.php) — jamais de valeur
 * utilisateur concaténée dans le SQL.
 */

require_once __DIR__ . '/../core/bootstrap.php';
require_once __DIR__ . '/repository.php';

apiRun(function (): void {
    apiRequireMethod(['GET']);

    // --- Détail par ID -------------------------------------------------
    if (isset($_GET['id']) && $_GET['id'] !== '') {
        $id = apiValidateInt($_GET['id'], 'id', 1);

        $ability = findAbilityById($id);

        if ($ability === null) {
            throw ApiException::notFound("Aucune capacité trouvée avec l'ID $id.");
        }

        apiSuccess($ability);
        return;
    }

    // --- Liste, avec filtres optionnels (champion, slot) ----------------
    $champion = null;
    if (isset($_GET['champion']) && $_GET['champion'] !== '') {
        $champion = apiValidateString($_GET['champion'], 'champion', 1, 60);
    }

    $slot = null;
    if (isset($_GET['slot']) && $_GET['slot'] !== '') {
        $slot = apiValidateEnum($_GET['slot'], 'slot', getAbilitySlots());
    }

    $abilities = findAbilities($champion, $slot);

    apiSuccess($abilities, 200, [
        'count'   => count($abilities),
        'filters' => [
            'champion' => $champion,
            'slot'     => $slot,
        ],
    ]);
});
