<?php
/**
 * Accès aux données pour la ressource "abilities" (capacités des
 * champions — passive + Q/W/E/R). Toutes les requêtes passent par
 * dbFetchAll()/dbFetchOne() (config/database.php), qui utilisent PDO en
 * requêtes préparées (aucune valeur n'est jamais concaténée dans le
 * SQL). Ce fichier ne fait aucune validation d'entrée : c'est le rôle
 * de index.php, avant d'appeler ces fonctions.
 *
 * Connecté à la table "champion_abilities" (voir database/schema.sql),
 * jointe à "champions" pour exposer le nom du champion plutôt que son
 * champion_id brut — même convention que tier-list/repository.php
 * (TIER_LIST_SELECT_COLUMNS).
 */

/**
 * Colonnes exposées par l'API pour une capacité. jamais SELECT *, et
 * jamais champion_id brut.
 */
const ABILITY_SELECT_COLUMNS = 'ca.id AS id, c.name AS champion, ca.slot AS slot, ca.name AS name, ca.description AS description, ca.image_url AS image_url';

/** Mêmes colonnes que ci-dessus, avec les dates en plus pour la vue détail. */
const ABILITY_DETAIL_SELECT_COLUMNS = ABILITY_SELECT_COLUMNS . ', ca.created_at AS created_at, ca.updated_at AS updated_at';

/**
 * Liste des emplacements de capacité valides, utilisée pour valider le
 * filtre ?slot=. Reprend l'ordre de définition de l'ENUM (voir
 * database/schema.sql) : passive puis les 4 sorts actifs.
 */
function getAbilitySlots(): array
{
    return ['passive', 'q', 'w', 'e', 'r'];
}

/**
 * Retourne les capacités correspondant aux filtres fournis, triées par
 * champion (nom), puis par emplacement (ordre naturel du kit : passive,
 * q, w, e, r — ordre de définition de l'ENUM 'slot'). $champion filtre
 * sur le slug du champion (c.slug), pas sur son nom affiché — comme
 * tier-list/repository.php::buildTierListWhereClause(). $champion et
 * $slot sont supposés déjà validés par l'appelant.
 */
function findAbilities(?string $champion, ?string $slot): array
{
    $sql = 'SELECT ' . ABILITY_SELECT_COLUMNS . '
        FROM champion_abilities ca
        INNER JOIN champions c ON c.id = ca.champion_id
        WHERE 1 = 1';
    $params = [];

    if ($champion !== null) {
        // BINARY : comparaison sensible à la casse, un slug est toujours
        // en minuscules (voir champions/repository.php pour le même choix
        // côté tier-list).
        $sql .= ' AND BINARY c.slug = :champion';
        $params['champion'] = $champion;
    }

    if ($slot !== null) {
        $sql .= ' AND ca.slot = :slot';
        $params['slot'] = $slot;
    }

    $sql .= ' ORDER BY c.name ASC, ca.slot ASC';

    return dbFetchAll($sql, $params);
}

/**
 * Retourne le détail d'une capacité par son ID (id, champion, slot,
 * name, description, image_url, dates), ou null si elle n'existe pas.
 */
function findAbilityById(int $id): ?array
{
    return dbFetchOne(
        'SELECT ' . ABILITY_DETAIL_SELECT_COLUMNS . '
         FROM champion_abilities ca
         INNER JOIN champions c ON c.id = ca.champion_id
         WHERE ca.id = :id',
        ['id' => $id]
    );
}
