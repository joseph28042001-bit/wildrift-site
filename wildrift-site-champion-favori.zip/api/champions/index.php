<?php
/**
 * Endpoint : /api/champions/
 * Ressource : Champions
 *
 * Un seul point d'entrée, différencié par la méthode HTTP et les
 * paramètres de requête (pas de réécriture d'URL pour des segments
 * /api/champions/{id}/ à ce stade — voir .htaccess) :
 *
 *   GET  /api/champions/                 → tous les champions
 *   GET  /api/champions/?id=5            → un champion par son ID
 *   GET  /api/champions/?search=lee      → recherche par nom (LIKE)
 *   GET  /api/champions/?role=jungle     → filtre par rôle
 *   POST /api/champions/                 → créer un champion
 *   PUT  /api/champions/?id=5            → modifier un champion existant
 *   DELETE /api/champions/?id=5          → supprimer un champion
 *
 * ?search= et ?role= peuvent être combinés (GET liste uniquement). ?id=
 * est prioritaire et exclusif pour GET (détail), et obligatoire pour
 * PUT/DELETE (mêmes règles de validation que la lecture).
 *
 * POST et PUT valident le corps JSON de la requête (voir
 * validateChampionPayload() ci-dessous) : slug (unique, format
 * minuscules/chiffres/tirets), name, role (enum), difficulty (entier de
 * 1 à 5), cc_level, engage_level, disengage_level, early_game_level,
 * late_game_level (chacun 'faible'/'moyen'/'fort') sont requis ; title
 * et image_url sont optionnels (null si absents/vides). PUT remplace
 * l'ensemble de ces champs (pas de modification partielle).
 *
 * DELETE supprime aussi, en cascade côté base de données, tout ce qui
 * référence ce champion (capacités, builds, matchups/counters, entrées
 * de tier list, synergies — voir REFERENCES champions ... ON DELETE
 * CASCADE dans database/schema.sql) : aucune suppression manuelle
 * supplémentaire n'est faite ici, la base s'en charge.
 *
 * Nouveauté par rapport à l'étape précédente (liste en lecture seule
 * uniquement) : POST/PUT/DELETE, au service de la nouvelle page de
 * gestion des champions dans l'espace d'administration (voir
 * admin/pages/champions.php et assets/js/admin-champions.js). Aucune
 * authentification n'est vérifiée à cette étape (voir admin/login.php,
 * dont la connexion effective n'est pas encore câblée côté serveur) :
 * ces trois méthodes d'écriture sont donc, pour l'instant, accessibles
 * sans connexion, au même titre que le reste de l'espace admin.
 *
 * Données lues/écrites depuis MySQL via PDO en requêtes préparées
 * (voir repository.php et config/database.php) — jamais de valeur
 * utilisateur concaténée dans le SQL.
 */

require_once __DIR__ . '/../core/bootstrap.php';
require_once __DIR__ . '/repository.php';

/**
 * Valide le corps JSON d'une création ou d'une modification de champion
 * et retourne un tableau prêt à être passé à insertChampion()/
 * updateChampion() (mêmes clés que CHAMPION_SELECT_COLUMNS, hormis
 * id/created_at/updated_at). Lève une ApiException 422 au premier champ
 * invalide — voir api/core/validator.php pour les helpers utilisés.
 */
function validateChampionPayload(array $body): array
{
    apiRequireFields($body, [
        'slug', 'name', 'role', 'difficulty',
        'cc_level', 'engage_level', 'disengage_level',
        'early_game_level', 'late_game_level',
    ]);

    $slug = apiValidateString($body['slug'], 'slug', 1, 60);
    if (!preg_match('/^[a-z0-9]+(-[a-z0-9]+)*$/', $slug)) {
        throw ApiException::validation(
            "Le champ 'slug' doit être en minuscules, chiffres et tirets uniquement (ex. 'lee-sin').",
            ['field' => 'slug']
        );
    }

    $name = apiValidateString($body['name'], 'name', 1, 60);

    $title = null;
    if (isset($body['title']) && $body['title'] !== '') {
        $title = apiValidateString($body['title'], 'title', 1, 120);
    }

    $role = apiValidateEnum($body['role'], 'role', getChampionRoles());
    $difficulty = apiValidateInt($body['difficulty'], 'difficulty', 1, 5);
    $ccLevel = apiValidateEnum($body['cc_level'], 'cc_level', getChampionCcLevels());
    $engageLevel = apiValidateEnum($body['engage_level'], 'engage_level', getChampionEngageLevels());
    $disengageLevel = apiValidateEnum($body['disengage_level'], 'disengage_level', getChampionEngageLevels());
    $earlyGameLevel = apiValidateEnum($body['early_game_level'], 'early_game_level', getChampionGamePhaseLevels());
    $lateGameLevel = apiValidateEnum($body['late_game_level'], 'late_game_level', getChampionGamePhaseLevels());

    $imageUrl = null;
    if (isset($body['image_url']) && $body['image_url'] !== '') {
        $imageUrl = apiValidateString($body['image_url'], 'image_url', 1, 255);
    }

    return [
        'slug'              => $slug,
        'name'              => $name,
        'title'             => $title,
        'role'              => $role,
        'difficulty'        => $difficulty,
        'cc_level'          => $ccLevel,
        'engage_level'      => $engageLevel,
        'disengage_level'   => $disengageLevel,
        'early_game_level'  => $earlyGameLevel,
        'late_game_level'   => $lateGameLevel,
        'image_url'         => $imageUrl,
    ];
}

apiRun(function (): void {
    apiRequireMethod(['GET', 'POST', 'PUT', 'DELETE']);

    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    // Écritures réservées à un administrateur connecté (voir api/core/auth.php).
    if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
        apiRequireAdmin();
    }

    // --- Création (POST) -------------------------------------------
    if ($method === 'POST') {
        $data = validateChampionPayload(apiGetJsonBody());

        if (findChampionBySlug($data['slug']) !== null) {
            throw ApiException::validation(
                "Ce slug est déjà utilisé par un autre champion.",
                ['field' => 'slug']
            );
        }

        $id = insertChampion($data);

        apiSuccess(findChampionById($id), 201);
        return;
    }

    // --- Modification et suppression (PUT/DELETE) : ?id= obligatoire
    if ($method === 'PUT' || $method === 'DELETE') {
        if (!isset($_GET['id']) || $_GET['id'] === '') {
            throw ApiException::badRequest("Le paramètre 'id' est requis pour cette méthode.");
        }

        $id = apiValidateInt($_GET['id'], 'id', 1);

        if (findChampionById($id) === null) {
            throw ApiException::notFound("Aucun champion trouvé avec l'ID $id.");
        }

        if ($method === 'DELETE') {
            deleteChampion($id);
            apiSuccess(['id' => $id]);
            return;
        }

        $data = validateChampionPayload(apiGetJsonBody());

        $existingWithSlug = findChampionBySlug($data['slug']);
        if ($existingWithSlug !== null && (int) $existingWithSlug['id'] !== $id) {
            throw ApiException::validation(
                "Ce slug est déjà utilisé par un autre champion.",
                ['field' => 'slug']
            );
        }

        updateChampion($id, $data);

        apiSuccess(findChampionById($id));
        return;
    }

    // --- Détail par ID (GET) ---------------------------------------
    if (isset($_GET['id']) && $_GET['id'] !== '') {
        $id = apiValidateInt($_GET['id'], 'id', 1);

        $champion = findChampionById($id);

        if ($champion === null) {
            throw ApiException::notFound("Aucun champion trouvé avec l'ID $id.");
        }

        apiSuccess($champion);
        return;
    }

    // --- Liste, avec filtres optionnels (recherche, rôle) [GET] ------
    $role = null;
    if (isset($_GET['role']) && $_GET['role'] !== '') {
        $role = apiValidateEnum($_GET['role'], 'role', getChampionRoles());
    }

    $search = null;
    if (isset($_GET['search']) && $_GET['search'] !== '') {
        $search = apiValidateString($_GET['search'], 'search', 1, 60);
    }

    $champions = findChampions($role, $search);

    apiSuccess($champions, 200, [
        'count'   => count($champions),
        'filters' => [
            'role'   => $role,
            'search' => $search,
        ],
    ]);
});
