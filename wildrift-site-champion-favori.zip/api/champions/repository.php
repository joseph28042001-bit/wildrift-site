<?php
/**
 * Accès aux données pour la ressource "champions".
 * Toutes les requêtes passent par dbFetchAll()/dbFetchOne() (config/database.php),
 * qui utilisent PDO en requêtes préparées (aucune valeur n'est jamais concaténée
 * dans le SQL). Ce fichier ne fait aucune validation d'entrée : c'est le rôle
 * de index.php, avant d'appeler ces fonctions.
 */

/** Colonnes exposées par l'API pour un champion (jamais SELECT *). */
const CHAMPION_SELECT_COLUMNS = 'id, slug, name, title, role, difficulty, cc_level, engage_level, disengage_level, early_game_level, late_game_level, image_url, created_at, updated_at';

/**
 * Liste des rôles Wild Rift valides, utilisée pour valider le filtre ?role=.
 */
function getChampionRoles(): array
{
    return ['baron', 'jungle', 'mid', 'dragon', 'support'];
}

/**
 * Niveaux de contrôle de foule (CC) valides pour un champion (colonne
 * cc_level) — pas de filtre correspondant sur l'API à cette étape,
 * exposée pour rester cohérente avec getChampionRoles() si un filtre
 * ?cc_level= est ajouté plus tard.
 */
function getChampionCcLevels(): array
{
    return ['faible', 'moyen', 'fort'];
}

/**
 * Niveaux d'engagement/disengage valides pour un champion (colonnes
 * engage_level et disengage_level) — même échelle et même principe que
 * getChampionCcLevels() ci-dessus, réutilisée pour les deux colonnes.
 */
function getChampionEngageLevels(): array
{
    return ['faible', 'moyen', 'fort'];
}

/**
 * Niveaux de puissance early/late game valides pour un champion
 * (colonnes early_game_level et late_game_level) — même échelle et même
 * principe que getChampionCcLevels()/getChampionEngageLevels().
 */
function getChampionGamePhaseLevels(): array
{
    return ['faible', 'moyen', 'fort'];
}

/**
 * Retourne les champions correspondant aux filtres fournis, triés par nom.
 * $role et $search sont supposés déjà validés par l'appelant.
 */
function findChampions(?string $role, ?string $search): array
{
    $sql = 'SELECT ' . CHAMPION_SELECT_COLUMNS . ' FROM champions WHERE 1 = 1';
    $params = [];

    if ($role !== null) {
        $sql .= ' AND role = :role';
        $params['role'] = $role;
    }

    if ($search !== null) {
        $sql .= ' AND name LIKE :search';
        $params['search'] = '%' . $search . '%';
    }

    $sql .= ' ORDER BY name ASC';

    return dbFetchAll($sql, $params);
}

/**
 * Retourne un champion par son ID, ou null s'il n'existe pas.
 */
function findChampionById(int $id): ?array
{
    return dbFetchOne(
        'SELECT ' . CHAMPION_SELECT_COLUMNS . ' FROM champions WHERE id = :id',
        ['id' => $id]
    );
}

/**
 * Retourne un champion par son slug, ou null s'il n'existe pas — utilisé
 * par index.php pour vérifier l'unicité du slug à la création et à la
 * modification (colonne `slug` UNIQUE, voir database/schema.sql), avant
 * même de tenter la requête d'écriture.
 */
function findChampionBySlug(string $slug): ?array
{
    return dbFetchOne(
        'SELECT ' . CHAMPION_SELECT_COLUMNS . ' FROM champions WHERE slug = :slug',
        ['slug' => $slug]
    );
}

/**
 * Insère un nouveau champion et retourne son ID généré. $data est
 * supposé déjà validé par l'appelant (voir validateChampionPayload()
 * dans index.php) : mêmes clés que CHAMPION_SELECT_COLUMNS, hormis
 * id/created_at/updated_at (gérés par la base).
 */
function insertChampion(array $data): int
{
    dbExecute(
        'INSERT INTO champions (
            slug, name, title, role, difficulty,
            cc_level, engage_level, disengage_level,
            early_game_level, late_game_level, image_url
        ) VALUES (
            :slug, :name, :title, :role, :difficulty,
            :cc_level, :engage_level, :disengage_level,
            :early_game_level, :late_game_level, :image_url
        )',
        $data
    );

    return (int) dbLastInsertId();
}

/**
 * Remplace les champs modifiables d'un champion existant. $data est
 * supposé déjà validé par l'appelant, même forme que insertChampion().
 * L'existence de $id est supposée déjà vérifiée par l'appelant (voir
 * index.php) : ne fait rien si l'ID n'existe pas (0 ligne affectée).
 */
function updateChampion(int $id, array $data): void
{
    $data['id'] = $id;

    dbExecute(
        'UPDATE champions SET
            slug = :slug,
            name = :name,
            title = :title,
            role = :role,
            difficulty = :difficulty,
            cc_level = :cc_level,
            engage_level = :engage_level,
            disengage_level = :disengage_level,
            early_game_level = :early_game_level,
            late_game_level = :late_game_level,
            image_url = :image_url
        WHERE id = :id',
        $data
    );
}

/**
 * Supprime un champion par son ID. Les tables liées (capacités, builds,
 * matchups/counters, tier list, synergies — voir database/schema.sql,
 * REFERENCES champions ... ON DELETE CASCADE) sont automatiquement
 * nettoyées par la base : aucune suppression manuelle supplémentaire
 * n'est nécessaire ici. L'existence de $id est supposée déjà vérifiée
 * par l'appelant (voir index.php).
 */
function deleteChampion(int $id): void
{
    dbExecute('DELETE FROM champions WHERE id = :id', ['id' => $id]);
}
