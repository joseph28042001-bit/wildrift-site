<?php
/**
 * Endpoint : /api/patches/
 * Ressource : Patchs (table `patches`, voir includes/patches.php et
 * docs/mysql.md, section `patches`) — au service de la nouvelle section
 * "Gestion des patches" de l'espace d'administration (voir
 * admin/pages/patches.php et assets/js/admin-patches.js), sur le même
 * modèle que /api/champions/, /api/items/, /api/runes/, /api/builds/ et
 * /api/news/ :
 *
 *   GET   /api/patches/                  → tous les patchs (le patch
 *                                          actif en premier, voir
 *                                          findAllPatches())
 *   GET   /api/patches/?id=5             → un patch par son ID
 *   POST  /api/patches/                  → créer un patch (inactif par
 *                                          défaut, voir insertPatch())
 *   PUT   /api/patches/?id=5             → modifier les informations
 *                                          d'un patch (version, date de
 *                                          sortie, description) — ne
 *                                          change jamais is_active
 *   PATCH /api/patches/?id=5             → activer/désactiver un patch
 *                                          (corps JSON {"is_active":
 *                                          true|false}, voir
 *                                          setPatchActiveState()) —
 *                                          même convention que
 *                                          PATCH /api/news/ (publication)
 *
 * GET est public (lecture seule, comme le reste de l'API) ; POST, PUT et
 * PATCH sont réservés à un administrateur connecté (apiRequireAdmin(),
 * voir api/core/auth.php).
 *
 * Activer un patch (PATCH avec is_active=true) désactive automatiquement,
 * dans la même transaction, le patch actif précédent : le site n'a donc
 * jamais plus d'un patch actif à la fois (voir setPatchActiveState(),
 * includes/patches.php). Désactiver un patch (is_active=false) ne
 * touche que ce patch, sans en activer un autre à sa place.
 *
 * Aucune suppression (DELETE) n'est exposée à cette étape : retirer un
 * patch de la liste n'est pas un besoin exprimé, et la table `patches`
 * étant référencée par patch_id (ON DELETE SET NULL, voir
 * database/migration_patch_links.sql) depuis champions/items/runes/
 * builds/tier_list/counters/synergies, une suppression mal maîtrisée
 * détacherait silencieusement ces données de leur patch — hors
 * périmètre de cette étape.
 *
 * Données lues/écrites depuis MySQL via PDO en requêtes préparées (voir
 * includes/patches.php et config/database.php) — jamais de valeur
 * utilisateur concaténée dans le SQL.
 */

require_once __DIR__ . '/../core/bootstrap.php';
require_once __DIR__ . '/../../includes/patches.php';

/**
 * Valide le corps JSON d'une création ou d'une modification de patch et
 * retourne un tableau prêt à être passé à insertPatch()/updatePatch() :
 * 'version', 'release_date' (nullable), 'description' (nullable). Lève
 * une ApiException 422 au premier champ invalide.
 */
function validatePatchPayload(array $body): array
{
    apiRequireFields($body, ['version']);

    $version = apiValidateString($body['version'], 'version', 1, 10);

    $releaseDate = null;
    if (isset($body['release_date']) && $body['release_date'] !== '') {
        $releaseDate = apiValidateString($body['release_date'], 'release_date', 10, 10);

        $parts = explode('-', $releaseDate);
        if (
            count($parts) !== 3
            || !ctype_digit($parts[0]) || !ctype_digit($parts[1]) || !ctype_digit($parts[2])
            || !checkdate((int) $parts[1], (int) $parts[2], (int) $parts[0])
        ) {
            throw ApiException::validation(
                "Le champ 'release_date' doit être une date valide au format AAAA-MM-JJ.",
                ['field' => 'release_date']
            );
        }
    }

    $description = null;
    if (isset($body['description']) && $body['description'] !== '') {
        $description = apiValidateString($body['description'], 'description', 1, 500);
    }

    return [
        'version'      => $version,
        'release_date' => $releaseDate,
        'description'  => $description,
    ];
}

apiRun(function (): void {
    apiRequireMethod(['GET', 'POST', 'PUT', 'PATCH']);

    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    // Écritures réservées à un administrateur connecté (voir api/core/auth.php).
    if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
        apiRequireAdmin();
    }

    // --- Création (POST) -------------------------------------------
    if ($method === 'POST') {
        $data = validatePatchPayload(apiGetJsonBody());

        if (findPatchByVersion($data['version']) !== null) {
            throw ApiException::validation(
                'Cette version de patch existe déjà.',
                ['field' => 'version']
            );
        }

        $id = insertPatch($data);

        apiSuccess(findPatchById($id), 201);
        return;
    }

    // --- Activation/désactivation (PATCH ?id=) -----------------------
    if ($method === 'PATCH') {
        if (!isset($_GET['id']) || $_GET['id'] === '') {
            throw ApiException::badRequest("Le paramètre 'id' est requis pour cette méthode.");
        }

        $id = apiValidateInt($_GET['id'], 'id', 1);

        if (findPatchById($id) === null) {
            throw ApiException::notFound("Aucun patch trouvé avec l'ID $id.");
        }

        $body = apiGetJsonBody();

        apiRequireFields($body, ['is_active']);
        if (!is_bool($body['is_active'])) {
            throw ApiException::validation(
                "Le champ 'is_active' doit être un booléen (true ou false).",
                ['field' => 'is_active']
            );
        }

        setPatchActiveState($id, $body['is_active']);

        apiSuccess(findPatchById($id));
        return;
    }

    // --- Modification (PUT ?id=) --------------------------------------
    if ($method === 'PUT') {
        if (!isset($_GET['id']) || $_GET['id'] === '') {
            throw ApiException::badRequest("Le paramètre 'id' est requis pour cette méthode.");
        }

        $id = apiValidateInt($_GET['id'], 'id', 1);

        if (findPatchById($id) === null) {
            throw ApiException::notFound("Aucun patch trouvé avec l'ID $id.");
        }

        $data = validatePatchPayload(apiGetJsonBody());

        $existingWithVersion = findPatchByVersion($data['version']);
        if ($existingWithVersion !== null && (int) $existingWithVersion['id'] !== $id) {
            throw ApiException::validation(
                'Cette version de patch est déjà utilisée par un autre patch.',
                ['field' => 'version']
            );
        }

        updatePatch($id, $data);

        apiSuccess(findPatchById($id));
        return;
    }

    // --- Détail par ID (GET) ---------------------------------------
    if (isset($_GET['id']) && $_GET['id'] !== '') {
        $id = apiValidateInt($_GET['id'], 'id', 1);

        $patch = findPatchById($id);

        if ($patch === null) {
            throw ApiException::notFound("Aucun patch trouvé avec l'ID $id.");
        }

        apiSuccess($patch);
        return;
    }

    // --- Liste (GET) ---------------------------------------------------
    $patches = findAllPatches();

    apiSuccess($patches, 200, ['count' => count($patches)]);
});
