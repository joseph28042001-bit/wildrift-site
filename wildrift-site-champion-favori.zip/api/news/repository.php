<?php
/**
 * Accès aux données pour la ressource "news" (actualités).
 * Toutes les requêtes passent par dbFetchAll()/dbFetchOne() (config/database.php),
 * qui utilisent PDO en requêtes préparées (aucune valeur n'est jamais concaténée
 * dans le SQL). Ce fichier ne fait aucune validation d'entrée : c'est le rôle
 * de index.php, avant d'appeler ces fonctions.
 *
 * Étape actuelle : structure minimale, sur le modèle des autres ressources
 * (voir api/champions/repository.php, api/builds/repository.php...) — une
 * seule fonction de lecture (liste complète, sans filtre ni détail par ID),
 * qui viendront dans de prochaines étapes.
 */

/**
 * Colonnes exposées par l'API pour un article, en liste : jamais SELECT *.
 * Le corps complet de l'article ('content') n'est volontairement pas
 * exposé ici — il est réservé à la vue détail (?id=), voir
 * NEWS_DETAIL_SELECT_COLUMNS ci-dessous.
 */
const NEWS_SELECT_COLUMNS = 'id, slug, title, excerpt, category, image_url, published_at';

/**
 * Colonnes exposées par l'API pour le détail d'un article (GET ?id=) :
 * les colonnes de la liste, plus le corps complet ('content') et les
 * dates, propres à la vue détail — même convention que
 * TIER_LIST_DETAIL_SELECT_COLUMNS (tier-list/repository.php).
 */
const NEWS_DETAIL_SELECT_COLUMNS = NEWS_SELECT_COLUMNS . ', content, created_at, updated_at';

/**
 * Nombre maximal d'articles pouvant être demandés via ?limit= (voir
 * findAllNews() ci-dessous) — évite qu'un client ne demande une valeur
 * disproportionnée tant qu'il n'y a pas de pagination complète sur cette
 * ressource (voir BUILD_PAGE_SIZE, builds/repository.php, pour la
 * pagination classique déjà en place sur /api/builds/).
 */
const NEWS_MAX_RECENT_LIMIT = 20;

/**
 * Liste des catégories d'actualités valides (voir database/schema.sql) :
 * 'patch' (notes de mise à jour), 'esport' (compétition), 'evenement'
 * (événements en jeu à durée limitée), 'communaute' (créateurs de
 * contenu, sondages...). Utilisée par index.php pour valider le filtre
 * ?category= — même convention que getChampionRoles()
 * (champions/repository.php).
 */
function getNewsCategories(): array
{
    return ['patch', 'esport', 'evenement', 'communaute'];
}

/**
 * Retourne les actualités publiées correspondant aux filtres fournis
 * (optionnels, combinables), triées par date de publication (la plus
 * récente d'abord). $search, $category et $limit sont supposés déjà
 * validés par l'appelant. Pas encore de pagination complète (page/offset)
 * à cette étape.
 *
 * La recherche porte sur le titre de l'article (LIKE, insensible à la
 * casse par défaut en MySQL/MariaDB) — même principe que
 * findChampions()/findItems()/findRunes() (recherche par nom). Le filtre
 * de catégorie est une égalité exacte sur l'ENUM `category` (voir
 * getNewsCategories() et database/schema.sql).
 *
 * $limit (optionnel, borné à NEWS_MAX_RECENT_LIMIT par l'appelant) limite
 * le nombre de résultats aux $limit plus récents : comme le tri se fait
 * déjà par published_at DESC, cela revient à récupérer "les articles
 * récents". Laissé à null (défaut), le comportement est inchangé : tous
 * les résultats correspondants sont renvoyés, sans LIMIT.
 *
 * LIMIT n'est pas lié via les paramètres préparés habituels : avec
 * PDO::ATTR_EMULATE_PREPARES à false (voir config/database.php), MySQL
 * refuse une valeur liée à cette clause. On l'insère donc directement
 * dans le SQL, ce qui reste sûr ici : c'est un entier PHP déjà validé
 * (jamais une chaîne provenant directement de la requête utilisateur) —
 * même choix que findBuilds() (builds/repository.php).
 *
 * Les articles non encore publiés (published_at NULL, ex. un brouillon)
 * sont exclus : cette fonction ne renvoie que ce qu'un visiteur du site
 * peut légitimement voir. NULLS LAST n'existe pas en MySQL 5.7 ; comme un
 * brouillon est de toute façon exclu par le WHERE, l'ordre par
 * published_at DESC seul suffit ici.
 */
function findAllNews(?string $search = null, ?string $category = null, ?int $limit = null): array
{
    $sql = 'SELECT ' . NEWS_SELECT_COLUMNS . '
            FROM news
            WHERE published_at IS NOT NULL';
    $params = [];

    if ($search !== null) {
        $sql .= ' AND title LIKE :search';
        $params['search'] = '%' . $search . '%';
    }

    if ($category !== null) {
        $sql .= ' AND category = :category';
        $params['category'] = $category;
    }

    $sql .= ' ORDER BY published_at DESC';

    if ($limit !== null) {
        $sql .= ' LIMIT ' . $limit;
    }

    return dbFetchAll($sql, $params);
}

/**
 * Retourne le détail d'un article précis (id, slug, title, excerpt,
 * category, image_url, published_at, content, dates), ou null s'il
 * n'existe pas. $id est supposé déjà validé par l'appelant.
 *
 * Un article non publié (published_at NULL, ex. un brouillon) n'est
 * jamais renvoyé, même par ID — même règle que findAllNews() : cette
 * fonction ne renvoie que ce qu'un visiteur du site peut légitimement
 * voir.
 */
function findNewsById(int $id): ?array
{
    return dbFetchOne(
        'SELECT ' . NEWS_DETAIL_SELECT_COLUMNS . '
         FROM news
         WHERE id = :id
           AND published_at IS NOT NULL',
        ['id' => $id]
    );
}

/**
 * Retourne tous les articles, publiés ET brouillons (published_at NULL),
 * pour l'espace d'administration — contrairement à findAllNews()/
 * findNewsById(), réservées à ce qu'un visiteur public peut voir. Les
 * brouillons sont affichés en premier (les plus récemment créés
 * d'abord), puis les articles publiés (du plus récent au plus ancien) —
 * pour que l'admin voie d'abord ce qui reste à publier.
 */
function findAllNewsForAdmin(): array
{
    return dbFetchAll(
        'SELECT ' . NEWS_SELECT_COLUMNS . '
         FROM news
         ORDER BY (published_at IS NULL) DESC, published_at DESC, created_at DESC'
    );
}

/**
 * Retourne le détail d'un article par ID, sans filtrer sur son état de
 * publication (contrairement à findNewsById()) — pour que l'admin
 * puisse retrouver un brouillon avant de le publier. $id est supposé
 * déjà validé par l'appelant.
 */
function findNewsByIdForAdmin(int $id): ?array
{
    return dbFetchOne(
        'SELECT ' . NEWS_SELECT_COLUMNS . '
         FROM news
         WHERE id = :id',
        ['id' => $id]
    );
}

/**
 * Publie ($published = true, published_at = maintenant) ou dépublie
 * ($published = false, published_at = NULL) un article. $id est
 * supposé déjà validé et existant (voir findNewsByIdForAdmin()).
 */
function setNewsPublishState(int $id, bool $published): void
{
    dbExecute(
        'UPDATE news SET published_at = ' . ($published ? 'NOW()' : 'NULL') . '
         WHERE id = :id',
        ['id' => $id]
    );
}
