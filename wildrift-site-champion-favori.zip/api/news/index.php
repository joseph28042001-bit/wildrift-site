<?php
/**
 * Endpoint : /api/news/
 * Ressource : Actualités (news)
 *
 * Étape actuelle : liste complète des actualités publiées, avec recherche
 * optionnelle par titre, filtre optionnel par catégorie et récupération
 * optionnelle des articles récents (combinables entre eux), le détail
 * d'un article précis par son ID, et désormais la publication/
 * dépublication d'un article (espace admin) — même convention que
 * /api/champions/, /api/items/, /api/runes/, /api/builds/ et
 * /api/tier-list/ :
 *
 *   GET   /api/news/                     → toutes les actualités publiées
 *   GET   /api/news/?search=patch        → recherche par titre (LIKE)
 *   GET   /api/news/?category=esport     → filtre par catégorie
 *   GET   /api/news/?limit=3             → les 3 articles les plus récents
 *   GET   /api/news/?id=5                → un article précis (détail complet)
 *   GET   /api/news/?all=1               → tous les articles, brouillons
 *                                           inclus (espace admin, voir
 *                                           findAllNewsForAdmin())
 *   PATCH /api/news/?id=5                → publie/dépublie l'article
 *                                           (espace admin, voir plus bas)
 *
 * ?search=, ?category= et ?limit= sont combinables (ex. ?category=patch
 * &limit=3 → les 3 articles "patch" les plus récents). ?id= est
 * prioritaire et exclusif : s'il est présent, les autres filtres sont
 * ignorés. ?all=1 est exclusif lui aussi (ignore ?search=/?category=/
 * ?limit=) : réservé à la liste de gestion de l'espace admin (voir
 * admin/pages/news.php et assets/js/admin-news.js), il expose aussi les
 * brouillons (published_at NULL) — contrairement à toutes les autres
 * variantes de GET sur cet endpoint, qui ne renvoient que les articles
 * publiés (voir findAllNews() et findNewsById(), repository.php).
 *
 * PATCH ?id= attend un corps JSON {"published": true|false} et bascule
 * published_at (maintenant si true, NULL si false) via
 * setNewsPublishState() — seul ce champ est modifiable par cet endpoint ;
 * titre, contenu, catégorie, etc. ne sont pas concernés (hors périmètre
 * de cette étape, aucun formulaire de création/modification d'article
 * n'existe encore). Comme pour les autres écritures déjà en place
 * (POST/PUT/DELETE /api/champions/, .../items/, .../builds/, .../runes/),
 * aucune authentification n'est vérifiée à cette étape (voir
 * admin/login.php, dont la connexion effective n'est pas encore câblée
 * côté serveur).
 *
 * Gestion des erreurs :
 *   - ?id= non entier ou < 1 → 422 validation_error (apiValidateInt()) ;
 *   - ?id= valide mais aucun article correspondant (publié pour GET
 *     simple, tout état confondu pour ?all=1/PATCH) → 404 not_found ;
 *   - ?search= trop long (> 150 caractères) → 422 validation_error ;
 *   - ?category= hors énumération (patch/esport/evenement/communaute)
 *     → 422 validation_error (apiValidateEnum()) ;
 *   - ?limit= non entier, < 1 ou > NEWS_MAX_RECENT_LIMIT (20)
 *     → 422 validation_error (apiValidateInt()) ;
 *   - PATCH sans le champ 'published', ou avec une valeur non booléenne
 *     → 422 validation_error.
 *
 * Pas encore de pagination complète (page/offset) à cette étape : viendra
 * dans une prochaine étape, sur le modèle de /api/builds/.
 *
 * Données lues/écrites depuis MySQL via PDO en requêtes préparées
 * (voir repository.php et config/database.php) — jamais de valeur
 * utilisateur concaténée dans le SQL.
 */

require_once __DIR__ . "/../core/bootstrap.php";
require_once __DIR__ . "/repository.php";

apiRun(function (): void {
    apiRequireMethod(['GET', 'PATCH']);

    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    // Écritures réservées à un administrateur connecté (voir api/core/auth.php).
    if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
        apiRequireAdmin();
    }

    // --- Publication/dépublication (PATCH, espace admin) --------------
    if ($method === 'PATCH') {
        if (!isset($_GET['id']) || $_GET['id'] === '') {
            throw ApiException::badRequest("Le paramètre 'id' est requis pour cette méthode.");
        }

        $id = apiValidateInt($_GET['id'], 'id', 1);

        if (findNewsByIdForAdmin($id) === null) {
            throw ApiException::notFound("Aucun article trouvé avec l'ID $id.");
        }

        $body = apiGetJsonBody();

        apiRequireFields($body, ['published']);
        if (!is_bool($body['published'])) {
            throw ApiException::validation(
                "Le champ 'published' doit être un booléen (true ou false).",
                ['field' => 'published']
            );
        }

        setNewsPublishState($id, $body['published']);

        apiSuccess(findNewsByIdForAdmin($id));
        return;
    }

    // --- Liste de gestion, brouillons inclus (GET ?all=1, espace admin)
    if (isset($_GET['all']) && $_GET['all'] !== '') {
        $news = findAllNewsForAdmin();

        apiSuccess($news, 200, ['count' => count($news)]);
        return;
    }

    // --- Détail par ID -----------------------------------------------
    if (isset($_GET['id']) && $_GET['id'] !== '') {
        $id = apiValidateInt($_GET['id'], 'id', 1);

        $article = findNewsById($id);

        if ($article === null) {
            throw ApiException::notFound("Aucun article publié trouvé avec l'ID $id.");
        }

        apiSuccess($article);
        return;
    }

    // --- Liste, avec filtres optionnels (recherche, catégorie, limite) --
    $search = null;
    if (isset($_GET['search']) && $_GET['search'] !== '') {
        $search = apiValidateString($_GET['search'], 'search', 1, 150);
    }

    $category = null;
    if (isset($_GET['category']) && $_GET['category'] !== '') {
        $category = apiValidateEnum($_GET['category'], 'category', getNewsCategories());
    }

    $limit = null;
    if (isset($_GET['limit']) && $_GET['limit'] !== '') {
        $limit = apiValidateInt($_GET['limit'], 'limit', 1, NEWS_MAX_RECENT_LIMIT);
    }

    $news = findAllNews($search, $category, $limit);

    apiSuccess($news, 200, [
        'count'   => count($news),
        'filters' => [
            'search'   => $search,
            'category' => $category,
            'limit'    => $limit,
        ],
    ]);
});
