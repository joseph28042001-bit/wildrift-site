<?php
/**
 * Endpoint : /api/rune-trees/
 * Ressource : Arbres de runes (rune_trees)
 *
 * Un seul point d'entrée, différencié par les paramètres de requête GET
 * (pas de réécriture d'URL pour des segments /api/rune-trees/{id}/ à ce
 * stade — voir .htaccess) :
 *
 *   GET /api/rune-trees/                  → tous les arbres (5, triés par nom)
 *   GET /api/rune-trees/?id=5             → un arbre par son ID
 *
 * Pas de filtre de recherche ni de pagination ici : contrairement aux
 * autres ressources, rune_trees est une table de référence à 5 lignes
 * fixes — la liste complète est toujours le cas d'usage normal (par
 * exemple pour peupler le filtre ?tree= de /api/runes/, voir
 * assets/js/runes.js).
 *
 * Données lues depuis MySQL via PDO en requêtes préparées
 * (voir repository.php et config/database.php) — jamais de valeur
 * utilisateur concaténée dans le SQL.
 */

require_once __DIR__ . '/../core/bootstrap.php';
require_once __DIR__ . '/repository.php';

apiRun(function (): void {
    apiRequireMethod(['GET']);

    // --- Détail par ID -------------------------------------------------
    if (isset($_GET['id']) && $_GET['id'] !== '') {
        $id = apiValidateInt($_GET['id'], 'id', 1);

        $tree = findRuneTreeById($id);

        if ($tree === null) {
            throw ApiException::notFound("Aucun arbre de runes trouvé avec l'ID $id.");
        }

        apiSuccess($tree);
        return;
    }

    // --- Liste, sans filtre (voir docblock ci-dessus) -------------------
    $trees = findRuneTrees();

    apiSuccess($trees, 200, [
        'count' => count($trees),
    ]);
});
