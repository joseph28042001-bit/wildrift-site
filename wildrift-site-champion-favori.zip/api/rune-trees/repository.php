<?php
/**
 * Accès aux données pour la ressource "rune-trees" (arbres de runes).
 * Toutes les requêtes passent par dbFetchAll()/dbFetchOne() (config/database.php),
 * qui utilisent PDO en requêtes préparées (aucune valeur n'est jamais concaténée
 * dans le SQL). Ce fichier ne fait aucune validation d'entrée : c'est le rôle
 * de index.php, avant d'appeler ces fonctions.
 *
 * Connecté à la table "rune_trees" (voir database/schema.sql) : une
 * table de référence à 5 lignes fixes (une par arbre), sans lien de
 * clé étrangère avec `runes` — le rapprochement se fait par slug (même
 * valeur que l'ENUM runes.tree), comme documenté sur la table.
 */

/** Colonnes exposées par l'API pour un arbre de runes (jamais SELECT *). */
const RUNE_TREE_SELECT_COLUMNS = 'id, slug, name, description, image_url';

/**
 * Retourne tous les arbres de runes, triés par nom.
 */
function findRuneTrees(): array
{
    return dbFetchAll(
        'SELECT ' . RUNE_TREE_SELECT_COLUMNS . ' FROM rune_trees ORDER BY name ASC'
    );
}

/**
 * Retourne un arbre de runes par son ID, ou null s'il n'existe pas.
 */
function findRuneTreeById(int $id): ?array
{
    return dbFetchOne(
        'SELECT ' . RUNE_TREE_SELECT_COLUMNS . ' FROM rune_trees WHERE id = :id',
        ['id' => $id]
    );
}
