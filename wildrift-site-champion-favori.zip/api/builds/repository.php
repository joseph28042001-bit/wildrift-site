<?php
/**
 * Accès aux données pour la ressource "builds".
 * Toutes les requêtes passent par dbFetchAll()/dbFetchOne() (config/database.php),
 * qui utilisent PDO en requêtes préparées (aucune valeur n'est jamais concaténée
 * dans le SQL). Ce fichier ne fait aucune validation d'entrée : c'est le rôle
 * de index.php, avant d'appeler ces fonctions.
 */

// Rattachement à un patch (colonne patch_id) : voir includes/patches.php.
require_once __DIR__ . '/../../includes/patches.php';

/**
 * Colonnes exposées par l'API pour un build : uniquement les informations
 * essentielles (id, nom, champion, rôle, patch) — jamais SELECT *, et
 * jamais champion_id brut : le nom du champion est résolu par jointure
 * sur la table `champions`.
 *
 * champion_slug (slug du champion, voir champions.slug) s'ajoute ici
 * uniquement pour permettre la navigation champion → /builds/<slug>
 * (voir assets/js/home.js) : un champ en plus, aucun champ retiré, donc
 * sans impact sur les consommateurs existants de cette liste.
 */
const BUILD_SELECT_COLUMNS = 'b.id AS id, b.name AS name, c.name AS champion, c.slug AS champion_slug, b.role AS role, b.patch AS patch';

/**
 * Colonnes exposées par l'API pour le détail d'un build (GET ?id=) :
 * les colonnes de la liste, plus la description et la source, propres
 * à la vue détail, ainsi que champion_id — nécessaire à l'espace
 * d'administration pour pré-remplir le sélecteur de champion du
 * formulaire de modification (voir admin/pages/builds.php et
 * assets/js/admin-builds.js), la liste (BUILD_SELECT_COLUMNS) ne
 * l'exposant volontairement pas (voir plus haut). Toujours pas de
 * SELECT *.
 */
const BUILD_DETAIL_SELECT_COLUMNS = BUILD_SELECT_COLUMNS . ', b.champion_id AS champion_id, b.description AS description, b.source AS source';

/**
 * Colonnes exposées par l'API pour un objet associé à un build : un
 * sous-ensemble plus léger que ITEM_SELECT_COLUMNS (items/repository.php)
 * — pas de dates, le détail complet d'un objet restant du ressort de
 * /api/items/?id=. `description` est incluse (contrairement au reste de
 * cet allègement) : c'est le seul texte disponible dans le modèle de
 * données actuel pour expliquer quand utiliser une botte (section
 * Bottes de pages/champion-build.php — voir assets/js/champion-build.js
 * ::renderBootsSection()), aucune colonne dédiée à cet usage n'existant.
 */
const BUILD_ITEM_SELECT_COLUMNS = 'i.id AS id, i.slug AS slug, i.name AS name, i.category AS category, i.price AS price, i.description AS description, i.image_url AS image_url';

/**
 * Colonnes exposées par l'API pour une rune associée à un build : même
 * logique d'allègement que BUILD_ITEM_SELECT_COLUMNS — pas de
 * description ni de dates, le détail complet d'une rune restant du
 * ressort de /api/runes/?id=. `image_url` est incluse pour permettre
 * l'affichage de l'icône de la rune (section Runes de
 * pages/champion-build.php — voir assets/js/champion-build.js::
 * renderRuneChip()), alimentée depuis l'admin Runes (admin/pages/runes.php).
 */
const BUILD_RUNE_SELECT_COLUMNS = 'r.id AS id, r.slug AS slug, r.name AS name, r.tree AS tree, r.slot AS slot, r.image_url AS image_url';

/**
 * Nombre de builds renvoyés par page sur la liste (GET /api/builds/?page=N).
 * Valeur fixe pour cette étape : pas de ?per_page= côté client.
 */
const BUILD_PAGE_SIZE = 5;

/**
 * Liste des slots valides pour un objet de build (table de relation
 * `build_items`) : objets de départ, objets principaux, bottes,
 * enchantement de bottes, objets situationnels.
 */
function getBuildItemSlots(): array
{
    return ['starting', 'core', 'boots', 'enchantment', 'situational'];
}

/**
 * Liste des rôles Wild Rift valides, utilisée pour valider le filtre ?role=.
 * Dupliquée depuis champions/repository.php plutôt qu'importée : chaque
 * ressource de l'API reste autonome (voir le même choix dans items/ et
 * runes/), et builds.role partage volontairement l'ENUM de champions.role
 * (voir database/schema.sql).
 */
function getBuildRoles(): array
{
    return ['baron', 'jungle', 'mid', 'dragon', 'support'];
}

/**
 * Construit la clause WHERE (+ ses paramètres liés) commune à findBuilds()
 * et countBuilds(), à partir des mêmes filtres optionnels. $champion, $role,
 * $patch et $search sont supposés déjà validés par l'appelant. $champion
 * filtre sur le slug du champion (c.slug), pas sur son nom affiché.
 * Usage interne à ce fichier uniquement.
 *
 * @return array{0: string, 1: array<string, string>} [clause SQL, paramètres liés]
 */
function buildBuildsWhereClause(?string $champion, ?string $role, ?string $patch, ?string $search): array
{
    $sql = 'WHERE 1 = 1';
    $params = [];

    if ($champion !== null) {
        // BINARY force une comparaison sensible à la casse : la collation par
        // défaut de `champions` (utf8mb4_unicode_ci, voir database/schema.sql)
        // est insensible à la casse, ce qui ferait autrement matcher
        // champion=Jinx sur le slug jinx. Le slug est censé être une clé
        // exacte (voir docblock d'index.php : "filtre par slug, pas par nom
        // affiché ni casse libre"), pas une recherche texte libre.
        $sql .= ' AND BINARY c.slug = :champion';
        $params['champion'] = $champion;
    }

    if ($role !== null) {
        $sql .= ' AND b.role = :role';
        $params['role'] = $role;
    }

    if ($patch !== null) {
        $sql .= ' AND b.patch = :patch';
        $params['patch'] = $patch;
    }

    if ($search !== null) {
        $sql .= ' AND b.name LIKE :search';
        $params['search'] = '%' . $search . '%';
    }

    return [$sql, $params];
}

/**
 * Retourne les builds correspondant aux filtres fournis (tous optionnels),
 * triés par nom, avec le nom du champion associé résolu via une jointure
 * sur `champions` (champion_id → champions.id).
 * $champion, $role, $patch et $search sont supposés déjà validés par
 * l'appelant. $champion filtre sur le slug du champion (c.slug), pas sur
 * son nom affiché.
 *
 * $page (optionnel) active la pagination : $page=1 renvoie les
 * BUILD_PAGE_SIZE premiers résultats, $page=2 les suivants, etc. $page est
 * supposé déjà validé par l'appelant (entier >= 1). Laissé à null (défaut),
 * le comportement est inchangé : tous les résultats sont renvoyés, sans
 * LIMIT — c'est le cas utilisé par findAllBuilds() ci-dessous.
 *
 * LIMIT/OFFSET ne sont pas liés via les paramètres préparés habituels : avec
 * PDO::ATTR_EMULATE_PREPARES à false (voir config/database.php), MySQL
 * refuse une valeur liée à ces clauses. On les insère donc directement dans
 * le SQL, ce qui reste sûr ici : ce sont des entiers PHP déjà validés
 * (jamais une chaîne provenant directement de la requête utilisateur).
 */
function findBuilds(?string $champion, ?string $role, ?string $patch, ?string $search, ?int $page = null): array
{
    [$where, $params] = buildBuildsWhereClause($champion, $role, $patch, $search);

    $sql = 'SELECT ' . BUILD_SELECT_COLUMNS . '
            FROM builds b
            INNER JOIN champions c ON c.id = b.champion_id
            ' . $where . '
            ORDER BY b.name ASC';

    if ($page !== null) {
        $offset = ($page - 1) * BUILD_PAGE_SIZE;
        $sql .= ' LIMIT ' . BUILD_PAGE_SIZE . ' OFFSET ' . $offset;
    }

    return dbFetchAll($sql, $params);
}

/**
 * Retourne le nombre total de builds correspondant aux filtres fournis
 * (mêmes filtres, mêmes règles de validation que findBuilds(), jamais
 * paginé) — utilisé pour calculer le nombre total de pages en meta de la
 * réponse liste (voir index.php).
 */
function countBuilds(?string $champion, ?string $role, ?string $patch, ?string $search): int
{
    [$where, $params] = buildBuildsWhereClause($champion, $role, $patch, $search);

    $sql = 'SELECT COUNT(*) AS total
            FROM builds b
            INNER JOIN champions c ON c.id = b.champion_id
            ' . $where;

    $row = dbFetchOne($sql, $params);

    return $row !== null ? (int) $row['total'] : 0;
}

/**
 * Retourne tous les builds, sans filtre ni pagination. Conservée telle
 * quelle (même nom, même signature, même résultat) pour ne rien changer au
 * comportement existant ; s'appuie désormais sur findBuilds() en interne.
 */
function findAllBuilds(): array
{
    return findBuilds(null, null, null, null);
}

/**
 * Retourne le détail d'un build par son ID (id, nom, champion,
 * champion_id, rôle, patch, description, source), ou null s'il
 * n'existe pas. $id est supposé déjà validé par l'appelant.
 */
function findBuildById(int $id): ?array
{
    return dbFetchOne(
        'SELECT ' . BUILD_DETAIL_SELECT_COLUMNS . '
         FROM builds b
         INNER JOIN champions c ON c.id = b.champion_id
         WHERE b.id = :id',
        ['id' => $id]
    );
}

/**
 * Retourne le build d'un champion donné portant ce nom, ou null s'il
 * n'existe pas. Sert à vérifier l'unicité de la paire (champion_id,
 * name) en création/modification (voir index.php et
 * uniq_builds_champion_name dans database/schema.sql) — même principe
 * que findChampionBySlug()/findItemBySlug()/findRuneBySlug().
 */
function findBuildByChampionAndName(int $championId, string $name): ?array
{
    return dbFetchOne(
        'SELECT ' . BUILD_SELECT_COLUMNS . '
         FROM builds b
         INNER JOIN champions c ON c.id = b.champion_id
         WHERE b.champion_id = :champion_id AND b.name = :name',
        ['champion_id' => $championId, 'name' => $name]
    );
}

/**
 * Insère un nouveau build et retourne son ID généré. $data doit déjà
 * être validé par l'appelant (voir validateBuildPayload(), index.php) :
 * champion_id, name, role, patch, description, source.
 *
 * La colonne texte `patch` reste la référence écrite ici ; le build est
 * ensuite rattaché à la table `patches` (colonne patch_id) si la
 * migration database/migration_patch_links.sql est en place — sinon ce
 * rattachement est simplement ignoré (voir linkRowToPatch()).
 */
function insertBuild(array $data): int
{
    dbExecute(
        'INSERT INTO builds (champion_id, name, role, patch, description, source)
         VALUES (:champion_id, :name, :role, :patch, :description, :source)',
        [
            'champion_id' => $data['champion_id'],
            'name'        => $data['name'],
            'role'        => $data['role'],
            'patch'       => $data['patch'],
            'description' => $data['description'],
            'source'      => $data['source'],
        ]
    );

    $id = (int) dbLastInsertId();
    linkRowToPatch('builds', $id, $data['patch']);

    return $id;
}

/**
 * Remplace l'ensemble des champs modifiables d'un build existant (pas
 * de modification partielle : les objets/runes/ordre de compétences
 * associés — build_items, build_runes, build_skill_order — ne sont pas
 * touchés ici, leur gestion restant hors périmètre de cette étape).
 * $id est supposé déjà validé et existant par l'appelant (voir
 * findBuildById()) ; $data déjà validé par validateBuildPayload()
 * (index.php). Le rattachement au patch (patch_id) est resynchronisé
 * avec la colonne `patch`, comme dans insertBuild().
 */
function updateBuild(int $id, array $data): void
{
    dbExecute(
        'UPDATE builds
         SET champion_id = :champion_id, name = :name, role = :role, patch = :patch,
             description = :description, source = :source
         WHERE id = :id',
        [
            'id'          => $id,
            'champion_id' => $data['champion_id'],
            'name'        => $data['name'],
            'role'        => $data['role'],
            'patch'       => $data['patch'],
            'description' => $data['description'],
            'source'      => $data['source'],
        ]
    );

    linkRowToPatch('builds', $id, $data['patch']);
}

/**
 * Supprime un build par son ID. La base de données supprime en cascade
 * tout ce qui le référence (objets, runes et ordre de compétences du
 * build — voir REFERENCES builds ... ON DELETE CASCADE dans
 * database/schema.sql) : aucune suppression manuelle supplémentaire
 * n'est faite ici, même principe que deleteChampion()/deleteItem()/
 * deleteRune().
 */
function deleteBuild(int $id): void
{
    dbExecute('DELETE FROM builds WHERE id = :id', ['id' => $id]);
}

/**
 * Retourne les lignes brutes de la table de relation `build_items` pour
 * un build donné (un objet + son slot, sa position dans l'ordre
 * d'achat et sa situation — voir build_items.situation,
 * database/schema.sql), triées par slot puis par ordre d'achat (les
 * objets sans ordre — slot 'situational' — en dernier au sein de leur
 * slot). $buildId est supposé déjà validé par l'appelant.
 */
function findBuildItems(int $buildId): array
{
    $sql = 'SELECT bi.slot AS slot, bi.purchase_order AS purchase_order, bi.situation AS situation, '
        . BUILD_ITEM_SELECT_COLUMNS . '
        FROM build_items bi
        INNER JOIN items i ON i.id = bi.item_id
        WHERE bi.build_id = :build_id
        ORDER BY bi.slot ASC, (bi.purchase_order IS NULL) ASC, bi.purchase_order ASC, i.name ASC';

    return dbFetchAll($sql, ['build_id' => $buildId]);
}

/**
 * Retourne les objets d'un build regroupés par slot (starting, core,
 * boots, enchantment, situational — voir getBuildItemSlots()), plus un
 * "purchase_order" global : la séquence d'achat conseillée (objets des
 * slots à ordre fixe uniquement — starting/boots/core/enchantment — les
 * objets 'situational' étant des alternatives et non une étape figée).
 * $buildId est supposé déjà validé par l'appelant ; ne vérifie pas que
 * le build existe, c'est le rôle de l'appelant (voir findBuildById()).
 */
function findBuildItemsGrouped(int $buildId): array
{
    $grouped = array_fill_keys(getBuildItemSlots(), []);
    $grouped['purchase_order'] = [];

    foreach (findBuildItems($buildId) as $row) {
        $slot = $row['slot'];
        $purchaseOrder = $row['purchase_order'] !== null ? (int) $row['purchase_order'] : null;

        unset($row['slot']);
        $row['purchase_order'] = $purchaseOrder;

        $grouped[$slot][] = $row;

        if ($purchaseOrder !== null) {
            $grouped['purchase_order'][] = [
                'order' => $purchaseOrder,
                'slot'  => $slot,
                'item'  => $row['name'],
            ];
        }
    }

    usort($grouped['purchase_order'], fn (array $a, array $b): int => $a['order'] <=> $b['order']);

    return $grouped;
}

/**
 * Retourne les runes d'un build (table de relation `build_runes`,
 * jointe à `runes`), triées par leur position dans la page de runes
 * (1 = première choisie, typiquement la keystone). Le détail complet
 * de chaque rune (arbre, keystone/mineure) provient de `runes` elle-même,
 * pas dupliqué dans build_runes. $buildId est supposé déjà validé par
 * l'appelant ; ne vérifie pas que le build existe, c'est le rôle de
 * l'appelant (voir findBuildById()). Retourne un tableau vide si le
 * build n'a aucune rune associée — ce n'est pas une erreur.
 */
function findBuildRunes(int $buildId): array
{
    $sql = 'SELECT br.position AS position, ' . BUILD_RUNE_SELECT_COLUMNS . '
            FROM build_runes br
            INNER JOIN runes r ON r.id = br.rune_id
            WHERE br.build_id = :build_id
            ORDER BY br.position ASC';

    $rows = dbFetchAll($sql, ['build_id' => $buildId]);

    foreach ($rows as &$row) {
        $row['position'] = (int) $row['position'];
    }
    unset($row);

    return $rows;
}

/**
 * Retourne l'ordre des compétences d'un build (table de relation
 * `build_skill_order`) : un point par niveau, du niveau 1 au niveau
 * max (15 en Wild Rift), trié par niveau croissant. `skill` vaut '1',
 * '2', '3' ou 'ultimate' — l'emplacement générique de la compétence
 * dans l'interface Wild Rift (pas de table de compétences dédiée dans
 * ce schéma). $buildId est supposé déjà validé par l'appelant.
 * Retourne un tableau vide si le build n'a pas d'ordre de compétences
 * renseigné — ce n'est pas une erreur.
 */
function findBuildSkillOrder(int $buildId): array
{
    $sql = 'SELECT level, skill
            FROM build_skill_order
            WHERE build_id = :build_id
            ORDER BY level ASC';

    $rows = dbFetchAll($sql, ['build_id' => $buildId]);

    foreach ($rows as &$row) {
        $row['level'] = (int) $row['level'];
    }
    unset($row);

    return $rows;
}
