<?php
/**
 * Endpoint : /api/builds/
 * Ressource : Builds
 *
 * Un seul point d'entrée, différencié par la méthode HTTP et les
 * paramètres de requête (pas de réécriture d'URL pour des segments
 * /api/builds/{id}/ à ce stade — voir .htaccess) :
 *
 *   GET  /api/builds/                    → tous les builds
 *   GET  /api/builds/?id=5               → un build par son ID (détail complet)
 *   GET  /api/builds/?search=carry       → recherche par nom (LIKE)
 *   GET  /api/builds/?champion=jinx      → filtre par champion (slug)
 *   GET  /api/builds/?role=dragon        → filtre par rôle
 *   GET  /api/builds/?patch=5.2          → filtre par patch
 *   GET  /api/builds/?page=2             → pagination (page 1, page 2, ...)
 *   POST /api/builds/                    → créer un build
 *   PUT  /api/builds/?id=5               → modifier un build existant
 *   DELETE /api/builds/?id=5             → supprimer un build
 *
 * ?search=, ?champion=, ?role=, ?patch= et ?page= sont combinables entre eux
 * (ET logique, GET liste uniquement). ?id= est prioritaire et exclusif pour
 * GET (détail), et obligatoire pour PUT/DELETE (mêmes règles de validation
 * que la lecture) — même convention que /api/champions/, /api/items/ et
 * /api/runes/.
 *
 * La liste est paginée : BUILD_PAGE_SIZE résultats par page (voir
 * repository.php), ?page=1 par défaut si absent. La réponse inclut un bloc
 * "pagination" en meta (page courante, taille de page, total de résultats,
 * total de pages) — voir apiSuccess() ci-dessous. ?id= (détail) n'est pas
 * concerné par la pagination.
 *
 * En liste, chaque build ne contient que les informations essentielles :
 * id, nom, champion (résolu par jointure sur `champions`), rôle, patch.
 * En détail (?id=), s'ajoutent champion_id (nécessaire à l'espace
 * d'administration, voir BUILD_DETAIL_SELECT_COLUMNS dans
 * repository.php), description, source, les objets associés au build
 * (relation `build_items`, liée à `items`) : objets de départ, objets
 * principaux, bottes, enchantement, objets situationnels et l'ordre
 * d'achat conseillé — voir repository.php (findBuildItemsGrouped()) —
 * ainsi que les runes (relation `build_runes`, liée à `runes`) et
 * l'ordre des compétences (`build_skill_order`, propre au build).
 * POST/PUT/DELETE ne renvoient que les colonnes propres du build
 * (BUILD_DETAIL_SELECT_COLUMNS) : pas ces relations, dont la gestion
 * reste hors périmètre de cette étape (voir plus bas).
 *
 * POST et PUT valident le corps JSON de la requête (voir
 * validateBuildPayload() ci-dessous) : champion_id (doit référencer un
 * champion existant), name, role (enum, voir getBuildRoles()) et patch
 * sont requis ; description et source sont optionnels (null si
 * absents/vides). La paire (champion_id, name) doit être unique (voir
 * uniq_builds_champion_name, database/schema.sql). PUT remplace
 * l'ensemble de ces champs (pas de modification partielle) — même
 * principe que /api/champions/, /api/items/ et /api/runes/.
 *
 * Hors périmètre de cette étape (comme pour la gestion des champions,
 * des objets et des runes) : la gestion des relations d'un build — ses
 * objets (build_items), ses runes (build_runes) et son ordre de
 * compétences (build_skill_order) ne sont pas modifiables via cet
 * endpoint, uniquement consultables en détail (GET ?id=).
 *
 * DELETE supprime aussi, en cascade côté base de données, tout ce qui
 * référence ce build (ses objets, ses runes, son ordre de compétences —
 * voir REFERENCES builds ... ON DELETE CASCADE dans
 * database/schema.sql) : aucune suppression manuelle supplémentaire
 * n'est faite ici.
 *
 * Nouveauté par rapport à l'étape précédente (liste et détail en
 * lecture seule uniquement) : POST/PUT/DELETE, au service de la
 * nouvelle gestion des builds dans l'espace d'administration (voir
 * admin/pages/builds.php et assets/js/admin-builds.js) — même principe
 * que l'étape équivalente sur /api/champions/, /api/items/ et
 * /api/runes/. Aucune authentification n'est vérifiée à cette étape
 * (voir admin/login.php, dont la connexion effective n'est pas encore
 * câblée côté serveur) : ces trois méthodes d'écriture sont donc, pour
 * l'instant, accessibles sans connexion, au même titre que le reste de
 * l'espace admin.
 *
 * Données lues/écrites depuis MySQL via PDO en requêtes préparées
 * (voir repository.php et config/database.php) — jamais de valeur
 * utilisateur concaténée dans le SQL.
 */

require_once __DIR__ . '/../core/bootstrap.php';
require_once __DIR__ . '/repository.php';
require_once __DIR__ . '/../champions/repository.php';

/**
 * Valide le corps JSON d'une création ou d'une modification de build et
 * retourne un tableau prêt à être passé à insertBuild()/updateBuild()
 * (mêmes clés que les colonnes propres de `builds`, hormis
 * id/created_at/updated_at). Lève une ApiException 422 au premier champ
 * invalide — même principe que validateChampionPayload()/
 * validateItemPayload()/validateRunePayload().
 */
function validateBuildPayload(array $body): array
{
    apiRequireFields($body, ['champion_id', 'name', 'role', 'patch']);

    $championId = apiValidateInt($body['champion_id'], 'champion_id', 1);
    if (findChampionById($championId) === null) {
        throw ApiException::validation(
            "Aucun champion trouvé avec l'ID $championId.",
            ['field' => 'champion_id']
        );
    }

    $name = apiValidateString($body['name'], 'name', 1, 80);
    $role = apiValidateEnum($body['role'], 'role', getBuildRoles());
    $patch = apiValidateString($body['patch'], 'patch', 1, 10);

    $description = null;
    if (isset($body['description']) && $body['description'] !== '') {
        $description = apiValidateString($body['description'], 'description', 1, 500);
    }

    $source = null;
    if (isset($body['source']) && $body['source'] !== '') {
        $source = apiValidateString($body['source'], 'source', 1, 255);
    }

    return [
        'champion_id' => $championId,
        'name'        => $name,
        'role'        => $role,
        'patch'       => $patch,
        'description' => $description,
        'source'      => $source,
    ];
}

apiRun(function (): void {
    apiRequireMethod(['GET', 'POST', 'PUT', 'DELETE']);

    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    // Écritures réservées à un administrateur connecté (voir api/core/auth.php).
    if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
        apiRequireAdmin();
    }

    // --- Création (POST) -------------------------------------------
    if ($method === 'POST') {
        $data = validateBuildPayload(apiGetJsonBody());

        if (findBuildByChampionAndName($data['champion_id'], $data['name']) !== null) {
            throw ApiException::validation(
                'Ce champion a déjà un build portant ce nom.',
                ['field' => 'name']
            );
        }

        $id = insertBuild($data);

        apiSuccess(findBuildById($id), 201);
        return;
    }

    // --- Modification et suppression (PUT/DELETE) : ?id= obligatoire
    if ($method === 'PUT' || $method === 'DELETE') {
        if (!isset($_GET['id']) || $_GET['id'] === '') {
            throw ApiException::badRequest("Le paramètre 'id' est requis pour cette méthode.");
        }

        $id = apiValidateInt($_GET['id'], 'id', 1);

        if (findBuildById($id) === null) {
            throw ApiException::notFound("Aucun build trouvé avec l'ID $id.");
        }

        if ($method === 'DELETE') {
            deleteBuild($id);
            apiSuccess(['id' => $id]);
            return;
        }

        $data = validateBuildPayload(apiGetJsonBody());

        $existingWithName = findBuildByChampionAndName($data['champion_id'], $data['name']);
        if ($existingWithName !== null && (int) $existingWithName['id'] !== $id) {
            throw ApiException::validation(
                'Ce champion a déjà un build portant ce nom.',
                ['field' => 'name']
            );
        }

        updateBuild($id, $data);

        apiSuccess(findBuildById($id));
        return;
    }

    // --- Détail par ID -------------------------------------------------
    if (isset($_GET['id']) && $_GET['id'] !== '') {
        $id = apiValidateInt($_GET['id'], 'id', 1);

        $build = findBuildById($id);

        if ($build === null) {
            throw ApiException::notFound("Aucun build trouvé avec l'ID $id.");
        }

        $build['items'] = findBuildItemsGrouped($id);
        $build['runes'] = findBuildRunes($id);
        $build['skill_order'] = findBuildSkillOrder($id);

        apiSuccess($build);
        return;
    }

    // --- Liste, avec filtres optionnels (recherche, champion, rôle, patch)
    $search = null;
    if (isset($_GET['search']) && $_GET['search'] !== '') {
        $search = apiValidateString($_GET['search'], 'search', 1, 60);
    }

    $champion = null;
    if (isset($_GET['champion']) && $_GET['champion'] !== '') {
        $champion = apiValidateString($_GET['champion'], 'champion', 1, 60);
    }

    $role = null;
    if (isset($_GET['role']) && $_GET['role'] !== '') {
        $role = apiValidateEnum($_GET['role'], 'role', getBuildRoles());
    }

    $patch = null;
    if (isset($_GET['patch']) && $_GET['patch'] !== '') {
        $patch = apiValidateString($_GET['patch'], 'patch', 1, 10);
    }

    $page = 1;
    if (isset($_GET['page']) && $_GET['page'] !== '') {
        $page = apiValidateInt($_GET['page'], 'page', 1);
    }

    $builds = findBuilds($champion, $role, $patch, $search, $page);
    $total = countBuilds($champion, $role, $patch, $search);
    $totalPages = $total > 0 ? (int) ceil($total / BUILD_PAGE_SIZE) : 0;

    apiSuccess($builds, 200, [
        'count'   => count($builds),
        'filters' => [
            'search'   => $search,
            'champion' => $champion,
            'role'     => $role,
            'patch'    => $patch,
        ],
        'pagination' => [
            'page'        => $page,
            'per_page'    => BUILD_PAGE_SIZE,
            'total'       => $total,
            'total_pages' => $totalPages,
        ],
    ]);
});
