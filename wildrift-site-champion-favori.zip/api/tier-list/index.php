<?php
/**
 * Endpoint : /api/tier-list/
 * Ressource : Tier list
 *
 * Étape actuelle : récupération de la tier list depuis MySQL, avec
 * filtres optionnels et combinables par champion (slug), rôle, patch,
 * tier et recherche libre par nom de champion, ainsi que le détail
 * d'une entrée par son ID — même convention que /api/champions/,
 * /api/items/, /api/runes/ et /api/builds/.
 *
 *   GET /api/tier-list/                       → toute la tier list
 *   GET /api/tier-list/?id=5                  → une entrée par son ID (détail complet)
 *   GET /api/tier-list/?champion=malphite     → filtre par champion (slug)
 *   GET /api/tier-list/?role=baron            → filtre par rôle
 *   GET /api/tier-list/?patch=5.2             → filtre par patch
 *   GET /api/tier-list/?tier=S                → filtre par tier (S/A/B/C/D)
 *   GET /api/tier-list/?search=lee            → recherche par nom de champion (LIKE)
 *
 * ?champion=, ?role=, ?patch=, ?tier= et ?search= sont combinables entre
 * eux (ET logique). ?id= est prioritaire et exclusif : s'il est présent,
 * les autres filtres sont ignorés — même convention que /api/champions/,
 * /api/items/, /api/runes/ et /api/builds/.
 *
 * En liste, chaque entrée contient : id, champion (résolu par jointure
 * sur `champions`, jamais champion_id brut), rôle, tier, patch, ainsi
 * que les taux win_rate/pick_rate/ban_rate (facultatifs, null si non
 * renseignés). En détail (?id=), s'ajoutent les notes et les dates de
 * création/mise à jour — voir repository.php.
 *
 * Triée par patch (le plus récent d'abord), puis par tier (S en tête),
 * puis par nom de champion (voir findTierList(), repository.php).
 *
 * Gestion des erreurs :
 *   - ?id= non entier ou < 1 → 422 validation_error (apiValidateInt()) ;
 *   - ?id= valide mais aucune entrée correspondante → 404 not_found ;
 *   - ?role= hors énumération (baron/jungle/mid/dragon/support) → 422 ;
 *   - ?tier= hors énumération (S/A/B/C/D) → 422 ;
 *   - ?champion= ou ?patch= trop long (> 60 / > 10 caractères) → 422 ;
 *   - ?search= vide ou trop long (> 60 caractères) → 422.
 *
 * Données lues depuis MySQL via PDO en requêtes préparées
 * (voir repository.php et config/database.php) — jamais de valeur
 * utilisateur concaténée dans le SQL.
 *
 * Pas encore implémenté à cette étape (viendra ensuite, si besoin, sur
 * le modèle des ressources les plus avancées) :
 *   - pagination (jeu de données restreint pour l'instant, contrairement
 *     à /api/builds/) ;
 *   - écriture (création/mise à jour) : réservée à l'admin de gestion de
 *     la tier list, à venir.
 */

require_once __DIR__ . "/../core/bootstrap.php";
require_once __DIR__ . "/repository.php";

apiRun(function (): void {
    apiRequireMethod(['GET']);

    // --- Détail par ID ---------------------------------------------------
    if (isset($_GET['id']) && $_GET['id'] !== '') {
        $id = apiValidateInt($_GET['id'], 'id', 1);

        $entry = findTierListById($id);

        if ($entry === null) {
            throw ApiException::notFound("Aucune entrée de tier list trouvée avec l'ID $id.");
        }

        apiSuccess($entry);
        return;
    }

    // --- Liste, avec filtres optionnels (champion, rôle, patch, tier, recherche) ---
    $champion = null;
    if (isset($_GET['champion']) && $_GET['champion'] !== '') {
        $champion = apiValidateString($_GET['champion'], 'champion', 1, 60);
    }

    $role = null;
    if (isset($_GET['role']) && $_GET['role'] !== '') {
        $role = apiValidateEnum($_GET['role'], 'role', getTierListRoles());
    }

    $patch = null;
    if (isset($_GET['patch']) && $_GET['patch'] !== '') {
        $patch = apiValidateString($_GET['patch'], 'patch', 1, 10);
    }

    $tier = null;
    if (isset($_GET['tier']) && $_GET['tier'] !== '') {
        $tier = apiValidateEnum($_GET['tier'], 'tier', getTierListTiers());
    }

    $search = null;
    if (isset($_GET['search']) && $_GET['search'] !== '') {
        $search = apiValidateString($_GET['search'], 'search', 1, 60);
    }

    $tierList = findTierList($champion, $role, $patch, $tier, $search);

    apiSuccess($tierList, 200, [
        'count'   => count($tierList),
        'filters' => [
            'champion' => $champion,
            'role'     => $role,
            'patch'    => $patch,
            'tier'     => $tier,
            'search'   => $search,
        ],
    ]);
});
