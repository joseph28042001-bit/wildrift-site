<?php
/**
 * Accès aux données pour la ressource "tier-list" (classement des champions
 * par rôle et par patch). Toutes les requêtes passent par
 * dbFetchAll()/dbFetchOne() (config/database.php), qui utilisent PDO en
 * requêtes préparées (aucune valeur n'est jamais concaténée dans le SQL).
 * Ce fichier ne fait aucune validation d'entrée : c'est le rôle de
 * index.php, avant d'appeler ces fonctions.
 */

/**
 * Colonnes exposées par l'API pour une entrée de tier list, en liste :
 * jamais SELECT *, et jamais champion_id brut — le nom du champion est
 * résolu par jointure sur la table `champions` (même convention que
 * BUILD_SELECT_COLUMNS, builds/repository.php).
 */
const TIER_LIST_SELECT_COLUMNS = 't.id AS id, c.name AS champion, t.role AS role, t.tier AS tier, t.patch AS patch, t.win_rate AS win_rate, t.pick_rate AS pick_rate, t.ban_rate AS ban_rate';

/**
 * Colonnes exposées par l'API pour le détail d'une entrée (GET ?id=) :
 * les colonnes de la liste, plus les notes et les dates, propres à la
 * vue détail. Toujours pas de SELECT * ni de champion_id brut.
 */
const TIER_LIST_DETAIL_SELECT_COLUMNS = TIER_LIST_SELECT_COLUMNS . ', t.notes AS notes, t.created_at AS created_at, t.updated_at AS updated_at';

/**
 * Liste des rôles Wild Rift valides, utilisée pour valider le filtre ?role=.
 * Dupliquée depuis champions/repository.php plutôt qu'importée : chaque
 * ressource de l'API reste autonome (même choix que dans items/, runes/
 * et builds/), et tier_list.role partage volontairement l'ENUM de
 * champions.role (voir database/schema.sql).
 */
function getTierListRoles(): array
{
    return ['baron', 'jungle', 'mid', 'dragon', 'support'];
}

/**
 * Liste des tiers valides, utilisée pour valider le filtre ?tier=, du
 * plus fort ('S+') au plus faible ('D').
 */
function getTierListTiers(): array
{
    return ['S+', 'S', 'A', 'B', 'C', 'D'];
}

/**
 * Convertit les taux (win_rate/pick_rate/ban_rate) d'une ligne de
 * tier_list de leur forme brute PDO (chaîne, colonnes DECIMAL) vers un
 * float PHP, NULL conservé tel quel. Usage interne à ce fichier.
 */
function castTierListRates(array $row): array
{
    foreach (['win_rate', 'pick_rate', 'ban_rate'] as $field) {
        $row[$field] = $row[$field] !== null ? (float) $row[$field] : null;
    }

    return $row;
}

/**
 * Construit la clause WHERE (+ ses paramètres liés) commune à
 * findTierList(), à partir des mêmes filtres optionnels. $champion,
 * $role, $patch, $tier et $search sont supposés déjà validés par
 * l'appelant. $champion filtre sur le slug du champion (c.slug), pas sur
 * son nom affiché ; $search filtre sur le nom affiché (c.name, LIKE),
 * même convention que buildBuildsWhereClause() (builds/repository.php)
 * et findChampions() (champions/repository.php). Usage interne à ce
 * fichier uniquement.
 *
 * @return array{0: string, 1: array<string, string>} [clause SQL, paramètres liés]
 */
function buildTierListWhereClause(?string $champion, ?string $role, ?string $patch, ?string $tier, ?string $search = null): array
{
    $sql = 'WHERE 1 = 1';
    $params = [];

    if ($champion !== null) {
        // BINARY force une comparaison sensible à la casse, même choix
        // que buildBuildsWhereClause() (builds/repository.php) : le slug
        // est une clé exacte, pas une recherche texte libre.
        $sql .= ' AND BINARY c.slug = :champion';
        $params['champion'] = $champion;
    }

    if ($role !== null) {
        $sql .= ' AND t.role = :role';
        $params['role'] = $role;
    }

    if ($patch !== null) {
        $sql .= ' AND t.patch = :patch';
        $params['patch'] = $patch;
    }

    if ($tier !== null) {
        $sql .= ' AND t.tier = :tier';
        $params['tier'] = $tier;
    }

    if ($search !== null) {
        $sql .= ' AND c.name LIKE :search';
        $params['search'] = '%' . $search . '%';
    }

    return [$sql, $params];
}

/**
 * Retourne les entrées de tier list correspondant aux filtres fournis
 * (tous optionnels, combinables), avec le nom du champion associé
 * résolu via une jointure sur `champions` (champion_id → champions.id).
 * $champion, $role, $patch, $tier et $search sont supposés déjà validés
 * par l'appelant. $champion filtre sur le slug du champion (c.slug), pas
 * sur son nom affiché ; $search filtre par recherche libre sur le nom
 * affiché (c.name, LIKE).
 *
 * Triée par patch (le plus récent d'abord), puis par tier (S+ en tête,
 * D en dernier), puis par nom de champion.
 */
function findTierList(?string $champion, ?string $role, ?string $patch, ?string $tier, ?string $search = null): array
{
    [$where, $params] = buildTierListWhereClause($champion, $role, $patch, $tier, $search);

    $sql = 'SELECT ' . TIER_LIST_SELECT_COLUMNS . '
            FROM tier_list t
            INNER JOIN champions c ON c.id = t.champion_id
            ' . $where . "
            ORDER BY t.patch DESC, FIELD(t.tier, 'S+', 'S', 'A', 'B', 'C', 'D') ASC, c.name ASC";

    return array_map('castTierListRates', dbFetchAll($sql, $params));
}

/**
 * Retourne le détail d'une entrée de tier list par son ID (id, champion,
 * rôle, tier, patch, taux, notes, dates), ou null si elle n'existe pas.
 * $id est supposé déjà validé par l'appelant.
 */
function findTierListById(int $id): ?array
{
    $row = dbFetchOne(
        'SELECT ' . TIER_LIST_DETAIL_SELECT_COLUMNS . '
         FROM tier_list t
         INNER JOIN champions c ON c.id = t.champion_id
         WHERE t.id = :id',
        ['id' => $id]
    );

    return $row !== null ? castTierListRates($row) : null;
}
