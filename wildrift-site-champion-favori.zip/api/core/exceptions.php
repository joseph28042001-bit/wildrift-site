<?php
/**
 * Exception dédiée à l'API : porte le code HTTP et un code d'erreur
 * machine-readable, prête à être interceptée par apiRun() (voir runner.php)
 * pour produire une réponse JSON standardisée.
 */

class ApiException extends RuntimeException
{
    private int $statusCode;
    private string $errorCode;
    private array $details;

    public function __construct(
        string $message,
        int $statusCode = 400,
        string $errorCode = 'bad_request',
        array $details = []
    ) {
        parent::__construct($message);
        $this->statusCode = $statusCode;
        $this->errorCode = $errorCode;
        $this->details = $details;
    }

    public function getStatusCode(): int
    {
        return $this->statusCode;
    }

    public function getErrorCode(): string
    {
        return $this->errorCode;
    }

    public function getDetails(): array
    {
        return $this->details;
    }

    /** 400 — requête mal formée (JSON invalide, paramètre inattendu, etc.) */
    public static function badRequest(string $message = 'Requête invalide.', array $details = []): self
    {
        return new self($message, 400, 'bad_request', $details);
    }

    /** 422 — validation des données échouée */
    public static function validation(string $message = 'Données invalides.', array $details = []): self
    {
        return new self($message, 422, 'validation_error', $details);
    }

    /** 401 — authentification requise ou invalide */
    public static function unauthorized(string $message = 'Authentification requise.'): self
    {
        return new self($message, 401, 'unauthorized');
    }

    /** 403 — authentifié mais accès refusé */
    public static function forbidden(string $message = 'Accès refusé.'): self
    {
        return new self($message, 403, 'forbidden');
    }

    /** 404 — ressource introuvable */
    public static function notFound(string $message = 'Ressource introuvable.'): self
    {
        return new self($message, 404, 'not_found');
    }

    /** 405 — méthode HTTP non autorisée pour cet endpoint */
    public static function methodNotAllowed(string $message = 'Méthode non autorisée.'): self
    {
        return new self($message, 405, 'method_not_allowed');
    }

    /** 501 — endpoint prévu mais pas encore implémenté à cette étape du projet */
    public static function notImplemented(string $message = "Cet endpoint n'est pas encore implémenté."): self
    {
        return new self($message, 501, 'not_implemented');
    }

    /** 500 — erreur serveur générique (message toujours neutre, jamais de détail technique) */
    public static function serverError(string $message = 'Une erreur est survenue. Merci de réessayer plus tard.'): self
    {
        return new self($message, 500, 'internal_error');
    }
}
