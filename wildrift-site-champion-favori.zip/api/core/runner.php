<?php
/**
 * Point d'exécution commun à tous les endpoints de l'API.
 * Chaque fichier api/<ressource>/index.php enveloppe sa logique dans
 * apiRun() : ceci garantit qu'aucune exception ne fuite jamais une trace
 * technique au client (SQL, chemin serveur...), et que toute erreur,
 * prévue ou non, prend la forme JSON standard définie dans response.php.
 */

function apiRun(callable $handler): void
{
    try {
        $handler();
    } catch (ApiException $e) {
        apiError($e->getMessage(), $e->getStatusCode(), $e->getErrorCode(), $e->getDetails());
    } catch (DatabaseException $e) {
        // Message déjà générique (voir config/database.php) : sûr à renvoyer tel quel.
        apiError($e->getMessage(), 500, 'database_error');
    } catch (Throwable $e) {
        error_log('[API] Erreur non interceptée : ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
        apiError('Une erreur est survenue. Merci de réessayer plus tard.', 500, 'internal_error');
    }
}
