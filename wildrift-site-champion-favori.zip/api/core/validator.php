<?php
/**
 * Helpers de validation de base pour les entrées API (méthode HTTP, corps
 * JSON, champs requis, types simples). Volontairement minimal à cette
 * étape : chaque route métier affinera ses propres règles au moment de
 * son implémentation.
 */

/**
 * Vérifie que la méthode HTTP de la requête fait partie des méthodes
 * autorisées pour l'endpoint. Envoie l'en-tête Allow et lève une
 * ApiException 405 sinon.
 *
 * @param string[] $allowedMethods Ex. ['GET'], ['POST', 'PUT']
 */
function apiRequireMethod(array $allowedMethods): void
{
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if (!in_array($method, $allowedMethods, true)) {
        header('Allow: ' . implode(', ', $allowedMethods));
        throw ApiException::methodNotAllowed("Méthode $method non autorisée pour cet endpoint.");
    }
}

/**
 * Lit et décode le corps JSON de la requête (php://input).
 * Lève une ApiException 400 si le JSON est requis mais absent, ou mal formé.
 */
function apiGetJsonBody(bool $required = true): array
{
    $raw = file_get_contents('php://input');

    if ($raw === false || trim($raw) === '') {
        if ($required) {
            throw ApiException::badRequest('Corps de requête JSON attendu.');
        }
        return [];
    }

    $decoded = json_decode($raw, true);

    if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
        throw ApiException::badRequest('Corps de requête JSON invalide.');
    }

    return $decoded;
}

/**
 * Vérifie que les champs listés sont présents et non vides dans $data.
 * Lève une ApiException 422 listant les champs manquants.
 *
 * @param string[] $requiredFields
 */
function apiRequireFields(array $data, array $requiredFields): void
{
    $missing = [];

    foreach ($requiredFields as $field) {
        if (!array_key_exists($field, $data) || $data[$field] === '' || $data[$field] === null) {
            $missing[] = $field;
        }
    }

    if (!empty($missing)) {
        throw ApiException::validation('Champs manquants.', ['missing_fields' => $missing]);
    }
}

/**
 * Valide qu'une valeur est un entier (ou une chaîne numérique entière) et
 * la retourne convertie en int. Lève une ApiException 422 sinon.
 */
function apiValidateInt($value, string $fieldName, ?int $min = null, ?int $max = null): int
{
    if (!is_numeric($value) || (int) $value != $value) {
        throw ApiException::validation("Le champ '$fieldName' doit être un entier.");
    }

    $intValue = (int) $value;

    if ($min !== null && $intValue < $min) {
        throw ApiException::validation("Le champ '$fieldName' doit être supérieur ou égal à $min.");
    }

    if ($max !== null && $intValue > $max) {
        throw ApiException::validation("Le champ '$fieldName' doit être inférieur ou égal à $max.");
    }

    return $intValue;
}

/**
 * Longueur d'une chaîne, en multi-octet si l'extension mbstring est
 * disponible, avec repli sur strlen() sinon (certains hébergements
 * mutualisés ne l'activent pas par défaut).
 */
function apiStrLen(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

/**
 * Valide qu'une valeur est une chaîne de caractères, avec longueur
 * optionnelle, et la retourne "trimée".
 */
function apiValidateString($value, string $fieldName, int $minLength = 1, ?int $maxLength = null): string
{
    if (!is_string($value)) {
        throw ApiException::validation("Le champ '$fieldName' doit être une chaîne de caractères.");
    }

    $trimmed = trim($value);

    if (apiStrLen($trimmed) < $minLength) {
        throw ApiException::validation("Le champ '$fieldName' est trop court.");
    }

    if ($maxLength !== null && apiStrLen($trimmed) > $maxLength) {
        throw ApiException::validation("Le champ '$fieldName' est trop long.");
    }

    return $trimmed;
}

/**
 * Valide qu'une valeur fait partie d'une liste de valeurs autorisées (enum).
 *
 * @param mixed[] $allowedValues
 * @return mixed La valeur, inchangée, si elle est autorisée
 */
function apiValidateEnum($value, string $fieldName, array $allowedValues)
{
    if (!in_array($value, $allowedValues, true)) {
        throw ApiException::validation(
            "Le champ '$fieldName' doit être l'une des valeurs autorisées.",
            ['allowed_values' => $allowedValues]
        );
    }

    return $value;
}
