<?php
/**
 * Bootstrap spécifique à l'API.
 * Charge d'abord le bootstrap général du site (config, session, sécurité,
 * base de données...), puis le socle commun de l'API : exceptions,
 * réponses JSON, validation, exécution encadrée.
 *
 * À inclure en première ligne de chaque api/<ressource>/index.php :
 *   require_once __DIR__ . '/../core/bootstrap.php';
 */

require_once __DIR__ . '/../../includes/bootstrap.php';

require_once __DIR__ . '/exceptions.php';
require_once __DIR__ . '/response.php';
require_once __DIR__ . '/validator.php';
require_once __DIR__ . '/runner.php';
require_once __DIR__ . '/headers.php';
require_once __DIR__ . '/auth.php';

// Toute réponse de l'API est du JSON, sans exception.
header('Content-Type: application/json; charset=utf-8');

// Remplace les en-têtes génériques (pensés pour des pages HTML) par
// ceux réellement nécessaires à une réponse JSON.
sendApiHeaders();
