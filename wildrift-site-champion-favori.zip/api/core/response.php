<?php
/**
 * Enveloppe JSON standardisée pour toutes les réponses de l'API.
 * S'appuie sur jsonResponse() (includes/functions.php) pour l'encodage
 * et les en-têtes, et y ajoute une forme cohérente, quel que soit
 * l'endpoint : succès ou erreur, jamais autre chose.
 */

/**
 * Réponse de succès.
 * Forme : { "success": true, "data": ..., "meta": {...}? }
 *
 * @param mixed $data Donnée renvoyée (tableau associatif, liste, scalaire...)
 */
function apiSuccess($data = [], int $statusCode = 200, array $meta = []): void
{
    $payload = [
        'success' => true,
        'data'    => $data,
    ];

    if (!empty($meta)) {
        $payload['meta'] = $meta;
    }

    jsonResponse($payload, $statusCode);
}

/**
 * Réponse d'erreur.
 * Forme : { "success": false, "error": { "code", "message", "details"? } }
 * Ne jamais faire passer de détail technique (SQL, chemin serveur, trace)
 * dans $message ou $details : voir includes/error_handler.php et
 * config/database.php pour la règle générale du projet.
 */
function apiError(string $message, int $statusCode = 400, string $errorCode = 'bad_request', array $details = []): void
{
    $error = [
        'code'    => $errorCode,
        'message' => $message,
    ];

    if (!empty($details)) {
        $error['details'] = $details;
    }

    jsonResponse([
        'success' => false,
        'error'   => $error,
    ], $statusCode);
}
