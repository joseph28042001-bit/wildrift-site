<?php
/**
 * En-têtes HTTP spécifiques aux réponses de l'API.
 *
 * includes/bootstrap.php (chargé juste avant, dans api/core/bootstrap.php)
 * envoie déjà sendSecurityHeaders() : des en-têtes pensés pour des pages
 * HTML (protection contre le clickjacking, politique de referrer...).
 * L'API ne sert jamais de HTML, donc ces en-têtes n'ont pas de sens ici
 * et sont retirés. Seuls les en-têtes réellement utiles à une réponse
 * JSON sont conservés ou ajoutés :
 *
 *   - X-Content-Type-Options : empêche le navigateur de deviner un
 *     autre type de contenu que celui déclaré (JSON).
 *   - Cache-Control : les réponses de l'API sont dynamiques, elles ne
 *     doivent jamais être mises en cache par le navigateur ou un proxy.
 *   - X-Robots-Tag : les endpoints ne doivent jamais être indexés par
 *     les moteurs de recherche.
 */

function sendApiHeaders(): void
{
    // Retirés : pensés pour des pages HTML, sans objet pour du JSON.
    header_remove('X-Frame-Options');
    header_remove('Referrer-Policy');

    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    header('X-Robots-Tag: noindex, nofollow');
}
