<?php
/**
 * Protection des écritures de l'API (POST/PUT/PATCH/DELETE) — réservées
 * à un compte administrateur connecté.
 *
 * Dépend de includes/bootstrap.php (chargé par api/core/bootstrap.php),
 * qui démarre la session et définit ADMIN_SESSION_KEY (voir
 * config/environment.php) ; s'appuie sur la même session que
 * admin/login.php (ADMIN_SESSION_KEY rempli après un password_verify()
 * réussi contre la table `admins` — voir admin/includes/auth.php pour
 * l'équivalent côté pages HTML admin/*.php).
 *
 * Contrairement à requireAdminSession() (admin/includes/auth.php), qui
 * redirige vers la page de connexion, apiRequireAdmin() est pensée pour
 * l'API : elle lève une ApiException, interceptée par apiRun()
 * (runner.php) et transformée en réponse JSON standard.
 */

/**
 * Vérifie qu'un compte administrateur est connecté. Sinon, lève une
 * ApiException 401 (aucune session admin active) — jamais de détail
 * supplémentaire (pas de distinction email/mot de passe, comme pour
 * admin/login.php).
 *
 * À appeler explicitement, uniquement pour les méthodes d'écriture
 * (POST/PUT/PATCH/DELETE) de chaque endpoint api/<ressource>/index.php —
 * jamais pour les méthodes de lecture (GET), qui restent publiques.
 */
function apiRequireAdmin(): void
{
    if (empty($_SESSION[ADMIN_SESSION_KEY])) {
        throw ApiException::unauthorized('Authentification administrateur requise.');
    }
}
