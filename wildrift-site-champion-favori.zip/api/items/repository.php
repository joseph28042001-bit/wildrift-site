<?php
/**
 * Accès aux données pour la ressource "items" (objets).
 * Toutes les requêtes passent par dbFetchAll()/dbFetchOne() (config/database.php),
 * qui utilisent PDO en requêtes préparées (aucune valeur n'est jamais concaténée
 * dans le SQL). Ce fichier ne fait aucune validation d'entrée : c'est le rôle
 * de index.php, avant d'appeler ces fonctions.
 */

/** Colonnes exposées par l'API pour un objet (jamais SELECT *). */
const ITEM_SELECT_COLUMNS = 'id, slug, name, category, price, description, image_url, created_at, updated_at';

/**
 * Liste des catégories d'objets valides, utilisée pour valider le filtre
 * ?category= ainsi que le champ 'category' en création/modification (voir
 * validateItemPayload(), index.php). Reprend l'ENUM de la colonne
 * `category` (database/schema.sql) — 'enchantment' y figure et est déjà
 * utilisé par assets/js/admin-items.js (ADMIN_ITEM_CATEGORY_LABELS/
 * BADGE_CLASSES) et assets/js/items.js, mais manquait ici.
 */
function getItemCategories(): array
{
    return ['attack', 'magic', 'defense', 'boots', 'jungle', 'consumable', 'enchantment'];
}

/**
 * Retourne les objets correspondant aux filtres fournis, triés par nom.
 * $category et $search sont supposés déjà validés par l'appelant.
 */
function findItems(?string $category, ?string $search): array
{
    $sql = 'SELECT ' . ITEM_SELECT_COLUMNS . ' FROM items WHERE 1 = 1';
    $params = [];

    if ($category !== null) {
        $sql .= ' AND category = :category';
        $params['category'] = $category;
    }

    if ($search !== null) {
        $sql .= ' AND name LIKE :search';
        $params['search'] = '%' . $search . '%';
    }

    $sql .= ' ORDER BY name ASC';

    return dbFetchAll($sql, $params);
}

/**
 * Retourne un objet par son ID, ou null s'il n'existe pas.
 */
function findItemById(int $id): ?array
{
    return dbFetchOne(
        'SELECT ' . ITEM_SELECT_COLUMNS . ' FROM items WHERE id = :id',
        ['id' => $id]
    );
}

/**
 * Retourne un objet par son slug, ou null s'il n'existe pas. Sert à
 * vérifier l'unicité du slug en création/modification (voir index.php) —
 * même principe que findChampionBySlug() (api/champions/repository.php).
 */
function findItemBySlug(string $slug): ?array
{
    return dbFetchOne(
        'SELECT ' . ITEM_SELECT_COLUMNS . ' FROM items WHERE slug = :slug',
        ['slug' => $slug]
    );
}

/**
 * Insère un nouvel objet et retourne son ID généré. $data doit déjà être
 * validé par l'appelant (voir validateItemPayload(), index.php) — mêmes
 * clés que ITEM_SELECT_COLUMNS hormis id/created_at/updated_at.
 */
function insertItem(array $data): int
{
    dbExecute(
        'INSERT INTO items (slug, name, category, price, description, image_url)
         VALUES (:slug, :name, :category, :price, :description, :image_url)',
        [
            'slug'        => $data['slug'],
            'name'        => $data['name'],
            'category'    => $data['category'],
            'price'       => $data['price'],
            'description' => $data['description'],
            'image_url'   => $data['image_url'],
        ]
    );

    return (int) dbLastInsertId();
}

/**
 * Remplace l'ensemble des champs modifiables d'un objet existant (pas de
 * modification partielle). $id est supposé déjà validé et existant par
 * l'appelant (voir findItemById()) ; $data déjà validé par
 * validateItemPayload() (index.php).
 */
function updateItem(int $id, array $data): void
{
    dbExecute(
        'UPDATE items
         SET slug = :slug, name = :name, category = :category, price = :price,
             description = :description, image_url = :image_url
         WHERE id = :id',
        [
            'id'          => $id,
            'slug'        => $data['slug'],
            'name'        => $data['name'],
            'category'    => $data['category'],
            'price'       => $data['price'],
            'description' => $data['description'],
            'image_url'   => $data['image_url'],
        ]
    );
}

/**
 * Supprime un objet par son ID. La base de données supprime en cascade
 * tout ce qui le référence (recettes le contenant ou dont il est
 * composant, entrées de build — voir REFERENCES items ... ON DELETE
 * CASCADE dans database/schema.sql) : aucune suppression manuelle
 * supplémentaire n'est faite ici, même principe que deleteChampion()
 * (api/champions/repository.php).
 */
function deleteItem(int $id): void
{
    dbExecute('DELETE FROM items WHERE id = :id', ['id' => $id]);
}

/**
 * Colonnes exposées par l'API pour un composant de recette : un
 * sous-ensemble volontairement plus léger que ITEM_SELECT_COLUMNS —
 * pas de description ni de dates, le détail complet d'un composant
 * restant du ressort de /api/items/?id= (même principe que
 * BUILD_ITEM_SELECT_COLUMNS, api/builds/repository.php).
 */
const ITEM_RECIPE_COMPONENT_SELECT_COLUMNS = 'i.id AS id, i.slug AS slug, i.name AS name, i.category AS category, i.price AS price, i.image_url AS image_url';

/**
 * Retourne les composants de la recette d'un objet (table de relation
 * `item_recipes`, jointe à `items`), triés par prix croissant. Un
 * tableau vide signifie que l'objet n'a pas de recette connue (objet
 * de départ, consommable ou composant de base lui-même) — ce n'est pas
 * une erreur, même principe que findBuildRunes() sans rune associée
 * (api/builds/repository.php). $itemId est supposé déjà validé par
 * l'appelant ; ne vérifie pas que l'objet existe, c'est le rôle de
 * l'appelant (voir findItemById()).
 */
function findItemRecipe(int $itemId): array
{
    $sql = 'SELECT ' . ITEM_RECIPE_COMPONENT_SELECT_COLUMNS . '
            FROM item_recipes ir
            INNER JOIN items i ON i.id = ir.component_item_id
            WHERE ir.item_id = :item_id
            ORDER BY i.price ASC, i.name ASC';

    return dbFetchAll($sql, ['item_id' => $itemId]);
}
