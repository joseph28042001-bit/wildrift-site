<?php
/**
 * Endpoint : /api/items/
 * Ressource : Objets (items)
 *
 * Un seul point d'entrée, différencié par la méthode HTTP et les
 * paramètres de requête (pas de réécriture d'URL pour des segments
 * /api/items/{id}/ à ce stade — voir .htaccess) :
 *
 *   GET  /api/items/                     → tous les objets
 *   GET  /api/items/?id=5                → un objet par son ID
 *   GET  /api/items/?search=lame         → recherche par nom (LIKE)
 *   GET  /api/items/?category=attack     → filtre par catégorie
 *   POST /api/items/                     → créer un objet
 *   PUT  /api/items/?id=5                → modifier un objet existant
 *   DELETE /api/items/?id=5              → supprimer un objet
 *
 * ?search= et ?category= peuvent être combinés (GET liste uniquement).
 * ?id= est prioritaire et exclusif pour GET (détail), et obligatoire
 * pour PUT/DELETE (mêmes règles de validation que la lecture).
 *
 * Le détail par ID (GET) ajoute un champ "recipe" : la liste des objets
 * composants de sa recette (table `item_recipes`, voir
 * findItemRecipe(), repository.php), ou un tableau vide si l'objet n'a
 * pas de recette connue — ce n'est pas une erreur. Absent de la liste,
 * pour rester légère (même principe que items/build_items sur
 * /api/builds/?id=). POST/PUT/DELETE ne renvoient pas ce champ (même
 * principe que /api/champions/, qui ne renvoie pas non plus les
 * relations en écriture).
 *
 * POST et PUT valident le corps JSON de la requête (voir
 * validateItemPayload() ci-dessous) : slug (unique, format
 * minuscules/chiffres/tirets), name et category (enum, voir
 * getItemCategories()) sont requis ; price, description et image_url
 * sont optionnels (null si absents/vides). PUT remplace l'ensemble de
 * ces champs (pas de modification partielle) — même principe que
 * /api/champions/.
 *
 * DELETE supprime aussi, en cascade côté base de données, tout ce qui
 * référence cet objet (recettes le contenant ou dont il est composant,
 * entrées de build — voir REFERENCES items ... ON DELETE CASCADE dans
 * database/schema.sql) : aucune suppression manuelle supplémentaire
 * n'est faite ici.
 *
 * Nouveauté par rapport à l'étape précédente (liste en lecture seule
 * uniquement) : POST/PUT/DELETE, au service de la nouvelle gestion des
 * objets dans l'espace d'administration (voir admin/pages/items.php et
 * assets/js/admin-items.js) — même principe que l'étape équivalente sur
 * /api/champions/. Aucune authentification n'est vérifiée à cette étape
 * (voir admin/login.php, dont la connexion effective n'est pas encore
 * câblée côté serveur) : ces trois méthodes d'écriture sont donc, pour
 * l'instant, accessibles sans connexion, au même titre que le reste de
 * l'espace admin.
 *
 * Données lues/écrites depuis MySQL via PDO en requêtes préparées
 * (voir repository.php et config/database.php) — jamais de valeur
 * utilisateur concaténée dans le SQL.
 */

require_once __DIR__ . '/../core/bootstrap.php';
require_once __DIR__ . '/repository.php';

/**
 * Valide le corps JSON d'une création ou d'une modification d'objet et
 * retourne un tableau prêt à être passé à insertItem()/updateItem()
 * (mêmes clés que ITEM_SELECT_COLUMNS, hormis id/created_at/updated_at).
 * Lève une ApiException 422 au premier champ invalide — même principe
 * que validateChampionPayload() (api/champions/index.php).
 */
function validateItemPayload(array $body): array
{
    apiRequireFields($body, ['slug', 'name', 'category']);

    $slug = apiValidateString($body['slug'], 'slug', 1, 60);
    if (!preg_match('/^[a-z0-9]+(-[a-z0-9]+)*$/', $slug)) {
        throw ApiException::validation(
            "Le champ 'slug' doit être en minuscules, chiffres et tirets uniquement (ex. 'infinity-edge').",
            ['field' => 'slug']
        );
    }

    $name = apiValidateString($body['name'], 'name', 1, 60);
    $category = apiValidateEnum($body['category'], 'category', getItemCategories());

    $price = null;
    if (isset($body['price']) && $body['price'] !== '') {
        $price = apiValidateInt($body['price'], 'price', 0, 65535);
    }

    $description = null;
    if (isset($body['description']) && $body['description'] !== '') {
        $description = apiValidateString($body['description'], 'description', 1, 255);
    }

    $imageUrl = null;
    if (isset($body['image_url']) && $body['image_url'] !== '') {
        $imageUrl = apiValidateString($body['image_url'], 'image_url', 1, 255);
    }

    return [
        'slug'        => $slug,
        'name'        => $name,
        'category'    => $category,
        'price'       => $price,
        'description' => $description,
        'image_url'   => $imageUrl,
    ];
}

apiRun(function (): void {
    apiRequireMethod(['GET', 'POST', 'PUT', 'DELETE']);

    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    // Écritures réservées à un administrateur connecté (voir api/core/auth.php).
    if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
        apiRequireAdmin();
    }

    // --- Création (POST) -------------------------------------------
    if ($method === 'POST') {
        $data = validateItemPayload(apiGetJsonBody());

        if (findItemBySlug($data['slug']) !== null) {
            throw ApiException::validation(
                'Ce slug est déjà utilisé par un autre objet.',
                ['field' => 'slug']
            );
        }

        $id = insertItem($data);

        apiSuccess(findItemById($id), 201);
        return;
    }

    // --- Modification et suppression (PUT/DELETE) : ?id= obligatoire
    if ($method === 'PUT' || $method === 'DELETE') {
        if (!isset($_GET['id']) || $_GET['id'] === '') {
            throw ApiException::badRequest("Le paramètre 'id' est requis pour cette méthode.");
        }

        $id = apiValidateInt($_GET['id'], 'id', 1);

        if (findItemById($id) === null) {
            throw ApiException::notFound("Aucun objet trouvé avec l'ID $id.");
        }

        if ($method === 'DELETE') {
            deleteItem($id);
            apiSuccess(['id' => $id]);
            return;
        }

        $data = validateItemPayload(apiGetJsonBody());

        $existingWithSlug = findItemBySlug($data['slug']);
        if ($existingWithSlug !== null && (int) $existingWithSlug['id'] !== $id) {
            throw ApiException::validation(
                'Ce slug est déjà utilisé par un autre objet.',
                ['field' => 'slug']
            );
        }

        updateItem($id, $data);

        apiSuccess(findItemById($id));
        return;
    }

    // --- Détail par ID (GET) ---------------------------------------
    if (isset($_GET['id']) && $_GET['id'] !== '') {
        $id = apiValidateInt($_GET['id'], 'id', 1);

        $item = findItemById($id);

        if ($item === null) {
            throw ApiException::notFound("Aucun objet trouvé avec l'ID $id.");
        }

        // Recette (composants) de l'objet — voir findItemRecipe(),
        // repository.php. Tableau vide si l'objet n'a pas de recette
        // connue (objet de départ, consommable ou composant de base),
        // ce n'est pas une erreur — même principe que build_items/
        // build_runes sur /api/builds/?id= (api/builds/index.php).
        $item['recipe'] = findItemRecipe($id);

        apiSuccess($item);
        return;
    }

    // --- Liste, avec filtres optionnels (recherche, catégorie) ---------
    $category = null;
    if (isset($_GET['category']) && $_GET['category'] !== '') {
        $category = apiValidateEnum($_GET['category'], 'category', getItemCategories());
    }

    $search = null;
    if (isset($_GET['search']) && $_GET['search'] !== '') {
        $search = apiValidateString($_GET['search'], 'search', 1, 60);
    }

    $items = findItems($category, $search);

    apiSuccess($items, 200, [
        'count'   => count($items),
        'filters' => [
            'category' => $category,
            'search'   => $search,
        ],
    ]);
});
