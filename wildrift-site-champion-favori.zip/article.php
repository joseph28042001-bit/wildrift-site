<?php
/**
 * Point d'entrée public : Article (détail).
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/article.php. Toute la logique/contenu vit dans pages/ — même
 * principe que item.php (fiche détaillée d'un objet).
 *
 * Accessible via article.php?id=5 (voir GET /api/news/?id=,
 * api/news/index.php). L'ID n'est pas validé ici : c'est
 * assets/js/article.js qui le lit depuis l'URL et gère les cas absents
 * ou invalides (voir ce fichier).
 *
 * Étape actuelle : uniquement la page de détail elle-même. Aucune carte
 * de la liste des actualités (pages/news.php, assets/js/news.js) ne
 * pointe encore vers cette page — hors périmètre de cette étape, même
 * choix que pour item.php lors de sa création.
 */

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Article';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/article.php';
require __DIR__ . '/includes/components/footer.php';
