<?php
/**
 * Point d'entrée public : Tier list.
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/tier-list.php. Toute la logique/contenu vit dans pages/.
 */

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Tier list';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/tier-list.php';
require __DIR__ . '/includes/components/footer.php';
