<?php
/**
 * Point d'entrée public : Rune (détail).
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/rune.php. Toute la logique/contenu vit dans pages/ — même
 * principe que item.php (fiche détaillée d'un objet).
 *
 * Accessible via rune.php?id=5 (voir GET /api/runes/?id=,
 * api/runes/index.php). L'ID n'est pas validé ici : c'est
 * assets/js/rune.js qui le lit depuis l'URL et gère les cas absents ou
 * invalides (voir ce fichier).
 *
 * Étape actuelle : uniquement la page de détail elle-même. Aucune carte
 * de la liste des runes (pages/runes.php) ne pointe encore vers cette
 * page — hors périmètre de cette étape, même limite que item.php au
 * moment de son ajout par rapport à pages/items.php.
 */

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Rune';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/rune.php';
require __DIR__ . '/includes/components/footer.php';
