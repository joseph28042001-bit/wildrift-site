# Wild Rift Platform

Plateforme web premium dédiée à Wild Rift.
Architecture PHP/MySQL classique, compatible hébergement mutualisé (InfinityFree).
Pas de Node.js, pas de Docker, pas de serveur permanent requis.

## Structure du projet

L'architecture sépare strictement pages publiques, API, administration,
configuration, base de données, composants, CSS, JS, images et uploads.
Chaque point d'entrée (`index.php`) reste volontairement fin : il ne fait
qu'initialiser, appliquer un layout et charger le contenu depuis `pages/`
— aucune logique n'est concentrée dans un seul fichier.

```
wildrift-site/
├── index.php                       Point d'entrée public (Accueil) — fin, sans logique
├── .htaccess                       Config Apache (InfinityFree) + protection des dossiers internes
│
├── pages/                          PAGES PUBLIQUES (contenu, une page = un fichier)
│   └── home.php
│
├── api/                            API (AJAX/Fetch)
│   ├── index.php                   Point d'entrée /api/ — statut général (aiguille vers api/routes/)
│   ├── routes/
│   │   └── status.php              Route de statut
│   ├── core/                       Socle commun à tous les endpoints REST ci-dessous
│   │   ├── bootstrap.php           À inclure en tête de chaque api/<ressource>/index.php
│   │   ├── response.php            apiSuccess() / apiError() — enveloppe JSON standard
│   │   ├── exceptions.php          ApiException — code HTTP + code d'erreur machine-readable
│   │   ├── validator.php           Validation de base (méthode, JSON, champs requis, types)
│   │   └── runner.php              apiRun() — capture toute exception, jamais de fuite technique
│   ├── champions/                  Fonctionnel : liste, détail (id), recherche, filtre par rôle
│   │   ├── index.php                Routage GET par paramètres (?id=, ?search=, ?role=)
│   │   └── repository.php           Accès données (PDO, requêtes préparées) pour cette ressource
│   ├── items/                      Fonctionnel : liste, détail (id), recherche, filtre par catégorie
│   │   ├── index.php                Routage GET par paramètres (?id=, ?search=, ?category=)
│   │   └── repository.php           Accès données (PDO, requêtes préparées) pour cette ressource
│   ├── runes/                      Fonctionnel : liste, détail (id), recherche, filtre par arbre
│   │   ├── index.php                Routage GET par paramètres (?id=, ?search=, ?tree=)
│   │   └── repository.php           Accès données (PDO, requêtes préparées) pour cette ressource
│   ├── builds/                     Fonctionnel : liste complète (id, nom, champion, rôle, patch)
│   │   ├── index.php                Point d'entrée GET /api/builds/ (pas encore de filtre/détail)
│   │   └── repository.php           Accès données (PDO, requêtes préparées) pour cette ressource
│   ├── counters/                   Fonctionnel : liste avec filtres combinables (champion contré / champion qui contre)
│   │   ├── index.php                Routage GET par paramètres (?champion_id=, ?counter_champion_id=)
│   │   └── repository.php           Accès données (PDO, requêtes préparées) pour cette ressource
│   ├── tier-list/                  Fonctionnel : liste avec filtres combinables (champion, rôle, patch, tier) + détail par ID
│   │   ├── index.php                Routage GET par paramètres (?id=, ?champion=, ?role=, ?patch=, ?tier=)
│   │   └── repository.php           Accès données (PDO, requêtes préparées) pour cette ressource
│   ├── news/                       Fonctionnel : liste complète des actualités publiées (structure initiale)
│   │   ├── index.php                Point d'entrée GET /api/news/ (pas encore de filtre/détail)
│   │   └── repository.php           Accès données (PDO, requêtes préparées) pour cette ressource
│   └── synergies/                  Fonctionnel : liste avec filtres combinables (champion consulté / champion partenaire)
│       ├── index.php                Routage GET par paramètres (?champion_id=, ?synergy_champion_id=)
│       └── repository.php           Accès données (PDO, requêtes préparées) pour cette ressource
│
├── admin/                          ADMINISTRATION (isolée du site public)
│   ├── index.php                   Point d'entrée admin — fin, sans logique
│   ├── includes/
│   │   ├── bootstrap.php           Initialisation propre à l'admin
│   │   ├── header.php              Gabarit d'en-tête admin
│   │   └── footer.php              Gabarit de pied de page admin
│   └── pages/
│       └── dashboard.php           Contenu du tableau de bord (placeholder)
│
├── config/                         CONFIGURATION (voir section dédiée ci-dessous)
│   ├── environment.php              Environnement + chargement de config.local.php
│   ├── app.php                      Configuration générale (nom, version, chemins)
│   ├── site.php                     URL du site + helpers url()/asset()
│   ├── session.php                  Paramètres de session
│   ├── security.php                 Paramètres de sécurité (CSRF, en-têtes, hachage)
│   ├── uploads.php                  Paramètres d'upload
│   ├── database.php                 Connexion PDO à MySQL
│   ├── config.local.php.example     Modèle de config locale (non versionné)
│   └── database.local.php.example   Modèle pour les identifiants réels (non versionné)
│
├── database/                       BASE DE DONNÉES
│   ├── schema.sql                  Schéma SQL à importer sur le serveur MySQL
│   ├── migration_patches.sql       Migration : table `patches` seule, pour une base déjà en place
│   └── migration_patch_links.sql   Migration : colonne `patch_id` sur les données (rejouable)
│
├── includes/                       COMPOSANTS / INCLUDES PARTAGÉS
│   ├── bootstrap.php               Point d'entrée commun (à inclure en tête de page)
│   ├── error_handler.php           Filet de sécurité global (aucune erreur sensible affichée)
│   ├── functions.php               Fonctions utilitaires partagées
│   ├── patches.php                 Patchs : patch actif, recherche par version, rattachement patch_id
│   └── components/
│       ├── header.php              Gabarit d'en-tête HTML public
│       └── footer.php              Gabarit de pied de page HTML public
│
├── assets/
│   ├── css/style.css               CSS
│   ├── js/main.js                  JavaScript
│   └── images/                     Images
│
└── uploads/                        Fichiers uploadés (non versionné)
```

### Convention des points d'entrée

- `index.php` (racine, admin) : initialise, applique le layout, inclut une page — jamais de logique métier.
- `pages/*.php` et `admin/pages/*.php` : contenu HTML/PHP d'une page, un fichier par page.
- `includes/components/*.php` : éléments de layout réutilisables (header, footer, futurs composants).
- `api/index.php` : routeur du statut général uniquement ; chaque route de statut vit dans son propre fichier sous `api/routes/`.
- `api/<ressource>/index.php` (champions, items, runes, builds, counters, tier-list, news) : un point d'entrée REST par ressource. Chacun commence par `require_once __DIR__ . '/../core/bootstrap.php';` puis enveloppe sa logique dans `apiRun(function () { ... })`.
  - `champions` est développé : `GET /api/champions/` (liste), `?id=` (détail), `?search=` (recherche par nom), `?role=` (filtre parmi baron/jungle/mid/dragon/support) — `search` et `role` sont cumulables, `id` est prioritaire et exclusif. Données lues via PDO en requêtes préparées (`api/champions/repository.php`), table `champions` (voir `database/schema.sql`).
  - `items` est développé, sur le même principe : `GET /api/items/` (liste), `?id=` (détail), `?search=` (recherche par nom), `?category=` (filtre parmi attack/magic/defense/boots/jungle/consumable) — `search` et `category` sont cumulables, `id` est prioritaire et exclusif. Données lues via PDO en requêtes préparées (`api/items/repository.php`), table `items` (voir `database/schema.sql`).
  - `runes` est développé, sur le même principe : `GET /api/runes/` (liste), `?id=` (détail), `?search=` (recherche par nom), `?tree=` (filtre parmi precision/domination/sorcery/resolve/inspiration) — `search` et `tree` sont cumulables, `id` est prioritaire et exclusif. Données lues via PDO en requêtes préparées (`api/runes/repository.php`), table `runes` (voir `database/schema.sql`).
  - `builds` est développé, sur un principe plus simple que les trois ressources précédentes : `GET /api/builds/` renvoie la liste complète des builds (pas encore de détail par `?id=` ni de filtre à cette étape). Chaque build ne renvoie que les informations essentielles — id, nom, champion, rôle, patch — le nom du champion étant résolu par jointure sur `champions` (`champion_id`). Données lues via PDO en requêtes préparées (`api/builds/repository.php`), table `builds` (voir `database/schema.sql`).
  - `counters` (Matchups & counters) est développé : `GET /api/counters/` (liste), `?id=` (un matchup précis par l'ID du counter, prioritaire et exclusif — utilisé par `matchup.php`), `?champion_id=` (counters concernant le champion contré), `?counter_champion_id=` (n'a de sens qu'avec `champion_id`, précise le matchup) — les deux derniers filtres sont cumulables entre eux. Chaque counter renvoie aussi ses objets recommandés (relation `counter_items`, jointe à `items`), avec pour chacun sa colonne `situation` (nullable : renseignée pour un objet situationnel, absente pour un objet de base — voir `database/schema.sql`). Erreurs : `422` si un ID est invalide ou si `counter_champion_id` est fourni sans `champion_id`, `404` si un champion n'existe pas, si le matchup précis (`?id=`) n'existe pas, ou si le couple `champion_id`/`counter_champion_id` ne correspond à aucun matchup. Données lues via PDO en requêtes préparées (`api/counters/repository.php`), tables `counters` et `counter_items` (voir `database/schema.sql`).
  - `tier-list` (classement des champions) est développée : `GET /api/tier-list/` (liste), `?id=` (détail complet), `?champion=` (filtre par slug), `?role=` (filtre parmi baron/jungle/mid/dragon/support), `?patch=` (filtre par patch), `?tier=` (filtre parmi S+/S/A/B/C/D) — `champion`, `role`, `patch` et `tier` sont cumulables, `id` est prioritaire et exclusif. Chaque entrée associe un champion (résolu par jointure sur `champions`, jamais `champion_id` brut) à un rôle, un tier et un patch, avec des taux `win_rate`/`pick_rate`/`ban_rate` facultatifs ; le détail par `?id=` ajoute les notes et les dates. Triée par patch (le plus récent d'abord) puis par tier (S+ en tête). Données lues via PDO en requêtes préparées (`api/tier-list/repository.php`), table `tier_list` (voir `database/schema.sql`).
  - `news` (actualités) : `GET /api/news/` (liste complète des actualités publiées), `?search=` (recherche par titre, LIKE), `?category=` (filtre parmi patch/esport/evenement/communaute), `?limit=` (les N articles les plus récents, N entre 1 et 20) — `search`, `category` et `limit` sont cumulables — `?id=` (détail complet d'un article précis, ajoute le corps `content` et les dates) — `id` est prioritaire et exclusif sur les trois autres. Pas encore de pagination complète (page/offset) à cette étape. Un article non publié (`published_at` non renseigné, ex. un brouillon) n'est jamais renvoyé, quel que soit le filtre. Erreurs : `422` si `?id=` n'est pas un entier ≥ 1, si `?search=` dépasse 150 caractères, si `?category=` est hors énumération, ou si `?limit=` n'est pas un entier entre 1 et 20 ; `404` si aucun article publié ne correspond à l'ID. Données lues via PDO en requêtes préparées (`api/news/repository.php`), table `news` (voir `database/schema.sql`).
  - `abilities` (capacités des champions) : `GET /api/abilities/` (liste complète), `?id=` (détail complet), `?champion=` (filtre par slug de champion), `?slot=` (filtre parmi passive/q/w/e/r) — `champion` et `slot` sont cumulables, `id` est prioritaire et exclusif. Chaque capacité associe un champion (résolu par jointure sur `champions`, jamais `champion_id` brut) à un emplacement (`slot`), un nom et une description ; le détail par `?id=` ajoute les dates. Triée par champion (nom) puis par emplacement dans l'ordre naturel du kit (passive, q, w, e, r). Un slug de champion inconnu renvoie une liste vide (pas une erreur), comme `?champion=` sur `/api/tier-list/`. Erreurs : `422` si `?id=` n'est pas un entier ≥ 1, si `?slot=` est hors énumération, ou si `?champion=` dépasse 60 caractères ; `404` si aucune capacité ne correspond à l'ID. Données lues via PDO en requêtes préparées (`api/abilities/repository.php`), table `champion_abilities` (voir `database/schema.sql`).
  - `synergies` (synergies d'équipe) est développée, sur le même principe que `counters` : `GET /api/synergies/` (liste), `?champion_id=` (synergies concernant le champion consulté), `?synergy_champion_id=` (n'a de sens qu'avec `champion_id`, précise la paire) — les deux filtres sont cumulables. Pas encore de détail par `?id=` à cette étape. Contrairement à `counters`, pas de difficulté ni d'objets recommandés associés : chaque synergie ne renvoie que son explication. Erreurs : `422` si un ID est invalide ou si `synergy_champion_id` est fourni sans `champion_id`, `404` si un champion n'existe pas ou si la synergie précise n'existe pas. Données lues via PDO en requêtes préparées (`api/synergies/repository.php`), table `synergies` (voir `database/schema.sql`).
- `api/core/` : socle commun à ces endpoints — jamais appelé directement (protégé par `.htaccess`), toujours inclus via `api/core/bootstrap.php`.
- `assets/js/news.js` : première consommation côté navigateur d'une ressource API (voir section « Front-end » ci-dessous) — récupération de la liste des articles uniquement, pas encore d'affichage.
- `champions.php` + `pages/champions.php` + `assets/js/champions.js` : première page publique connectée à son API avec affichage (voir section « Front-end » ci-dessous, « Page Champions »).
- `items.php` + `pages/items.php` + `assets/js/items.js` : même principe, appliqué aux objets (voir section « Front-end » ci-dessous, « Page Objets »).

## Front-end (AJAX/Fetch)

Les ressources API ci-dessus n'étaient jusqu'ici consommées que côté
serveur/tests. `assets/js/news.js` amorce la consommation côté navigateur :

- `window.API_BASE_URL` (défini dans `includes/components/footer.php` via
  `asset('api')`) donne aux fichiers JS statiques une base d'URL valide
  quel que soit le sous-dossier d'installation du site.
- `fetchNewsList()` appelle `GET /api/news/` avec `fetch()`, lit l'enveloppe
  JSON standard (`{ success, data, meta }`) et renvoie la liste des
  articles publiés (ou rejette avec une erreur explicite en cas d'échec).
- `fetchNewsById(id)` appelle `GET /api/news/?id=` de la même façon et
  renvoie le détail d'un article précis (ou rejette si l'ID est invalide,
  si l'article n'existe pas, ou n'est pas publié).
- `fetchNewsSearch(query)` appelle `GET /api/news/?search=` de la même
  façon et renvoie les articles publiés dont le titre correspond (ou un
  tableau vide si aucun ne correspond).
- `fetchNewsByCategory(category)` appelle `GET /api/news/?category=` de
  la même façon et renvoie les articles publiés de cette catégorie (ou un
  tableau vide si aucun ne correspond).
- `fetchRecentNews(limit)` appelle `GET /api/news/?limit=` de la même
  façon et renvoie les `limit` articles publiés les plus récents.
- Les cinq fonctions ci-dessus s'appuient toutes sur un point d'entrée
  commun, `newsApiRequest(url)`, qui centralise la gestion des erreurs et
  rejette toujours avec un `NewsApiError` (code + message) plutôt qu'une
  erreur générique. Trois familles sont distinguées : la requête n'atteint
  pas le serveur (`network_error`), le serveur répond mais pas en JSON
  exploitable (`invalid_response`), ou l'API répond avec `success: false`
  (le `code` est alors celui de l'API — `validation_error`, `not_found`...
  — voir `api/core/response.php`). `logNewsApiError()` journalise ces
  erreurs de façon uniforme dans la démonstration ci-dessous.
- À cette étape, les résultats ne sont que journalisés en console au
  chargement de la page (`console.log`/`console.error`) : **aucun
  affichage HTML** n'a encore été ajouté — ce sera l'objet d'une prochaine
  étape, une fois les récupérations validées. Faute de page de détail, de
  champ de recherche et de menu de catégories, la démonstration réutilise
  le premier article de la liste (son ID, son titre, puis sa catégorie),
  et récupère les 3 articles les plus récents.

### Page Champions (`/champions.php`)

Contrairement à `assets/js/news.js` ci-dessus (fetch seul, sans affichage),
`champions.php` (point d'entrée) + `pages/champions.php` (contenu) +
`assets/js/champions.js` forment la première page publique réellement
connectée à son API, avec affichage :

- `fetchChampions()` appelle `GET /api/champions/` avec `fetch()` et
  renvoie la liste complète des champions (ou rejette avec un message
  d'erreur sûr à afficher, en distinguant échec réseau, réponse non-JSON
  et erreur applicative — même principe que `newsApiRequest()`, en plus
  simple).
- `renderChampionCard()` construit une carte par champion (composant
  `.card` du design system — voir `pages/styleguide.php`) : nom, titre
  (si renseigné), badge de rôle coloré (`CHAMPION_ROLE_BADGE_CLASSES`,
  un badge neutre pour `support`, faute de couleur dédiée dans le design
  system actuel) et niveau de difficulté brut (l'échelle exacte n'étant
  pas documentée dans `database/schema.sql`, aucun dénominateur n'est
  affiché).
- Trois états gérés dans `pages/champions.php` : chargement (`.spinner`,
  visible par défaut), erreur (texte caché par défaut, affiché uniquement
  en cas d'échec) et la grille de résultats (`.grid`, vide tant que l'API
  n'a pas répondu).
- `assets/js/champions.js` n'est chargé que sur cette page (contrairement
  à `news.js`, chargé globalement) : il dépend d'éléments (`#champions-*`)
  absents des autres pages.
- Aucun filtre (rôle, recherche) à cette étape : uniquement la liste
  complète, sans paramètre.

### Page Objets (`/items.php`)

Même principe que la page Champions ci-dessus, appliquée aux objets :

- `fetchItems(search, category)` appelle `GET /api/items/` avec des
  `?search=` et `?category=` optionnels et combinables, et renvoie la
  liste correspondante (mêmes trois familles d'erreur distinguées :
  réseau, réponse non-JSON, erreur applicative).
- `renderItemCard()` construit une carte par objet : nom, description (si
  renseignée), badge de catégorie coloré (`ITEM_CATEGORY_BADGE_CLASSES`)
  et prix en or (`null` affiché comme "Prix inconnu").
- Formulaire de recherche par nom et de filtre par catégorie
  (`#items-search-form`), sur le même principe que celui de la page
  Champions (`#champions-search-form`) : relance `loadItems()` avec le
  terme et/ou la catégorie sélectionnés à la soumission, le bouton de
  réinitialisation revient à la liste complète. Le select de catégorie
  ne propose que les six valeurs acceptées par `?category=` côté API
  (`getItemCategories()`, `api/items/repository.php`) — pas
  `enchantment`, absente de cette liste bien que présente dans l'ENUM
  `category` de `database/schema.sql` : un objet de cette catégorie
  reste visible sans filtre, mais ne peut pas être isolé par ce select.
- Mêmes trois états que la page Champions (chargement, erreur, grille) et
  même chargement du script propre à cette page uniquement.

## Configuration

Toute la configuration est centralisée dans `config/` et chargée dans
un ordre précis par `includes/bootstrap.php` : environnement → général →
URL du site → session → sécurité → uploads → base de données.

| Aspect               | Fichier                  | Contenu |
|----------------------|---------------------------|---------|
| Configuration générale | `config/app.php`        | Nom/version de l'app, chemins serveur, fuseau horaire |
| URL du site          | `config/site.php`         | `SITE_URL`, `BASE_URL`, helpers `url()` / `asset()` |
| Environnement         | `config/environment.php`  | `ENVIRONMENT` (`development` / `production`), charge `config.local.php` |
| Session               | `config/session.php`      | Nom du cookie, durée de vie, démarrage sécurisé (`startSecureSession()`) |
| Sécurité              | `config/security.php`     | En-têtes HTTP, jetons CSRF, coût du hachage des mots de passe |
| Uploads               | `config/uploads.php`      | Taille max, extensions autorisées, nommage sûr des fichiers |
| Base de données       | `config/database.php`     | Connexion PDO (identifiants dans `database.local.php`) |
| Patch actif           | `config/patch.php`        | `CURRENT_PATCH` (version du jeu, source unique ; `window.CURRENT_PATCH` côté JS) |

### Installation / modification après mise en ligne sur InfinityFree

Trois fichiers locaux, non versionnés, concentrent tout ce qu'il y a à
modifier après installation — aucun autre fichier n'a besoin d'être touché :

1. Copier `config/config.local.php.example` → `config/config.local.php`
   et adapter : `SITE_URL`, `BASE_URL`, réglages de session, `SECURITY_APP_KEY`,
   limites d'upload.
2. Copier `config/database.local.php.example` → `config/database.local.php`
   et renseigner les identifiants MySQL fournis par InfinityFree.
3. (Optionnel, étape 21.x) Copier `config/riot.local.php.example` →
   `config/riot.local.php` et renseigner une vraie clé d'API Riot, une
   fois disponible. Sans ce fichier, `isRiotApiConfigured()` retourne
   `false` et rien ne change au fonctionnement du site.

Ces trois fichiers sont ignorés par Git (`.gitignore`) et bloqués à l'accès
direct par `.htaccess` (tout le dossier `config/` est protégé).

## Prérequis

Aucun outil de build n'est nécessaire (pas de Node.js, pas de Composer :
le projet n'a aucune dépendance externe). Il faut seulement :

| Élément | Version / détail |
|---|---|
| PHP | 8.0 ou supérieur |
| Extensions PHP | `pdo_mysql`, `mbstring`, `json`, `session` (les 3 dernières sont activées par défaut sur PHP 8+) |
| MySQL / MariaDB | 5.7+ / MariaDB équivalent (fourni par InfinityFree) |
| Serveur web | Apache avec `mod_rewrite` et `mod_headers` (standard sur InfinityFree) |

Sur InfinityFree, `pdo_mysql` et `mbstring` sont activées par défaut ; rien
à configurer côté panneau d'hébergement. Sur un autre hébergeur Apache/PHP,
vérifier leur activation dans `php.ini` ou le panneau de contrôle.

## Variables d'environnement

Il n'y a pas de fichier `.env` : toute la configuration passe par des
constantes PHP définies dans `config/config.local.php` et
`config/database.local.php` (voir section précédente), chargées par-dessus
des valeurs par défaut sûres pour le développement local
(`config/environment.php`).

| Variable | Développement (défaut) | Production (à définir) |
|---|---|---|
| `ENVIRONMENT` | `development` | `production` |
| `SITE_URL` | `http://localhost` | `https://tondomaine.infinityfreeapp.com` (doit commencer par `https://`) |
| `BASE_URL` | `/` | `/` (ou `/sous-dossier/` si applicable) |
| `SESSION_COOKIE_SECURE` | `false` | `true` (obligatoire) |
| `SECURITY_APP_KEY` | clé de dev par défaut | chaîne aléatoire ≥ 32 caractères, générée via `php -r "echo bin2hex(random_bytes(32));"` |
| `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS` | valeurs locales | identifiants MySQL fournis par InfinityFree |

**Sécurité :** `config/environment.php` expose `checkProductionReadiness()`,
appelée automatiquement par `includes/bootstrap.php`. Si `ENVIRONMENT` vaut
`production` alors que `SECURITY_APP_KEY` est restée par défaut, que
`SITE_URL` n'est pas en `https://`, ou que `SESSION_COOKIE_SECURE` n'est
pas à `true`, le site refuse de démarrer (erreur générique affichée au
visiteur, détail journalisé côté serveur). Impossible donc de mettre en
ligne accidentellement avec des réglages de développement.

## HTTPS en production

- InfinityFree fournit un certificat SSL gratuit pour chaque (sous-)domaine :
  l'activer depuis le panneau d'hébergement avant la mise en ligne.
- `.htaccess` force la redirection de tout accès HTTP vers HTTPS
  (`RewriteCond %{HTTPS} off` + repli sur l'en-tête `X-Forwarded-Proto`
  pour le cas d'un CDN/proxy devant Apache).
- Une fois `SESSION_COOKIE_SECURE=true` et `ENVIRONMENT=production`,
  `sendSecurityHeaders()` (`config/security.php`) ajoute l'en-tête
  `Strict-Transport-Security` (HSTS).
- Le cookie de session est alors marqué `secure` + `httponly` +
  `SameSite=Lax` (`config/session.php`).

## Gestion des erreurs

Plusieurs niveaux, du plus interne au plus externe, garantissent qu'aucune
information technique (SQL, identifiants, chemin serveur, stack trace)
n'atteint jamais un visiteur :

1. **Base de données** (`config/database.php`) : toute `PDOException` est
   journalisée via `error_log()` puis remplacée par un message générique
   (`DatabaseException`).
2. **Filet global PHP** (`includes/error_handler.php`) : capture toute
   exception ou erreur PHP non interceptée ailleurs, journalise le détail,
   affiche un message générique.
3. **Affichage des erreurs** (`config/app.php`) : piloté par `APP_DEBUG`
   (= `ENVIRONMENT === 'development'`) — erreurs visibles en dev,
   totalement masquées en production (`display_errors=0`).
4. **Pages d'erreur Apache** (`errors/404.php`, `errors/403.php`,
   `errors/500.php`, déclarées via `ErrorDocument` dans `.htaccess`) :
   filet de tout dernier recours si Apache renvoie une erreur avant même
   que PHP n'ait pu s'exécuter. Volontairement autonomes (aucune
   dépendance à `bootstrap.php`, à la config ou à la base de données) pour
   rester fiables même si le reste de l'application est cassé.

## Configuration serveur (Apache)

Le projet cible un hébergement mutualisé Apache (InfinityFree) : pas
d'accès SSH, pas de Nginx, pas de PHP-FPM configurable — toute la
configuration serveur passe donc par `.htaccess`, qui gère :

- la redirection HTTPS ;
- les pages d'erreur personnalisées (`ErrorDocument`) ;
- les en-têtes de sécurité au niveau serveur (`X-Content-Type-Options`,
  `X-Frame-Options`, `Referrer-Policy`) — utile pour les fichiers statiques
  (CSS/JS/images) qu'Apache sert directement, sans passer par PHP ;
- le blocage d'accès direct aux fichiers sensibles (`*.local.php`, `*.sql`,
  `*.md`, `*.log`, `*.example`) et aux dossiers internes
  (`includes/`, `pages/`, `config/`, `database/`, `admin/includes/`,
  `admin/pages/`, `api/routes/`, `api/core/`) ;
- la désactivation du listing de répertoires.

Si le projet est un jour déployé sur un serveur avec accès complet
(VPS/Nginx) plutôt que sur de l'hébergement mutualisé, il faudra alors
traduire ces règles `.htaccess` en configuration `server{}` Nginx
(`try_files`, `location ~ \.php$`, `fastcgi_pass`) — non nécessaire ici
car hors du périmètre InfinityFree.

## Permissions

- `uploads/` doit rester accessible en écriture par PHP : `755` (ou `775`
  selon l'hébergeur) suffit, ne jamais mettre `777`.
- `config/config.local.php` et `config/database.local.php` : lecture seule
  pour le serveur web suffit (`644`) ; ils ne sont de toute façon jamais
  servis directement grâce au blocage `.htaccess` ci-dessus.
- Sur InfinityFree (accès FTP uniquement, pas de shell), les permissions
  par défaut appliquées à l'upload conviennent généralement ; les ajuster
  depuis le client FTP uniquement si `uploads/` n'est pas accessible en
  écriture après déploiement.

## Build et paquet de déploiement

Le projet est en PHP pur : il n'y a rien à compiler. `deploy/build.sh`
remplace l'étape de "build" par une validation + un empaquetage propre :

```bash
./deploy/build.sh
```

Le script :
1. vérifie la syntaxe de tous les fichiers `.php` (`php -l`, si PHP est
   disponible localement) ;
2. vérifie que `config/config.local.php` et `config/database.local.php`
   existent (sinon il s'arrête : mieux vaut échouer avant l'upload
   qu'après) ;
3. copie le projet dans un dossier temporaire en excluant `.git/`,
   `deploy/` et les fichiers `*.example` ;
4. produit `deploy/dist/wildrift-site-<horodatage>.zip`, prêt à être
   décompressé à la racine de `htdocs/` via FTP.

## Déploiement sur InfinityFree

1. Créer une base MySQL depuis le panneau InfinityFree (note le serveur,
   le nom de la base, l'utilisateur et le mot de passe fournis).
2. Copier `config/config.local.php.example` vers `config/config.local.php`
   et renseigner `SITE_URL` (en `https://`), `SECURITY_APP_KEY` (générée
   aléatoirement) et les autres réglages (voir section Variables
   d'environnement).
3. Copier `config/database.local.php.example` vers `config/database.local.php`
   et renseigner les 4 identifiants MySQL (serveur, nom de base, utilisateur,
   mot de passe).
4. Importer `database/schema.sql` via phpMyAdmin.
5. Activer le certificat SSL gratuit depuis le panneau InfinityFree.
6. Lancer `./deploy/build.sh` pour générer le paquet de déploiement.
7. Uploader le contenu du zip généré via FTP à la racine du site (`htdocs/`).

### Checklist avant mise en production

- [ ] `ENVIRONMENT` = `production` dans `config.local.php`
- [ ] `SITE_URL` commence par `https://`
- [ ] `SECURITY_APP_KEY` remplacée par une valeur aléatoire ≥ 32 caractères
- [ ] `SESSION_COOKIE_SECURE` = `true`
- [ ] SSL activé côté InfinityFree
- [ ] `database.local.php` renseigné avec les vrais identifiants MySQL
- [ ] `database/schema.sql` importé
- [ ] `deploy/build.sh` exécuté sans erreur

## Connexion à la base de données (PDO)

`config/database.php` fournit une connexion PDO unique (singleton) à MySQL
et des fonctions prêtes à l'emploi, toutes basées sur des **requêtes
préparées** (aucune valeur ne doit jamais être concaténée dans une chaîne SQL) :

| Fonction | Usage |
|----------|-------|
| `dbFetchOne($sql, $params)` | Récupère une seule ligne (ou `null`) |
| `dbFetchAll($sql, $params)` | Récupère toutes les lignes |
| `dbExecute($sql, $params)`  | INSERT/UPDATE/DELETE — retourne le nombre de lignes affectées |
| `dbLastInsertId()`          | Identifiant de la dernière ligne insérée |

Exemple :

```php
$champion = dbFetchOne(
    'SELECT * FROM champions WHERE slug = :slug',
    ['slug' => $slug]
);
```

**Sécurité des erreurs.** Ni les identifiants (serveur, base, utilisateur,
mot de passe), ni les messages d'erreur SQL bruts ne sont jamais envoyés au
visiteur :
- Une erreur de connexion ou de requête est toujours journalisée côté
  serveur (`error_log`) et remplacée par un message générique.
- `includes/error_handler.php` agit comme filet de sécurité global : toute
  exception ou erreur PHP non interceptée ailleurs affiche un message
  générique au visiteur, jamais le détail technique.

## Déploiement sur InfinityFree

1. Créer une base MySQL depuis le panneau InfinityFree (note le serveur,
   le nom de la base, l'utilisateur et le mot de passe fournis).
2. Copier `config/config.local.php.example` vers `config/config.local.php`
   et renseigner `SITE_URL` ainsi que les autres réglages (voir section Configuration).
3. Copier `config/database.local.php.example` vers `config/database.local.php`
   et renseigner les 4 identifiants MySQL (serveur, nom de base, utilisateur, mot de passe).
4. Importer `database/schema.sql` via phpMyAdmin.
5. Uploader l'ensemble du dossier via FTP à la racine du site (`htdocs/`).

## État du projet

- Étape 1 : initialisation de la structure générale du projet.
- Étape 2 : réorganisation propre de l'architecture (pages publiques / API / admin /
  config / base de données / composants / assets clairement séparés).
- Étape 3 : système de configuration complet (générale, URL du site, environnement,
  session, sécurité, uploads) avec fichier local d'exemple sans secret réel.
- Étape 4 : connexion PHP/MySQL via PDO et requêtes préparées (`dbFetchOne`,
  `dbFetchAll`, `dbExecute`), avec gestion d'erreurs qui ne montre jamais
  d'identifiant ni de message SQL au visiteur (journalisation serveur uniquement).
- Étape 5 : préparation au déploiement — garde-fou de mise en production
  (`checkProductionReadiness()`), HTTPS forcé + pages d'erreur personnalisées
  au niveau Apache (`errors/`), et script de build/packaging (`deploy/build.sh`).
- Étape 6 : design system "Hextech" — palette sombre, typographie (Rajdhani /
  Manrope / JetBrains Mono), boutons, cartes, badges, formulaires, menus,
  modales, loaders et notifications, tous animés et responsive
  (`assets/css/style.css`, `assets/js/main.js`). Vitrine consultable sur
  `/styleguide.php`.
- Étape 7 : API REST des ressources Wild Rift, développée progressivement
  ressource par ressource — `champions`, `items`, `runes`, `builds`
  (liste complète : id, nom, champion, rôle, patch), `counters`
  (Matchups & counters — liste avec filtres combinables par champion contré
  et champion qui contre, objets recommandés associés), puis `tier-list`
  (classement des champions — liste avec filtres combinables par champion,
  rôle, patch et tier, plus détail par ID), puis `news` (actualités —
  structure initiale : liste complète des actualités publiées).
- Étape 8 : première consommation de l'API côté navigateur (`assets/js/news.js`)
  — récupération de la liste des articles via `fetch()`, récupération d'un
  article précis par ID (`?id=`), recherche d'articles par titre
  (`?search=`), filtre par catégorie (`?category=`), récupération des
  articles récents (`?limit=`, ajoutés aussi côté API `/api/news/`), puis
  une gestion des erreurs commune (`NewsApiError`, `newsApiRequest()`)
  distinguant erreur réseau, réponse invalide et erreur applicative,
  uniquement, sans affichage HTML à cette étape (voir section « Front-end »
  ci-dessus). Couverture de test complète ajoutée pour l'API Actualités
  (`tests/test-news-api.php` — liste, recherche, catégorie, articles
  récents, détail par ID, exclusion des brouillons, méthode HTTP et codes
  d'erreur) : relecture du code n'ayant révélé aucun bug, aucune
  correction n'a été nécessaire.
- Étape 9 : première page publique connectée à son API avec affichage —
  page Champions (`champions.php`, `pages/champions.php`,
  `assets/js/champions.js`) : `fetchChampions()` récupère `GET
  /api/champions/` et affiche chaque champion sous forme de carte (design
  system existant — nom, titre, badge de rôle coloré, difficulté), avec
  un état de chargement et un état d'erreur. Uniquement la connexion de
  cette page à son API à cette étape : pas de filtre (rôle, recherche) ni
  de lien vers une éventuelle fiche champion.
- Étape 9 (suite) : même principe pour les objets — page Objets (`items.php`,
  `pages/items.php`, `assets/js/items.js`) : `fetchItems()` récupère `GET
  /api/items/` et affiche chaque objet sous forme de carte (nom,
  description, badge de catégorie coloré, prix), avec les mêmes états de
  chargement/erreur. Uniquement la connexion de cette page à son API à
  cette étape : pas de filtre (catégorie, recherche).
- Étape 9 (suite) : mise à jour du menu de navigation uniquement
  (`includes/components/header.php`) pour refléter l'ensemble des pages
  prévues : Accueil, Champions, Builds, Tier List, Counters, Objets/Runes,
  Simulation, Actualités. "Objets" et "Runes" sont regroupés sous une
  seule entrée "Objets/Runes" grâce au composant `.dropdown` déjà existant
  du design system (aucun nouveau CSS/JS de comportement, seul le balisage
  change) ; les deux pages restent inchangées et toujours accessibles
  individuellement. Le lien "Simulation" est ajouté avec un point d'entrée
  minimal (`simulation.php` + `pages/simulation.php`, contenu provisoire)
  pour éviter un lien mort — la fonctionnalité de simulation elle-même
  n'est pas développée à cette étape. Le lien "Design system" est retiré
  du menu public (la page `/styleguide.php` reste accessible directement,
  elle n'est simplement plus listée dans la navigation).
- Étape 10 : nouvelle ressource API — `abilities` (capacités des
  champions : passive + Q/W/E/R), sur le même principe que les
  ressources précédentes (`GET /api/abilities/`, `?id=`, `?champion=`,
  `?slot=` — voir section « API » ci-dessus), adossée à une nouvelle
  table `champion_abilities` (voir `database/schema.sql`, jeu de données
  complet : les 5 capacités des 10 champions existants). Cette ressource
  alimente une troisième section "Capacités" sur la page de détail
  Champion (`pages/champion.php` + `assets/js/champion.js`), affichée
  sous la section "Statistiques" existante : une carte par capacité
  (emplacement, nom, description), avec ses propres états de
  chargement/erreur/vide, interrogée via `GET
  /api/abilities/?champion=<slug>` une fois la fiche du champion
  chargée — même principe que la section "Statistiques" (connexion
  indépendante, par le slug du champion).
- Étape 11 : quatrième section sur la page de détail Champion —
  "Builds" (`pages/champion.php` + `assets/js/champion.js`), affichée
  sous la section "Capacités" ajoutée à l'étape précédente. Réutilise la
  ressource `/api/builds/` existante (voir section « API » ci-dessus)
  avec son filtre `?champion=` déjà pris en charge côté API mais pas
  encore exploité côté navigateur (`pages/builds.php` affiche la liste
  complète paginée, sans filtre) : `GET
  /api/builds/?champion=<slug>` une fois la fiche du champion chargée,
  une carte par build (nom, rôle, patch), avec ses propres états de
  chargement/erreur/vide — même principe que les sections
  "Statistiques" et "Capacités" (connexion indépendante, par le slug du
  champion). Aucune pagination câblée ici (peu de builds par champion à
  ce stade) ; le détail d'un build (objets, runes, ordre des
  compétences, `GET /api/builds/?id=`) reste hors du périmètre de cette
  étape.
- Étape 12 : cinquième section sur la page de détail Champion —
  "Counters" (`pages/champion.php` + `assets/js/champion.js`), affichée
  sous la section "Builds" ajoutée à l'étape précédente. Réutilise la
  ressource `/api/counters/` existante (voir section « API » ci-dessus)
  avec son filtre `?champion_id=` déjà pris en charge côté API mais pas
  encore exploité côté navigateur (`pages/counters.php` affiche tous
  les counters, sans filtre) : `GET /api/counters/?champion_id=<id>`
  une fois la fiche du champion chargée (par son ID, cette ressource ne
  filtrant pas par slug), une carte par counter (explication, conseils,
  objets recommandés, difficulté), avec ses propres états de
  chargement/erreur/vide — même principe que les sections précédentes
  (connexion indépendante). Comme sur `pages/counters.php`
  (`assets/js/counters.js`), le champion qui contre
  (`counter_champion_id`) reste affiché en ID brut, l'API ne le
  résolvant pas en nom à ce stade — même limite reprise ici plutôt que
  corrigée, hors périmètre de cette étape.
- Étape 13 : nouvelle ressource API — `synergies` (synergies d'équipe),
  sur le même principe que `counters` (`GET /api/synergies/`,
  `?champion_id=`, `?synergy_champion_id=` — voir section « API »
  ci-dessus), adossée à une nouvelle table `synergies` (voir
  `database/schema.sql`, jeu de données minimal : 5 paires de champions,
  renseignées dans les deux sens). Contrairement à `counters`, pas de
  difficulté ni d'objets recommandés associés. Cette ressource alimente
  une sixième section "Synergies" sur la page de détail Champion
  (`pages/champion.php` + `assets/js/champion.js`), affichée sous la
  section "Counters" ajoutée à l'étape précédente : `GET
  /api/synergies/?champion_id=<id>` une fois la fiche du champion
  chargée (par son ID, comme pour les counters), une carte par synergie
  (explication uniquement), avec ses propres états de
  chargement/erreur/vide — même principe que les sections précédentes
  (connexion indépendante). Comme pour les counters, le champion
  partenaire (`synergy_champion_id`) reste affiché en ID brut, l'API ne
  le résolvant pas en nom à ce stade — même limite reprise ici, hors
  périmètre de cette étape.
- Étape 14 : nouvelle page d'administration — liste des objets
  (`admin/items.php` + `admin/pages/items.php` +
  `assets/js/admin-items.js`), sur le même principe que la page
  d'administration Champions déjà existante (`admin/champions.php` +
  `admin/pages/champions.php` + `assets/js/admin-champions.js`) :
  uniquement la liste en lecture seule, injectée via `GET /api/items/`
  (la même API que la page publique Objets), avec ses propres états de
  chargement/erreur. Aucune action de gestion (création, modification,
  suppression) n'est développée à cette étape. Lien "Objets" ajouté au
  menu d'administration (`admin/includes/header.php`), à côté de
  "Champions".
- Étape 15 : recherche par nom sur la page publique Objets
  (`pages/items.php` + `assets/js/items.js`), sur le même principe que
  la recherche déjà existante sur la page Champions
  (`#champions-search-form`) : formulaire `#items-search-form` câblé sur
  le paramètre `?search=` déjà supporté par `/api/items/` (voir section
  « API » ci-dessus), qui relance `loadItems()` avec le terme saisi à
  la soumission ; le bouton de réinitialisation revient à la liste
  complète. Contrairement à la page Champions, pas de filtre par
  catégorie ajouté ici (uniquement la recherche à cette étape) — le
  paramètre `?category=` de `/api/items/` reste donc inexploité côté
  navigateur.
- Étape 16 : filtre par catégorie sur la page publique Objets
  (`pages/items.php` + `assets/js/items.js`), en complément de la
  recherche par nom ajoutée à l'étape précédente — sur le même principe
  que le filtre par rôle de la page Champions (`#champions-role-filter`) :
  select `#items-category-filter` câblé sur le paramètre `?category=`
  déjà supporté par `/api/items/` (voir section « API » ci-dessus),
  combinable avec `?search=`. Ne propose que les six catégories
  acceptées par l'API (`getItemCategories()`,
  `api/items/repository.php`) — pas `enchantment`, absente de cette
  liste bien que présente dans l'ENUM `category` de
  `database/schema.sql` : un objet de cette catégorie reste visible
  sans filtre, mais ne peut pas être isolé par ce select — même limite
  reprise ici plutôt que corrigée, hors périmètre de cette étape.
- Étape 17 : fiche détaillée d'un objet (`item.php` + `pages/item.php` +
  `assets/js/item.js`), sur le même principe que la fiche détaillée
  d'un champion (`champion.php` + `pages/champion.php` +
  `assets/js/champion.js`) : accessible via `item.php?id=5`, lit l'ID
  dans l'URL et interroge `GET /api/items/?id=` (déjà fonctionnel côté
  API — voir section « API » ci-dessus) au chargement de la page — une
  carte avec nom, description, catégorie et prix, mêmes trois états que
  la fiche Champion (chargement, erreur, détail). Un ID absent, invalide
  ou introuvable est traité comme une erreur au même titre qu'un échec
  réseau. Contrairement à la fiche Champion, aucune section
  supplémentaire (statistiques, capacités, builds, counters, synergies)
  : un objet n'a pas ce type de relations. Aucune carte de la liste des
  objets (`pages/items.php`) ne pointe encore vers cette page — hors
  périmètre de cette étape.

- Étape 18 : fiche détaillée d'un matchup (`matchup.php` +
  `pages/matchup.php` + `assets/js/matchup.js`), sur le même principe que
  la fiche détaillée d'un champion ou d'un objet : accessible via
  `matchup.php?id=7` (l'ID du counter, pas d'un champion), lit l'ID dans
  l'URL et interroge `GET /api/counters/?id=` au chargement de la page —
  ajouté à l'API à cette même étape (voir section « API » ci-dessus),
  sur le modèle de `/api/items/?id=` et `/api/runes/?id=` (prioritaire et
  exclusif sur les autres filtres). Affiche les deux champions du
  matchup (chacun résolu séparément via `GET /api/champions/?id=`, avec
  lien vers sa fiche complète), l'analyse du contre (explication,
  conseils, difficulté) et les objets recommandés déjà inclus dans la
  réponse (relation `counter_items`). Un ID absent, invalide ou
  introuvable est traité comme une erreur au même titre qu'un échec
  réseau. Aucune carte de la liste des matchups (`pages/counters.php`)
  ni de la section Counters d'une fiche champion (`pages/champion.php`)
  ne pointe encore vers cette page — hors périmètre de cette étape.

- Étape 15.5 : section "Conseils" dédiée sur la page de détail d'un
  matchup (`pages/matchup.php` + `assets/js/matchup.js`), séparée de la
  section "Analyse du matchup" — celle-ci ne contient désormais plus que
  l'explication et la difficulté, les conseils pratiques (colonne
  `tips` de la table `counters`) ayant leur propre section, avec un
  message si le matchup n'en a encore aucun. Aucun appel API
  supplémentaire (`tips` fait déjà partie de la réponse `GET
  /api/counters/?id=`) : uniquement un réagencement de l'affichage.

- Étape 15.6 : recommandations d'objets situationnels sur la page de
  détail d'un matchup (`database/schema.sql` + `api/counters/repository.php`
  + `pages/matchup.php` + `assets/js/matchup.js`) — nouvelle colonne
  nullable `counter_items.situation` (texte expliquant le contexte de
  jeu qui justifie l'achat, ex. « si l'adversaire prend l'avance »),
  renseignée dans le jeu de données de démo pour le 2e objet de chaque
  matchup existant. Exposée par `GET /api/counters/` (liste et `?id=`)
  via `findCounterItems()`. Sur `matchup.php`, les objets sont
  désormais répartis en deux sections selon cette colonne : « Objets
  recommandés » (objets de base, sans `situation`) inchangée dans son
  fonctionnement, et une nouvelle section « Recommandations d'objets
  situationnels » juste en dessous, dont chaque carte affiche en plus
  le texte de `situation`. Aucun nouvel appel réseau : la répartition
  se fait entièrement côté navigateur, à partir de la même réponse
  `GET /api/counters/?id=` déjà récupérée.

- Étape 16.1 : catégorie de tier supplémentaire `S+` (au-dessus de `S`)
  pour la Tier List (`database/schema.sql`, ENUM `tier_list.tier` +
  `api/tier-list/repository.php` : `getTierListTiers()` et l'ordre de
  tri `FIELD()`). Exposée partout où l'API et le tri de la tier list
  interviennent (`GET /api/tier-list/`, filtre `?tier=`) sans rien
  changer d'autre au comportement existant. Badge dédié sur les trois
  pages qui affichent un tier (`assets/js/tier-list.js`,
  `assets/js/home.js`, `assets/js/champion.js`) — `S+` reprend la même
  couleur que `S` (`badge--crimson`), faute d'une 5e couleur de badge
  disponible dans le design system, même principe de partage que les 7
  catégories d'objets sur 4 couleurs (page Objets). Une entrée de
  démonstration (Master Yi, jungle, patch 5.2) passe de `S` à `S+`
  dans le jeu de données, pour que la nouvelle catégorie soit visible
  sans donnée supplémentaire à saisir.

- Étape 19.1 : page d'inscription (`register.php` + `pages/register.php` +
  `assets/js/register.js`), sur le même principe d'entrée fine que les
  autres pages publiques. Formulaire complet (pseudo, email, mot de
  passe, confirmation, acceptation des conditions), avec les classes du
  design system déjà utilisées par le styleguide (`.field`, `.input`,
  `.checkbox`, `.field__hint`, `.field__error`) et un jeton CSRF déjà
  généré (`csrfToken()`, voir `config/security.php`). La validation à ce
  stade reste entièrement côté navigateur : attributs HTML natifs
  (`required`, `minlength`, `pattern`, `type="email"`) complétés par
  `assets/js/register.js` pour la correspondance des deux mots de passe.
  Hors périmètre de cette étape : le traitement du formulaire côté
  serveur (validation, unicité du pseudo/email, hachage et création du
  compte — la table `users` reste à ajouter à `database/schema.sql` —
  puis connexion automatique via `SESSION_USER_KEY`). La soumission du
  formulaire recharge donc simplement la page pour l'instant. Aucun lien
  vers cette page n'a encore été ajouté au header ni au footer.

- Étape 19.2 : page de connexion (`pages/login.php` + `assets/js/login.js`,
  `login.php` inchangé — le point d'entrée existait déjà), sur le même
  principe que la page d'inscription (étape 19.1) : le contenu placeholder
  précédent est remplacé par un formulaire complet (email, mot de passe,
  case « Rester connecté »), mêmes classes du design system et même jeton
  CSRF déjà généré. Validation encore entièrement côté navigateur
  (attributs HTML natifs + `assets/js/login.js`, qui reprend le principe
  de `assets/js/register.js`). Hors périmètre de cette étape : le
  traitement du formulaire côté serveur (vérification des identifiants,
  limitation des tentatives via `SECURITY_MAX_LOGIN_ATTEMPTS`, connexion
  effective via `SESSION_USER_KEY` et `regenerateSessionId()`) — cela
  dépend aussi de la table `users`, elle-même pas encore ajoutée à
  `database/schema.sql` (voir étape 19.1). La soumission du formulaire
  recharge donc simplement la page pour l'instant.

- Étape 19.3 : déconnexion (`logout.php`, à la racine). Contrairement à
  `register.php`/`login.php`, ce point d'entrée ne charge aucun layout
  ni page : c'est une action, pas un contenu à afficher — il détruit la
  session en cours via `destroySession()` (`config/session.php`) puis
  redirige vers l'accueil (`redirect('')`, `includes/functions.php`,
  jusqu'ici jamais utilisée). N'agit que sur une requête `POST`
  accompagnée d'un jeton CSRF valide (`verifyCsrfToken()`,
  `config/security.php`) ; une requête `GET` redirige vers l'accueil
  sans rien détruire. Hors périmètre de cette étape : aucun lien ou
  bouton « Déconnexion » n'est encore ajouté au header, au footer ou à
  la page Profil — cela dépend de la connexion effective des comptes via
  `SESSION_USER_KEY`, toujours pas développée (voir étapes 19.1 et 19.2).

- Étape 19.4 : page Profil (`pages/profile.php`, `profile.php` inchangé
  — le point d'entrée existait déjà). Le contenu placeholder précédent
  est remplacé par une page désormais protégée : un visiteur sans
  session utilisateur active (`$_SESSION[SESSION_USER_KEY]` vide) est
  redirigé vers `login.php` via `redirect()`, plutôt que d'afficher un
  contenu qui ne le concerne pas. Intègre aussi le bouton de déconnexion
  annoncé à l'étape 19.3 : un formulaire `POST` avec jeton CSRF vers
  `logout.php`, première page à l'utiliser. Hors périmètre de cette
  étape : le contenu réel du compte (pseudo, email, date d'inscription,
  historique...), qui dépend de la table `users` (toujours pas ajoutée à
  `database/schema.sql`) et de la connexion effective des comptes
  (`pages/login.php`, `pages/register.php`), laquelle ne remplit encore
  jamais `SESSION_USER_KEY` — cette page reste donc inaccessible en
  pratique tant qu'aucune session utilisateur n'existe réellement.

- Étape 19.5 : modification du pseudo (`pages/profile.php` +
  `assets/js/profile.js`), ajoutée sur la page Profil. Nouveau
  formulaire « Modifier le pseudo », mêmes contraintes et mêmes classes
  du design system que le champ pseudo du formulaire d'inscription
  (`.field`, `.input`, `.field__hint`, `.field__error`, attributs
  `minlength`/`maxlength`/`pattern`, voir étape 19.1), avec sa propre
  validation côté navigateur (`assets/js/profile.js`, même principe que
  `assets/js/register.js`). Jeton CSRF déjà généré, comme sur les autres
  formulaires du site. Hors périmètre de cette étape : le traitement
  serveur (vérification d'unicité du nouveau pseudo, mise à jour en
  base) et le pré-remplissage du champ avec le pseudo actuel, qui
  dépendent tous deux de la table `users`, toujours pas ajoutée à
  `database/schema.sql`. La soumission du formulaire recharge donc
  simplement la page pour l'instant.

- Étape 19.6 : modification de la bio (`pages/profile.php` +
  `assets/js/profile.js`), ajoutée sur la page Profil, sur le même
  principe que la modification du pseudo (étape 19.5). Nouveau
  formulaire « Modifier la bio » avec un `textarea` (`.textarea`, voir
  le styleguide), limité à 280 caractères (`maxlength`), et sa propre
  validation côté navigateur. `assets/js/profile.js` est réorganisé
  autour d'une fonction `wireFieldValidation()` réutilisable, qui
  branche désormais les deux formulaires (pseudo et bio) sur les mêmes
  classes du design system (`.field.is-invalid`, `.field__error`).
  Jeton CSRF déjà généré, comme sur les autres formulaires du site. Hors
  périmètre de cette étape : le traitement serveur (mise à jour en base)
  et le pré-remplissage du champ avec la bio actuelle, qui dépendent
  tous deux de la table `users` (colonne `bio` comprise), toujours pas
  ajoutée à `database/schema.sql`. La soumission du formulaire recharge
  donc simplement la page pour l'instant.

- Étape 19.7 : modification de l'avatar (`pages/profile.php` +
  `assets/js/profile.js`), ajoutée sur la page Profil, sur le même
  principe que le pseudo et la bio (étapes 19.5 et 19.6). Nouveau
  formulaire « Modifier l'avatar » avec un champ fichier (`type="file"`,
  `enctype="multipart/form-data"`), dont les contraintes (formats
  acceptés, taille maximale) viennent directement de
  `config/uploads.php` (`UPLOAD_MAX_SIZE_MB`,
  `UPLOAD_ALLOWED_EXTENSIONS_LIST`) et sont exposées à la validation
  côté navigateur via des attributs `data-*` sur l'input — une seule
  source de vérité entre PHP et JS. `assets/js/profile.js` gagne une
  fonction dédiée `wireAvatarValidation()` : contrairement au pseudo et
  à la bio, la validité HTML5 native d'un champ fichier ne vérifie que
  sa présence, pas son format ni sa taille, d'où une vérification
  manuelle de l'extension et de la taille du fichier choisi. Jeton CSRF
  déjà généré, comme sur les autres formulaires du site. Hors périmètre
  de cette étape : le traitement serveur (stockage effectif du fichier
  dans `uploads/` via `generateSafeUploadFilename()`, déjà prête dans
  `config/uploads.php` mais jamais encore appelée, et mise à jour en
  base) et le pré-remplissage avec l'avatar actuel, qui dépendent tous
  deux de la table `users` (colonne `avatar` comprise), toujours pas
  ajoutée à `database/schema.sql`. La soumission du formulaire recharge
  donc simplement la page pour l'instant.

- Étape 19.8 : champions favoris (`pages/profile.php` +
  `assets/js/profile.js`), ajoutés sur la page Profil, sur le même
  principe que le pseudo, la bio et l'avatar (étapes 19.5 à 19.7).
  Nouvelle section « Champions favoris » : une case à cocher par
  champion, récupérés via l'API déjà fonctionnelle `GET
  /api/champions/` (voir api/champions/index.php) — mêmes trois états
  (chargement, erreur, liste) que sur `pages/champions.php`, avec la
  même règle de construction du DOM (`createElement`/`textContent`,
  jamais `innerHTML` sur une valeur venant de l'API). Duplique
  volontairement une version minimale de la récupération déjà faite par
  `assets/js/champions.js` (`fetchChampionsForFavorites()`) plutôt que
  de la partager : ce dernier n'est chargé que sur la page Champions
  (référence directe à des éléments `#champions-*` absents ailleurs),
  chaque page restant autonome dans ce projet. Jeton CSRF déjà généré,
  comme sur les autres formulaires du site. Hors périmètre de cette
  étape : le traitement serveur (sauvegarde de la sélection, qui
  dépendrait d'une table de liaison telle que
  `user_favorite_champions`, elle aussi pas encore ajoutée à
  `database/schema.sql`) et la présélection des favoris déjà
  enregistrés. La soumission du formulaire recharge donc simplement la
  page pour l'instant.

- Étape 21.1 : architecture permettant de recevoir des données Riot,
  sans connecter l'API Riot elle-même (hors périmètre de cette étape).
  Trois ajouts, purement structurels :
  - `config/riot.php` (+ `config/riot.local.php.example`), sur le même
    principe que `config/database.php` : définit les constantes
    `RIOT_API_BASE_URL`, `RIOT_API_KEY`, `RIOT_API_REGION`,
    `RIOT_API_TIMEOUT_SECONDS`, `RIOT_API_CACHE_TTL_MINUTES` (vides/par
    défaut tant que `riot.local.php` n'existe pas) et
    `isRiotApiConfigured()` (vérifie juste qu'une clé est renseignée,
    sans requête réseau). Chargé par `includes/bootstrap.php`, comme
    les autres fichiers de `config/`.
  - Deux nouvelles tables dans `database/schema.sql` :
    `riot_raw_payloads` (dépôt brut des données reçues de Riot, en
    JSON, avant tout traitement — `resource_type`, `external_id`,
    `patch`, `payload`, `fetched_at`, `processed_at`) et
    `riot_sync_log` (historique des tentatives de synchronisation —
    `resource_type`, `status`, `message`, `started_at`,
    `finished_at`). Aucune colonne ajoutée aux tables métier
    existantes (`champions`, `items`...) : le rapprochement entre
    données Riot et données du site est hors périmètre de cette étape.
  - `includes/riot/` : `RiotApiClient.php`, squelette avec les
    signatures prévues (`fetchChampion()`, `fetchItem()`,
    `fetchResourceList()`) qui lèvent toutes
    `RiotApiNotConnectedException` au lieu d'appeler l'API (aucun
    cURL, aucune requête réseau dans ce fichier) ; et
    `RiotRepository.php`, couche de stockage fonctionnelle (elle,
    active) qui sait déjà enregistrer un payload reçu
    (`storeRiotRawPayload()`), consulter les payloads stockés
    (`findRiotRawPayloads()`) et journaliser une synchronisation
    (`startRiotSyncLog()` / `finishRiotSyncLog()` /
    `findRiotSyncLog()`) — mais que rien n'appelle encore à ce stade.
  Hors périmètre de cette étape : la connexion réelle à l'API Riot
  (implémentation des méthodes de `RiotApiClient`), tout script ou
  page qui déclencherait une synchronisation, et le rapprochement des
  données reçues avec les tables `champions`/`items`/etc.

- Étape 21.2 : sécurisation effective du stockage de la clé d'API Riot
  (`RIOT_API_KEY`, définie à l'étape 21.1). Deux ajouts, uniquement
  défensifs — aucun changement de comportement de `config/riot.php` ou
  du reste de l'intégration Riot :
  - `.gitignore` (racine du projet) : ignore désormais `config/riot.local.php`
    en plus de `config/config.local.php` et `config/database.local.php` — la
    clé réelle ne peut donc jamais atterrir dans le dépôt Git. `deploy/build.sh`
    supprimait déjà ce fichier du paquet de déploiement ; il existe maintenant
    réellement dans le projet.
  - `config/.htaccess` : interdit tout accès direct au dossier `config/`
    depuis un navigateur (`Require all denied`, avec repli `Deny from all`
    pour Apache 2.2), donc à `riot.local.php` comme aux autres fichiers
    `*.local.php`. Ces fichiers ne sont chargés que côté serveur, via
    `require_once` (voir `includes/bootstrap.php`), jamais via une URL.
  Comme à l'étape 21.1, la clé n'est jamais codée en dur, jamais affichée,
  et n'est référencée dans aucun fichier JavaScript du projet — seul
  `includes/riot/RiotApiClient.php` (PHP, côté serveur) la lit.
  Hors périmètre de cette étape : tout le reste (connexion réelle à
  l'API, synchronisation...), inchangé depuis l'étape 21.1.

- Étape 21.3 : première connexion réelle, limitée aux données de
  champions **autorisées** — c'est-à-dire disponibles sans clé de
  production Riot. `includes/riot/RiotApiClient.php` :
  - `fetchChampion($riotChampionId)` et `fetchResourceList('champion', $patch = null)`
    appellent désormais réellement **Data Dragon**
    (`https://ddragon.leagueoflegends.com`, nouvelle constante
    `RIOT_DDRAGON_BASE_URL` dans `config/riot.php`) : le CDN statique et
    public de Riot conçu pour les fan sites, qui ne demande aucune clé
    d'API. C'est la seule source de données de champions autorisée pour
    ce projet — les endpoints de l'API Riot authentifiée
    (`RIOT_API_BASE_URL`) portent sur des données de compte/partie et
    nécessitent, pour la plupart, une clé de production que Riot n'a pas
    approuvée ici ; ils restent donc hors périmètre, comme `fetchItem()`
    qui lève toujours `RiotApiNotConnectedException`.
  - Les deux méthodes exigent quand même `isRiotApiConfigured()` (une
    clé renseignée dans `riot.local.php`) : pas parce que Data Dragon en
    a besoin, mais comme interrupteur global — tant qu'aucune clé n'est
    configurée, aucune fonctionnalité Riot ne s'active sur le site.
  - Nouvelle constante `RIOT_DDRAGON_LOCALE` (`fr_FR` par défaut) pour la
    langue des données récupérées (nom, titre, lore...).
  - Nouvelle exception `RiotApiRequestException` (`includes/riot/`) pour
    les échecs réels d'appel (réseau, code HTTP inattendu, JSON invalide,
    identifiant de champion introuvable) — distincte de
    `RiotApiNotConnectedException`, qui continue de signaler une méthode
    non implémentée.
  - Requêtes faites en cURL, avec le délai `RIOT_API_TIMEOUT_SECONDS`
    existant. `RIOT_API_KEY` n'est jamais transmise à Data Dragon (elle
    ne sert à rien pour ce CDN) et reste absente de tout fichier
    JavaScript.
  Hors périmètre de cette étape : tout ce qui consommerait ces données
  (script de synchronisation, page d'admin, écriture dans
  `riot_raw_payloads` via `storeRiotRawPayload()`, rapprochement avec la
  table `champions`) — `RiotApiClient` reste, pour l'instant, une classe
  que rien n'appelle encore dans le reste du site.

- Étape 22.2 : import des informations de patch WRChina (uniquement les
  patchs — pas les builds, hors périmètre de cette étape) :
  - `database/schema.sql` : nouvelle table `wrchina_patches` (numéro de
    patch, nom, date, statut, source, URL source, date de récupération),
    distincte de `wrchina_raw_payloads` (JSON brut non exploité).
    `patch_number` y est `UNIQUE` : c'est ce qui permet l'anti-doublons.
  - `includes/wrchina/WrChinaApiClient.php` : nouvelle méthode
    `fetchPatches()`. Important — elle ne fait toujours **aucune requête
    vers WRChina.gg** : le constat de l'étape 22.1 n'a pas changé (aucune
    méthode d'accès autorisée identifiée). Elle lit un fichier JSON local
    (`data/wrchina/patches.json`, chemin dans la nouvelle constante
    `WRCHINA_PATCHES_STAGING_FILE` de `config/wrchina.php`, injectable au
    constructeur pour les tests), que le webmaster tient à jour à la main
    à partir de ce qu'il consulte lui-même sur WRChina.gg — voir
    `data/wrchina/README.md` pour le détail et le format attendu.
    `data/wrchina/.htaccess` bloque l'accès direct au dossier, comme
    `config/.htaccess`.
  - `includes/wrchina/WrChinaRepository.php` : `importWrChinaPatch()`
    (upsert par `patch_number` — met à jour la ligne existante au lieu
    d'en créer une nouvelle, donc jamais de doublon), plus
    `findWrChinaPatchByNumber()`, `findWrChinaPatches()` et
    `countWrChinaPatches()`. Toujours en requêtes préparées PDO.
  - `includes/wrchina/WrChinaPatchImporter.php` (nouveau) : orchestre
    récupération (`fetchPatches()`), validation entrée par entrée
    (`validateWrChinaPatch()` — patch_number obligatoire et ≤20
    caractères, autres champs facultatifs mais typés/bornés si présents)
    et enregistrement (`importWrChinaPatch()`) via `importWrChinaPatches()`.
    Une entrée invalide est rejetée et journalisée (`error_log`) sans
    bloquer les autres. Toute tentative est journalisée dans
    `wrchina_sync_log` (`startWrChinaSyncLog()`/`finishWrChinaSyncLog()`),
    y compris un échec (ex. fichier de staging introuvable).
  - `tests/test-wrchina-patch-import.php` : test manuel CLI couvrant la
    création, la validation (entrée invalide rejetée sans bloquer les
    autres), l'anti-doublons (réimport du même `patch_number` → mise à
    jour, pas de nouvelle ligne) et l'échec propre si le fichier de
    staging est introuvable. Utilise un fichier fixture dédié et des
    `patch_number` préfixés `TEST-`, nettoyés avant/après exécution.
  Hors périmètre de cette étape : les builds (comme demandé), toute page
  d'administration ou route API exposant ces patchs, et le rapprochement
  avec `wrchina_raw_payloads` ou d'autres tables métier.

- Étape 22.3 : sauvegarde réelle des builds favoris (`database/schema.sql`
  + `profile.php` + `assets/js/profile.js`), qui complète l'étape 19.8
  (restée limitée aux champions favoris) :
  - `database/schema.sql` : nouvelle table `user_favorite_builds`,
    relation N-N entre `users` et `builds` (`ON DELETE CASCADE` des
    deux côtés, contrainte unique `(user_id, build_id)` pour éviter les
    doublons).
  - `profile.php` : nouveau traitement du formulaire « Builds favoris »
    (`$submittedForm === 'favorite_builds'`), sur le même principe que
    pseudo/bio/avatar — jeton CSRF vérifié, puis synchronisation
    complète (pas de mise à jour partielle) : les IDs de builds cochés
    sont d'abord filtrés (entiers positifs uniques, puis vérifiés comme
    correspondant à des builds réellement existants) avant de
    remplacer entièrement le contenu de `user_favorite_builds` pour ce
    compte (`DELETE` puis `INSERT`). Les favoris actuels
    (`$favoriteBuildIds`) sont aussi relus avant l'affichage.
  - `pages/profile.php` : le formulaire porte désormais le champ caché
    `form` (`favorite_builds`, manquant jusqu'ici) et affiche un message
    de confirmation (`?saved=favorite_builds`) ; son conteneur de
    cases à cocher expose les favoris actuels via l'attribut
    `data-selected-ids` (JSON des IDs), lu côté JS.
  - `assets/js/profile.js` : `renderFavoriteBuilds()` pré-coche
    désormais les builds déjà en favoris à partir de
    `data-selected-ids`, au lieu de n'afficher qu'une liste vierge.
  Hors périmètre de cette étape : les champions favoris restent sans
  sauvegarde réelle (voir étape 19.8), faute de table de liaison
  dédiée ; pas de bouton « ajouter/retirer » unitaire sur la fiche
  build (`build.php`) — l'ajout/retrait se fait depuis la page Profil,
  en cochant/décochant puis en cliquant sur Enregistrer.

- Gestion des patchs, étape 2 : rattachement des données à un patch
  (`patch_id`), sans supprimer ni modifier aucune donnée existante et
  sans changer le design :
  - `database/migration_patch_links.sql` (nouveau, rejouable) et fin de
    `database/schema.sql` : colonne `patch_id` (NULL autorisé, clé
    étrangère vers `patches`, `ON DELETE SET NULL`) sur `champions`,
    `items`, `runes`, `builds`, `tier_list`, `counters` et `synergies`
    (les tables enfants suivent leur table parente ; les statistiques
    `win_rate`/`pick_rate`/`ban_rate` sont dans `tier_list`). Les
    versions déjà utilisées par `builds.patch` et `tier_list.patch`
    sont ajoutées à `patches` (inactives) et ces deux tables sont
    rattachées automatiquement ; leur colonne texte `patch` est
    inchangée et reste la référence.
  - `includes/patches.php` (nouveau) : `findActivePatch()`,
    `findPatchByVersion()`, `findAllPatches()`, `tableHasPatchLink()`,
    `linkRowToPatch()`. `api/builds/repository.php` : `insertBuild()` et
    `updateBuild()` resynchronisent `patch_id` avec `patch` (ignoré tant
    que la migration n'est pas importée).
  - `tests/test-patch-links.php` : test manuel CLI (présence des
    colonnes, cohérence `patch` / `patch_id`, écriture, `ON DELETE SET
    NULL`), avec des lignes de test nettoyées avant/après.
  - Inchangé : toutes les réponses de l'API, les requêtes de lecture,
    les pages, le JavaScript et le CSS.
  - Hors périmètre de cette étape (prochaines) : filtre `?patch=` sur les
    autres ressources de l'API (avec `NULL` = tous les patchs),
    sélecteur de patch dans l'administration, attribution d'un patch aux
    champions/objets/runes/counters/synergies existants, et plusieurs
    versions d'une même donnée (contraintes d'unicité à élargir).

Les fonctionnalités restantes (simulateur, admin de contenu...) seront
ajoutées lors des prochaines étapes.
