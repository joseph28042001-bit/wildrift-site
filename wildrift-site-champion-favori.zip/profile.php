<?php
/**
 * Point d'entrée public : Profil.
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/profile.php. Toute la logique/contenu vit dans pages/.
 */

require_once __DIR__ . '/includes/bootstrap.php';

/**
 * Traitement serveur de la page Profil (voir pages/profile.php pour le
 * contenu affiché). Reste dans ce point d'entrée, comme pour
 * register.php et login.php.
 *
 * Corrige au passage un problème existant : la vérification de session
 * (redirection vers login.php si non connecté) vivait jusqu'ici dans
 * pages/profile.php, inclus APRÈS le header — trop tard pour qu'un
 * redirect() (header() PHP) fonctionne, puisque le header avait déjà
 * commencé à envoyer du HTML. Elle est donc désormais faite ici, avant
 * tout affichage.
 *
 * Récupère aussi les informations réelles du compte connecté (pseudo,
 * email, bio, avatar, date d'inscription) et traite les trois
 * formulaires de modification (pseudo, bio, avatar) : validation,
 * unicité du pseudo, stockage sécurisé du fichier avatar
 * (generateSafeUploadFilename(), voir config/uploads.php), mise à jour
 * dans `users`. Chaque formulaire porte un champ caché "form" pour
 * savoir lequel a été soumis (voir pages/profile.php).
 *
 * La section "Builds favoris" affiche désormais directement les builds
 * réellement mis en favoris par le compte connecté (voir
 * $favoriteBuilds ci-dessous : nom, champion, rôle et patch, résolus
 * par jointure sur `builds`/`champions`), chacun avec un lien pour
 * l'ouvrir (build.php?id=) et un bouton pour le retirer individuellement
 * de ses favoris. Le retrait poste uniquement l'ID du build concerné
 * (voir le traitement du formulaire "remove_favorite_build" plus bas) :
 * une seule ligne supprimée dans `user_favorite_builds`, pas de
 * resynchronisation complète.
 *
 * Hors périmètre : la section "Champions favoris" reste sans
 * sauvegarde réelle (dépend d'une table de liaison — ex.
 * `user_favorite_champions` — toujours pas ajoutée à
 * database/schema.sql). De même, ajouter un nouveau build aux favoris
 * (depuis build.php ou builds.php, par exemple) n'est pas traité ici :
 * cette étape ne couvre que l'affichage des favoris existants, leur
 * ouverture et leur retrait individuel (voir pages/profile.php).
 */
if (empty($_SESSION[SESSION_USER_KEY])) {
    redirect('login.php');
}

$currentUserId = (int) $_SESSION[SESSION_USER_KEY];
$currentUser = dbFetchOne(
    'SELECT id, pseudo, email, bio, avatar, created_at FROM users WHERE id = :id LIMIT 1',
    ['id' => $currentUserId]
);

// Session valide mais compte disparu entre-temps (supprimé côté admin,
// par exemple) : on ne peut pas afficher un profil qui n'existe plus.
if ($currentUser === null) {
    destroySession();
    redirect('login.php');
}

// Builds actuellement en favoris pour ce compte (nom, champion, rôle,
// patch), pour l'affichage direct de la section "Builds favoris" dans
// pages/profile.php — voir son commentaire d'en-tête. Triés par nom de
// build, même convention que BUILD_SELECT_COLUMNS/findBuilds() dans
// api/builds/repository.php (non réutilisé ici : cette requête reste
// propre à profile.php, comme les autres requêtes de ce fichier).
$favoriteBuilds = dbFetchAll(
    'SELECT b.id AS id, b.name AS name, c.name AS champion, b.role AS role, b.patch AS patch
     FROM user_favorite_builds ufb
     INNER JOIN builds b ON b.id = ufb.build_id
     INNER JOIN champions c ON c.id = b.champion_id
     WHERE ufb.user_id = :user_id
     ORDER BY b.name ASC',
    ['user_id' => $currentUserId]
);

// Champion favori du compte (arrière-plan du profil) et liste des champions
// proposés dans le sélecteur. Requêtes séparées de celle de $currentUser et
// protégées : si la migration database/migration_favorite_champion.sql n'a
// pas encore été exécutée, le profil reste affiché normalement, sans favori.
$favoriteChampion = null;
$championChoices = [];
try {
    $favoriteChampion = dbFetchOne(
        'SELECT c.id, c.name, c.role, c.image_url
         FROM users u
         INNER JOIN champions c ON c.id = u.favorite_champion_id
         WHERE u.id = :id LIMIT 1',
        ['id' => $currentUserId]
    );
    $championChoices = dbFetchAll('SELECT id, name, role FROM champions ORDER BY name ASC');
} catch (DatabaseException $exception) {
    error_log('[Profil] Champion favori indisponible : ' . $exception->getMessage());
}

$profileErrors = [];
$oldPseudo = $currentUser['pseudo'];
$oldBio = $currentUser['bio'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        $profileErrors['global'] = 'Ta session a expiré ou la requête est invalide. Merci de réessayer.';
    } else {
        $submittedForm = (string) ($_POST['form'] ?? '');

        if ($submittedForm === 'pseudo') {
            $pseudo = trim((string) ($_POST['pseudo'] ?? ''));
            $oldPseudo = $pseudo;

            if ($pseudo === '' || mb_strlen($pseudo) < 3 || mb_strlen($pseudo) > 20 || !preg_match('/^[A-Za-z0-9_]+$/', $pseudo)) {
                $profileErrors['pseudo'] = "Choisis un pseudo de 3 à 20 caractères (lettres, chiffres, underscore).";
            } elseif ($pseudo !== $currentUser['pseudo']) {
                try {
                    $existingUser = dbFetchOne(
                        'SELECT id FROM users WHERE pseudo = :pseudo AND id != :id LIMIT 1',
                        ['pseudo' => $pseudo, 'id' => $currentUserId]
                    );

                    if ($existingUser !== null) {
                        $profileErrors['pseudo'] = 'Ce pseudo est déjà pris.';
                    }
                } catch (DatabaseException $exception) {
                    $profileErrors['global'] = $exception->getMessage();
                }
            }

            if (empty($profileErrors)) {
                try {
                    dbExecute('UPDATE users SET pseudo = :pseudo WHERE id = :id', [
                        'pseudo' => $pseudo,
                        'id' => $currentUserId,
                    ]);
                    redirect('profile.php?saved=pseudo');
                } catch (DatabaseException $exception) {
                    $profileErrors['global'] = $exception->getMessage();
                }
            }
        } elseif ($submittedForm === 'bio') {
            $bio = trim((string) ($_POST['bio'] ?? ''));
            $oldBio = $bio;

            if (mb_strlen($bio) > 280) {
                $profileErrors['bio'] = 'La bio ne peut pas dépasser 280 caractères.';
            }

            if (empty($profileErrors)) {
                try {
                    dbExecute('UPDATE users SET bio = :bio WHERE id = :id', [
                        'bio' => $bio === '' ? null : $bio,
                        'id' => $currentUserId,
                    ]);
                    redirect('profile.php?saved=bio');
                } catch (DatabaseException $exception) {
                    $profileErrors['global'] = $exception->getMessage();
                }
            }
        } elseif ($submittedForm === 'avatar') {
            $avatarFile = $_FILES['avatar'] ?? null;

            if ($avatarFile === null || $avatarFile['error'] === UPLOAD_ERR_NO_FILE) {
                $profileErrors['avatar'] = 'Choisis un fichier à envoyer.';
            } elseif ($avatarFile['error'] !== UPLOAD_ERR_OK) {
                $profileErrors['avatar'] = 'Fichier invalide : vérifie le format et la taille.';
            } elseif (!isAllowedUploadExtension($avatarFile['name']) || !isAllowedUploadSize((int) $avatarFile['size'])) {
                $profileErrors['avatar'] = 'Fichier invalide : vérifie le format et la taille.';
            } elseif (@getimagesize($avatarFile['tmp_name']) === false) {
                // Vérifie que le contenu est réellement une image, pas
                // seulement un nom de fichier avec la bonne extension.
                $profileErrors['avatar'] = 'Fichier invalide : vérifie le format et la taille.';
            } else {
                $newFilename = generateSafeUploadFilename($avatarFile['name']);
                $destination = UPLOADS_PATH . '/' . $newFilename;

                if (!is_dir(UPLOADS_PATH) || !move_uploaded_file($avatarFile['tmp_name'], $destination)) {
                    error_log('[Profil] Échec de l\'enregistrement de l\'avatar pour l\'utilisateur ' . $currentUserId);
                    $profileErrors['avatar'] = 'Le fichier n\'a pas pu être enregistré. Merci de réessayer.';
                } else {
                    try {
                        dbExecute('UPDATE users SET avatar = :avatar WHERE id = :id', [
                            'avatar' => $newFilename,
                            'id' => $currentUserId,
                        ]);

                        // Nettoyage de l'ancien fichier une fois le nouveau
                        // bien enregistré en base (jamais avant, pour ne pas
                        // perdre l'avatar existant si l'écriture échoue).
                        $previousAvatar = $currentUser['avatar'];
                        if ($previousAvatar) {
                            $previousPath = UPLOADS_PATH . '/' . $previousAvatar;
                            if (is_file($previousPath)) {
                                @unlink($previousPath);
                            }
                        }

                        redirect('profile.php?saved=avatar');
                    } catch (DatabaseException $exception) {
                        @unlink($destination);
                        $profileErrors['global'] = $exception->getMessage();
                    }
                }
            }
        } elseif ($submittedForm === 'favorite_champion') {
            // Champion favori : un seul choix par compte (0 / vide = retirer).
            $championId = (int) ($_POST['champion_id'] ?? 0);

            try {
                if ($championId < 0) {
                    $profileErrors['favorite_champion'] = 'Champion invalide.';
                } elseif ($championId > 0 && dbFetchOne('SELECT id FROM champions WHERE id = :id LIMIT 1', ['id' => $championId]) === null) {
                    $profileErrors['favorite_champion'] = 'Champion invalide.';
                } else {
                    dbExecute('UPDATE users SET favorite_champion_id = :champion_id WHERE id = :id', [
                        'champion_id' => $championId > 0 ? $championId : null,
                        'id' => $currentUserId,
                    ]);
                    redirect('profile.php?saved=favorite_champion');
                }
            } catch (DatabaseException $exception) {
                $profileErrors['global'] = $exception->getMessage();
            }
        } elseif ($submittedForm === 'remove_favorite_build') {
            // Retrait d'un seul favori (voir pages/profile.php, section
            // "Builds favoris" : un bouton "Retirer" par build affiché,
            // chacun postant son propre ID) — pas de resynchronisation
            // de l'ensemble des favoris du compte.
            $buildId = (int) ($_POST['build_id'] ?? 0);

            if ($buildId <= 0) {
                $profileErrors['global'] = 'Build invalide.';
            } else {
                try {
                    dbExecute(
                        'DELETE FROM user_favorite_builds WHERE user_id = :user_id AND build_id = :build_id',
                        ['user_id' => $currentUserId, 'build_id' => $buildId]
                    );

                    redirect('profile.php?saved=favorite_build_removed');
                } catch (DatabaseException $exception) {
                    $profileErrors['global'] = $exception->getMessage();
                }
            }
        }
    }
}

// Mêmes contraintes que config/uploads.php, exposées au formulaire et
// à sa validation côté navigateur (assets/js/profile.js) via les
// attributs data-* de l'input, pour une seule source de vérité.
$avatarAllowedExtensions = UPLOAD_ALLOWED_EXTENSIONS_LIST;
$avatarAcceptAttr = implode(',', array_map(function (string $ext): string {
    return '.' . $ext;
}, $avatarAllowedExtensions));

$savedFlag = $_GET['saved'] ?? '';
if (!in_array($savedFlag, ['pseudo', 'bio', 'avatar', 'favorite_champion', 'favorite_build_removed'], true)) {
    $savedFlag = '';
}

$pageTitle = 'Profil';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/profile.php';
require __DIR__ . '/includes/components/footer.php';
