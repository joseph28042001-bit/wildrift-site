<?php
/**
 * Script CLI : création d'un compte administrateur.
 * ---------------------------------------------------
 * Les comptes administrateurs ne s'auto-inscrivent pas (voir le
 * commentaire d'en-tête de admin/pages/login.php) : c'est le seul
 * moyen d'en créer un, à lancer depuis un terminal, sur le serveur ou
 * en local.
 *
 * Usage (depuis la racine du projet) :
 *   php scripts/create-admin.php admin@exemple.com "mot de passe"
 *
 * Le mot de passe est haché avec password_hash() (mêmes réglages que
 * l'inscription publique, voir PASSWORD_HASH_OPTIONS dans
 * config/security.php) avant d'être stocké dans `admins.password_hash` —
 * jamais en clair, jamais journalisé.
 *
 * Protection (ceinture et bretelles, même principe que uploads/.htaccess) :
 * - scripts/.htaccess bloque tout accès direct à ce dossier depuis le
 *   navigateur : ce script ne doit jamais être atteignable en HTTP.
 * - Il refuse aussi explicitement de s'exécuter hors CLI, ci-dessous,
 *   au cas où le blocage .htaccess serait absent ou inactif (certains
 *   hébergements mutualisés, serveur autre qu'Apache...).
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Ce script ne peut être exécuté qu’en ligne de commande.');
}

require_once __DIR__ . '/../includes/bootstrap.php';

$email = trim((string) ($argv[1] ?? ''));
$password = (string) ($argv[2] ?? '');

if ($email === '' || $password === '') {
    fwrite(STDERR, "Usage : php scripts/create-admin.php email@exemple.com \"mot de passe\"\n");
    exit(1);
}

if (filter_var($email, FILTER_VALIDATE_EMAIL) === false || mb_strlen($email) > 190) {
    fwrite(STDERR, "Email invalide : {$email}\n");
    exit(1);
}

if (strlen($password) < 8) {
    fwrite(STDERR, "Le mot de passe doit contenir au moins 8 caractères.\n");
    exit(1);
}

if (strlen($password) > 72) {
    // bcrypt (password_hash() plus bas) ignore silencieusement tout au-delà
    // de 72 octets — même limite que register.php pour les comptes publics.
    fwrite(STDERR, "Le mot de passe ne peut pas dépasser 72 caractères.\n");
    exit(1);
}

try {
    $existing = dbFetchOne('SELECT id FROM admins WHERE email = :email LIMIT 1', ['email' => $email]);
} catch (DatabaseException $exception) {
    fwrite(STDERR, $exception->getMessage() . "\n");
    exit(1);
}

if ($existing !== null) {
    fwrite(STDERR, "Un compte administrateur existe déjà avec cet email.\n");
    exit(1);
}

try {
    $passwordHash = password_hash($password, PASSWORD_BCRYPT, PASSWORD_HASH_OPTIONS);

    dbExecute(
        'INSERT INTO admins (email, password_hash) VALUES (:email, :password_hash)',
        ['email' => $email, 'password_hash' => $passwordHash]
    );
} catch (DatabaseException $exception) {
    fwrite(STDERR, $exception->getMessage() . "\n");
    exit(1);
}

echo "Compte administrateur créé pour {$email}.\n";
