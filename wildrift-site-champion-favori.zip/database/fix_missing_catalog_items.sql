-- ============================================================
-- Correctif — Objets manquants du catalogue `items`
-- ============================================================
-- Objets référencés dans build_items par un ou plusieurs lots
-- WildRiftFire mais jamais créés par leur propre INSERT INTO items
-- (l'INNER JOIN les ignore alors silencieusement : le build
-- s'importe sans erreur mais l'objet n'apparaît pas). À importer
-- APRÈS schema.sql. Peut être rejoué sans effet (ON DUPLICATE KEY
-- UPDATE), et sans ordre imposé par rapport aux seeds/lots puisqu'il
-- ne fait que compléter le catalogue, pas les builds eux-mêmes.
--
-- Terminus     : référencé par le lot 7 (Warwick, core).
-- Sundered Sky : référencé par les lots 5 (Nocturne, Olaf), 6 (Vi)
--                et 7 (Xin Zhao) — bug préexistant aux lots 5 et 6,
--                pas seulement au lot 7.
-- Sunfire Aegis : référencé par le lot 1 (Amumu, core) et le lot 5
--                (Nunu & Willump, Rammus) — bug préexistant au lot 1,
--                déjà repéré en commentaire par le lot 2 sans être
--                corrigé à l'époque.
--
-- Statistiques et prix vérifiés sur le wiki Wild Rift (namespace
-- WR:, distinct des pages League of Legends PC qui ont des valeurs
-- différentes) au 24/09/2026.
--
-- 'kaenic-rookern' (référencé par le lot 1 pour Amumu, situationnel)
-- N'EST PAS inséré ici : aucune page WR: n'existe pour cet objet,
-- seulement des pages League of Legends PC (ajouté en Saison 14,
-- patch 14.1) — tout indique qu'il n'existe pas dans Wild Rift.
-- Insérer des stats PC sous ce slug reviendrait à inventer un objet.
-- Voir le message accompagnant ce fichier pour la marche à suivre.
-- ============================================================

INSERT INTO items (slug, name, category, price, description, image_url) VALUES
    ('terminus', 'Terminus', 'attack', 3300, 'Dégâts d''attaque et vitesse d''attaque ; les coups sur un champion alternent Lumière (armure/résistance magique) et Ténèbres (pénétration armure/magique), cumulables 3 fois chacun.', NULL),
    ('sundered-sky', 'Sundered Sky', 'attack', 2900, 'Dégâts d''attaque, PV et réduction des délais de récupération ; le prochain coup porté sur un champion critique et soigne selon les dégâts d''attaque.', NULL),
    ('sunfire-aegis', 'Sunfire Aegis', 'defense', 2900, 'Armure, PV et réduction des délais de récupération ; brûle les ennemis proches en combat, dégâts renforcés contre sbires/monstres et cumulables contre les champions.', NULL)
ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    category = VALUES(category),
    price = VALUES(price),
    description = VALUES(description);
