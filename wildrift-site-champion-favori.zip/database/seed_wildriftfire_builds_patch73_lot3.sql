-- ============================================================
-- Lot 3 — Builds patch 7.3 — source WildRiftFire.com
-- Champions : Hecarim, Jarvan IV, Kayn, Kha'Zix, Kindred
-- (suite du rôle jungle après Ekko, Evelynn, Fiddlesticks, Gragas,
-- Graves du lot 2).
-- À importer APRÈS schema.sql, seed_wildriftfire_builds.sql,
-- seed_wildriftfire_builds_patch73_lot1.sql ET
-- seed_wildriftfire_builds_patch73_lot2.sql (complète les objets/
-- runes déjà présents plutôt que de les redéfinir).
--
-- Point bloquant conservé (voir méthode) : les sorts d'invocateur
-- de chaque build (Hecarim : Ghost/Smite ; Jarvan IV : Flash/Smite ;
-- Kayn : Flash/Smite ; Kha'Zix : Flash/Smite ; Kindred : Flash/Smite)
-- ne sont PAS importés ici, faute de colonne/table pour les stocker
-- — même limitation que les lots précédents.
--
-- Kayn : le champion a deux transformations avec kits et builds
-- entièrement distincts (Shadow Assassin / Rhaast), affichées comme
-- deux onglets sur la fiche. Comme pour Volibear au lot 1, seule la
-- 1ère variante listée (Shadow Assassin, Tier "TBD" mais affichée en
-- premier) est reprise ; la variante Rhaast (bruiser sustain) est
-- ignorée conformément à la méthode.
--
-- Hecarim : le "Core Items" du site liste Manamune, mais le "Final
-- Build" affiche sa forme évoluée Muramana (même emplacement
-- d'objet, effet amélioré). On reprend 'manamune' comme objet du
-- catalogue (celui réellement acheté), sans dupliquer une entrée
-- distincte pour Muramana, cohérent avec le traitement des objets
-- similaires (Infinity Orb/Zhonya's Hourglass) aux lots précédents.
--
-- Kindred : un résultat de recherche indexé affichait "Patch 7.2e"
-- dans son titre, mais la page réellement récupérée (fetch direct)
-- confirme bien "Patch 7.3" partout (titre ET bandeau champion) —
-- il s'agissait d'un résultat de recherche obsolète, pas d'un écart
-- réel sur la page. Autre point mineur : la page affiche l'icône
-- "Lethal Tempo" dans la liste des runes, mais le texte descriptif
-- juste en dessous nomme la rune "Conqueror" (erreur de copier-coller
-- probable côté WildRiftFire) ; l'icône/le nom affichés dans la liste
-- de runes font foi, donc 'lethal-tempo' est repris en position 1.
--
-- Items/runes situationnels apparaissant aussi dans le Final Build
-- (ex. Lord Dominik's Regard et Hexoptics C44 pour Kindred, Guardian
-- Angel pour Hecarim/Jarvan/Kayn/Kha'Zix) : conservés en 'core' (ils
-- font partie du Final Build affiché), seuls les objets de
-- remplacement propres à la section "Situational Items" sont
-- importés en 'situational' — même convention que les lots
-- précédents.
--
-- Comme aux lots précédents, plusieurs runes utilisées ici
-- ('transcendence', 'unshakeable', 'perseverance', 'brutal')
-- figuraient déjà, non définies, dans les référencements cassés du
-- lot 1 (voir commentaire du lot 2) : leur définition ici comble
-- au passage ce manque pour les builds du lot 1 qui les utilisaient.
-- Les runes du lot 1 encore non définies après ce lot 3
-- ('battle-zeal', 'demolish', 'last-stand', 'overgrowth',
-- 'second-wind') restent à traiter dans un correctif dédié.
-- ============================================================

-- Nouveaux objets nécessaires (absents de schema.sql et des seeds existants)
INSERT INTO items (slug, name, category, price, description, image_url) VALUES
    ('manamune', 'Manamune', 'attack', 2700, 'Dégâts d''attaque et mana bonus, se transforme en Muramana avec du mana consommé.', NULL),
    ('radiant-virtue', 'Radiant Virtue', 'defense', 2800, 'PV et résistances bonus ; soin d''équipe déclenché à l''utilisation de la capacité ultime.', NULL),
    ('goredrinker', 'Goredrinker', 'attack', 3000, 'Dégâts d''attaque et PV bonus ; effet actif de soin basé sur les dégâts infligés en zone.', NULL),
    ('unending-despair', 'Unending Despair', 'defense', 2800, 'Résistances et PV bonus ; bouclier déclenché à l''utilisation d''une capacité.', NULL),
    ('boots-of-dynamism', 'Boots of Dynamism', 'boots', 1100, 'Bottes utilitaires : réduction des délais de récupération et vitesse de déplacement bonus.', NULL),
    ('edge-of-night', 'Edge of Night', 'attack', 2900, 'Dégâts d''attaque et PV bonus ; bouclier actif absorbant le prochain sort ennemi.', NULL),
    ('eclipse', 'Eclipse', 'attack', 2600, 'Pénétration létale ; bouclier et dégâts bonus après deux coups portés sur un champion.', NULL),
    ('kraken-slayer', 'Kraken Slayer', 'attack', 3100, 'Dégâts d''attaque et vitesse d''attaque ; le 3e coup consécutif inflige des dégâts bonus.', NULL),
    ('hexoptics-c44', 'Hexoptics C44', 'attack', 2700, 'Dégâts d''attaque et vitesse de déplacement bonus contre les cibles révélées.', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Nouvelles runes nécessaires (Hecarim, Jarvan IV, Kindred)
INSERT INTO runes (slug, name, tree, slot, description, image_url) VALUES
    ('transcendence', 'Transcendance', 'sorcery', 'minor', 'Réduction des délais de récupération après avoir atteint le niveau 10.', NULL),
    ('nimbus-cloak', 'Manteau de Nimbus', 'sorcery', 'keystone', 'Vitesse de déplacement bonus après l''utilisation d''un sort d''invocateur.', NULL),
    ('legend-bloodline', 'Légende : lignée de sang', 'precision', 'minor', 'Vol de vie cumulable en prenant des éliminations/assistances ou du temps de jeu.', NULL),
    ('unshakeable', 'Inébranlable', 'resolve', 'minor', 'Résistances bonus temporaires après avoir subi un contrôle de foule.', NULL),
    ('bone-plating', 'Plaques osseuses', 'resolve', 'minor', 'Réduit les dégâts subis des prochaines attaques/sorts ennemis pendant quelques secondes.', NULL),
    ('perseverance', 'Persévérance', 'resolve', 'minor', 'Réduction des dégâts subis pendant une courte période après un contrôle de foule.', NULL),
    ('lethal-tempo', 'Tempo fatal', 'precision', 'keystone', 'Vitesse d''attaque bonus croissante en attaquant la même cible.', NULL),
    ('brutal', 'Brutal', 'precision', 'minor', 'Dégâts d''attaque et de sort bonus contre les champions.', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Builds
INSERT INTO builds (champion_id, name, role, patch, description, source)
SELECT id, 'Bruiser mobilité vitesse de déplacement', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Manamune (évolue en Muramana) et Trinity Force pour le combo sort-auto, Black Cleaver pour le shred d''armure, Death''s Dance et Guardian Angel en fin de Final Build pour la survie en teamfight.',
       'WildRiftFire.com' FROM champions WHERE slug = 'hecarim'
UNION ALL
SELECT id, 'Bruiser engage lockdown', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Trinity Force et Goredrinker pour l''engagement Flag and Drag, Radiant Virtue et Amaranth''s Twinguard pour la tankiness, Unending Despair et Guardian Angel en fin de Final Build pour la survie.',
       'WildRiftFire.com' FROM champions WHERE slug = 'jarvan-iv'
UNION ALL
SELECT id, 'Assassin létalité invisibilité (Shadow Assassin)', 'jungle', '7.3',
       'Build Jungle de WildRiftFire (forme Shadow Assassin) : Youmuu''s Ghostblade pour la mobilité de roaming, Serpent''s Fang et Serylda''s Grudge pour la pénétration, Duskblade of Draktharr et Guardian Angel en fin de Final Build pour l''exécution en embuscade.',
       'WildRiftFire.com' FROM champions WHERE slug = 'kayn'
UNION ALL
SELECT id, 'Assassin burst mobilité isolement', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Youmuu''s Ghostblade et Serylda''s Grudge pour la pénétration létale sur cibles isolées, Serpent''s Fang contre les boucliers, Eclipse et Guardian Angel en fin de Final Build pour le burst en embuscade.',
       'WildRiftFire.com' FROM champions WHERE slug = 'khazix'
UNION ALL
SELECT id, 'Marksman mobilité scaling', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Kraken Slayer et The Collector pour le DPS soutenu, Lord Dominik''s Regard contre les cibles tanky, Infinity Edge et Hexoptics C44 en fin de Final Build pour le carry en fin de partie.',
       'WildRiftFire.com' FROM champions WHERE slug = 'kindred'
ON DUPLICATE KEY UPDATE
    role = VALUES(role),
    patch = VALUES(patch),
    description = VALUES(description),
    source = VALUES(source);

-- Objets des builds
INSERT INTO build_items (build_id, item_id, slot, purchase_order, situation)
SELECT b.id, i.id, x.slot, x.purchase_order, x.situation
FROM (
    -- Hecarim (jungle) — Bruiser mobilité vitesse de déplacement
    SELECT 'hecarim' AS champion_slug, 'Bruiser mobilité vitesse de déplacement' AS build_name, 'long-sword' AS item_slug, 'starting' AS slot, 1 AS purchase_order, NULL AS situation
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 'manamune', 'core', 2, NULL
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 'trinity-force', 'core', 3, NULL
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 'black-cleaver', 'core', 4, NULL
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 'ionian-boots-of-lucidity', 'boots', 5, NULL
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 'deaths-dance', 'core', 6, NULL
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 'guardian-angel', 'core', 7, NULL
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 'serpents-fang', 'situational', NULL, 'vs Shielding (Build 3rd)'
    -- Jarvan IV (jungle) — Bruiser engage lockdown
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'trinity-force', 'core', 2, NULL
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'radiant-virtue', 'core', 3, NULL
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'amaranths-twinguard', 'core', 4, NULL
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'plated-steelcaps', 'boots', 5, NULL
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'goredrinker', 'core', 6, NULL
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'unending-despair', 'core', 7, NULL
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'guardian-angel', 'core', 8, NULL
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'thornmail', 'situational', NULL, 'vs Healing'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'randuins-omen', 'situational', NULL, 'vs Critical Strike Damage'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'frozen-heart', 'situational', NULL, 'vs Attack Speed'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'mercurys-treads', 'situational', NULL, 'vs AP / CC'
    -- Kayn Shadow Assassin (jungle) — Assassin létalité invisibilité
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'youmuus-ghostblade', 'core', 2, NULL
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'serpents-fang', 'core', 3, NULL
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'seryldas-grudge', 'core', 4, NULL
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'boots-of-dynamism', 'boots', 5, NULL
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'duskblade-of-draktharr', 'core', 6, NULL
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'guardian-angel', 'core', 7, NULL
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'edge-of-night', 'situational', NULL, 'vs Crowd Control'
    -- Kha'Zix (jungle) — Assassin burst mobilité isolement
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'youmuus-ghostblade', 'core', 2, NULL
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'serpents-fang', 'core', 3, NULL
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'seryldas-grudge', 'core', 4, NULL
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'gluttonous-greaves', 'boots', 5, NULL
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'eclipse', 'core', 6, NULL
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'guardian-angel', 'core', 7, NULL
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'edge-of-night', 'situational', NULL, 'vs Crowd Control'
    -- Kindred (jungle) — Marksman mobilité scaling
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'kraken-slayer', 'core', 2, NULL
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'the-collector', 'core', 3, NULL
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'lord-dominiks-regard', 'core', 4, NULL
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'berserkers-greaves', 'boots', 5, NULL
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'infinity-edge', 'core', 6, NULL
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'hexoptics-c44', 'core', 7, NULL
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'mortal-reminder', 'situational', NULL, 'vs Healing'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'guardian-angel', 'situational', NULL, 'vs Burst Damage'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'mercurial-scimitar', 'situational', NULL, 'vs Crowd Control'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN items i ON i.slug = x.item_slug
ON DUPLICATE KEY UPDATE purchase_order = VALUES(purchase_order), situation = VALUES(situation);

-- Runes des builds
INSERT INTO build_runes (build_id, rune_id, position)
SELECT b.id, r.id, x.position
FROM (
    SELECT 'hecarim' AS champion_slug, 'Bruiser mobilité vitesse de déplacement' AS build_name, 'phase-rush' AS rune_slug, 1 AS position
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 'axiom-arcanist', 2
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 'transcendence', 3
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 'nimbus-cloak', 4
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 'legend-bloodline', 5
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'conqueror', 1
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'unshakeable', 2
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'bone-plating', 3
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'perseverance', 4
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 'triumph', 5
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'dark-harvest', 1
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'sudden-impact', 2
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'hubris', 3
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'eyeball-collector', 4
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 'absolute-focus', 5
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'dark-harvest', 1
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'sudden-impact', 2
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'hubris', 3
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'eyeball-collector', 4
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 'absolute-focus', 5
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'lethal-tempo', 1
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'brutal', 2
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'cut-down', 3
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'legend-alacrity', 4
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 'absolute-focus', 5
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN runes r ON r.slug = x.rune_slug
ON DUPLICATE KEY UPDATE position = VALUES(position);

-- Ordre des compétences (1 point par niveau, 1 à 15)
INSERT INTO build_skill_order (build_id, level, skill)
SELECT b.id, x.level, x.skill
FROM (
    -- Hecarim : Rampage(1) > Spirit of Dread(2) > Devastating Charge(3)
    SELECT 'hecarim' AS champion_slug, 'Bruiser mobilité vitesse de déplacement' AS build_name, 1 AS level, '1' AS skill
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 2, '1'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 3, '1'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 4, '1'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 5, 'ultimate'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 6, '1'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 7, '2'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 8, '2'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 9, 'ultimate'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 10, '2'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 11, '2'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 12, '3'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 13, 'ultimate'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 14, '3'
    UNION ALL SELECT 'hecarim', 'Bruiser mobilité vitesse de déplacement', 15, '3'
    -- Jarvan IV : Dragon Strike(1) > Demacian Standard(3) > Golden Aegis(2)
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 1, '1'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 2, '1'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 3, '1'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 4, '1'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 5, 'ultimate'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 6, '1'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 7, '3'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 8, '3'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 9, 'ultimate'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 10, '3'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 11, '3'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 12, '2'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 13, 'ultimate'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 14, '2'
    UNION ALL SELECT 'jarvan-iv', 'Bruiser engage lockdown', 15, '2'
    -- Kayn Shadow Assassin : Reaping Slash(1) > Blade's Reach(2) > Shadow Step(3)
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 1, '1'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 2, '1'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 3, '1'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 4, '1'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 5, 'ultimate'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 6, '1'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 7, '2'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 8, '2'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 9, 'ultimate'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 10, '2'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 11, '2'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 12, '3'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 13, 'ultimate'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 14, '3'
    UNION ALL SELECT 'kayn', 'Assassin létalité invisibilité (Shadow Assassin)', 15, '3'
    -- Kha'Zix : Taste Their Fear(1) > Void Spike(2) > Leap(3)
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 1, '1'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 2, '1'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 3, '1'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 4, '1'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 5, 'ultimate'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 6, '1'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 7, '2'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 8, '2'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 9, 'ultimate'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 10, '2'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 11, '2'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 12, '3'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 13, 'ultimate'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 14, '3'
    UNION ALL SELECT 'khazix', 'Assassin burst mobilité isolement', 15, '3'
    -- Kindred : Dance of Arrows(1) > Wolf's Frenzy(2) > Mounting Dread(3)
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 1, '1'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 2, '1'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 3, '1'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 4, '1'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 5, 'ultimate'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 6, '1'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 7, '2'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 8, '2'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 9, 'ultimate'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 10, '2'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 11, '2'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 12, '3'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 13, 'ultimate'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 14, '3'
    UNION ALL SELECT 'kindred', 'Marksman mobilité scaling', 15, '3'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
ON DUPLICATE KEY UPDATE skill = VALUES(skill);
