-- ============================================================
-- Lot 6 — Builds patch 7.3 — source WildRiftFire.com
-- Champions : Rengar, Shyvana, Talon, Vi, Volibear
-- (suite du rôle jungle après le lot 5 ; Rek'Sai, Skarner et Viego
-- sont écartés : leurs fiches WildRiftFire affichent encore
-- "Patch 7.2e", Rek'Sai sans build "Coming soon").
-- À importer APRÈS schema.sql, seed_wildriftfire_builds.sql et les
-- lots 1 à 5. Aucune suppression, aucune modification de données
-- existantes hors ces 5 nouveaux builds. Relancer le fichier est
-- sans effet (idempotent).
--
-- Vérifié le 24/09/2026 : les 5 fiches affichent "Patch 7.3".
--
-- Volibear : sa fiche propose deux builds (Jungle A, Solo/Baron S).
-- Seule la version Jungle (Recommended Role) est reprise.
--
-- Écarts texte/liste : pour Shyvana (Bone Plating, Perseverance cités
-- dans le texte), Vi (Brutal cité), Volibear (Brutal, Legend: Bloodline,
-- Nimbus Cloak et un build AP cités), la liste des 5 runes et le Final
-- Build affichés font foi (même règle que les lots 3 à 5).
--
-- Objets situationnels déjà présents dans le Final Build (Eclipse pour
-- Rengar, Sterak's Gage pour Shyvana, Plated Steelcaps pour Vi) : non
-- dupliqués, ils restent 'core' ou 'boots'.
--
-- Limites conservées : sorts d'invocateur non importés (Flash/Smite),
-- runes situationnelles non importées. Ordre des compétences : seule la
-- priorité est donnée sur la page ; gabarit à 4/4/4 rangs (1 point par
-- niveau, 1 à 15, ultimes aux niveaux 5, 9 et 13).
--
-- Aucune nouvelle rune n'est créée ici : les runes absentes du
-- catalogue sont signalées par la vérification 3 (lignes de runes
-- correspondantes absentes tant qu'elles ne sont pas définies).
-- ============================================================

-- Builds
INSERT INTO builds (champion_id, name, role, patch, description, source)
SELECT id, 'Assassin furtif plongeon', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Duskblade of Draktharr, Serpent''s Fang et Serylda''s Grudge pour le burst et la pénétration d''armure avant un saut furtif, Eclipse et Guardian Angel en fin de Final Build pour survivre après l''engage.',
       'WildRiftFire.com' FROM champions WHERE slug = 'rengar'
UNION ALL
SELECT id, 'Bruiser scaling plongeon', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Trinity Force, Spear of Shojin et Death''s Dance pour un bruiser qui monte en puissance avec les dragons, Amaranth''s Twinguard et Sterak''s Gage en fin de Final Build pour tenir en forme de dragon.',
       'WildRiftFire.com' FROM champions WHERE slug = 'shyvana'
UNION ALL
SELECT id, 'Assassin burst mobilité', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Youmuu''s Ghostblade, Serpent''s Fang et Serylda''s Grudge pour la pénétration d''armure et le burst, Trinity Force et Guardian Angel en fin de Final Build pour tenir après le plongeon.',
       'WildRiftFire.com' FROM champions WHERE slug = 'talon'
UNION ALL
SELECT id, 'Bruiser plongeon verrouillage', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Trinity Force, Sundered Sky et Death''s Dance pour un bruiser résistant qui verrouille sa cible, Guardian Angel et Sterak''s Gage en fin de Final Build pour survivre en teamfight.',
       'WildRiftFire.com' FROM champions WHERE slug = 'vi'
UNION ALL
SELECT id, 'Bruiser plongeon soutien (Jungle)', 'jungle', '7.3',
       'Build Jungle de WildRiftFire (version Jungle) : Dusk and Dawn, Navori Quickblades et Riftmaker pour un bruiser à vitesse d''attaque qui se soigne, Amaranth''s Twinguard et Cosmic Drive en fin de Final Build ; la version Baron Lane n''est pas reprise.',
       'WildRiftFire.com' FROM champions WHERE slug = 'volibear'
ON DUPLICATE KEY UPDATE
    role = VALUES(role),
    patch = VALUES(patch),
    description = VALUES(description),
    source = VALUES(source);

-- Objets des builds
INSERT INTO build_items (build_id, item_id, slot, purchase_order, situation)
SELECT b.id, i.id, x.slot, x.purchase_order, x.situation
FROM (
    -- rengar
    SELECT 'rengar' AS champion_slug, 'Assassin furtif plongeon' AS build_name, 'long-sword' AS item_slug, 'starting' AS slot, 1 AS purchase_order, NULL AS situation
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 'duskblade-of-draktharr', 'core', 2, NULL
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 'serpents-fang', 'core', 3, NULL
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 'seryldas-grudge', 'core', 4, NULL
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 'boots-of-dynamism', 'boots', 5, NULL
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 'eclipse', 'core', 6, NULL
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 'guardian-angel', 'core', 7, NULL
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 'edge-of-night', 'situational', NULL, 'vs Crowd Control'
    -- shyvana
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'trinity-force', 'core', 2, NULL
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'spear-of-shojin', 'core', 3, NULL
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'deaths-dance', 'core', 4, NULL
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'berserkers-greaves', 'boots', 5, NULL
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'amaranths-twinguard', 'core', 6, NULL
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'steraks-gage', 'core', 7, NULL
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'randuins-omen', 'situational', NULL, 'vs Critical Strike Damage'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'thornmail', 'situational', NULL, 'vs Healing'
    -- talon
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 'youmuus-ghostblade', 'core', 2, NULL
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 'serpents-fang', 'core', 3, NULL
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 'seryldas-grudge', 'core', 4, NULL
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 'gluttonous-greaves', 'boots', 5, NULL
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 'trinity-force', 'core', 6, NULL
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 'guardian-angel', 'core', 7, NULL
    -- vi
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'trinity-force', 'core', 2, NULL
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'sundered-sky', 'core', 3, NULL
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'deaths-dance', 'core', 4, NULL
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'plated-steelcaps', 'boots', 5, NULL
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'guardian-angel', 'core', 6, NULL
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'steraks-gage', 'core', 7, NULL
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'mercurys-treads', 'situational', NULL, 'vs AP / CC'
    -- volibear
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 'dusk-and-dawn', 'core', 2, NULL
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 'navori-quickblades', 'core', 3, NULL
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 'riftmaker', 'core', 4, NULL
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 'berserkers-greaves', 'boots', 5, NULL
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 'amaranths-twinguard', 'core', 6, NULL
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 'cosmic-drive', 'core', 7, NULL
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN items i ON i.slug = x.item_slug
ON DUPLICATE KEY UPDATE purchase_order = VALUES(purchase_order), situation = VALUES(situation);

-- Runes des builds
INSERT INTO build_runes (build_id, rune_id, position)
SELECT b.id, r.id, x.position
FROM (
    -- rengar
    SELECT 'rengar' AS champion_slug, 'Assassin furtif plongeon' AS build_name, 'first-strike' AS rune_slug, 1 AS position
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 'sudden-impact', 2
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 'tyrant', 3
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 'eyeball-collector', 4
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 'transcendence', 5
    -- shyvana
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'fleet-footwork', 1
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'unshakeable', 2
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'second-wind', 3
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'overgrowth', 4
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 'transcendence', 5
    -- talon
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 'first-strike', 1
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 'sudden-impact', 2
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 'hubris', 3
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 'eyeball-collector', 4
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 'absolute-focus', 5
    -- vi
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'conqueror', 1
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'triumph', 2
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'cut-down', 3
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'legend-alacrity', 4
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 'sudden-impact', 5
    -- volibear
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 'lethal-tempo', 1
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 'battle-zeal', 2
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 'last-stand', 3
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 'legend-alacrity', 4
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 'overgrowth', 5
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN runes r ON r.slug = x.rune_slug
ON DUPLICATE KEY UPDATE position = VALUES(position);

-- Ordre des compétences (1 point par niveau, 1 à 15)
INSERT INTO build_skill_order (build_id, level, skill)
SELECT b.id, x.level, x.skill
FROM (
    -- rengar
    SELECT 'rengar' AS champion_slug, 'Assassin furtif plongeon' AS build_name, 1 AS level, '1' AS skill
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 2, '2'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 3, '3'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 4, '1'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 5, 'ultimate'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 6, '1'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 7, '1'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 8, '2'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 9, 'ultimate'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 10, '2'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 11, '2'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 12, '3'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 13, 'ultimate'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 14, '3'
    UNION ALL SELECT 'rengar', 'Assassin furtif plongeon', 15, '3'
    -- shyvana
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 1, '3'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 2, '2'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 3, '1'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 4, '3'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 5, 'ultimate'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 6, '3'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 7, '3'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 8, '2'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 9, 'ultimate'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 10, '2'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 11, '2'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 12, '1'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 13, 'ultimate'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 14, '1'
    UNION ALL SELECT 'shyvana', 'Bruiser scaling plongeon', 15, '1'
    -- talon
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 1, '1'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 2, '2'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 3, '3'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 4, '1'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 5, 'ultimate'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 6, '1'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 7, '1'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 8, '2'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 9, 'ultimate'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 10, '2'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 11, '2'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 12, '3'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 13, 'ultimate'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 14, '3'
    UNION ALL SELECT 'talon', 'Assassin burst mobilité', 15, '3'
    -- vi
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 1, '1'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 2, '3'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 3, '2'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 4, '1'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 5, 'ultimate'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 6, '1'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 7, '1'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 8, '3'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 9, 'ultimate'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 10, '3'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 11, '3'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 12, '2'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 13, 'ultimate'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 14, '2'
    UNION ALL SELECT 'vi', 'Bruiser plongeon verrouillage', 15, '2'
    -- volibear
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 1, '2'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 2, '1'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 3, '3'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 4, '2'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 5, 'ultimate'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 6, '2'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 7, '2'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 8, '1'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 9, 'ultimate'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 10, '1'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 11, '1'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 12, '3'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 13, 'ultimate'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 14, '3'
    UNION ALL SELECT 'volibear', 'Bruiser plongeon soutien (Jungle)', 15, '3'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
ON DUPLICATE KEY UPDATE skill = VALUES(skill);

-- ============================================================
-- Vérification (lecture seule) — à lancer après l'import
-- ============================================================

-- 1) Champions du lot absents de la table champions (doit être vide)
SELECT s.slug AS champion_manquant
FROM (
    SELECT 'rengar' AS slug
    UNION ALL SELECT 'shyvana'
    UNION ALL SELECT 'talon'
    UNION ALL SELECT 'vi'
    UNION ALL SELECT 'volibear'
) s
LEFT JOIN champions c ON c.slug = s.slug
WHERE c.id IS NULL;

-- 2) Objets référencés mais absents du catalogue (doit être vide)
SELECT s.slug AS objet_manquant
FROM (
    SELECT 'amaranths-twinguard' AS slug
    UNION ALL SELECT 'berserkers-greaves'
    UNION ALL SELECT 'boots-of-dynamism'
    UNION ALL SELECT 'cosmic-drive'
    UNION ALL SELECT 'deaths-dance'
    UNION ALL SELECT 'dusk-and-dawn'
    UNION ALL SELECT 'duskblade-of-draktharr'
    UNION ALL SELECT 'eclipse'
    UNION ALL SELECT 'edge-of-night'
    UNION ALL SELECT 'gluttonous-greaves'
    UNION ALL SELECT 'guardian-angel'
    UNION ALL SELECT 'long-sword'
    UNION ALL SELECT 'mercurys-treads'
    UNION ALL SELECT 'navori-quickblades'
    UNION ALL SELECT 'plated-steelcaps'
    UNION ALL SELECT 'randuins-omen'
    UNION ALL SELECT 'riftmaker'
    UNION ALL SELECT 'serpents-fang'
    UNION ALL SELECT 'seryldas-grudge'
    UNION ALL SELECT 'spear-of-shojin'
    UNION ALL SELECT 'steraks-gage'
    UNION ALL SELECT 'sundered-sky'
    UNION ALL SELECT 'thornmail'
    UNION ALL SELECT 'trinity-force'
    UNION ALL SELECT 'youmuus-ghostblade'
) s
LEFT JOIN items i ON i.slug = s.slug
WHERE i.id IS NULL;

-- 3) Runes référencées mais absentes du catalogue (doit être vide)
SELECT s.slug AS rune_manquante
FROM (
    SELECT 'absolute-focus' AS slug
    UNION ALL SELECT 'battle-zeal'
    UNION ALL SELECT 'conqueror'
    UNION ALL SELECT 'cut-down'
    UNION ALL SELECT 'eyeball-collector'
    UNION ALL SELECT 'first-strike'
    UNION ALL SELECT 'fleet-footwork'
    UNION ALL SELECT 'hubris'
    UNION ALL SELECT 'last-stand'
    UNION ALL SELECT 'legend-alacrity'
    UNION ALL SELECT 'lethal-tempo'
    UNION ALL SELECT 'overgrowth'
    UNION ALL SELECT 'second-wind'
    UNION ALL SELECT 'sudden-impact'
    UNION ALL SELECT 'transcendence'
    UNION ALL SELECT 'triumph'
    UNION ALL SELECT 'tyrant'
    UNION ALL SELECT 'unshakeable'
) s
LEFT JOIN runes r ON r.slug = s.slug
WHERE r.id IS NULL;

-- 4) Complétude des 5 builds 7.3 : attendu 7 objets hors situationnels,
--    5 runes, 15 niveaux de compétences
SELECT c.slug AS champion, b.name AS build, b.patch,
       (SELECT COUNT(*) FROM build_items bi WHERE bi.build_id = b.id AND bi.slot <> 'situational') AS objets_finaux,
       (SELECT COUNT(*) FROM build_items bi WHERE bi.build_id = b.id AND bi.slot = 'situational') AS objets_situationnels,
       (SELECT COUNT(*) FROM build_runes br WHERE br.build_id = b.id) AS runes,
       (SELECT COUNT(*) FROM build_skill_order bs WHERE bs.build_id = b.id) AS niveaux_competences
FROM builds b
INNER JOIN champions c ON c.id = b.champion_id
WHERE c.slug IN ('rengar', 'shyvana', 'talon', 'vi', 'volibear') AND b.patch = '7.3'
ORDER BY c.slug;

-- 5) Doublons éventuels (doit être vide)
SELECT champion_id, name, COUNT(*) AS n
FROM builds
WHERE patch = '7.3' AND champion_id IN (SELECT id FROM champions WHERE slug IN ('rengar', 'shyvana', 'talon', 'vi', 'volibear'))
GROUP BY champion_id, name
HAVING COUNT(*) > 1;

-- 6) Autres builds déjà en base pour ces 5 champions (anciens patchs,
--    conservés) : à comparer avec le 7.3 pour l'affichage
SELECT c.slug AS champion, b.name AS build, b.role, b.patch
FROM builds b
INNER JOIN champions c ON c.id = b.champion_id
WHERE c.slug IN ('rengar', 'shyvana', 'talon', 'vi', 'volibear')
ORDER BY c.slug, b.patch DESC, b.name;
