-- ============================================================
-- Lot 5 — Builds patch 7.3 — source WildRiftFire.com
-- Champions : Nocturne, Nunu & Willump, Olaf, Pantheon, Rammus
-- (suite du rôle jungle après Lee Sin, Lillia, Master Yi, Nidalee
-- du lot 4 ; Nilah reste écartée, sa fiche étant encore en 7.2e).
-- À importer APRÈS schema.sql, seed_wildriftfire_builds.sql et les
-- lots 1 à 4. Aucune suppression, aucune modification de données
-- existantes hors ces 5 nouveaux builds. Relancer le fichier est
-- sans effet (idempotent).
--
-- Vérifié le 24/09/2026 : les 5 fiches affichent "Patch 7.3".
--
-- Olaf : sa fiche propose deux builds (Jungle S, Solo/Baron A).
-- Seule la version Jungle (Recommended Role) est reprise ; la
-- version Baron n'est pas importée (valeur de rôle Baron non
-- confirmée en base).
--
-- Nunu & Willump : le slug WildRiftFire est 'nunu-amp-willump' ;
-- on suppose 'nunu-willump' en base. À corriger si la requête de
-- vérification 1 le signale.
--
-- Bottes : Nocturne et Pantheon affichent un 2e objet dans le bloc
-- "Boots" (Stridebreaker / Galeforce). Bottes retenues : Boots of
-- Dynamism ; l'autre objet est repris en 'core' en dernier (ordre 8),
-- comme dans leur Final Build (7 objets + bottes).
--
-- Écarts texte/liste : pour Nocturne (First Strike/Chain Assault
-- cités dans le texte, mais liste = Electrocute), Pantheon (First
-- Strike, Chain Assault, Eyeball Collector, Absolute Focus cités,
-- liste = Hextech Flashtraption, Transcendence, Nimbus Cloak),
-- Nunu et Rammus (Courage of the Colossus/Bone Plating cités), la
-- liste des 5 runes du bloc "Runes" fait foi (même règle que
-- Kindred au lot 3). Nocturne : le texte cite aussi Gluttonous
-- Greaves et Sundered Sky ; le Final Build affiché fait foi.
--
-- Objets situationnels également présents dans le Final Build
-- (Sundered Sky pour Nocturne, Twinguard pour Nunu, Mantle of the
-- Twelfth Hour pour Rammus, Plated Steelcaps) : conservés en 'core'
-- ou 'boots', même convention que les lots précédents.
--
-- Limites conservées : sorts d'invocateur non importés (Flash/Smite ;
-- Ghost/Smite pour Olaf), runes situationnelles non importées, ordre
-- des compétences au gabarit habituel (seule la priorité est donnée
-- sur la page).
--
-- Runes 'chain-assault', 'celerity' et 'hextech-flashtraption' : non
-- définies ici (arbre/emplacement non confirmés). Si la vérification
-- 3 les signale, les lignes de runes correspondantes sont absentes.
-- Seules 'second-wind', 'last-stand' (listées comme non définies à
-- la fin du lot 3) et 'overgrowth' sont créées, uniquement si absentes.
-- ============================================================

-- Nouvelles runes nécessaires (Nunu, Rammus, Olaf)
INSERT INTO runes (slug, name, tree, slot, description, image_url)
SELECT v.slug, v.name, v.tree, v.slot, v.description, v.image_url
FROM (
    SELECT 'second-wind' AS slug, 'Second souffle' AS name, 'resolve' AS tree, 'minor' AS slot, 'Régénération de PV après avoir subi des dégâts d''un champion ennemi.' AS description, NULL AS image_url
    UNION ALL SELECT 'last-stand', 'Dernier rempart', 'precision', 'minor', 'Dégâts bonus qui augmentent quand tes PV sont bas.', NULL
    UNION ALL SELECT 'overgrowth', 'Surcroissance', 'resolve', 'minor', 'PV maximum bonus en fonction des sbires et monstres qui meurent à proximité.', NULL
) v
WHERE NOT EXISTS (SELECT 1 FROM runes r WHERE r.slug = v.slug);


-- Builds
INSERT INTO builds (champion_id, name, role, patch, description, source)
SELECT id, 'Assassin plongeon engage', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Duskblade of Draktharr, Serpent''s Fang et Serylda''s Grudge pour le burst et la pénétration avant un plongeon en Paranoia, Sundered Sky, Guardian Angel et Stridebreaker en fin de Final Build pour tenir et poursuivre.',
       'WildRiftFire.com' FROM champions WHERE slug = 'nocturne'
UNION ALL
SELECT id, 'Tank engage contrôle de foule', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Sunfire Aegis, Thornmail et Warmog''s Armor pour un tank de première ligne, Frozen Heart et Amaranth''s Twinguard en fin de Final Build pour encaisser les teamfights.',
       'WildRiftFire.com' FROM champions WHERE slug = 'nunu-willump'
UNION ALL
SELECT id, 'Bruiser duelliste anti-contrôle (Jungle)', 'jungle', '7.3',
       'Build Jungle de WildRiftFire (version Jungle) : Trinity Force, Sundered Sky et Death''s Dance pour un duelliste résistant, Sterak''s Gage et Amaranth''s Twinguard en fin de Final Build pour survivre en teamfight.',
       'WildRiftFire.com' FROM champions WHERE slug = 'olaf'
UNION ALL
SELECT id, 'Assassin plongeon burst', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Youmuu''s Ghostblade, Duskblade of Draktharr et Serylda''s Grudge pour le burst à l''engagement, Edge of Night, Guardian Angel et Galeforce en fin de Final Build.',
       'WildRiftFire.com' FROM champions WHERE slug = 'pantheon'
UNION ALL
SELECT id, 'Tank engage anti-auto-attaques', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Thornmail, Sunfire Aegis et Dawnshroud pour un tank qui punit les auto-attaques, Amaranth''s Twinguard et Mantle of the Twelfth Hour en fin de Final Build.',
       'WildRiftFire.com' FROM champions WHERE slug = 'rammus'
ON DUPLICATE KEY UPDATE
    role = VALUES(role),
    patch = VALUES(patch),
    description = VALUES(description),
    source = VALUES(source);

-- Objets des builds
INSERT INTO build_items (build_id, item_id, slot, purchase_order, situation)
SELECT b.id, i.id, x.slot, x.purchase_order, x.situation
FROM (
    -- nocturne
    SELECT 'nocturne' AS champion_slug, 'Assassin plongeon engage' AS build_name, 'long-sword' AS item_slug, 'starting' AS slot, 1 AS purchase_order, NULL AS situation
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 'duskblade-of-draktharr', 'core', 2, NULL
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 'serpents-fang', 'core', 3, NULL
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 'seryldas-grudge', 'core', 4, NULL
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 'boots-of-dynamism', 'boots', 5, NULL
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 'sundered-sky', 'core', 6, NULL
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 'guardian-angel', 'core', 7, NULL
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 'stridebreaker', 'core', 8, NULL
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 'edge-of-night', 'situational', NULL, 'vs Crowd Control'
    -- nunu-willump
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'ruby-crystal', 'starting', 1, NULL
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'sunfire-aegis', 'core', 2, NULL
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'thornmail', 'core', 3, NULL
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'warmogs-armor', 'core', 4, NULL
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'plated-steelcaps', 'boots', 5, NULL
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'frozen-heart', 'core', 6, NULL
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'amaranths-twinguard', 'core', 7, NULL
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'randuins-omen', 'situational', NULL, 'vs Critical Strike Damage'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'mercurys-treads', 'situational', NULL, 'vs AP / CC'
    -- olaf
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'trinity-force', 'core', 2, NULL
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'sundered-sky', 'core', 3, NULL
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'deaths-dance', 'core', 4, NULL
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'plated-steelcaps', 'boots', 5, NULL
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'steraks-gage', 'core', 6, NULL
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'amaranths-twinguard', 'core', 7, NULL
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'mercurys-treads', 'situational', NULL, 'vs Ability Power'
    -- pantheon
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'youmuus-ghostblade', 'core', 2, NULL
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'duskblade-of-draktharr', 'core', 3, NULL
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'seryldas-grudge', 'core', 4, NULL
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'boots-of-dynamism', 'boots', 5, NULL
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'edge-of-night', 'core', 6, NULL
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'guardian-angel', 'core', 7, NULL
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'galeforce', 'core', 8, NULL
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'serpents-fang', 'situational', NULL, 'vs Shielding'
    -- rammus
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'ruby-crystal', 'starting', 1, NULL
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'thornmail', 'core', 2, NULL
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'sunfire-aegis', 'core', 3, NULL
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'dawnshroud', 'core', 4, NULL
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'plated-steelcaps', 'boots', 5, NULL
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'amaranths-twinguard', 'core', 6, NULL
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'mantle-of-the-twelfth-hour', 'core', 7, NULL
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'randuins-omen', 'situational', NULL, 'vs Critical Strike Damage'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'mercurys-treads', 'situational', NULL, 'vs AP / CC'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN items i ON i.slug = x.item_slug
ON DUPLICATE KEY UPDATE purchase_order = VALUES(purchase_order), situation = VALUES(situation);

-- Runes des builds
INSERT INTO build_runes (build_id, rune_id, position)
SELECT b.id, r.id, x.position
FROM (
    -- nocturne
    SELECT 'nocturne' AS champion_slug, 'Assassin plongeon engage' AS build_name, 'electrocute' AS rune_slug, 1 AS position
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 'sudden-impact', 2
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 'chain-assault', 3
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 'eyeball-collector', 4
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 'transcendence', 5
    -- nunu-willump
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'ice-overlord', 1
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'unshakeable', 2
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'second-wind', 3
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'overgrowth', 4
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 'transcendence', 5
    -- olaf
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'conqueror', 1
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'triumph', 2
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'last-stand', 3
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'legend-alacrity', 4
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 'nimbus-cloak', 5
    -- pantheon
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'conqueror', 1
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'hextech-flashtraption', 2
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'transcendence', 3
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'nimbus-cloak', 4
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 'sudden-impact', 5
    -- rammus
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'ice-overlord', 1
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'unshakeable', 2
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'second-wind', 3
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'overgrowth', 4
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 'celerity', 5
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN runes r ON r.slug = x.rune_slug
ON DUPLICATE KEY UPDATE position = VALUES(position);

-- Ordre des compétences (1 point par niveau, 1 à 15)
INSERT INTO build_skill_order (build_id, level, skill)
SELECT b.id, x.level, x.skill
FROM (
    -- nocturne
    SELECT 'nocturne' AS champion_slug, 'Assassin plongeon engage' AS build_name, 1 AS level, '1' AS skill
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 2, '1'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 3, '1'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 4, '1'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 5, 'ultimate'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 6, '1'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 7, '3'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 8, '3'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 9, 'ultimate'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 10, '3'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 11, '3'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 12, '2'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 13, 'ultimate'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 14, '2'
    UNION ALL SELECT 'nocturne', 'Assassin plongeon engage', 15, '2'
    -- nunu-willump
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 1, '1'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 2, '1'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 3, '1'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 4, '1'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 5, 'ultimate'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 6, '1'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 7, '3'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 8, '3'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 9, 'ultimate'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 10, '3'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 11, '3'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 12, '2'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 13, 'ultimate'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 14, '2'
    UNION ALL SELECT 'nunu-willump', 'Tank engage contrôle de foule', 15, '2'
    -- olaf
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 1, '1'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 2, '1'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 3, '1'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 4, '1'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 5, 'ultimate'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 6, '1'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 7, '3'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 8, '3'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 9, 'ultimate'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 10, '3'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 11, '3'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 12, '2'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 13, 'ultimate'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 14, '2'
    UNION ALL SELECT 'olaf', 'Bruiser duelliste anti-contrôle (Jungle)', 15, '2'
    -- pantheon
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 1, '1'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 2, '1'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 3, '1'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 4, '1'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 5, 'ultimate'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 6, '1'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 7, '2'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 8, '2'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 9, 'ultimate'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 10, '2'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 11, '2'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 12, '3'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 13, 'ultimate'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 14, '3'
    UNION ALL SELECT 'pantheon', 'Assassin plongeon burst', 15, '3'
    -- rammus
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 1, '1'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 2, '1'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 3, '1'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 4, '1'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 5, 'ultimate'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 6, '1'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 7, '3'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 8, '3'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 9, 'ultimate'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 10, '3'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 11, '3'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 12, '2'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 13, 'ultimate'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 14, '2'
    UNION ALL SELECT 'rammus', 'Tank engage anti-auto-attaques', 15, '2'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
ON DUPLICATE KEY UPDATE skill = VALUES(skill);

-- ============================================================
-- Vérification (lecture seule) — à lancer après l'import
-- ============================================================

-- 1) Champions du lot absents de la table champions (doit être vide)
--    Si 'nunu-willump' apparaît, le slug réel de Nunu en base est différent.
SELECT s.slug AS champion_manquant
FROM (
    SELECT 'nocturne' AS slug
    UNION ALL SELECT 'nunu-willump'
    UNION ALL SELECT 'olaf'
    UNION ALL SELECT 'pantheon'
    UNION ALL SELECT 'rammus'
) s
LEFT JOIN champions c ON c.slug = s.slug
WHERE c.id IS NULL;

-- 2) Objets référencés mais absents du catalogue (doit être vide)
SELECT s.slug AS objet_manquant
FROM (
    SELECT 'amaranths-twinguard' AS slug
    UNION ALL SELECT 'boots-of-dynamism'
    UNION ALL SELECT 'dawnshroud'
    UNION ALL SELECT 'deaths-dance'
    UNION ALL SELECT 'duskblade-of-draktharr'
    UNION ALL SELECT 'edge-of-night'
    UNION ALL SELECT 'frozen-heart'
    UNION ALL SELECT 'galeforce'
    UNION ALL SELECT 'guardian-angel'
    UNION ALL SELECT 'long-sword'
    UNION ALL SELECT 'mantle-of-the-twelfth-hour'
    UNION ALL SELECT 'mercurys-treads'
    UNION ALL SELECT 'plated-steelcaps'
    UNION ALL SELECT 'randuins-omen'
    UNION ALL SELECT 'ruby-crystal'
    UNION ALL SELECT 'serpents-fang'
    UNION ALL SELECT 'seryldas-grudge'
    UNION ALL SELECT 'steraks-gage'
    UNION ALL SELECT 'stridebreaker'
    UNION ALL SELECT 'sundered-sky'
    UNION ALL SELECT 'sunfire-aegis'
    UNION ALL SELECT 'thornmail'
    UNION ALL SELECT 'trinity-force'
    UNION ALL SELECT 'warmogs-armor'
    UNION ALL SELECT 'youmuus-ghostblade'
) s
LEFT JOIN items i ON i.slug = s.slug
WHERE i.id IS NULL;

-- 3) Runes référencées mais absentes du catalogue (doit être vide)
SELECT s.slug AS rune_manquante
FROM (
    SELECT 'celerity' AS slug
    UNION ALL SELECT 'chain-assault'
    UNION ALL SELECT 'conqueror'
    UNION ALL SELECT 'electrocute'
    UNION ALL SELECT 'eyeball-collector'
    UNION ALL SELECT 'hextech-flashtraption'
    UNION ALL SELECT 'ice-overlord'
    UNION ALL SELECT 'last-stand'
    UNION ALL SELECT 'legend-alacrity'
    UNION ALL SELECT 'nimbus-cloak'
    UNION ALL SELECT 'overgrowth'
    UNION ALL SELECT 'second-wind'
    UNION ALL SELECT 'sudden-impact'
    UNION ALL SELECT 'transcendence'
    UNION ALL SELECT 'triumph'
    UNION ALL SELECT 'unshakeable'
) s
LEFT JOIN runes r ON r.slug = s.slug
WHERE r.id IS NULL;

-- 4) Complétude des 5 builds 7.3 : attendu 7 ou 8 objets hors situationnels
--    (Nocturne 8, Pantheon 8, les autres 7), 5 runes, 15 niveaux de compétences
SELECT c.slug AS champion, b.name AS build, b.patch,
       (SELECT COUNT(*) FROM build_items bi WHERE bi.build_id = b.id AND bi.slot <> 'situational') AS objets_finaux,
       (SELECT COUNT(*) FROM build_items bi WHERE bi.build_id = b.id AND bi.slot = 'situational') AS objets_situationnels,
       (SELECT COUNT(*) FROM build_runes br WHERE br.build_id = b.id) AS runes,
       (SELECT COUNT(*) FROM build_skill_order bs WHERE bs.build_id = b.id) AS niveaux_competences
FROM builds b
INNER JOIN champions c ON c.id = b.champion_id
WHERE c.slug IN ('nocturne', 'nunu-willump', 'olaf', 'pantheon', 'rammus') AND b.patch = '7.3'
ORDER BY c.slug;

-- 5) Doublons éventuels (doit être vide)
SELECT champion_id, name, COUNT(*) AS n
FROM builds
WHERE patch = '7.3' AND champion_id IN (SELECT id FROM champions WHERE slug IN ('nocturne', 'nunu-willump', 'olaf', 'pantheon', 'rammus'))
GROUP BY champion_id, name
HAVING COUNT(*) > 1;
