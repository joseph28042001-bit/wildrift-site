-- ============================================================
-- Lot 4 — Builds patch 7.3 — source WildRiftFire.com
-- Champions : Lee Sin, Lillia, Master Yi, Nidalee
-- (suite du rôle jungle après Hecarim, Jarvan IV, Kayn, Kha'Zix,
-- Kindred du lot 3). 4 champions seulement, voir Nilah ci-dessous.
-- À importer APRÈS schema.sql, seed_wildriftfire_builds.sql et les
-- lots 1, 2 et 3 (complète les objets/runes déjà présents plutôt
-- que de les redéfinir). Aucune suppression, aucune modification
-- de données existantes hors ces 4 nouveaux builds.
--
-- Nilah NON importée : sa fiche WildRiftFire affiche encore
-- "Patch 7.2e" (Tier C jungle) au 24/09/2026, pas 7.3. Elle est
-- laissée de côté conformément à la vérification du patch.
--
-- Doublons : Lee Sin et Master Yi ont déjà un build (patch 7.2e,
-- seed_wildriftfire_builds.sql). Les builds 7.3 ci-dessous portent
-- un NOM DIFFÉRENT (clé champion + nom) : ils s'ajoutent à
-- l'existant sans l'écraser ni fusionner leurs objets. Relancer
-- ce fichier est sans effet (idempotent).
--
-- Point bloquant conservé : les sorts d'invocateur (Flash/Smite
-- pour les 4 champions) ne sont PAS importés, faute de colonne/table
-- pour les stocker — même limitation que les lots précédents.
-- Les runes situationnelles (ex. Coup de Grace vs Squishies) ne
-- sont pas non plus importées, comme aux lots précédents.
--
-- Écarts texte/liste sur WildRiftFire : pour Lee Sin (Sudden Impact
-- cité dans le texte), Master Yi (Brutal et Nimbus Cloak cités) et
-- Nidalee (Chain Assault et Transcendence cités), le texte
-- explicatif diffère de la liste de runes affichée. La liste des
-- 5 runes du bloc "Runes" fait foi (même règle que pour Kindred au
-- lot 3). Master Yi : le texte cite aussi Blade of the Ruined King
-- dans le build, mais le Final Build ne l'inclut pas ; il est donc
-- repris en 'situational' (vs Tanks), comme l'indique la section
-- Situational Items.
--
-- Objets situationnels également présents dans le Final Build
-- (Zhonya's Hourglass pour Lillia/Nidalee, Guardian Angel pour
-- Master Yi) : conservés en 'core', même convention que les lots
-- précédents. Lee Sin n'a aucun objet situationnel sur sa fiche.
--
-- Ordre des compétences : la page ne donne que la priorité
-- (Quick Skill Order), pas le détail niveau par niveau ; le
-- schéma 1-15 est le même gabarit que les lots précédents.
--
-- Runes battle-zeal et overgrowth : listées comme "encore non
-- définies" à la fin du lot 3 et utilisées ici (Lee Sin/Lillia et
-- Master Yi). Elles sont définies ci-dessous, uniquement si elles
-- sont absentes (aucun écrasement). Aucun autre objet ni rune n'est
-- créé : si un slug est manquant, la ligne est ignorée par les
-- INNER JOIN et la requête de vérification en fin de fichier le
-- signale.
-- ============================================================

-- Nouvelles runes nécessaires (Lee Sin, Lillia, Master Yi)
INSERT INTO runes (slug, name, tree, slot, description, image_url)
SELECT v.slug, v.name, v.tree, v.slot, v.description, v.image_url
FROM (
    SELECT 'battle-zeal' AS slug, 'Zèle de bataille' AS name, 'precision' AS tree, 'minor' AS slot, 'Dégâts bonus qui augmentent au fil des combats prolongés contre des champions.' AS description, NULL AS image_url
    UNION ALL SELECT 'overgrowth', 'Surcroissance', 'resolve', 'minor', 'PV maximum bonus en fonction des sbires et monstres qui meurent à proximité.', NULL
) v
WHERE NOT EXISTS (SELECT 1 FROM runes r WHERE r.slug = v.slug);


-- Builds
INSERT INTO builds (champion_id, name, role, patch, description, source)
SELECT id, 'Bruiser mobilité haute maîtrise', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Youmuu''s Ghostblade pour roamer vite et gagner du burst, Trinity Force et Serylda''s Grudge (ralentissement sur les sorts) pour poursuivre, Serpent''s Fang et Guardian Angel en fin de Final Build pour finir les cibles et survivre.',
       'WildRiftFire.com' FROM champions WHERE slug = 'lee-sin'
UNION ALL
SELECT id, 'Mage AoE mobilité brûlure', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Liandry''s Torment et Blackfire Torch pour amplifier les dégâts sur la durée de Dream-Laden Bough, Rabadon''s Deathcap pour le burst, Riftmaker et Zhonya''s Hourglass en fin de Final Build pour tenir en teamfight.',
       'WildRiftFire.com' FROM champions WHERE slug = 'lillia'
UNION ALL
SELECT id, 'Hypercarry poursuite auto-attaques', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Kraken Slayer et Guinsoo''s Rageblade pour la vitesse d''attaque et les dégâts vrais de Wuju Style, Death''s Dance et Black Cleaver pour tenir et percer l''armure, Guardian Angel en fin de Final Build.',
       'WildRiftFire.com' FROM champions WHERE slug = 'master-yi'
UNION ALL
SELECT id, 'Assassin poke burst', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Lich Bane pour le combo javelot puis Takedown, Infinity Orb pour exécuter les cibles affaiblies, Rabadon''s Deathcap pour le burst, Void Staff et Zhonya''s Hourglass en fin de Final Build.',
       'WildRiftFire.com' FROM champions WHERE slug = 'nidalee'
ON DUPLICATE KEY UPDATE
    role = VALUES(role),
    patch = VALUES(patch),
    description = VALUES(description),
    source = VALUES(source);

-- Objets des builds
INSERT INTO build_items (build_id, item_id, slot, purchase_order, situation)
SELECT b.id, i.id, x.slot, x.purchase_order, x.situation
FROM (
    -- lee-sin (jungle) — Bruiser mobilité haute maîtrise
    SELECT 'lee-sin' AS champion_slug, 'Bruiser mobilité haute maîtrise' AS build_name, 'long-sword' AS item_slug, 'starting' AS slot, 1 AS purchase_order, NULL AS situation
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 'youmuus-ghostblade', 'core', 2, NULL
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 'trinity-force', 'core', 3, NULL
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 'seryldas-grudge', 'core', 4, NULL
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 'gluttonous-greaves', 'boots', 5, NULL
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 'serpents-fang', 'core', 6, NULL
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 'guardian-angel', 'core', 7, NULL
    -- lillia (jungle) — Mage AoE mobilité brûlure
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'amplifying-tome', 'starting', 1, NULL
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'liandrys-torment', 'core', 2, NULL
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'blackfire-torch', 'core', 3, NULL
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'rabadons-deathcap', 'core', 4, NULL
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'boots-of-mana', 'boots', 5, NULL
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'riftmaker', 'core', 6, NULL
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'zhonyas-hourglass', 'core', 7, NULL
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'oceanids-trident', 'situational', NULL, 'vs Shielding'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'banshees-veil', 'situational', NULL, 'vs Crowd Control'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'bloodletters-curse', 'situational', NULL, 'vs Tanks'
    -- master-yi (jungle) — Hypercarry poursuite auto-attaques
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'kraken-slayer', 'core', 2, NULL
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'guinsoos-rageblade', 'core', 3, NULL
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'deaths-dance', 'core', 4, NULL
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'berserkers-greaves', 'boots', 5, NULL
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'black-cleaver', 'core', 6, NULL
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'guardian-angel', 'core', 7, NULL
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'wits-end', 'situational', NULL, 'vs Ability Power'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'mercurial-scimitar', 'situational', NULL, 'vs Crowd Control'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'blade-of-the-ruined-king', 'situational', NULL, 'vs Tanks'
    -- nidalee (jungle) — Assassin poke burst
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'amplifying-tome', 'starting', 1, NULL
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'lich-bane', 'core', 2, NULL
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'infinity-orb', 'core', 3, NULL
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'rabadons-deathcap', 'core', 4, NULL
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'boots-of-mana', 'boots', 5, NULL
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'void-staff', 'core', 6, NULL
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'zhonyas-hourglass', 'core', 7, NULL
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'oceanids-trident', 'situational', NULL, 'vs Shielding'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'banshees-veil', 'situational', NULL, 'vs Crowd Control'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN items i ON i.slug = x.item_slug
ON DUPLICATE KEY UPDATE purchase_order = VALUES(purchase_order), situation = VALUES(situation);

-- Runes des builds
INSERT INTO build_runes (build_id, rune_id, position)
SELECT b.id, r.id, x.position
FROM (
    SELECT 'lee-sin' AS champion_slug, 'Bruiser mobilité haute maîtrise' AS build_name, 'conqueror' AS rune_slug, 1 AS position
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 'battle-zeal', 2
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 'cut-down', 3
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 'legend-alacrity', 4
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 'absolute-focus', 5
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'phase-rush', 1
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'battle-zeal', 2
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'cut-down', 3
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'legend-bloodline', 4
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 'transcendence', 5
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'lethal-tempo', 1
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'triumph', 2
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'cut-down', 3
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'legend-alacrity', 4
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 'overgrowth', 5
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'dark-harvest', 1
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'sudden-impact', 2
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'tyrant', 3
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'eyeball-collector', 4
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 'absolute-focus', 5
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN runes r ON r.slug = x.rune_slug
ON DUPLICATE KEY UPDATE position = VALUES(position);

-- Ordre des compétences (1 point par niveau, 1 à 15)
INSERT INTO build_skill_order (build_id, level, skill)
SELECT b.id, x.level, x.skill
FROM (
    -- lee-sin : Sonic Wave(1) > Safeguard(2) > Tempest(3)
    SELECT 'lee-sin' AS champion_slug, 'Bruiser mobilité haute maîtrise' AS build_name, 1 AS level, '1' AS skill
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 2, '1'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 3, '1'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 4, '1'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 5, 'ultimate'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 6, '1'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 7, '2'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 8, '2'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 9, 'ultimate'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 10, '2'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 11, '2'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 12, '3'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 13, 'ultimate'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 14, '3'
    UNION ALL SELECT 'lee-sin', 'Bruiser mobilité haute maîtrise', 15, '3'
    -- lillia : Blooming Blows(1) > Watch Out! Eep!(2) > Swirlseed(3)
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 1, '1'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 2, '1'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 3, '1'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 4, '1'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 5, 'ultimate'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 6, '1'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 7, '2'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 8, '2'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 9, 'ultimate'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 10, '2'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 11, '2'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 12, '3'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 13, 'ultimate'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 14, '3'
    UNION ALL SELECT 'lillia', 'Mage AoE mobilité brûlure', 15, '3'
    -- master-yi : Alpha Strike(1) > Wuju Style(3) > Meditate(2)
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 1, '1'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 2, '1'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 3, '1'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 4, '1'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 5, 'ultimate'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 6, '1'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 7, '3'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 8, '3'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 9, 'ultimate'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 10, '3'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 11, '3'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 12, '2'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 13, 'ultimate'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 14, '2'
    UNION ALL SELECT 'master-yi', 'Hypercarry poursuite auto-attaques', 15, '2'
    -- nidalee : Javelin Toss(1) > Primal Surge(3) > Bushwhack(2)
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 1, '1'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 2, '1'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 3, '1'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 4, '1'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 5, 'ultimate'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 6, '1'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 7, '3'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 8, '3'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 9, 'ultimate'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 10, '3'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 11, '3'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 12, '2'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 13, 'ultimate'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 14, '2'
    UNION ALL SELECT 'nidalee', 'Assassin poke burst', 15, '2'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
ON DUPLICATE KEY UPDATE skill = VALUES(skill);

-- ============================================================
-- Vérification (lecture seule) — à lancer après l'import
-- ============================================================

-- 1) Champions du lot absents de la table champions (doit être vide)
SELECT s.slug AS champion_manquant
FROM (SELECT 'lee-sin' AS slug UNION ALL SELECT 'lillia' UNION ALL SELECT 'master-yi' UNION ALL SELECT 'nidalee') s
LEFT JOIN champions c ON c.slug = s.slug
WHERE c.id IS NULL;

-- 2) Objets référencés mais absents du catalogue (doit être vide)
SELECT s.slug AS objet_manquant
FROM (
    SELECT 'long-sword' AS slug UNION ALL SELECT 'youmuus-ghostblade' UNION ALL SELECT 'trinity-force' UNION ALL SELECT 'seryldas-grudge'
    UNION ALL SELECT 'gluttonous-greaves' UNION ALL SELECT 'serpents-fang' UNION ALL SELECT 'guardian-angel'
    UNION ALL SELECT 'amplifying-tome' UNION ALL SELECT 'liandrys-torment' UNION ALL SELECT 'blackfire-torch' UNION ALL SELECT 'rabadons-deathcap'
    UNION ALL SELECT 'boots-of-mana' UNION ALL SELECT 'riftmaker' UNION ALL SELECT 'zhonyas-hourglass' UNION ALL SELECT 'oceanids-trident'
    UNION ALL SELECT 'banshees-veil' UNION ALL SELECT 'bloodletters-curse'
    UNION ALL SELECT 'kraken-slayer' UNION ALL SELECT 'guinsoos-rageblade' UNION ALL SELECT 'deaths-dance' UNION ALL SELECT 'berserkers-greaves'
    UNION ALL SELECT 'black-cleaver' UNION ALL SELECT 'wits-end' UNION ALL SELECT 'mercurial-scimitar' UNION ALL SELECT 'blade-of-the-ruined-king'
    UNION ALL SELECT 'lich-bane' UNION ALL SELECT 'infinity-orb' UNION ALL SELECT 'void-staff'
) s
LEFT JOIN items i ON i.slug = s.slug
WHERE i.id IS NULL;

-- 3) Runes référencées mais absentes du catalogue (doit être vide)
SELECT s.slug AS rune_manquante
FROM (
    SELECT 'conqueror' AS slug UNION ALL SELECT 'battle-zeal' UNION ALL SELECT 'cut-down' UNION ALL SELECT 'legend-alacrity' UNION ALL SELECT 'absolute-focus'
    UNION ALL SELECT 'phase-rush' UNION ALL SELECT 'legend-bloodline' UNION ALL SELECT 'transcendence'
    UNION ALL SELECT 'lethal-tempo' UNION ALL SELECT 'triumph' UNION ALL SELECT 'overgrowth'
    UNION ALL SELECT 'dark-harvest' UNION ALL SELECT 'sudden-impact' UNION ALL SELECT 'tyrant' UNION ALL SELECT 'eyeball-collector'
) s
LEFT JOIN runes r ON r.slug = s.slug
WHERE r.id IS NULL;

-- 4) Complétude des 4 builds 7.3 : attendu 7 objets hors situationnels,
--    5 runes, 15 niveaux de compétences par build
SELECT c.slug AS champion, b.name AS build, b.patch,
       (SELECT COUNT(*) FROM build_items bi WHERE bi.build_id = b.id AND bi.slot <> 'situational') AS objets_finaux,
       (SELECT COUNT(*) FROM build_items bi WHERE bi.build_id = b.id AND bi.slot = 'situational') AS objets_situationnels,
       (SELECT COUNT(*) FROM build_runes br WHERE br.build_id = b.id) AS runes,
       (SELECT COUNT(*) FROM build_skill_order bs WHERE bs.build_id = b.id) AS niveaux_competences
FROM builds b
INNER JOIN champions c ON c.id = b.champion_id
WHERE c.slug IN ('lee-sin', 'lillia', 'master-yi', 'nidalee') AND b.patch = '7.3'
ORDER BY c.slug;

-- 5) Doublons éventuels (doit être vide)
SELECT champion_id, name, COUNT(*) AS n
FROM builds
WHERE patch = '7.3' AND champion_id IN (SELECT id FROM champions WHERE slug IN ('lee-sin', 'lillia', 'master-yi', 'nidalee'))
GROUP BY champion_id, name
HAVING COUNT(*) > 1;
