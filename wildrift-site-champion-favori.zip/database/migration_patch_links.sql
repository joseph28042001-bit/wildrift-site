-- ============================================================
-- Wild Rift Platform — migration : rattachement des données aux patchs
-- ============================================================
-- À importer (phpMyAdmin > onglet SQL) sur une base DÉJÀ en place, APRÈS
-- migration_patches.sql (ou seule : elle crée `patches` si besoin).
-- Ajoute une colonne `patch_id` (NULL autorisé, clé étrangère vers
-- `patches`) sur : champions, items, runes, builds, tier_list, counters,
-- synergies. Les tables enfants (champion_abilities, item_recipes,
-- build_items, build_runes, build_skill_order, counter_items) n'en ont
-- pas besoin : elles dépendent de leur table parente.
--
-- Garanties :
--   - aucune ligne n'est supprimée ni modifiée dans ses colonnes
--     existantes (les colonnes `patch` de builds et tier_list restent
--     intactes, `updated_at` n'est pas réécrit) ;
--   - patch_id est NULL par défaut : le code et les requêtes actuels,
--     qui ne le connaissent pas, continuent de fonctionner à
--     l'identique ;
--   - rejouable sans risque : une colonne déjà présente n'est pas
--     recréée, et le rattachement builds / tier_list est simplement
--     recalculé (utile après un import de seed qui aurait modifié
--     builds.patch ou tier_list.patch) ;
--   - NULL signifie « non rattaché à un patch précis / valable pour
--     tous les patchs » : c'est le cas de toutes les données existantes
--     hors builds et tier_list, jusqu'à ce qu'un patch leur soit
--     attribué.
-- Ces mêmes instructions figurent à la fin de schema.sql (installations
-- neuves) : inutile de réimporter tout schema.sql sur une base existante.
-- Compatible MySQL 5.7+ / MariaDB (InfinityFree) : pas de DELIMITER,
-- pas de procédure stockée, pas de « ADD COLUMN IF NOT EXISTS ».
-- ============================================================

SET NAMES utf8mb4;

-- 0) Prérequis : table `patches` et patch 7.2e (identique à
--    migration_patches.sql ; sans effet si déjà en place).
CREATE TABLE IF NOT EXISTS patches (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    version VARCHAR(10) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 0,
    release_date DATE NULL,
    description VARCHAR(500) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_patches_version (version),
    INDEX idx_patches_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO patches (version, is_active, release_date, description)
VALUES ('7.2e', 1, NULL, 'Patch actif à la mise en place de la gestion des patchs.')
ON DUPLICATE KEY UPDATE version = version;

-- 1) Versions déjà utilisées par les données existantes : chaque valeur
--    distincte de builds.patch / tier_list.patch qui n'existe pas encore
--    dans `patches` y est ajoutée, INACTIVE (le patch actif ne change pas).
INSERT INTO patches (version, is_active, release_date, description)
SELECT s.version, 0, NULL, 'Version reprise automatiquement des données existantes (builds / tier list).'
FROM (
    SELECT patch AS version FROM builds
    UNION
    SELECT patch AS version FROM tier_list
) s
LEFT JOIN patches p ON p.version = s.version
WHERE p.id IS NULL AND s.version <> '';

-- 2) Colonne `patch_id` (NULL autorisé) + index + clé étrangère, sur chaque
--    table à versionner. Ajoutée seulement si elle n'existe pas déjà
--    (rejouable). ON DELETE SET NULL : supprimer un patch ne supprime
--    jamais de données, la ligne perd simplement son rattachement.

-- champions
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE champions ADD COLUMN patch_id INT UNSIGNED NULL, ADD INDEX idx_champions_patch_id (patch_id), ADD CONSTRAINT fk_champions_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'champions'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- items
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE items ADD COLUMN patch_id INT UNSIGNED NULL, ADD INDEX idx_items_patch_id (patch_id), ADD CONSTRAINT fk_items_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'items'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- runes
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE runes ADD COLUMN patch_id INT UNSIGNED NULL, ADD INDEX idx_runes_patch_id (patch_id), ADD CONSTRAINT fk_runes_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'runes'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- builds
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE builds ADD COLUMN patch_id INT UNSIGNED NULL AFTER patch, ADD INDEX idx_builds_patch_id (patch_id), ADD CONSTRAINT fk_builds_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'builds'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- tier_list
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE tier_list ADD COLUMN patch_id INT UNSIGNED NULL AFTER patch, ADD INDEX idx_tier_list_patch_id (patch_id), ADD CONSTRAINT fk_tier_list_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'tier_list'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- counters
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE counters ADD COLUMN patch_id INT UNSIGNED NULL, ADD INDEX idx_counters_patch_id (patch_id), ADD CONSTRAINT fk_counters_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'counters'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- synergies
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE synergies ADD COLUMN patch_id INT UNSIGNED NULL, ADD INDEX idx_synergies_patch_id (patch_id), ADD CONSTRAINT fk_synergies_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'synergies'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 3) Rattachement automatique de `builds` et `tier_list` : leur colonne
--    texte `patch` (inchangée) est la référence, `patch_id` la suit.
--    `updated_at = updated_at` évite que MySQL ne réécrive la date de
--    dernière modification de chaque ligne.

UPDATE builds t
INNER JOIN patches p ON p.version = t.patch
SET t.patch_id = p.id, t.updated_at = t.updated_at
WHERE t.patch_id IS NULL OR t.patch_id <> p.id;

UPDATE tier_list t
INNER JOIN patches p ON p.version = t.patch
SET t.patch_id = p.id, t.updated_at = t.updated_at
WHERE t.patch_id IS NULL OR t.patch_id <> p.id;

-- 4) Contrôle (lecture seule) : nombre de lignes par table et lignes
--    encore sans patch (`sans_patch`). Attendu : 0 pour builds et
--    tier_list ; les autres tables restent à NULL tant qu'aucun patch
--    ne leur est attribué (NULL = valable pour tous les patchs).
SELECT 'champions' AS table_name, COUNT(*) AS total, SUM(patch_id IS NULL) AS sans_patch FROM champions
UNION ALL SELECT 'items', COUNT(*), SUM(patch_id IS NULL) FROM items
UNION ALL SELECT 'runes', COUNT(*), SUM(patch_id IS NULL) FROM runes
UNION ALL SELECT 'builds', COUNT(*), SUM(patch_id IS NULL) FROM builds
UNION ALL SELECT 'tier_list', COUNT(*), SUM(patch_id IS NULL) FROM tier_list
UNION ALL SELECT 'counters', COUNT(*), SUM(patch_id IS NULL) FROM counters
UNION ALL SELECT 'synergies', COUNT(*), SUM(patch_id IS NULL) FROM synergies;
