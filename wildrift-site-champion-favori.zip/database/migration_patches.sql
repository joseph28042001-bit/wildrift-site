-- ============================================================
-- Wild Rift Platform — migration : gestion des patchs (table `patches`)
-- ============================================================
-- À importer (phpMyAdmin > onglet SQL) sur une base DÉJÀ en place :
-- crée uniquement la table `patches` et y ajoute le patch 7.2e (actif).
-- Ne touche à aucune autre table et ne supprime ni ne modifie aucune
-- donnée existante ; peut être réimporté sans risque.
-- Ces mêmes instructions figurent à la fin de schema.sql (pour les
-- installations neuves) : il n'est PAS nécessaire de réimporter tout
-- schema.sql sur une base existante.
-- Compatible MySQL 5.7+ / MariaDB (InfinityFree).
-- ============================================================

SET NAMES utf8mb4;

-- ------------------------------------------------------------
-- Patchs (versions du jeu Wild Rift gérées par le site)
-- Une ligne par version : 7.2e, 7.3, 7.3a, 7.3b, etc.
--   - version : numéro du patch, tel qu'il est écrit dans le jeu.
--     VARCHAR(10), même taille et même format que builds.patch et
--     tier_list.patch, pour pouvoir les rapprocher plus tard. UNIQUE :
--     un patch n'existe qu'une seule fois.
--   - is_active : 1 = patch actif du site, 0 = inactif. Le site n'est
--     censé avoir qu'UN SEUL patch actif à la fois ; MySQL/MariaDB ne
--     permettent pas de l'imposer par une simple contrainte (sans
--     colonne générée, non disponible sur toutes les versions), donc la
--     bascule d'un patch à l'autre doit désactiver l'ancien et activer
--     le nouveau dans une même transaction (exemple dans
--     docs/mysql.md, section `patches`).
--   - release_date : date de sortie du patch (facultative : NULL tant
--     qu'elle n'est pas renseignée).
--   - description : note libre facultative.
--   - created_at / updated_at : gérés automatiquement par MySQL.
--
-- Distincte de `wrchina_patches` (informations de patch importées
-- depuis WRChina.gg) : cette table-ci est la liste des versions que le
-- site gère lui-même. builds.patch et tier_list.patch restent des
-- textes ; leur rattachement à cette table (colonne patch_id) est fait
-- par migration_patch_links.sql (voir la fin de schema.sql).
--
-- Le patch 7.2e est créé et actif. Le INSERT est volontairement sans
-- effet s'il existe déjà (ON DUPLICATE KEY UPDATE version = version) :
-- réimporter ce script ne réactive jamais 7.2e une fois qu'un autre
-- patch est devenu actif, et ne modifie aucune ligne existante.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS patches (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    version VARCHAR(10) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 0,
    release_date DATE NULL,
    description VARCHAR(500) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_patches_version (version),
    INDEX idx_patches_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO patches (version, is_active, release_date, description)
VALUES ('7.2e', 1, NULL, 'Patch actif à la mise en place de la gestion des patchs.')
ON DUPLICATE KEY UPDATE version = version;
