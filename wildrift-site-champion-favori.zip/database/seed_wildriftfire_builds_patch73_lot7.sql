-- ============================================================
-- Lot 7 — Builds patch 7.3 — source WildRiftFire.com
-- Champions : Warwick, Xin Zhao (2 champions seulement)
-- (fin du rôle jungle : Wukong est écarté, sa fiche WildRiftFire
-- affiche encore "Patch 7.2e" ; Rek'Sai, Skarner et Viego, écartés au
-- lot 6, restent en 7.2e). Aucun autre champion n'est ajouté pour
-- compléter le lot.
-- À importer APRÈS schema.sql, seed_wildriftfire_builds.sql et les
-- lots 1 à 6. Aucune suppression, aucune modification de données
-- existantes hors ces 2 nouveaux builds. Relancer le fichier est
-- sans effet (idempotent).
--
-- Vérifié le 24/09/2026 : les 2 fiches affichent "Patch 7.3".
--
-- Écarts texte/liste : pour Warwick (Empowerment, Transcendence,
-- Sudden Impact cités dans le texte) et Xin Zhao (Legend: Bloodline
-- et Mortal Reminder/Serpent's Fang cités dans le texte), la liste des
-- 5 runes et le Final Build affichés font foi.
--
-- Objets situationnels déjà présents dans le Final Build (Guardian
-- Angel, Plated Steelcaps) : non dupliqués, ils restent 'core' ou
-- 'boots'. Xin Zhao : Goredrinker, 2e objet du bloc "Boots", repris en
-- 'core' en dernier (ordre 8), comme Nocturne et Pantheon au lot 5.
--
-- Limites conservées : sorts d'invocateur non importés (Flash/Smite),
-- runes situationnelles non importées. Ordre des compétences : seule la
-- priorité est donnée sur la page ; gabarit à 4/4/4 rangs (1 point par
-- niveau, 1 à 15, ultimes aux niveaux 5, 9 et 13).
--
-- Aucune nouvelle rune n'est créée ici : les runes absentes du
-- catalogue sont signalées par la vérification 3.
-- ============================================================

-- Builds
INSERT INTO builds (champion_id, name, role, patch, description, source)
SELECT id, 'Duelliste plongeon soutien', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Kraken Slayer, Blade of the Ruined King et Dusk and Dawn pour un duelliste à vitesse d''attaque qui se soigne, Terminus et Guardian Angel en fin de Final Build pour rester en vie pendant l''engage.',
       'WildRiftFire.com' FROM champions WHERE slug = 'warwick'
UNION ALL
SELECT id, 'Bruiser plongeon duelliste', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Trinity Force, Sundered Sky et Black Cleaver pour un duelliste résistant dès le début de partie, Death''s Dance, Guardian Angel et Goredrinker en fin de Final Build pour tenir en teamfight.',
       'WildRiftFire.com' FROM champions WHERE slug = 'xin-zhao'
ON DUPLICATE KEY UPDATE
    role = VALUES(role),
    patch = VALUES(patch),
    description = VALUES(description),
    source = VALUES(source);

-- Objets des builds
INSERT INTO build_items (build_id, item_id, slot, purchase_order, situation)
SELECT b.id, i.id, x.slot, x.purchase_order, x.situation
FROM (
    -- warwick
    SELECT 'warwick' AS champion_slug, 'Duelliste plongeon soutien' AS build_name, 'long-sword' AS item_slug, 'starting' AS slot, 1 AS purchase_order, NULL AS situation
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 'kraken-slayer', 'core', 2, NULL
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 'blade-of-the-ruined-king', 'core', 3, NULL
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 'dusk-and-dawn', 'core', 4, NULL
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 'berserkers-greaves', 'boots', 5, NULL
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 'terminus', 'core', 6, NULL
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 'guardian-angel', 'core', 7, NULL
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 'mercurial-scimitar', 'situational', NULL, 'vs Crowd Control'
    -- xin-zhao
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'trinity-force', 'core', 2, NULL
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'sundered-sky', 'core', 3, NULL
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'black-cleaver', 'core', 4, NULL
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'plated-steelcaps', 'boots', 5, NULL
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'deaths-dance', 'core', 6, NULL
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'guardian-angel', 'core', 7, NULL
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'goredrinker', 'core', 8, NULL
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'maw-of-malmortius', 'situational', NULL, 'vs Ability Power'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'mercurys-treads', 'situational', NULL, 'vs AP / CC'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN items i ON i.slug = x.item_slug
ON DUPLICATE KEY UPDATE purchase_order = VALUES(purchase_order), situation = VALUES(situation);

-- Runes des builds
INSERT INTO build_runes (build_id, rune_id, position)
SELECT b.id, r.id, x.position
FROM (
    -- warwick
    SELECT 'warwick' AS champion_slug, 'Duelliste plongeon soutien' AS build_name, 'lethal-tempo' AS rune_slug, 1 AS position
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 'axiom-arcanist', 2
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 'absolute-focus', 3
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 'nimbus-cloak', 4
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 'perseverance', 5
    -- xin-zhao
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'phase-rush', 1
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'triumph', 2
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'cut-down', 3
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'legend-bloodline', 4
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 'absolute-focus', 5
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN runes r ON r.slug = x.rune_slug
ON DUPLICATE KEY UPDATE position = VALUES(position);

-- Ordre des compétences (1 point par niveau, 1 à 15)
INSERT INTO build_skill_order (build_id, level, skill)
SELECT b.id, x.level, x.skill
FROM (
    -- warwick
    SELECT 'warwick' AS champion_slug, 'Duelliste plongeon soutien' AS build_name, 1 AS level, '1' AS skill
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 2, '3'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 3, '2'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 4, '1'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 5, 'ultimate'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 6, '1'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 7, '1'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 8, '3'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 9, 'ultimate'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 10, '3'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 11, '3'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 12, '2'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 13, 'ultimate'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 14, '2'
    UNION ALL SELECT 'warwick', 'Duelliste plongeon soutien', 15, '2'
    -- xin-zhao
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 1, '2'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 2, '3'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 3, '1'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 4, '2'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 5, 'ultimate'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 6, '2'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 7, '2'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 8, '3'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 9, 'ultimate'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 10, '3'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 11, '3'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 12, '1'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 13, 'ultimate'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 14, '1'
    UNION ALL SELECT 'xin-zhao', 'Bruiser plongeon duelliste', 15, '1'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
ON DUPLICATE KEY UPDATE skill = VALUES(skill);

-- ============================================================
-- Vérification (lecture seule) — à lancer après l'import
-- ============================================================

-- 1) Champions du lot absents de la table champions (doit être vide)
SELECT s.slug AS champion_manquant
FROM (
    SELECT 'warwick' AS slug
    UNION ALL SELECT 'xin-zhao'
) s
LEFT JOIN champions c ON c.slug = s.slug
WHERE c.id IS NULL;

-- 2) Objets référencés mais absents du catalogue (doit être vide)
SELECT s.slug AS objet_manquant
FROM (
    SELECT 'berserkers-greaves' AS slug
    UNION ALL SELECT 'black-cleaver'
    UNION ALL SELECT 'blade-of-the-ruined-king'
    UNION ALL SELECT 'deaths-dance'
    UNION ALL SELECT 'dusk-and-dawn'
    UNION ALL SELECT 'goredrinker'
    UNION ALL SELECT 'guardian-angel'
    UNION ALL SELECT 'kraken-slayer'
    UNION ALL SELECT 'long-sword'
    UNION ALL SELECT 'maw-of-malmortius'
    UNION ALL SELECT 'mercurial-scimitar'
    UNION ALL SELECT 'mercurys-treads'
    UNION ALL SELECT 'plated-steelcaps'
    UNION ALL SELECT 'sundered-sky'
    UNION ALL SELECT 'terminus'
    UNION ALL SELECT 'trinity-force'
) s
LEFT JOIN items i ON i.slug = s.slug
WHERE i.id IS NULL;

-- 3) Runes référencées mais absentes du catalogue (doit être vide)
SELECT s.slug AS rune_manquante
FROM (
    SELECT 'absolute-focus' AS slug
    UNION ALL SELECT 'axiom-arcanist'
    UNION ALL SELECT 'cut-down'
    UNION ALL SELECT 'legend-bloodline'
    UNION ALL SELECT 'lethal-tempo'
    UNION ALL SELECT 'nimbus-cloak'
    UNION ALL SELECT 'perseverance'
    UNION ALL SELECT 'phase-rush'
    UNION ALL SELECT 'triumph'
) s
LEFT JOIN runes r ON r.slug = s.slug
WHERE r.id IS NULL;

-- 4) Complétude des 2 builds 7.3 : attendu 7 (Warwick) ou 8 (Xin Zhao) objets hors situationnels,
--    5 runes, 15 niveaux de compétences
SELECT c.slug AS champion, b.name AS build, b.patch,
       (SELECT COUNT(*) FROM build_items bi WHERE bi.build_id = b.id AND bi.slot <> 'situational') AS objets_finaux,
       (SELECT COUNT(*) FROM build_items bi WHERE bi.build_id = b.id AND bi.slot = 'situational') AS objets_situationnels,
       (SELECT COUNT(*) FROM build_runes br WHERE br.build_id = b.id) AS runes,
       (SELECT COUNT(*) FROM build_skill_order bs WHERE bs.build_id = b.id) AS niveaux_competences
FROM builds b
INNER JOIN champions c ON c.id = b.champion_id
WHERE c.slug IN ('warwick', 'xin-zhao') AND b.patch = '7.3'
ORDER BY c.slug;

-- 5) Doublons éventuels (doit être vide)
SELECT champion_id, name, COUNT(*) AS n
FROM builds
WHERE patch = '7.3' AND champion_id IN (SELECT id FROM champions WHERE slug IN ('warwick', 'xin-zhao'))
GROUP BY champion_id, name
HAVING COUNT(*) > 1;

-- 6) Autres builds déjà en base pour ces 2 champions (anciens patchs,
--    conservés) : à comparer avec le 7.3 pour l'affichage
SELECT c.slug AS champion, b.name AS build, b.role, b.patch
FROM builds b
INNER JOIN champions c ON c.id = b.champion_id
WHERE c.slug IN ('warwick', 'xin-zhao')
ORDER BY c.slug, b.patch DESC, b.name;
