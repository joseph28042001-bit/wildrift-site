# Progression — builds WildRiftFire

Fichier alimenté par lots successifs dans `seed_wildriftfire_builds.sql`.
À importer après `schema.sql`.

## ✅ Traités (28 / 141)
- aatrox, ambessa, camille, chogath, dr-mundo, fiora, garen, gnar, gwen, irelia,
  jax, jayce, ksante, kayle, kennen, mordekaiser, nasus, ornn, poppy, renekton,
  riven, rumble, sett, shen, singed, sion, teemo, tryndamere (rôle baron)

Note Jayce/Kayle/Kennen/Tryndamere : le site WildRiftFire met en avant une
variante Mid ou Jungle par défaut pour ces champions, mais schema.sql les
classe en rôle 'baron' → on a repris leur variante Solo Lane à chaque fois,
pour rester cohérent avec l'appli. K'Sante, Mordekaiser, Poppy, Renekton,
Riven, Rumble, Sett, Shen, Singed, Sion et Teemo n'ont qu'un seul build sur
le site (ou on reprend le 1er build Solo Lane).

## ⏳ Restants (113)
Baron : urgot, volibear, yone

Jungle : amumu, diana, ekko, evelynn, fiddlesticks, gragas, graves, hecarim,
jarvan-iv, kayn, khazix, kindred, lee-sin(déjà fait), lillia, master-yi(déjà fait),
nidalee, nocturne, nunu-willump, olaf, pantheon, rammus, rengar, shyvana,
skarner, talon, vi, viego, warwick, wukong, xin-zhao

Mid : ahri(déjà fait), akali(déjà fait), akshan, annie, aurelion-sol, aurora,
fizz, galio, heimerdinger, kassadin, katarina, lissandra, lux, mel, norra,
orianna, ryze, swain, syndra, taliyah, twisted-fate, veigar, velkoz, vex,
viktor, vladimir, yasuo(déjà fait), zed, ziggs, zoe

Dragon (ADC) : ashe, caitlyn, corki, draven, ezreal, jhin, jinx(déjà fait),
kaisa, kalista, kogmaw, lucian, miss-fortune(déjà fait), nilah, samira, senna,
sivir, smolder, tristana, twitch, varus, vayne, xayah, yunara, zeri

Support : alistar, bard, blitzcrank, brand, braum, janna, karma, leona,
lulu(déjà fait), maokai, milio, morgana, nami, nautilus, pyke, rakan, rell,
seraphine, sona, soraka, thresh, yuumi, zilean, zyra

## Méthode (pour rester cohérent d'un lot à l'autre)
1. Fetch `https://www.wildriftfire.com/guide/<slug>`
2. Utiliser le 1er build listé (rôle recommandé), ignorer le build alternatif
3. items: starting / core / boots / (extras du "Final Build" non listés en
   situationnel → core) / situational (répartis dans build_items.slot)
4. runes: 5 runes listées (pas les situationnelles) → build_runes.position 1-5
5. skill order: déduit du "Quick Skill Order" (p1,p2,p3) via le patron générique :
   niv1-4:p1, 5:ult, 6:p1, 7-8:p2, 9:ult, 10-11:p2, 12:p3, 13:ult, 14-15:p3
6. Ajouter les items/runes manquants dans le fichier (INSERT ON DUPLICATE KEY)
   avant de les référencer dans build_items/build_runes
