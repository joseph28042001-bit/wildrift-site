-- ============================================================
-- Wild Rift Platform — schéma de base de données
-- Étape 1 : initialisation (app_meta uniquement).
-- Étape 7 : ajout des tables champions, items, runes puis builds (API REST).
-- Compatible MySQL 5.7+ / MariaDB (InfinityFree).
-- ============================================================

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS app_meta (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    meta_key VARCHAR(100) NOT NULL UNIQUE,
    meta_value TEXT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO app_meta (meta_key, meta_value)
VALUES ('schema_version', '0.7.0')
ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value);

-- ------------------------------------------------------------
-- Champions
-- 'role' correspond aux 5 rôles Wild Rift (baron/jungle/mid/
-- dragon/support) ; utilisé par le filtre /api/champions/?role=.
-- 'slug' est prévu pour de futures URLs propres (fiche champion),
-- non utilisé par l'API à cette étape (recherche/filtre par id/nom).
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS champions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(60) NOT NULL UNIQUE,
    name VARCHAR(60) NOT NULL,
    title VARCHAR(120) NULL,
    role ENUM('baron', 'jungle', 'mid', 'dragon', 'support') NOT NULL,
    difficulty TINYINT UNSIGNED NOT NULL DEFAULT 1,
    -- Niveau de contrôle de foule (CC) du kit du champion, indépendant
    -- du rôle (contrairement à la frontline) : saisi manuellement par
    -- champion, comme 'difficulty'. Utilisé par l'analyse CC de la
    -- Simulation 5v5 (voir pages/simulation.php / assets/js/simulation.js).
    cc_level ENUM('faible', 'moyen', 'fort') NOT NULL DEFAULT 'faible',
    -- Potentiel d'engagement (capacité à initier un combat) et de
    -- disengage (capacité à protéger/exfiltrer un allié ou se
    -- désengager), indépendants l'un de l'autre et du rôle — saisis
    -- manuellement par champion, même principe que cc_level. Utilisés
    -- par l'analyse engage/disengage de la Simulation 5v5 (voir
    -- pages/simulation.php / assets/js/simulation.js).
    engage_level ENUM('faible', 'moyen', 'fort') NOT NULL DEFAULT 'faible',
    disengage_level ENUM('faible', 'moyen', 'fort') NOT NULL DEFAULT 'faible',
    -- Puissance en early game / late game, indépendante l'une de
    -- l'autre et des autres échelles ci-dessus — saisies manuellement
    -- par champion, même principe que cc_level/engage_level. Utilisées
    -- par l'analyse Early Game / Late Game de la Simulation 5v5 (voir
    -- pages/simulation.php / assets/js/simulation.js).
    early_game_level ENUM('faible', 'moyen', 'fort') NOT NULL DEFAULT 'faible',
    late_game_level ENUM('faible', 'moyen', 'fort') NOT NULL DEFAULT 'faible',
    image_url VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_champions_role (role),
    INDEX idx_champions_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données complet des 141 champions actuels de Wild Rift (rôle,
-- difficulté, CC/engage/disengage/early/late game) — remplace le jeu de
-- données minimal precedent. À ajuster librement une fois l'admin
-- champions disponible (CRUD non encore développé).
INSERT INTO champions (slug, name, title, role, difficulty, cc_level, engage_level, disengage_level, early_game_level, late_game_level, image_url) VALUES
    ('aatrox', 'Aatrox', 'L''Épée des Ténèbres', 'baron', 2, 'faible', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('ambessa', 'Ambessa', NULL, 'baron', 3, 'moyen', 'fort', 'faible', 'fort', 'moyen', NULL),
    ('camille', 'Camille', 'L''Ombre d''acier', 'baron', 3, 'moyen', 'fort', 'faible', 'moyen', 'fort', NULL),
    ('chogath', 'Cho''Gath', 'La Terreur du Vide', 'baron', 2, 'fort', 'moyen', 'faible', 'faible', 'fort', NULL),
    ('darius', 'Darius', 'La main de Noxus', 'baron', 2, 'moyen', 'moyen', 'faible', 'fort', 'faible', NULL),
    ('dr-mundo', 'Dr. Mundo', 'Le Cinglé de Zaun', 'baron', 1, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('fiora', 'Fiora', 'La Grande Duelliste', 'baron', 3, 'faible', 'moyen', 'moyen', 'moyen', 'fort', NULL),
    ('garen', 'Garen', 'La Puissance de Demacia', 'baron', 1, 'faible', 'moyen', 'faible', 'moyen', 'moyen', NULL),
    ('gnar', 'Gnar', 'Le Chaînon manquant', 'baron', 3, 'fort', 'fort', 'faible', 'moyen', 'fort', NULL),
    ('gwen', 'Gwen', 'L''Enchantée', 'baron', 2, 'faible', 'faible', 'moyen', 'faible', 'fort', NULL),
    ('irelia', 'Irelia', 'La Danseuse des lames', 'baron', 3, 'moyen', 'moyen', 'moyen', 'moyen', 'fort', NULL),
    ('jax', 'Jax', 'Maître d''armes de Poteau de réverbère', 'baron', 2, 'faible', 'moyen', 'faible', 'faible', 'fort', NULL),
    ('jayce', 'Jayce', 'Le Défenseur du Futur', 'baron', 3, 'moyen', 'moyen', 'moyen', 'fort', 'moyen', NULL),
    ('ksante', 'K''Sante', 'L''Orgueil de Nazumah', 'baron', 3, 'fort', 'fort', 'moyen', 'faible', 'fort', NULL),
    ('kayle', 'Kayle', 'La Justicière ailée', 'baron', 2, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('kennen', 'Kennen', 'Le Coeur de la tempête', 'baron', 2, 'fort', 'fort', 'faible', 'moyen', 'moyen', NULL),
    ('malphite', 'Malphite', 'Le monolithe de la Faille', 'baron', 1, 'fort', 'fort', 'faible', 'moyen', 'moyen', NULL),
    ('mordekaiser', 'Mordekaiser', 'Le Seigneur de fer', 'baron', 2, 'faible', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('nasus', 'Nasus', 'Le Chien-garou du désert', 'baron', 1, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('ornn', 'Ornn', 'Le Feu sous la montagne', 'baron', 2, 'fort', 'fort', 'faible', 'moyen', 'fort', NULL),
    ('poppy', 'Poppy', 'La Gardienne du marteau', 'baron', 2, 'fort', 'moyen', 'fort', 'moyen', 'moyen', NULL),
    ('renekton', 'Renekton', 'Le Boucher des sables', 'baron', 2, 'moyen', 'fort', 'faible', 'fort', 'faible', NULL),
    ('riven', 'Riven', 'L''Exilée', 'baron', 3, 'moyen', 'fort', 'moyen', 'fort', 'moyen', NULL),
    ('rumble', 'Rumble', 'Le Terreur mécanique', 'baron', 2, 'moyen', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('sett', 'Sett', 'Le Chef incontesté', 'baron', 2, 'moyen', 'fort', 'faible', 'moyen', 'fort', NULL),
    ('shen', 'Shen', 'L''Œil du crépuscule', 'baron', 2, 'moyen', 'moyen', 'fort', 'faible', 'moyen', NULL),
    ('singed', 'Singed', 'Le Chimiste fou', 'baron', 2, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('sion', 'Sion', 'L''Incarnation de la terreur', 'baron', 2, 'fort', 'fort', 'faible', 'faible', 'fort', NULL),
    ('teemo', 'Teemo', 'L''Éclaireur agile', 'baron', 1, 'moyen', 'faible', 'faible', 'moyen', 'moyen', NULL),
    ('tryndamere', 'Tryndamere', 'Le Roi barbare', 'baron', 2, 'faible', 'moyen', 'faible', 'faible', 'fort', NULL),
    ('urgot', 'Urgot', 'Le Bourreau déchu', 'baron', 3, 'moyen', 'fort', 'faible', 'moyen', 'fort', NULL),
    ('volibear', 'Volibear', 'Le Tonnerre déchaîné', 'baron', 2, 'moyen', 'fort', 'faible', 'moyen', 'moyen', NULL),
    ('yone', 'Yone', 'Le fils de l''orage', 'baron', 3, 'moyen', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('amumu', 'Amumu', 'La Momie pleureuse', 'jungle', 1, 'fort', 'fort', 'faible', 'moyen', 'moyen', NULL),
    ('diana', 'Diana', 'L''Écho de Lune', 'jungle', 2, 'moyen', 'fort', 'faible', 'moyen', 'fort', NULL),
    ('ekko', 'Ekko', 'Le Frappeur du temps', 'jungle', 3, 'moyen', 'moyen', 'moyen', 'moyen', 'fort', NULL),
    ('evelynn', 'Evelynn', 'Agonie sans repos', 'jungle', 2, 'moyen', 'fort', 'faible', 'faible', 'fort', NULL),
    ('fiddlesticks', 'Fiddlesticks', 'L''Épouvantail Ancien', 'jungle', 2, 'fort', 'fort', 'faible', 'faible', 'fort', NULL),
    ('gragas', 'Gragas', 'L''Ivrogne bourru', 'jungle', 2, 'moyen', 'fort', 'moyen', 'moyen', 'moyen', NULL),
    ('graves', 'Graves', 'L''Homme de main', 'jungle', 2, 'faible', 'moyen', 'faible', 'fort', 'moyen', NULL),
    ('hecarim', 'Hecarim', 'L''Épouvante de guerre', 'jungle', 2, 'moyen', 'fort', 'faible', 'moyen', 'moyen', NULL),
    ('jarvan-iv', 'Jarvan IV', 'L''Exemple de Demacia', 'jungle', 2, 'moyen', 'fort', 'faible', 'fort', 'moyen', NULL),
    ('kayn', 'Kayn', 'Le Faucheur des Ombres', 'jungle', 3, 'faible', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('khazix', 'Kha''Zix', 'Le Fléau du Vide', 'jungle', 2, 'faible', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('kindred', 'Kindred', 'Les Éternels chasseurs', 'jungle', 2, 'faible', 'faible', 'faible', 'moyen', 'fort', NULL),
    ('lee-sin', 'Lee Sin', 'Le moine aveugle', 'jungle', 3, 'moyen', 'fort', 'moyen', 'fort', 'faible', NULL),
    ('lillia', 'Lillia', 'La Timide Faon', 'jungle', 2, 'moyen', 'moyen', 'faible', 'faible', 'fort', NULL),
    ('master-yi', 'Master Yi', 'L''épéiste wuju', 'jungle', 2, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('nidalee', 'Nidalee', 'La Chasseresse bestiale', 'jungle', 3, 'faible', 'moyen', 'faible', 'fort', 'faible', NULL),
    ('nocturne', 'Nocturne', 'L''Éternel Cauchemar', 'jungle', 2, 'moyen', 'fort', 'faible', 'moyen', 'fort', NULL),
    ('nunu-willump', 'Nunu & Willump', 'Le Garçon et son Yéti', 'jungle', 1, 'fort', 'fort', 'faible', 'moyen', 'moyen', NULL),
    ('olaf', 'Olaf', 'Le Berserker', 'jungle', 2, 'faible', 'moyen', 'faible', 'fort', 'moyen', NULL),
    ('pantheon', 'Pantheon', 'L''Esprit inébranlable', 'jungle', 2, 'moyen', 'fort', 'faible', 'fort', 'faible', NULL),
    ('rammus', 'Rammus', 'L''Armadillo blindé', 'jungle', 1, 'fort', 'fort', 'faible', 'moyen', 'moyen', NULL),
    ('rengar', 'Rengar', 'Le Chasseur féroce', 'jungle', 2, 'moyen', 'fort', 'faible', 'fort', 'faible', NULL),
    ('shyvana', 'Shyvana', 'La Demi-Dragonne', 'jungle', 1, 'faible', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('skarner', 'Skarner', 'L''Aiguillon de cristal', 'jungle', 2, 'fort', 'fort', 'faible', 'moyen', 'moyen', NULL),
    ('talon', 'Talon', 'La Lame ombreuse', 'jungle', 2, 'faible', 'moyen', 'faible', 'fort', 'faible', NULL),
    ('vi', 'Vi', 'La Pugiliste', 'jungle', 2, 'fort', 'fort', 'faible', 'moyen', 'moyen', NULL),
    ('viego', 'Viego', 'Le Roi ruiné', 'jungle', 3, 'moyen', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('warwick', 'Warwick', 'L''Ire incontrôlée de Zaun', 'jungle', 1, 'moyen', 'moyen', 'faible', 'moyen', 'moyen', NULL),
    ('wukong', 'Wukong', 'Le Roi Singe', 'jungle', 2, 'moyen', 'fort', 'faible', 'moyen', 'fort', NULL),
    ('xin-zhao', 'Xin Zhao', 'Le Sénéchal de Demacia', 'jungle', 1, 'moyen', 'fort', 'faible', 'fort', 'faible', NULL),
    ('ahri', 'Ahri', 'La renarde à neuf queues', 'mid', 2, 'moyen', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('akali', 'Akali', 'L''assassine solitaire', 'mid', 3, 'faible', 'moyen', 'faible', 'fort', 'moyen', NULL),
    ('akshan', 'Akshan', 'Le Flingueur Réprouvé', 'mid', 2, 'faible', 'faible', 'moyen', 'faible', 'fort', NULL),
    ('annie', 'Annie', 'L''Enfant obscure', 'mid', 1, 'fort', 'fort', 'faible', 'fort', 'moyen', NULL),
    ('aurelion-sol', 'Aurelion Sol', 'La Forge des étoiles', 'mid', 3, 'moyen', 'moyen', 'faible', 'faible', 'fort', NULL),
    ('aurora', 'Aurora', 'La Sorcière entre deux mondes', 'mid', 2, 'moyen', 'moyen', 'moyen', 'moyen', 'fort', NULL),
    ('fizz', 'Fizz', 'Le Fripon des marées', 'mid', 2, 'faible', 'moyen', 'moyen', 'moyen', 'fort', NULL),
    ('galio', 'Galio', 'Le Colosse', 'mid', 2, 'fort', 'fort', 'moyen', 'faible', 'fort', NULL),
    ('heimerdinger', 'Heimerdinger', 'Le Révérend Inventeur', 'mid', 2, 'moyen', 'faible', 'faible', 'fort', 'faible', NULL),
    ('kassadin', 'Kassadin', 'Le Marcheur du Vide', 'mid', 3, 'faible', 'moyen', 'moyen', 'faible', 'fort', NULL),
    ('katarina', 'Katarina', 'La Lame de Noxus', 'mid', 3, 'faible', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('lissandra', 'Lissandra', 'La Reine de glace', 'mid', 2, 'fort', 'fort', 'moyen', 'moyen', 'fort', NULL),
    ('lux', 'Lux', 'La Dame de lumière', 'mid', 2, 'moyen', 'faible', 'faible', 'moyen', 'fort', NULL),
    ('mel', 'Mel', NULL, 'mid', 2, 'faible', 'faible', 'faible', 'moyen', 'fort', NULL),
    ('norra', 'Norra', NULL, 'mid', 2, 'moyen', 'moyen', 'moyen', 'moyen', 'fort', NULL),
    ('orianna', 'Orianna', 'La Dame mécanique', 'mid', 3, 'moyen', 'fort', 'moyen', 'faible', 'fort', NULL),
    ('ryze', 'Ryze', 'Le Mage renégat', 'mid', 3, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('swain', 'Swain', 'Le Grand Général de Noxus', 'mid', 2, 'moyen', 'moyen', 'faible', 'faible', 'fort', NULL),
    ('syndra', 'Syndra', 'La Souveraine sombre', 'mid', 2, 'moyen', 'faible', 'faible', 'moyen', 'fort', NULL),
    ('taliyah', 'Taliyah', 'La Tisseuse de pierre', 'mid', 2, 'moyen', 'moyen', 'moyen', 'moyen', 'fort', NULL),
    ('twisted-fate', 'Twisted Fate', 'Le Baladin des cartes', 'mid', 2, 'faible', 'moyen', 'faible', 'faible', 'fort', NULL),
    ('veigar', 'Veigar', 'Le Petit Maître du mal', 'mid', 1, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('velkoz', 'Vel''Koz', 'L''Œil du Vide', 'mid', 2, 'moyen', 'faible', 'faible', 'moyen', 'fort', NULL),
    ('vex', 'Vex', 'Le Yordle Morose', 'mid', 2, 'faible', 'faible', 'faible', 'moyen', 'fort', NULL),
    ('viktor', 'Viktor', 'Le Héraut de l''ère machine', 'mid', 2, 'moyen', 'faible', 'faible', 'faible', 'fort', NULL),
    ('vladimir', 'Vladimir', 'Le Seigneur écarlate', 'mid', 2, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('yasuo', 'Yasuo', 'Le renégat', 'mid', 3, 'moyen', 'moyen', 'moyen', 'moyen', 'fort', NULL),
    ('zed', 'Zed', 'Le Maître de l''ombre', 'mid', 3, 'faible', 'moyen', 'faible', 'fort', 'moyen', NULL),
    ('ziggs', 'Ziggs', 'L''Artificier hexplosif', 'mid', 1, 'moyen', 'faible', 'faible', 'moyen', 'fort', NULL),
    ('zoe', 'Zoe', 'La Fille cosmique', 'mid', 2, 'moyen', 'moyen', 'faible', 'fort', 'moyen', NULL),
    ('ashe', 'Ashe', 'L''Archère de glace', 'dragon', 1, 'fort', 'moyen', 'faible', 'moyen', 'moyen', NULL),
    ('caitlyn', 'Caitlyn', 'Le Shérif de Piltover', 'dragon', 2, 'moyen', 'faible', 'faible', 'fort', 'moyen', NULL),
    ('corki', 'Corki', 'L''As téméraire', 'dragon', 2, 'faible', 'faible', 'faible', 'moyen', 'moyen', NULL),
    ('draven', 'Draven', 'Le Bourreau glorieux', 'dragon', 3, 'faible', 'faible', 'faible', 'fort', 'faible', NULL),
    ('ezreal', 'Ezreal', 'L''Explorateur prodige', 'dragon', 2, 'faible', 'faible', 'moyen', 'moyen', 'fort', NULL),
    ('jhin', 'Jhin', 'Le Virtuose', 'dragon', 2, 'moyen', 'faible', 'faible', 'moyen', 'fort', NULL),
    ('jinx', 'Jinx', 'La détraquée survoltée', 'dragon', 2, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('kaisa', 'Kai''Sa', 'La Fille du Vide', 'dragon', 2, 'faible', 'moyen', 'faible', 'faible', 'fort', NULL),
    ('kalista', 'Kalista', 'L''Esprit de la vengeance', 'dragon', 3, 'faible', 'faible', 'moyen', 'moyen', 'fort', NULL),
    ('kogmaw', 'Kog''Maw', 'La Bouche du Vide', 'dragon', 1, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('lucian', 'Lucian', 'Le Chasseur purificateur', 'dragon', 2, 'faible', 'moyen', 'faible', 'fort', 'moyen', NULL),
    ('miss-fortune', 'Miss Fortune', 'La chasseuse de primes', 'dragon', 1, 'faible', 'faible', 'faible', 'moyen', 'fort', NULL),
    ('nilah', 'Nilah', 'La Joie insaisissable', 'dragon', 3, 'faible', 'moyen', 'moyen', 'moyen', 'fort', NULL),
    ('samira', 'Samira', 'La Rose du désert', 'dragon', 3, 'faible', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('senna', 'Senna', 'La Rédemptrice', 'dragon', 2, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('sivir', 'Sivir', 'La Maîtresse des lames', 'dragon', 1, 'faible', 'faible', 'moyen', 'moyen', 'moyen', NULL),
    ('smolder', 'Smolder', 'Le Prince né du feu', 'dragon', 2, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('tristana', 'Tristana', 'La Tireuse d''élite', 'dragon', 2, 'faible', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('twitch', 'Twitch', 'Le Rat des égouts', 'dragon', 2, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('varus', 'Varus', 'La Flèche du châtiment', 'dragon', 2, 'moyen', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('vayne', 'Vayne', 'La Traqueuse de la nuit', 'dragon', 3, 'faible', 'faible', 'faible', 'faible', 'fort', NULL),
    ('xayah', 'Xayah', 'La Rebelle', 'dragon', 2, 'moyen', 'moyen', 'faible', 'moyen', 'fort', NULL),
    ('yunara', 'Yunara', NULL, 'dragon', 2, 'faible', 'faible', 'faible', 'moyen', 'fort', NULL),
    ('zeri', 'Zeri', 'L''Étincelle de Zaun', 'dragon', 3, 'faible', 'faible', 'moyen', 'moyen', 'fort', NULL),
    ('alistar', 'Alistar', 'Le Minotaure', 'support', 1, 'fort', 'fort', 'moyen', 'moyen', 'moyen', NULL),
    ('bard', 'Bard', 'Le Vagabond épique', 'support', 3, 'moyen', 'moyen', 'moyen', 'faible', 'fort', NULL),
    ('blitzcrank', 'Blitzcrank', 'Le Golem à vapeur', 'support', 2, 'fort', 'fort', 'faible', 'moyen', 'faible', NULL),
    ('brand', 'Brand', 'La Vengeance ardente', 'support', 2, 'moyen', 'faible', 'faible', 'moyen', 'fort', NULL),
    ('braum', 'Braum', 'Le Coeur de la Freljord', 'support', 1, 'fort', 'moyen', 'fort', 'moyen', 'moyen', NULL),
    ('janna', 'Janna', 'La Furie des tempêtes', 'support', 2, 'moyen', 'faible', 'fort', 'faible', 'fort', NULL),
    ('karma', 'Karma', 'L''Illuminée', 'support', 2, 'moyen', 'faible', 'moyen', 'moyen', 'fort', NULL),
    ('leona', 'Leona', 'L''Aube radieuse', 'support', 1, 'fort', 'fort', 'faible', 'fort', 'moyen', NULL),
    ('lulu', 'Lulu', 'La fée magique', 'support', 1, 'fort', 'faible', 'fort', 'moyen', 'fort', NULL),
    ('maokai', 'Maokai', 'L''Arbre torturé', 'support', 2, 'fort', 'fort', 'faible', 'faible', 'moyen', NULL),
    ('milio', 'Milio', 'Le Gentil Cœur en feu', 'support', 1, 'faible', 'faible', 'fort', 'moyen', 'fort', NULL),
    ('morgana', 'Morgana', 'Les Larmes déchues', 'support', 2, 'fort', 'moyen', 'moyen', 'moyen', 'fort', NULL),
    ('nami', 'Nami', 'L''Appel des vagues', 'support', 2, 'fort', 'moyen', 'moyen', 'moyen', 'fort', NULL),
    ('nautilus', 'Nautilus', 'Le Titan des abysses', 'support', 2, 'fort', 'fort', 'faible', 'moyen', 'moyen', NULL),
    ('pyke', 'Pyke', 'L''Éventreur des quais', 'support', 3, 'moyen', 'fort', 'faible', 'fort', 'moyen', NULL),
    ('rakan', 'Rakan', 'Le Charmeur', 'support', 3, 'moyen', 'fort', 'moyen', 'moyen', 'moyen', NULL),
    ('rell', 'Rell', 'La Furie de fer', 'support', 2, 'fort', 'fort', 'faible', 'fort', 'faible', NULL),
    ('seraphine', 'Seraphine', 'L''Étoile montante de Zaun', 'support', 2, 'moyen', 'faible', 'moyen', 'faible', 'fort', NULL),
    ('sona', 'Sona', 'La Virtuose des cordes', 'support', 1, 'moyen', 'faible', 'moyen', 'faible', 'fort', NULL),
    ('soraka', 'Soraka', 'L''Enfant des étoiles', 'support', 1, 'faible', 'faible', 'fort', 'faible', 'fort', NULL),
    ('thresh', 'Thresh', 'Le Geôlier des âmes', 'support', 3, 'fort', 'fort', 'moyen', 'moyen', 'fort', NULL),
    ('yuumi', 'Yuumi', 'Le Compagnon magique', 'support', 2, 'faible', 'faible', 'moyen', 'faible', 'fort', NULL),
    ('zilean', 'Zilean', 'Le Gardien du temps', 'support', 2, 'faible', 'faible', 'fort', 'faible', 'fort', NULL),
    ('zyra', 'Zyra', 'L''Éveil de la nature', 'support', 2, 'fort', 'moyen', 'faible', 'moyen', 'fort', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name), title = VALUES(title), role = VALUES(role), difficulty = VALUES(difficulty), cc_level = VALUES(cc_level), engage_level = VALUES(engage_level), disengage_level = VALUES(disengage_level), early_game_level = VALUES(early_game_level), late_game_level = VALUES(late_game_level);

-- ------------------------------------------------------------
-- Capacités des champions (champion_abilities)
-- Un champion possède exactement 5 capacités : une passive puis les
-- 4 sorts actifs (Q/W/E/R), représentés par l'ENUM 'slot' — l'ordre de
-- définition de l'ENUM (passive, q, w, e, r) correspond à l'ordre
-- d'affichage naturel du kit et sert de tri par défaut (ORDER BY slot).
-- Contrainte unique (champion_id, slot) : un champion ne peut pas avoir
-- deux capacités sur le même emplacement — permet aussi un import
-- idempotent du jeu de données ci-dessous. ON DELETE CASCADE : supprimer
-- un champion retire proprement ses capacités, sans ligne orpheline.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS champion_abilities (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    champion_id INT UNSIGNED NOT NULL,
    slot ENUM('passive', 'q', 'w', 'e', 'r') NOT NULL,
    name VARCHAR(60) NOT NULL,
    description VARCHAR(255) NULL,
    image_url VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_champion_abilities_champion FOREIGN KEY (champion_id)
        REFERENCES champions (id) ON DELETE CASCADE,
    UNIQUE KEY uniq_champion_abilities_champion_slot (champion_id, slot),
    INDEX idx_champion_abilities_champion (champion_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données complet (les 5 capacités des 10 champions du jeu de
-- données minimal ci-dessus). champion_id résolu par sous-requête sur
-- le slug, pour rester indépendant de l'ordre d'auto-incrément des
-- champions — même principe que builds/build_items/build_runes plus bas.
INSERT INTO champion_abilities (champion_id, slot, name, description, image_url)
SELECT c.id, x.slot, x.name, x.description, NULL
FROM (
    -- Ahri
    SELECT 'ahri' AS champion_slug, 'passive' AS slot, 'Génie Vulpin' AS name,
           'Une partie des dégâts infligés aux champions par ses sorts lui rend des PV.' AS description
    UNION ALL SELECT 'ahri', 'q', 'Orbe Trompeur', 'Lance un orbe qui inflige des dégâts magiques à l''aller puis au retour.'
    UNION ALL SELECT 'ahri', 'w', 'Feu de Renard', 'Libère trois flammes qui verrouillent et poursuivent les ennemis proches.'
    UNION ALL SELECT 'ahri', 'e', 'Charme', 'Un projectile qui charme la cible touchée, la forçant à marcher vers elle.'
    UNION ALL SELECT 'ahri', 'r', 'Bond Spirituel', 'Se téléporte dans une direction en tirant des éclats sur les ennemis proches.'
    -- Akali
    UNION ALL SELECT 'akali', 'passive', 'Assassine des Ombres', 'Ses sorts marquent la cible ; toucher une cible marquée inflige des dégâts bonus.'
    UNION ALL SELECT 'akali', 'q', 'Cinq Lames Mortelles', 'Projette un éventail de lames devant elle, dégâts physiques.'
    UNION ALL SELECT 'akali', 'w', 'Voile Crépusculaire', 'Crée un nuage de fumée qui octroie invisibilité et vitesse à l''intérieur.'
    UNION ALL SELECT 'akali', 'e', 'Bond Ninja', 'Se propulse à travers la cible en lui infligeant des dégâts, peut être relancé.'
    UNION ALL SELECT 'akali', 'r', 'Rafale Fatale', 'Lance un kunai énergisé puis peut s''y téléporter en infligeant des dégâts.'
    -- Darius
    UNION ALL SELECT 'darius', 'passive', 'Hémorragie', 'Ses attaques et sorts infligent un saignement qui s''accumule sur la cible.'
    UNION ALL SELECT 'darius', 'q', 'Décimer', 'Un large coup de hache circulaire, dégâts renforcés sur le tranchant.'
    UNION ALL SELECT 'darius', 'w', 'Prise de Sang', 'Sa prochaine attaque inflige des dégâts et soigne selon les stacks de saignement.'
    UNION ALL SELECT 'darius', 'e', 'Attraction', 'Tire les ennemis vers lui avec le crochet de sa hache et les ralentit.'
    UNION ALL SELECT 'darius', 'r', 'Bras de Noxus', 'Tourne sur lui-même en infligeant des dégâts continus, exécute les cibles affaiblies.'
    -- Jinx
    UNION ALL SELECT 'jinx', 'passive', 'Adrénaline Débridée', 'Gagne une vitesse d''attaque et de déplacement massive après une élimination.'
    UNION ALL SELECT 'jinx', 'q', 'Passe à niveau !', 'Alterne entre sa minigun (vitesse d''attaque, portée) et son lance-roquettes (dégâts de zone).'
    UNION ALL SELECT 'jinx', 'w', 'Zap !', 'Tire une décharge électrique longue portée qui ralentit et inflige de lourds dégâts.'
    UNION ALL SELECT 'jinx', 'e', 'Piège Chomp-Chomp', 'Lance un piège qui immobilise le premier ennemi qui marche dessus.'
    UNION ALL SELECT 'jinx', 'r', 'Super Méga Mort-Fusée !', 'Tire une roquette longue portée, dégâts croissants avec la distance, exécute les cibles affaiblies.'
    -- Lee Sin
    UNION ALL SELECT 'lee-sin', 'passive', 'Force du Flux', 'Toucher avec un sort renforce sa prochaine attaque de base d''un effet bonus.'
    UNION ALL SELECT 'lee-sin', 'q', 'Sonde Sonique', 'Envoie une onde qui peut être relancée pour foncer sur l''ennemi touché.'
    UNION ALL SELECT 'lee-sin', 'w', 'Ondes de Choc', 'Envoie une balise de soin qui peut être relancée pour repousser les ennemis proches.'
    UNION ALL SELECT 'lee-sin', 'e', 'Balayage Tenace', 'Inflige des dégâts et révèle brièvement la cible touchée.'
    UNION ALL SELECT 'lee-sin', 'r', 'Coup du Dragon', 'Frappe la cible qui s''envole et percute les ennemis sur sa trajectoire.'
    -- Lulu
    UNION ALL SELECT 'lulu', 'passive', 'Pixie de compagnie', 'Pix tire un projectile supplémentaire à chaque attaque ou sort de Lulu.'
    UNION ALL SELECT 'lulu', 'q', 'Éclat Étincelant', 'Un projectile qui ralentit deux ennemis ou accélère deux alliés touchés.'
    UNION ALL SELECT 'lulu', 'w', 'Ensorcellement', 'Transforme un ennemi (désactive ses sorts) ou octroie bouclier et vitesse à un allié.'
    UNION ALL SELECT 'lulu', 'e', 'Aide, Pix !', 'Pix bondit sur une cible, inflige des dégâts à un ennemi ou protège un allié.'
    UNION ALL SELECT 'lulu', 'r', 'Bond Chevaleresque', 'Agrandit un allié (PV bonus, repousse les ennemis) ou rapetisse un ennemi.'
    -- Malphite
    UNION ALL SELECT 'malphite', 'passive', 'Peau de Granit', 'Octroie une armure bonus et réduit les dégâts des coups consécutifs.'
    UNION ALL SELECT 'malphite', 'q', 'Éclats de Pierre Acérés', 'Inflige des dégâts et réduit la vitesse d''attaque de la cible.'
    UNION ALL SELECT 'malphite', 'w', 'Bouclier de Terre', 'Armure passive bonus ; actif, un bouclier magique absorbe les dégâts.'
    UNION ALL SELECT 'malphite', 'e', 'Séisme', 'Inflige des dégâts continus en zone et augmente son armure pendant l''effet.'
    UNION ALL SELECT 'malphite', 'r', 'Choc Sismique', 'Fonce vers un point, inflige des dégâts et projette en l''air tous les ennemis touchés.'
    -- Master Yi
    UNION ALL SELECT 'master-yi', 'passive', 'Style Duraliste', 'Alterne deux styles d''attaque : dégâts vrais bonus ou soin.'
    UNION ALL SELECT 'master-yi', 'q', 'Frappe Alpha', 'Traverse plusieurs cibles en devenant brièvement inattaquable, inflige des dégâts.'
    UNION ALL SELECT 'master-yi', 'w', 'Méditation', 'Se soigne et réduit les dégâts subis pendant un court canal.'
    UNION ALL SELECT 'master-yi', 'e', 'Vitesse du Vent', 'Octroie une vitesse de déplacement et d''attaque bonus.'
    UNION ALL SELECT 'master-yi', 'r', 'Highlander', 'Octroie une vitesse d''attaque et de déplacement massive, immunité aux ralentissements.'
    -- Miss Fortune
    UNION ALL SELECT 'miss-fortune', 'passive', 'Amour Mortel', 'Sa première attaque contre une nouvelle cible inflige des dégâts bonus.'
    UNION ALL SELECT 'miss-fortune', 'q', 'Double Coup de Feu', 'Tire deux projectiles sur la même cible.'
    UNION ALL SELECT 'miss-fortune', 'w', 'Élan', 'Vitesse de déplacement passive près des ennemis ; actif, accélère un allié.'
    UNION ALL SELECT 'miss-fortune', 'e', 'Rafale de Munitions', 'Crée une zone conique qui ralentit et inflige des dégâts périodiques.'
    UNION ALL SELECT 'miss-fortune', 'r', 'Pluie de Balles', 'Canalise une rafale de balles infligeant des dégâts continus en cône.'
    -- Yasuo
    UNION ALL SELECT 'yasuo', 'passive', 'Flux Sans Faille', 'Accumule passivement des chances de coup critique ; un bouclier apparaît en se déplaçant.'
    UNION ALL SELECT 'yasuo', 'q', 'Tempête Déchirante', 'Un coup d''épée (tourbillon à distance) ; le troisième coup consécutif projette en l''air.'
    UNION ALL SELECT 'yasuo', 'w', 'Mur du Vent', 'Crée un mur bloquant tous les projectiles ennemis pendant un court instant.'
    UNION ALL SELECT 'yasuo', 'e', 'Fente', 'Fonce à travers un ennemi en lui infligeant des dégâts.'
    UNION ALL SELECT 'yasuo', 'r', 'Coup de Grâce', 'Projette en l''air tous les ennemis proches déjà aériens et fonce à travers eux.'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    description = VALUES(description);

-- ------------------------------------------------------------
-- Objets (items)
-- 'category' regroupe les objets par famille ; utilisé par le
-- filtre /api/items/?category=. 'price' est le coût en gold,
-- NULL pour un objet sans prix direct (récompense, etc.).
-- 'enchantment' a été ajoutée à la liste des catégories pour les
-- enchantements de bottes (voir build_items ci-dessous, slot
-- 'enchantment') : ce sont des objets à part entière en Wild Rift,
-- achetés après les bottes de base.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(60) NOT NULL UNIQUE,
    name VARCHAR(60) NOT NULL,
    category ENUM('attack', 'magic', 'defense', 'boots', 'jungle', 'consumable', 'enchantment') NOT NULL,
    price SMALLINT UNSIGNED NULL,
    description VARCHAR(255) NULL,
    image_url VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_items_category (category),
    INDEX idx_items_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données minimal pour développer/tester l'API sans attendre
-- l'admin de gestion des objets (à venir).
INSERT INTO items (slug, name, category, price, description, image_url) VALUES
    ('infinity-edge', 'Infinity Edge', 'attack', 3200, 'Dégâts d''attaque et chance de coup critique élevés.', NULL),
    ('blade-of-the-ruined-king', 'Blade of the Ruined King', 'attack', 3200, 'Vol de vie et dégâts basés sur les PV actuels de la cible.', NULL),
    ('rabadons-deathcap', 'Rabadon''s Deathcap', 'magic', 3200, 'Puissance magique très élevée, amplifiée en pourcentage.', NULL),
    ('zhonyas-hourglass', 'Zhonya''s Hourglass', 'magic', 3300, 'Puissance magique et invulnérabilité temporaire active.', NULL),
    ('thornmail', 'Thornmail', 'defense', 3000, 'Armure élevée et renvoi de dégâts aux attaquants.', NULL),
    ('warmogs-armor', 'Warmog''s Armor', 'defense', 3000, 'PV maximum très élevés et régénération accrue.', NULL),
    ('guardian-angel', 'Guardian Angel', 'defense', 3000, 'Armure et résurrection unique après la mort.', NULL),
    ('sorcerers-shoes', 'Sorcerer''s Shoes', 'boots', 1100, 'Vitesse de déplacement et pénétration magique.', NULL),
    ('boots-of-swiftness', 'Boots of Swiftness', 'boots', 1000, 'Vitesse de déplacement accrue, résistance au ralentissement.', NULL),
    ('stalkers-blade', 'Stalker''s Blade', 'jungle', 450, 'Objet de jungle : dégâts accrus contre les monstres.', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Objets supplémentaires nécessaires pour couvrir tous les slots d'un
-- build (voir build_items ci-dessous) : objets de départ (consommables)
-- et enchantements de bottes, absents du jeu de données minimal ci-dessus.
INSERT INTO items (slug, name, category, price, description, image_url) VALUES
    ('refillable-potion', 'Refillable Potion', 'consumable', 350, 'Potion de soin rechargeable en base, objet de départ classique.', NULL),
    ('stealth-ward', 'Stealth Ward', 'consumable', 75, 'Balise de vision invisible, objet de départ ou de contrôle de carte.', NULL),
    ('boots-enchantment-alacrity', 'Enchantement : Célérité', 'enchantment', 950, 'Enchantement de bottes : vitesse d''attaque et de déplacement bonus.', NULL),
    ('boots-enchantment-distortion', 'Enchantement : Distorsion', 'enchantment', 950, 'Enchantement de bottes : téléportation courte portée en sort actif.', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Objets de base (composants) nécessaires pour exprimer les recettes
-- ci-dessous (voir item_recipes) : les objets finaux du jeu de données
-- ci-dessus se combinent à partir de ces composants plus simples, eux
-- aussi des objets à part entière du catalogue (catégorie 'attack',
-- 'magic', 'defense', 'boots' ou 'jungle' selon le composant).
INSERT INTO items (slug, name, category, price, description, image_url) VALUES
    ('long-sword', 'Long Sword', 'attack', 300, 'Dégâts d''attaque de base, composant classique des objets offensifs.', NULL),
    ('bf-sword', 'B.F. Sword', 'attack', 1300, 'Dégâts d''attaque bruts très élevés, composant d''objets offensifs majeurs.', NULL),
    ('cloak-of-agility', 'Cloak of Agility', 'attack', 600, 'Chance de coup critique bonus, composant d''objets critiques.', NULL),
    ('recurve-bow', 'Recurve Bow', 'attack', 1000, 'Vitesse d''attaque bonus, composant d''objets d''attaque rapide.', NULL),
    ('vampiric-scepter', 'Vampiric Scepter', 'attack', 900, 'Vol de vie bonus, composant d''objets de sustain offensif.', NULL),
    ('amplifying-tome', 'Amplifying Tome', 'magic', 400, 'Puissance magique de base, composant classique des objets magiques.', NULL),
    ('blasting-wand', 'Blasting Wand', 'magic', 850, 'Puissance magique élevée, composant d''objets magiques puissants.', NULL),
    ('needlessly-large-rod', 'Needlessly Large Rod', 'magic', 1250, 'Puissance magique très élevée, composant des objets magiques ultimes.', NULL),
    ('cloth-armor', 'Cloth Armor', 'defense', 300, 'Armure de base, composant classique des objets défensifs.', NULL),
    ('chain-vest', 'Chain Vest', 'defense', 500, 'Armure élevée, composant d''objets défensifs contre les dégâts physiques.', NULL),
    ('bramble-vest', 'Bramble Vest', 'defense', 450, 'Armure et renvoi de dégâts, composant des objets anti-attaque.', NULL),
    ('ruby-crystal', 'Ruby Crystal', 'defense', 400, 'PV bonus, composant classique des objets défensifs.', NULL),
    ('giants-belt', 'Giant''s Belt', 'defense', 900, 'PV élevés, composant des objets de tank majeurs.', NULL),
    ('boots', 'Boots', 'boots', 500, 'Vitesse de déplacement de base, objet de départ pour toutes les bottes améliorées.', NULL),
    ('hunters-machete', 'Hunter''s Machete', 'jungle', 350, 'Dégâts accrus contre les monstres, objet de départ en jungle.', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Objets réels ajoutés à l'étape 21 pour aligner les builds sur les
-- guides actuels de WildRiftFire.com (patch 7.2e au moment de la
-- rédaction). Ces objets remplacent/complètent le jeu de données
-- minimal ci-dessus dans les builds mis à jour plus bas.
INSERT INTO items (slug, name, category, price, description, image_url) VALUES
    ('the-collector', 'The Collector', 'attack', 3000, 'Dégâts d''attaque et pénétration létale ; exécute les cibles sous 5% de PV.', NULL),
    ('magnetic-blaster', 'Magnetic Blaster', 'attack', 2600, 'Augmente la portée d''attaque et la vitesse d''attaque, idéal pour kiter.', NULL),
    ('mortal-reminder', 'Mortal Reminder', 'attack', 2700, 'Dégâts d''attaque et Grievous Wounds pour réduire le soin des cibles qui stackent les PV.', NULL),
    ('berserkers-greaves', 'Berserker''s Greaves', 'boots', 1100, 'Bottes offensives : vitesse d''attaque bonus.', NULL),
    ('galeforce', 'Galeforce', 'attack', 2900, 'Dégâts d''attaque et critique avec un dash actif vers une cible.', NULL),
    ('runaans-hurricane', 'Runaan''s Hurricane', 'attack', 2600, 'Fait tirer des flèches supplémentaires sur deux cibles proches.', NULL),
    ('lord-dominiks-regard', 'Lord Dominik''s Regard', 'attack', 2700, 'Pénétration d''armure croissante contre les cibles à PV élevés.', NULL),
    ('mercurial-scimitar', 'Mercurial Scimitar', 'attack', 3000, 'Résistance magique et purge active des contrôles de foule.', NULL),
    ('stridebreaker', 'Stridebreaker', 'attack', 3000, 'Dégâts d''attaque et PV avec un coup de zone actif qui ralentit.', NULL),
    ('steraks-gage', 'Sterak''s Gage', 'attack', 2700, 'PV bonus et bouclier d''attaque déclenché à PV critiques.', NULL),
    ('youmuus-ghostblade', 'Youmuu''s Ghostblade', 'attack', 2700, 'Dégâts d''attaque et vitesse de déplacement active pour roam plus vite.', NULL),
    ('trinity-force', 'Trinity Force', 'attack', 3300, 'Statistiques hybrides complètes avec un coup bonus après un sort.', NULL),
    ('seryldas-grudge', 'Serylda''s Grudge', 'attack', 2900, 'Pénétration d''armure et ralentissement appliqué par les sorts.', NULL),
    ('serpents-fang', 'Serpent''s Fang', 'attack', 2500, 'Réduit les boucliers ennemis à chaque coup, utile contre les enchanteurs.', NULL),
    ('guinsoos-rageblade', 'Guinsoo''s Rageblade', 'attack', 2700, 'Vitesse d''attaque croissante et dégâts magiques bonus sur chaque coup.', NULL),
    ('black-cleaver', 'Black Cleaver', 'attack', 2900, 'Dégâts d''attaque et réduction d''armure cumulable sur la cible.', NULL),
    ('deaths-dance', 'Death''s Dance', 'attack', 2700, 'Armure et report d''une partie des dégâts subis au lieu d''un coup direct.', NULL),
    ('wits-end', 'Wit''s End', 'attack', 2400, 'Dégâts magiques bonus au contact et résistance magique.', NULL),
    ('duskblade-of-draktharr', 'Duskblade of Draktharr', 'attack', 2700, 'Dégâts d''attaque et camouflage bref après avoir été hors de vue.', NULL),
    ('bloodthirster', 'Bloodthirster', 'attack', 3200, 'Dégâts d''attaque et vol de vie avec un bouclier qui stocke l''excédent de soin.', NULL),
    ('essence-reaver', 'Essence Reaver', 'attack', 2700, 'Dégâts d''attaque et régénération de mana basée sur les sorts touchés.', NULL),
    ('maw-of-malmortius', 'Maw of Malmortius', 'attack', 2700, 'Dégâts d''attaque et résistance magique avec un bouclier anti-burst magique.', NULL),
    ('ludens-echo', 'Luden''s Echo', 'magic', 2700, 'Puissance magique avec une décharge bonus qui rebondit sur les ennemis proches.', NULL),
    ('lich-bane', 'Lich Bane', 'magic', 2900, 'Puissance magique ; la prochaine attaque après un sort inflige des dégâts bonus.', NULL),
    ('infinity-orb', 'Infinity Orb', 'magic', 2700, 'Pénétration magique et puissance magique, dégâts bonus aux cibles affaiblies.', NULL),
    ('void-staff', 'Void Staff', 'magic', 2700, 'Puissance magique et forte pénétration magique en pourcentage.', NULL),
    ('oceanids-trident', 'Oceanid''s Trident', 'magic', 2500, 'Puissance magique et bouclier actif qui absorbe un pic de dégâts.', NULL),
    ('banshees-veil', 'Banshee''s Veil', 'magic', 2700, 'Puissance magique et bouclier bloquant le prochain sort ennemi subi.', NULL),
    ('ardent-censer', 'Ardent Censer', 'magic', 2400, 'PV et puissance magique ; soigner ou protéger un allié buffe ses dégâts.', NULL),
    ('harmonic-echo', 'Harmonic Echo', 'magic', 2400, 'PV et puissance magique ; les sorts sur les alliés infligent des dégâts bonus en zone.', NULL),
    ('redemption', 'Redemption', 'magic', 2400, 'PV et puissance magique avec un soin/dégât actif en zone à portée globale.', NULL),
    ('black-mist-scythe', 'Black Mist Scythe', 'magic', 700, 'Objet de départ support amélioré : or bonus par assist et vision.', NULL),
    ('knights-vow', 'Knight''s Vow', 'magic', 2400, 'Lie Lulu à un allié : elle prend une partie des dégâts qu''il subit.', NULL),
    ('mikaels-blessing', 'Mikael''s Blessing', 'magic', 2400, 'Soin actif qui purge aussi les contrôles de foule sur la cible.', NULL),
    ('spectral-sickle', 'Spectral Sickle', 'magic', 450, 'Objet de départ support : or bonus sur les assists et vision.', NULL),
    ('amaranths-twinguard', 'Amaranth''s Twinguard', 'defense', 2700, 'Armure et résistance magique, bonus renforcé en combat prolongé.', NULL),
    ('dead-mans-plate', 'Dead Man''s Plate', 'defense', 2900, 'PV et armure ; accumule de la vitesse de déplacement en se déplaçant.', NULL),
    ('force-of-nature', 'Force of Nature', 'defense', 2900, 'Résistance magique et vitesse de déplacement, PV bonus en subissant des dégâts magiques.', NULL),
    ('randuins-omen', 'Randuin''s Omen', 'defense', 2900, 'PV et armure avec un actif qui ralentit les ennemis proches.', NULL),
    ('iceborn-gauntlet', 'Iceborn Gauntlet', 'defense', 2700, 'PV et armure ; le prochain coup après un sort ralentit en zone.', NULL),
    ('frozen-heart', 'Frozen Heart', 'defense', 2700, 'Armure élevée et réduction de la vitesse d''attaque des ennemis proches.', NULL),
    ('boots-of-mana', 'Boots of Mana', 'boots', 1000, 'Bottes utilitaires : régénération de mana et réduction du coût des sorts.', NULL),
    ('plated-steelcaps', 'Plated Steelcaps', 'boots', 1100, 'Bottes défensives : réduction des dégâts d''attaque des champions ennemis.', NULL),
    ('mercurys-treads', 'Mercury''s Treads', 'boots', 1100, 'Bottes défensives : résistance magique et réduction des contrôles de foule.', NULL),
    ('gluttonous-greaves', 'Gluttonous Greaves', 'boots', 1100, 'Bottes offensives : vol de vie omnivore bonus.', NULL),
    ('ionian-boots-of-lucidity', 'Ionian Boots of Lucidity', 'boots', 1100, 'Bottes utilitaires : réduction des délais de récupération des sorts.', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- ------------------------------------------------------------
-- Recettes des objets (item_recipes)
-- Table de relation N-N réflexive sur `items` : un objet fini
-- (item_id) est composé d'un ou plusieurs objets composants
-- (component_item_id), chacun étant lui-même une ligne à part entière
-- de `items` (voir INSERT ci-dessus). Une ligne = un composant ; un
-- objet fini a autant de lignes que de composants dans sa recette.
-- Les objets sans recette (objets de départ, consommables, composants
-- de base eux-mêmes) n'ont simplement aucune ligne ici — cas valide,
-- pas une erreur (même principe que build_runes/build_items pour un
-- build sans rune ou sans objet associé).
-- ON DELETE CASCADE des deux côtés : supprimer un objet (fini ou
-- composant) retire proprement les lignes de recette associées, sans
-- ligne orpheline.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS item_recipes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    item_id INT UNSIGNED NOT NULL,
    component_item_id INT UNSIGNED NOT NULL,
    CONSTRAINT fk_item_recipes_item FOREIGN KEY (item_id)
        REFERENCES items (id) ON DELETE CASCADE,
    CONSTRAINT fk_item_recipes_component FOREIGN KEY (component_item_id)
        REFERENCES items (id) ON DELETE CASCADE,
    UNIQUE KEY uniq_item_recipes_item_component (item_id, component_item_id),
    INDEX idx_item_recipes_item (item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données minimal pour développer/tester l'API sans attendre
-- l'admin de gestion des objets (à venir). item_id et component_item_id
-- résolus par sous-requêtes sur le slug (voir plus haut, même principe
-- que build_items/champion_abilities), pour rester indépendants de
-- l'ordre d'auto-incrément. Seuls les objets finaux qui se construisent
-- réellement à partir de composants ont des lignes ici ; les
-- consommables (Refillable Potion, Stealth Ward) et les composants de
-- base eux-mêmes n'en ont pas.
INSERT INTO item_recipes (item_id, component_item_id)
SELECT i1.id, i2.id
FROM (
    SELECT 'infinity-edge' AS item_slug, 'bf-sword' AS component_slug
    UNION ALL SELECT 'infinity-edge', 'cloak-of-agility'
    UNION ALL SELECT 'blade-of-the-ruined-king', 'recurve-bow'
    UNION ALL SELECT 'blade-of-the-ruined-king', 'vampiric-scepter'
    UNION ALL SELECT 'rabadons-deathcap', 'needlessly-large-rod'
    UNION ALL SELECT 'rabadons-deathcap', 'blasting-wand'
    UNION ALL SELECT 'zhonyas-hourglass', 'needlessly-large-rod'
    UNION ALL SELECT 'zhonyas-hourglass', 'cloth-armor'
    UNION ALL SELECT 'thornmail', 'bramble-vest'
    UNION ALL SELECT 'thornmail', 'chain-vest'
    UNION ALL SELECT 'warmogs-armor', 'giants-belt'
    UNION ALL SELECT 'warmogs-armor', 'ruby-crystal'
    UNION ALL SELECT 'guardian-angel', 'chain-vest'
    UNION ALL SELECT 'guardian-angel', 'ruby-crystal'
    UNION ALL SELECT 'sorcerers-shoes', 'boots'
    UNION ALL SELECT 'boots-of-swiftness', 'boots'
    UNION ALL SELECT 'stalkers-blade', 'hunters-machete'
    UNION ALL SELECT 'boots-enchantment-alacrity', 'sorcerers-shoes'
    UNION ALL SELECT 'boots-enchantment-distortion', 'boots-of-swiftness'
) x
INNER JOIN items i1 ON i1.slug = x.item_slug
INNER JOIN items i2 ON i2.slug = x.component_slug
ON DUPLICATE KEY UPDATE item_id = VALUES(item_id);


-- ------------------------------------------------------------
-- Arbres de runes (rune_trees)
-- Table de référence pour les 5 arbres de runes Wild Rift : jusqu'ici
-- 'precision'/'domination'/'sorcery'/'resolve'/'inspiration' n'étaient
-- que les valeurs de l'ENUM runes.tree (voir ci-dessous), sans nom
-- affiché ni description propres — codés en dur côté front
-- (assets/js/runes.js). Cette table les fait exister comme de vraies
-- données : slug (mêmes valeurs que l'ENUM runes.tree, c'est ce qui les
-- relie — pas de clé étrangère, même principe que les jointures par
-- slug de champion_abilities/item_recipes), nom affiché en français et
-- description courte.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS rune_trees (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(60) NOT NULL,
    description VARCHAR(255) NULL,
    image_url VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données complet (les 5 arbres) : contrairement aux runes,
-- champions ou objets, il n'y a pas de sous-ensemble "minimal" possible
-- ici, l'ENUM runes.tree n'en admettant de toute façon pas d'autres.
INSERT INTO rune_trees (slug, name, description, image_url) VALUES
    ('precision', 'Précision', 'Arbre offensif centré sur les attaques de base soutenues : vitesse d''attaque, dégâts constants et récompenses de combat prolongé.', NULL),
    ('domination', 'Domination', 'Arbre offensif centré sur le burst et l''explosivité : dégâts bonus à l''engagement, idéal pour éliminer rapidement une cible.', NULL),
    ('sorcery', 'Sorcellerie', 'Arbre magique centré sur la puissance des sorts et la gestion du mana, pour les champions qui reposent sur leurs capacités.', NULL),
    ('resolve', 'Détermination', 'Arbre défensif centré sur les PV, les résistances et le soutien au combat rapproché, pour encaisser et protéger les alliés.', NULL),
    ('inspiration', 'Inspiration', 'Arbre utilitaire aux effets variés (or, objets, contrôle de zone), pour des styles de jeu non conventionnels.', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- ------------------------------------------------------------
-- Runes
-- 'tree' correspond aux 5 arbres de runes Wild Rift (precision/
-- domination/sorcery/resolve/inspiration) ; utilisé par le
-- filtre /api/runes/?tree=. 'slot' distingue la rune majeure
-- ("keystone", une seule par arbre) des runes mineures.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS runes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(60) NOT NULL UNIQUE,
    name VARCHAR(60) NOT NULL,
    tree ENUM('precision', 'domination', 'sorcery', 'resolve', 'inspiration') NOT NULL,
    slot ENUM('keystone', 'minor') NOT NULL DEFAULT 'minor',
    description VARCHAR(255) NULL,
    image_url VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_runes_tree (tree),
    INDEX idx_runes_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données minimal pour développer/tester l'API sans attendre
-- l'admin de gestion des runes (à venir).
INSERT INTO runes (slug, name, tree, slot, description, image_url) VALUES
    ('electrocute', 'Électrocution', 'domination', 'keystone', 'Inflige des dégâts bonus après avoir touché 3 attaques ou sorts.', NULL),
    ('dark-harvest', 'Moisson sombre', 'domination', 'keystone', 'Dégâts bonus contre les cibles à PV bas, s''amplifie en s''accumulant.', NULL),
    ('sudden-impact', 'Impact soudain', 'domination', 'minor', 'Pénétration létale/magique après un dash ou un camouflage.', NULL),
    ('press-the-attack', 'Attaque intensifiée', 'precision', 'keystone', 'Les attaques consécutives rendent la cible vulnérable.', NULL),
    ('conqueror', 'Conquérant', 'precision', 'keystone', 'Accumule des stacks au combat pour du soin/dégâts adaptatifs.', NULL),
    ('triumph', 'Triomphe', 'precision', 'minor', 'Soin et gain d''or bonus après une élimination.', NULL),
    ('summon-aery', 'Invocation d''Aery', 'sorcery', 'keystone', 'Un esprit inflige des dégâts ou octroie un bouclier.', NULL),
    ('arcane-comet', 'Comète arcanique', 'sorcery', 'keystone', 'Une comète inflige des dégâts bonus à distance.', NULL),
    ('manaflow-band', 'Bande d''afflux de mana', 'sorcery', 'minor', 'Mana maximum bonus après avoir touché un champion ennemi.', NULL),
    ('grasp-of-the-undying', 'Étreinte des morts-vivants', 'resolve', 'keystone', 'Dégâts et soin bonus au contact, PV max augmentés.', NULL),
    ('aftershock', 'Choc en retour', 'resolve', 'keystone', 'Résistances et dégâts de zone bonus après un contrôle de foule.', NULL),
    ('font-of-life', 'Fontaine de vie', 'resolve', 'minor', 'Les alliés soignent une cible affaiblie récemment touchée.', NULL),
    ('first-strike', 'Frappe préventive', 'inspiration', 'keystone', 'Dégâts et or bonus en touchant l''ennemi en premier.', NULL),
    ('glacial-augment', 'Augment glacial', 'inspiration', 'keystone', 'Crée un champ de glace ralentissant les ennemis.', NULL),
    ('magical-footwear', 'Chaussures magiques', 'inspiration', 'minor', 'Bottes gratuites après un certain temps de jeu.', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- ------------------------------------------------------------
-- Builds
-- Un build est rattaché à un champion (champion_id, clé étrangère
-- vers champions.id, ON DELETE CASCADE). 'role' est volontairement
-- distinct du rôle par défaut du champion (champions.role) : il
-- permet de décrire un build joué hors de son rôle habituel
-- (ex. Yasuo support). 'patch' est la version Wild Rift pour
-- laquelle le build est valable (ex. '5.2'). 'description' détaille
-- le build (stratégie, ordre d'objets...) ; 'source' identifie sa
-- provenance (ex. 'community', pseudo d'un créateur de contenu, URL).
-- Les deux sont NULL pour rester facultatifs tant que l'admin de
-- gestion des builds n'impose pas de les renseigner.
-- Contrainte unique (champion_id, name) : un même champion ne peut
-- pas avoir deux builds au nom identique — permet un import
-- idempotent du jeu de données ci-dessous.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS builds (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    champion_id INT UNSIGNED NOT NULL,
    name VARCHAR(80) NOT NULL,
    role ENUM('baron', 'jungle', 'mid', 'dragon', 'support') NOT NULL,
    patch VARCHAR(10) NOT NULL,
    description VARCHAR(500) NULL,
    source VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_builds_champion FOREIGN KEY (champion_id)
        REFERENCES champions (id) ON DELETE CASCADE,
    UNIQUE KEY uniq_builds_champion_name (champion_id, name),
    INDEX idx_builds_role (role),
    INDEX idx_builds_patch (patch)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données mis à jour à l'étape 21 : les 9 builds ci-dessous
-- reprennent désormais les objets réels des guides WildRiftFire.com
-- (patch 7.2e au moment de la rédaction) au lieu d'objets inventés ;
-- le nom de chaque build est conservé pour ne pas casser les liens
-- existants (build_items, favoris...), seuls role/description/source
-- et les objets associés (voir build_items plus bas) changent. Un
-- 10e build est ajouté pour Yasuo, qui n'en avait aucun jusqu'ici.
-- champion_id résolu par sous-requête sur le slug, pour rester
-- indépendant de l'ordre d'auto-incrément des champions.
INSERT INTO builds (champion_id, name, role, patch, description, source)
SELECT id, 'Carry critique full attaque', 'dragon', '7.2e',
       'Build ADC full attaque de WildRiftFire : The Collector puis Magnetic Blaster pour la portée, Mortal Reminder contre le soin adverse.',
       'WildRiftFire.com' FROM champions WHERE slug = 'jinx'
UNION ALL
SELECT id, 'Bot lane à gold rapide', 'dragon', '7.2d',
       'Build agressif de WildRiftFire : Duskblade puis The Collector pour snowball tôt, Lord Dominik''s Regard contre les cibles tanky.',
       'WildRiftFire.com' FROM champions WHERE slug = 'miss-fortune'
UNION ALL
SELECT id, 'One-shot burst magique', 'mid', '7.2e',
       'Build burst de WildRiftFire : Luden''s Echo pour le poke et le waveclear, Lich Bane pour amplifier l''auto après un sort, Rabadon''s Deathcap pour finir.',
       'WildRiftFire.com' FROM champions WHERE slug = 'ahri'
UNION ALL
SELECT id, 'Assassin full létalité', 'mid', '7.2e',
       'Build burst de WildRiftFire (rebaptisé, désormais AP et non létalité) : Infinity Orb puis Lich Bane pour le combo sort-auto, Rabadon''s Deathcap pour finir.',
       'WildRiftFire.com' FROM champions WHERE slug = 'akali'
UNION ALL
SELECT id, 'Bruiser off-tank Baron', 'baron', '7.2e',
       'Build Solo Lane de WildRiftFire : Stridebreaker pour coller aux cibles, Sterak''s Gage pour la survie, Amaranth''s Twinguard en combat prolongé.',
       'WildRiftFire.com' FROM champions WHERE slug = 'darius'
UNION ALL
SELECT id, 'Tank pur résistances', 'baron', '7.2e',
       'Build Solo Lane S+ de WildRiftFire : Iceborn Gauntlet pour pousser et ralentir en zone, Thornmail et Frozen Heart pour tenir la ligne.',
       'WildRiftFire.com' FROM champions WHERE slug = 'malphite'
UNION ALL
SELECT id, 'Jungle rapide full AD', 'jungle', '7.2e',
       'Build de WildRiftFire : Blade of the Ruined King puis Guinsoo''s Rageblade pour stacker la vitesse d''attaque et le vrai dégât de Wuju Style.',
       'WildRiftFire.com' FROM champions WHERE slug = 'master-yi'
UNION ALL
SELECT id, 'Diver bruiser jungle', 'jungle', '7.2e',
       'Build jungle de WildRiftFire (AD et non AP) : Youmuu''s Ghostblade pour roam vite, Trinity Force et Serylda''s Grudge pour coller et ralentir les cibles.',
       'WildRiftFire.com' FROM champions WHERE slug = 'lee-sin'
UNION ALL
SELECT id, 'Enchanteur soutien', 'support', '7.2e',
       'Build support de WildRiftFire : Ardent Censer pour buffer les dégâts après un soin/bouclier, Harmonic Echo et Redemption pour la survie d''équipe.',
       'WildRiftFire.com' FROM champions WHERE slug = 'lulu'
UNION ALL
SELECT id, 'Carry critique mi-voie', 'mid', '7.2e',
       'Build de WildRiftFire : Blade of the Ruined King puis Essence Reaver pour l''économie de mana, Mortal Reminder contre le soin adverse.',
       'WildRiftFire.com' FROM champions WHERE slug = 'yasuo'
ON DUPLICATE KEY UPDATE
    role = VALUES(role),
    patch = VALUES(patch),
    description = VALUES(description),
    source = VALUES(source);

-- ------------------------------------------------------------
-- Objets d'un build (build_items)
-- Table de relation N-N entre `builds` et `items` (les deux tables
-- existantes), avec trois colonnes de contexte propres à l'association :
--   - slot : rôle de l'objet dans CE build (starting = objets de départ,
--     core = objets principaux, boots = bottes, enchantment = enchantement
--     de bottes, situational = objets situationnels/alternatifs selon
--     la partie). Indépendant de items.category (qui classe l'objet
--     lui-même dans le catalogue général).
--   - purchase_order : position dans l'ordre d'achat conseillé, pour les
--     slots à ordre fixe (starting/boots/core/enchantment). NULL pour
--     'situational' : ce sont des alternatives, pas une étape figée de
--     l'ordre d'achat.
--   - situation : facultatif, même principe que counter_items.situation
--     ci-dessous (ex. Aatrox contre Mundo) — quand renseigné, précise
--     dans quel contexte prendre cet objet plutôt qu'un autre (menace
--     rencontrée, type de composition adverse...), pertinent
--     essentiellement pour le slot 'situational'. NULL tant qu'aucune
--     donnée réelle n'est disponible pour cet objet : pas de texte
--     inventé, voir pages/champion-build.php section 5 et
--     assets/js/champion-build.js::renderSituationalSection().
-- ON DELETE CASCADE des deux côtés : supprimer un build ou un objet
-- retire proprement les associations, sans ligne orpheline.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS build_items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    build_id INT UNSIGNED NOT NULL,
    item_id INT UNSIGNED NOT NULL,
    slot ENUM('starting', 'core', 'boots', 'enchantment', 'situational') NOT NULL,
    purchase_order SMALLINT UNSIGNED NULL,
    situation VARCHAR(255) NULL,
    CONSTRAINT fk_build_items_build FOREIGN KEY (build_id)
        REFERENCES builds (id) ON DELETE CASCADE,
    CONSTRAINT fk_build_items_item FOREIGN KEY (item_id)
        REFERENCES items (id) ON DELETE CASCADE,
    UNIQUE KEY uniq_build_items_build_item_slot (build_id, item_id, slot),
    INDEX idx_build_items_build (build_id),
    INDEX idx_build_items_slot (slot),
    INDEX idx_build_items_order (purchase_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données mis à jour à l'étape 21 : objets réels des guides
-- WildRiftFire.com pour chaque build (starting/core/boots repris tels
-- quels de la section "Item Build" du guide ; situational repris de
-- la section "Situational Items" du guide, qui précise déjà contre
-- quelle menace prendre chaque objet — voir la description du build
-- correspondant pour le "pourquoi"). Remplace intégralement l'ancien
-- jeu de données inventé : les anciens objets (Boots of Swiftness,
-- enchantements de bottes...) ne correspondent plus aux builds actuels
-- de ces champions et sont retirés au profit des objets réels.
-- build_id et item_id résolus par sous-requêtes (sur le nom de build +
-- slug du champion, et sur le slug d'objet) pour rester indépendants
-- de l'ordre d'auto-incrément. Les 10 builds ont désormais leurs
-- objets associés (Yasuo inclus, nouveau build).
DELETE bi FROM build_items bi
INNER JOIN builds b ON b.id = bi.build_id
INNER JOIN champions c ON c.id = b.champion_id
WHERE c.slug IN ('jinx', 'ahri', 'akali', 'darius', 'malphite', 'master-yi', 'lee-sin', 'lulu', 'miss-fortune', 'yasuo');

INSERT INTO build_items (build_id, item_id, slot, purchase_order)
SELECT b.id, i.id, x.slot, x.purchase_order
FROM (
    -- Jinx (dragon) — Carry critique full attaque
    SELECT 'jinx' AS champion_slug, 'Carry critique full attaque' AS build_name, 'long-sword' AS item_slug, 'starting' AS slot, 1 AS purchase_order
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 'the-collector', 'core', 2
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 'magnetic-blaster', 'core', 3
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 'mortal-reminder', 'core', 4
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 'berserkers-greaves', 'boots', 5
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 'lord-dominiks-regard', 'situational', NULL
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 'mercurial-scimitar', 'situational', NULL
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 'guardian-angel', 'situational', NULL
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 'infinity-edge', 'situational', NULL
    -- Ahri (mid) — One-shot burst magique
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 'amplifying-tome', 'starting', 1
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 'ludens-echo', 'core', 2
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 'lich-bane', 'core', 3
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 'rabadons-deathcap', 'core', 4
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 'boots-of-mana', 'boots', 5
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 'infinity-orb', 'situational', NULL
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 'oceanids-trident', 'situational', NULL
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 'banshees-veil', 'situational', NULL
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 'zhonyas-hourglass', 'situational', NULL
    -- Akali (mid) — Assassin full létalité (AP réel, cf. description du build)
    UNION ALL SELECT 'akali', 'Assassin full létalité', 'amplifying-tome', 'starting', 1
    UNION ALL SELECT 'akali', 'Assassin full létalité', 'infinity-orb', 'core', 2
    UNION ALL SELECT 'akali', 'Assassin full létalité', 'lich-bane', 'core', 3
    UNION ALL SELECT 'akali', 'Assassin full létalité', 'rabadons-deathcap', 'core', 4
    UNION ALL SELECT 'akali', 'Assassin full létalité', 'boots-of-mana', 'boots', 5
    UNION ALL SELECT 'akali', 'Assassin full létalité', 'void-staff', 'situational', NULL
    UNION ALL SELECT 'akali', 'Assassin full létalité', 'zhonyas-hourglass', 'situational', NULL
    UNION ALL SELECT 'akali', 'Assassin full létalité', 'oceanids-trident', 'situational', NULL
    UNION ALL SELECT 'akali', 'Assassin full létalité', 'banshees-veil', 'situational', NULL
    -- Darius (baron) — Bruiser off-tank Baron
    UNION ALL SELECT 'darius', 'Bruiser off-tank Baron', 'ruby-crystal', 'starting', 1
    UNION ALL SELECT 'darius', 'Bruiser off-tank Baron', 'stridebreaker', 'core', 2
    UNION ALL SELECT 'darius', 'Bruiser off-tank Baron', 'steraks-gage', 'core', 3
    UNION ALL SELECT 'darius', 'Bruiser off-tank Baron', 'amaranths-twinguard', 'core', 4
    UNION ALL SELECT 'darius', 'Bruiser off-tank Baron', 'plated-steelcaps', 'boots', 5
    UNION ALL SELECT 'darius', 'Bruiser off-tank Baron', 'force-of-nature', 'situational', NULL
    UNION ALL SELECT 'darius', 'Bruiser off-tank Baron', 'mortal-reminder', 'situational', NULL
    UNION ALL SELECT 'darius', 'Bruiser off-tank Baron', 'randuins-omen', 'situational', NULL
    UNION ALL SELECT 'darius', 'Bruiser off-tank Baron', 'mercurys-treads', 'situational', NULL
    -- Malphite (baron) — Tank pur résistances
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 'ruby-crystal', 'starting', 1
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 'iceborn-gauntlet', 'core', 2
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 'thornmail', 'core', 3
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 'frozen-heart', 'core', 4
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 'plated-steelcaps', 'boots', 5
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 'force-of-nature', 'situational', NULL
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 'amaranths-twinguard', 'situational', NULL
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 'randuins-omen', 'situational', NULL
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 'mercurys-treads', 'situational', NULL
    -- Master Yi (jungle) — Jungle rapide full AD
    UNION ALL SELECT 'master-yi', 'Jungle rapide full AD', 'long-sword', 'starting', 1
    UNION ALL SELECT 'master-yi', 'Jungle rapide full AD', 'blade-of-the-ruined-king', 'core', 2
    UNION ALL SELECT 'master-yi', 'Jungle rapide full AD', 'guinsoos-rageblade', 'core', 3
    UNION ALL SELECT 'master-yi', 'Jungle rapide full AD', 'black-cleaver', 'core', 4
    UNION ALL SELECT 'master-yi', 'Jungle rapide full AD', 'berserkers-greaves', 'boots', 5
    UNION ALL SELECT 'master-yi', 'Jungle rapide full AD', 'deaths-dance', 'situational', NULL
    UNION ALL SELECT 'master-yi', 'Jungle rapide full AD', 'guardian-angel', 'situational', NULL
    UNION ALL SELECT 'master-yi', 'Jungle rapide full AD', 'wits-end', 'situational', NULL
    UNION ALL SELECT 'master-yi', 'Jungle rapide full AD', 'mercurial-scimitar', 'situational', NULL
    -- Lee Sin (jungle) — Diver bruiser jungle (AD réel, cf. description du build)
    UNION ALL SELECT 'lee-sin', 'Diver bruiser jungle', 'long-sword', 'starting', 1
    UNION ALL SELECT 'lee-sin', 'Diver bruiser jungle', 'youmuus-ghostblade', 'core', 2
    UNION ALL SELECT 'lee-sin', 'Diver bruiser jungle', 'trinity-force', 'core', 3
    UNION ALL SELECT 'lee-sin', 'Diver bruiser jungle', 'seryldas-grudge', 'core', 4
    UNION ALL SELECT 'lee-sin', 'Diver bruiser jungle', 'gluttonous-greaves', 'boots', 5
    UNION ALL SELECT 'lee-sin', 'Diver bruiser jungle', 'serpents-fang', 'situational', NULL
    UNION ALL SELECT 'lee-sin', 'Diver bruiser jungle', 'guardian-angel', 'situational', NULL
    -- Lulu (support) — Enchanteur soutien
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 'spectral-sickle', 'starting', 1
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 'ardent-censer', 'core', 2
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 'harmonic-echo', 'core', 3
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 'redemption', 'core', 4
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 'ionian-boots-of-lucidity', 'boots', 5
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 'mikaels-blessing', 'situational', NULL
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 'knights-vow', 'situational', NULL
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 'black-mist-scythe', 'situational', NULL
    -- Miss Fortune (dragon) — Bot lane à gold rapide
    UNION ALL SELECT 'miss-fortune', 'Bot lane à gold rapide', 'long-sword', 'starting', 1
    UNION ALL SELECT 'miss-fortune', 'Bot lane à gold rapide', 'duskblade-of-draktharr', 'core', 2
    UNION ALL SELECT 'miss-fortune', 'Bot lane à gold rapide', 'the-collector', 'core', 3
    UNION ALL SELECT 'miss-fortune', 'Bot lane à gold rapide', 'lord-dominiks-regard', 'core', 4
    UNION ALL SELECT 'miss-fortune', 'Bot lane à gold rapide', 'gluttonous-greaves', 'boots', 5
    UNION ALL SELECT 'miss-fortune', 'Bot lane à gold rapide', 'mortal-reminder', 'situational', NULL
    UNION ALL SELECT 'miss-fortune', 'Bot lane à gold rapide', 'guardian-angel', 'situational', NULL
    UNION ALL SELECT 'miss-fortune', 'Bot lane à gold rapide', 'bloodthirster', 'situational', NULL
    UNION ALL SELECT 'miss-fortune', 'Bot lane à gold rapide', 'serpents-fang', 'situational', NULL
    -- Yasuo (mid) — Carry critique mi-voie (nouveau build)
    UNION ALL SELECT 'yasuo', 'Carry critique mi-voie', 'long-sword', 'starting', 1
    UNION ALL SELECT 'yasuo', 'Carry critique mi-voie', 'blade-of-the-ruined-king', 'core', 2
    UNION ALL SELECT 'yasuo', 'Carry critique mi-voie', 'essence-reaver', 'core', 3
    UNION ALL SELECT 'yasuo', 'Carry critique mi-voie', 'mortal-reminder', 'core', 4
    UNION ALL SELECT 'yasuo', 'Carry critique mi-voie', 'berserkers-greaves', 'boots', 5
    UNION ALL SELECT 'yasuo', 'Carry critique mi-voie', 'lord-dominiks-regard', 'situational', NULL
    UNION ALL SELECT 'yasuo', 'Carry critique mi-voie', 'guardian-angel', 'situational', NULL
    UNION ALL SELECT 'yasuo', 'Carry critique mi-voie', 'maw-of-malmortius', 'situational', NULL
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN items i ON i.slug = x.item_slug
ON DUPLICATE KEY UPDATE purchase_order = VALUES(purchase_order);


-- ------------------------------------------------------------
-- Runes d'un build (build_runes)
-- Table de relation N-N entre `builds` et `runes` (les deux tables
-- existantes). 'position' fixe l'ordre d'affichage de la page de runes
-- du build (1 = première rune choisie, typiquement la keystone de
-- l'arbre principal, puis les runes mineures). Le détail de chaque rune
-- (arbre, type keystone/mineure) est déjà porté par `runes` elle-même
-- (runes.tree, runes.slot) : pas de duplication ici.
-- ON DELETE CASCADE des deux côtés, comme pour build_items.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS build_runes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    build_id INT UNSIGNED NOT NULL,
    rune_id INT UNSIGNED NOT NULL,
    position TINYINT UNSIGNED NOT NULL,
    CONSTRAINT fk_build_runes_build FOREIGN KEY (build_id)
        REFERENCES builds (id) ON DELETE CASCADE,
    CONSTRAINT fk_build_runes_rune FOREIGN KEY (rune_id)
        REFERENCES runes (id) ON DELETE CASCADE,
    UNIQUE KEY uniq_build_runes_build_rune (build_id, rune_id),
    UNIQUE KEY uniq_build_runes_build_position (build_id, position),
    INDEX idx_build_runes_build (build_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données minimal pour développer/tester l'API sans attendre
-- l'admin de gestion des builds (à venir). Les 9 builds du jeu de
-- données ont désormais leurs runes associées ; build_id et rune_id
-- résolus par sous-requêtes pour rester indépendants de l'ordre
-- d'auto-incrément.
INSERT INTO build_runes (build_id, rune_id, position)
SELECT b.id, r.id, x.position
FROM (
    SELECT 'jinx' AS champion_slug, 'Carry critique full attaque' AS build_name, 'press-the-attack' AS rune_slug, 1 AS position
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 'triumph', 2
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 'sudden-impact', 3
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 'arcane-comet', 1
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 'manaflow-band', 2
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 'sudden-impact', 3
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 'aftershock', 1
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 'font-of-life', 2
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 'magical-footwear', 3
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 'summon-aery', 1
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 'manaflow-band', 2
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 'font-of-life', 3
    -- Miss Fortune (dragon) — Bot lane à gold rapide
    UNION ALL SELECT 'miss-fortune', 'Bot lane à gold rapide', 'first-strike', 1
    UNION ALL SELECT 'miss-fortune', 'Bot lane à gold rapide', 'triumph', 2
    UNION ALL SELECT 'miss-fortune', 'Bot lane à gold rapide', 'magical-footwear', 3
    -- Akali (mid) — Assassin full létalité
    UNION ALL SELECT 'akali', 'Assassin full létalité', 'electrocute', 1
    UNION ALL SELECT 'akali', 'Assassin full létalité', 'sudden-impact', 2
    UNION ALL SELECT 'akali', 'Assassin full létalité', 'triumph', 3
    -- Darius (baron) — Bruiser off-tank Baron
    UNION ALL SELECT 'darius', 'Bruiser off-tank Baron', 'conqueror', 1
    UNION ALL SELECT 'darius', 'Bruiser off-tank Baron', 'triumph', 2
    UNION ALL SELECT 'darius', 'Bruiser off-tank Baron', 'font-of-life', 3
    -- Master Yi (jungle) — Jungle rapide full AD
    UNION ALL SELECT 'master-yi', 'Jungle rapide full AD', 'conqueror', 1
    UNION ALL SELECT 'master-yi', 'Jungle rapide full AD', 'triumph', 2
    UNION ALL SELECT 'master-yi', 'Jungle rapide full AD', 'sudden-impact', 3
    -- Lee Sin (jungle) — Diver AP jungle
    UNION ALL SELECT 'lee-sin', 'Diver AP jungle', 'electrocute', 1
    UNION ALL SELECT 'lee-sin', 'Diver AP jungle', 'sudden-impact', 2
    UNION ALL SELECT 'lee-sin', 'Diver AP jungle', 'manaflow-band', 3
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN runes r ON r.slug = x.rune_slug
ON DUPLICATE KEY UPDATE position = VALUES(position);

-- ------------------------------------------------------------
-- Ordre des compétences d'un build (build_skill_order)
-- Un point de compétence par niveau (1 à 15, niveau max en Wild Rift),
-- rattaché au build (pas de FK vers une table "compétences" : Wild
-- Rift identifie les compétences par leur emplacement générique sur
-- l'interface — 1, 2, 3, ultimate — non par une table dédiée qui
-- n'existe pas dans ce schéma). Contrainte unique (build_id, level) :
-- un seul point monté par niveau et par build.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS build_skill_order (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    build_id INT UNSIGNED NOT NULL,
    level TINYINT UNSIGNED NOT NULL,
    skill ENUM('1', '2', '3', 'ultimate') NOT NULL,
    CONSTRAINT fk_build_skill_order_build FOREIGN KEY (build_id)
        REFERENCES builds (id) ON DELETE CASCADE,
    UNIQUE KEY uniq_build_skill_order_build_level (build_id, level),
    INDEX idx_build_skill_order_build (build_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données minimal : mêmes 4 builds, un point par niveau de 1 à 15.
-- build_id résolu par sous-requête, comme pour build_items/build_runes.
INSERT INTO build_skill_order (build_id, level, skill)
SELECT b.id, x.level, x.skill
FROM (
    SELECT 'jinx' AS champion_slug, 'Carry critique full attaque' AS build_name, 1 AS level, '1' AS skill
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 2, '1'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 3, '1'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 4, '1'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 5, 'ultimate'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 6, '1'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 7, '3'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 8, '3'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 9, 'ultimate'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 10, '3'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 11, '3'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 12, '2'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 13, 'ultimate'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 14, '2'
    UNION ALL SELECT 'jinx', 'Carry critique full attaque', 15, '2'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 1, '2'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 2, '2'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 3, '2'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 4, '2'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 5, 'ultimate'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 6, '2'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 7, '1'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 8, '1'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 9, 'ultimate'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 10, '1'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 11, '1'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 12, '3'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 13, 'ultimate'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 14, '3'
    UNION ALL SELECT 'ahri', 'One-shot burst magique', 15, '3'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 1, '3'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 2, '3'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 3, '3'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 4, '3'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 5, 'ultimate'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 6, '3'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 7, '1'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 8, '1'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 9, 'ultimate'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 10, '1'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 11, '1'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 12, '2'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 13, 'ultimate'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 14, '2'
    UNION ALL SELECT 'malphite', 'Tank pur résistances', 15, '2'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 1, '2'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 2, '2'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 3, '2'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 4, '2'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 5, 'ultimate'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 6, '2'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 7, '1'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 8, '1'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 9, 'ultimate'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 10, '1'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 11, '1'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 12, '3'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 13, 'ultimate'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 14, '3'
    UNION ALL SELECT 'lulu', 'Enchanteur soutien', 15, '3'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
ON DUPLICATE KEY UPDATE skill = VALUES(skill);

-- ------------------------------------------------------------
-- Counters (Matchups & counters)
-- Une ligne = un champion (counter_champion_id) qui contre un
-- autre champion (champion_id), tous deux clés étrangères vers
-- champions.id (ON DELETE CASCADE). 'explanation' est le texte
-- expliquant le contre (pas de lien vidéo, conformément à la
-- décision de retirer les liens YouTube de Matchups & Counters).
-- 'tips' contient les conseils pratiques pour jouer le matchup
-- (ex. timing, objets, positionnement), distincts de 'explanation'
-- qui explique seulement pourquoi le contre fonctionne.
-- 'difficulty' est facultatif (NULL autorisé) et prend l'une des
-- trois valeurs 'facile', 'moyen', 'difficile' — difficulté du
-- matchup pour le champion qui contre.
-- Contrainte unique (champion_id, counter_champion_id) : un même
-- couple contré/contreur ne peut apparaître qu'une fois — permet
-- un import idempotent du jeu de données ci-dessous.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS counters (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    champion_id INT UNSIGNED NOT NULL,
    counter_champion_id INT UNSIGNED NOT NULL,
    explanation VARCHAR(500) NULL,
    tips VARCHAR(500) NULL,
    difficulty ENUM('facile', 'moyen', 'difficile') NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_counters_champion FOREIGN KEY (champion_id)
        REFERENCES champions (id) ON DELETE CASCADE,
    CONSTRAINT fk_counters_counter_champion FOREIGN KEY (counter_champion_id)
        REFERENCES champions (id) ON DELETE CASCADE,
    UNIQUE KEY uniq_counters_pair (champion_id, counter_champion_id),
    INDEX idx_counters_champion (champion_id),
    INDEX idx_counters_counter_champion (counter_champion_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données minimal pour développer/tester l'API sans attendre
-- l'admin de gestion des counters (à venir). champion_id et
-- counter_champion_id résolus par sous-requête sur le slug, pour
-- rester indépendant de l'ordre d'auto-incrément des champions.
INSERT INTO counters (champion_id, counter_champion_id, explanation, tips, difficulty)
SELECT c1.id, c2.id,
       'Malphite engage sans risque grâce à ses résistances et peut interrompre le combo d''Ahri avant qu''elle ne stack ses charmes.',
       'Attendez qu''Ahri utilise Charme ou son dash avant d''engager avec Éclat rocheux, puis enchaînez immédiatement avec vos sbires pour la punir.',
       'moyen'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'malphite'
WHERE c1.slug = 'ahri'
UNION ALL
SELECT c1.id, c2.id,
       'Master Yi ignore les contrôles d''Akali grâce à Highlander et la surpasse en dégâts soutenus une fois son ultime actif.',
       'Évitez d''engager tant qu''Highlander n''est pas disponible ; achetez un objet anti-invisibilité pour contrer Ombre parfaite d''Akali.',
       'difficile'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'master-yi'
WHERE c1.slug = 'akali'
UNION ALL
SELECT c1.id, c2.id,
       'Malphite empêche Darius de stacker Hémorragie en le gardant à distance avec ses résistances et son contrôle de zone.',
       'Gardez vos sbires entre vous et Darius pour limiter les stacks d''Hémorragie, et n''engagez qu''avec Éclat rocheux prêt pour couper sa fuite.',
       'facile'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'malphite'
WHERE c1.slug = 'darius'
UNION ALL
SELECT c1.id, c2.id,
       'Yasuo bloque les tirs de Jinx avec son vent et referme rapidement la distance grâce à sa mobilité.',
       'Gardez vos distances et utilisez vos pièges/ralentissements avant qu''il ne dashe sur vous ; visez entre deux utilisations de son mur de vent.',
       'moyen'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'yasuo'
WHERE c1.slug = 'jinx'
UNION ALL
SELECT c1.id, c2.id,
       'Malphite punit les engagements de Lee Sin : ses résistances neutralisent les dégâts physiques et son ultime coupe la fuite.',
       'Laissez Lee Sin engager en premier avant de contre-engager avec votre ultime, ses combos perdent beaucoup d''impact face à vos résistances.',
       'moyen'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'malphite'
WHERE c1.slug = 'lee-sin'
ON DUPLICATE KEY UPDATE explanation = VALUES(explanation), tips = VALUES(tips);

-- ------------------------------------------------------------
-- Objets recommandés pour un matchup (counter_items)
-- Table de relation entre `counters` et `items` : les objets
-- conseillés pour contrer le champion adverse dans ce matchup
-- (ex. Aatrox contre Mundo → objets anti-Mundo). 'purchase_order'
-- est facultatif (ordre d'achat conseillé, NULL si sans ordre
-- particulier). 'situation' est également facultatif : quand
-- renseigné, l'objet est situationnel (à acheter seulement dans un
-- contexte précis — ex. l'adversaire prend de l'avance, une menace
-- particulière apparaît en face...) plutôt que systématique ; NULL
-- signifie un objet de base, recommandé dans toutes les parties de ce
-- matchup. ON DELETE CASCADE des deux côtés : supprimer un
-- counter ou un objet retire proprement les associations, sans
-- ligne orpheline.
-- Contrainte unique (counter_id, item_id) : un même objet ne peut
-- pas être recommandé deux fois pour le même matchup — permet un
-- import idempotent du jeu de données ci-dessous.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS counter_items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    counter_id INT UNSIGNED NOT NULL,
    item_id INT UNSIGNED NOT NULL,
    purchase_order SMALLINT UNSIGNED NULL,
    situation VARCHAR(255) NULL,
    CONSTRAINT fk_counter_items_counter FOREIGN KEY (counter_id)
        REFERENCES counters (id) ON DELETE CASCADE,
    CONSTRAINT fk_counter_items_item FOREIGN KEY (item_id)
        REFERENCES items (id) ON DELETE CASCADE,
    UNIQUE KEY uniq_counter_items_counter_item (counter_id, item_id),
    INDEX idx_counter_items_counter (counter_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données minimal pour développer/tester l'API sans attendre
-- l'admin de gestion des counters (à venir). counter_id et item_id
-- résolus par sous-requête sur les slugs de champions et l'ID du
-- counter (couple champion/counter_champion), pour rester
-- indépendant de l'ordre d'auto-incrément. Le 2e objet de chaque
-- matchup est renseigné comme situationnel (colonne 'situation'
-- non NULL), le 1er restant un objet de base (situation NULL).
INSERT INTO counter_items (counter_id, item_id, purchase_order, situation)
SELECT co.id, i.id, x.purchase_order, x.situation
FROM (
    SELECT 'ahri' AS champion_slug, 'malphite' AS counter_champion_slug, 'thornmail' AS item_slug, 1 AS purchase_order, NULL AS situation
    UNION ALL SELECT 'ahri', 'malphite', 'guardian-angel', 2, 'Si Malphite arrive à vous prendre en combo rapproché malgré vos résistances, pour survivre à l''engagement et repositionner votre burst.'
    UNION ALL SELECT 'akali', 'master-yi', 'guardian-angel', 1, NULL
    UNION ALL SELECT 'akali', 'master-yi', 'blade-of-the-ruined-king', 2, 'Si Master Yi prend une avance en objets et devient trop résistant pour votre burst seul, pour ajouter des dégâts sur la durée.'
    UNION ALL SELECT 'darius', 'malphite', 'thornmail', 1, NULL
    UNION ALL SELECT 'darius', 'malphite', 'warmogs-armor', 2, 'Si Malphite engage sur vous en priorité à chaque combat, pour augmenter vos PV bruts et durer plus longtemps face à ses dégâts en zone.'
    UNION ALL SELECT 'jinx', 'yasuo', 'boots-of-swiftness', 1, NULL
    UNION ALL SELECT 'jinx', 'yasuo', 'blade-of-the-ruined-king', 2, 'Si Yasuo esquive vos attaques avec Jet d''acier (E), pour profiter des dégâts en pourcentage et du vol de vie compensant les attaques manquées.'
    UNION ALL SELECT 'lee-sin', 'malphite', 'thornmail', 1, NULL
    UNION ALL SELECT 'lee-sin', 'malphite', 'warmogs-armor', 2, 'Si Malphite vous engage systématiquement en premier lors des combats de jungle, pour survivre à l''ouverture et rester utile après.'
) x
INNER JOIN champions c1 ON c1.slug = x.champion_slug
INNER JOIN champions c2 ON c2.slug = x.counter_champion_slug
INNER JOIN counters co ON co.champion_id = c1.id AND co.counter_champion_id = c2.id
INNER JOIN items i ON i.slug = x.item_slug
ON DUPLICATE KEY UPDATE purchase_order = VALUES(purchase_order), situation = VALUES(situation);

-- ------------------------------------------------------------
-- Synergies
-- Une ligne = un champion (synergy_champion_id) qui forme une bonne
-- synergie d'équipe avec un autre champion (champion_id), tous deux
-- clés étrangères vers champions.id (ON DELETE CASCADE). 'explanation'
-- décrit pourquoi la synergie fonctionne (combo, protection, mise en
-- place...), du point de vue de champion_id. Contrairement aux
-- counters, il n'y a pas de notion de difficulté ni d'objets
-- recommandés associés : une synergie est une simple relation
-- champion <-> champion avec son explication.
-- Contrainte unique (champion_id, synergy_champion_id) : un même
-- couple ne peut apparaître qu'une fois dans un sens donné — permet
-- un import idempotent du jeu de données ci-dessous. La relation
-- n'est pas automatiquement symétrique en base (comme pour les
-- counters) : chaque sens est une ligne distincte, avec sa propre
-- explication adaptée au point de vue du champion consulté.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS synergies (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    champion_id INT UNSIGNED NOT NULL,
    synergy_champion_id INT UNSIGNED NOT NULL,
    explanation VARCHAR(500) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_synergies_champion FOREIGN KEY (champion_id)
        REFERENCES champions (id) ON DELETE CASCADE,
    CONSTRAINT fk_synergies_synergy_champion FOREIGN KEY (synergy_champion_id)
        REFERENCES champions (id) ON DELETE CASCADE,
    UNIQUE KEY uniq_synergies_pair (champion_id, synergy_champion_id),
    INDEX idx_synergies_champion (champion_id),
    INDEX idx_synergies_synergy_champion (synergy_champion_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données minimal pour développer/tester l'API sans attendre
-- l'admin de gestion des synergies (à venir). champion_id et
-- synergy_champion_id résolus par sous-requête sur le slug, pour
-- rester indépendant de l'ordre d'auto-incrément des champions.
-- Chaque paire est renseignée dans les deux sens, avec une
-- explication propre à chaque point de vue.
INSERT INTO synergies (champion_id, synergy_champion_id, explanation)
SELECT c1.id, c2.id,
       'Lulu protège Jinx avec Bouclier fantastique et peut la propulser hors de danger, lui laissant tout le temps de déverser ses dégâts à distance.'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'lulu'
WHERE c1.slug = 'jinx'
UNION ALL
SELECT c1.id, c2.id,
       'Jinx offre à Lulu une carry capable de transformer chaque bouclier et chaque polymorphe en dégâts massifs sur la durée.'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'jinx'
WHERE c1.slug = 'lulu'
UNION ALL
SELECT c1.id, c2.id,
       'Malphite ouvre le combat avec Éclat rocheux qui regroupe l''équipe adverse, permettant à Yasuo de suivre avec Tempête d''acier pour un combo dévastateur.'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'malphite'
WHERE c1.slug = 'yasuo'
UNION ALL
SELECT c1.id, c2.id,
       'Yasuo transforme l''engagement groupé de Malphite en un ultime garanti, rendant la paire redoutable dès qu''un combat s''engage.'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'yasuo'
WHERE c1.slug = 'malphite'
UNION ALL
SELECT c1.id, c2.id,
       'Lee Sin peut engager à la place d''Akali et l''escorter avec Passe d''armes, la protégeant le temps qu''elle place son combo de burst.'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'lee-sin'
WHERE c1.slug = 'akali'
UNION ALL
SELECT c1.id, c2.id,
       'Akali profite des engagements et des peels de Lee Sin pour se concentrer uniquement sur l''exécution de son burst.'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'akali'
WHERE c1.slug = 'lee-sin'
UNION ALL
SELECT c1.id, c2.id,
       'Malphite peut engager sur la cible de Darius puis la maintenir à portée, le temps que ses stacks d''Hémorragie s''accumulent jusqu''à l''exécution.'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'malphite'
WHERE c1.slug = 'darius'
UNION ALL
SELECT c1.id, c2.id,
       'Darius profite des engagements de Malphite pour appliquer Hémorragie sans risque et conclure les combats groupés.'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'darius'
WHERE c1.slug = 'malphite'
UNION ALL
SELECT c1.id, c2.id,
       'Lulu accélère et soigne Master Yi pendant Highlander, lui permettant de traverser toute l''équipe adverse sans jamais ralentir.'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'lulu'
WHERE c1.slug = 'master-yi'
UNION ALL
SELECT c1.id, c2.id,
       'Master Yi devient un finisheur redoutable une fois porté par les soins et les boosts de vitesse de Lulu.'
FROM champions c1
INNER JOIN champions c2 ON c2.slug = 'master-yi'
WHERE c1.slug = 'lulu'
ON DUPLICATE KEY UPDATE explanation = VALUES(explanation);

-- ------------------------------------------------------------
-- Tier list
-- Une ligne = le classement d'un champion (champion_id, clé étrangère
-- vers champions.id, ON DELETE CASCADE) pour un rôle et un patch donnés
-- ('role' réutilise volontairement l'ENUM de champions.role, même choix
-- que builds.role). 'tier' est le rang du champion sur ce rôle, à ce
-- patch : 'S+' (le plus fort, au-dessus de 'S') à 'D' (le plus faible).
-- 'win_rate',
-- 'pick_rate' et 'ban_rate' sont des pourcentages facultatifs (NULL si
-- non renseignés). 'notes' est un commentaire libre et facultatif sur le
-- classement (ex. contexte d'un changement de tier).
-- Un même champion peut apparaître plusieurs fois : sur des rôles
-- différents (ex. un champion flexible), ou sur des patchs différents
-- (historique de son évolution dans la tier list) — d'où la contrainte
-- unique sur le triplet (champion_id, role, patch), pas seulement sur
-- champion_id, qui permet aussi un import idempotent du jeu de données
-- ci-dessous.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tier_list (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    champion_id INT UNSIGNED NOT NULL,
    role ENUM('baron', 'jungle', 'mid', 'dragon', 'support') NOT NULL,
    patch VARCHAR(10) NOT NULL,
    tier ENUM('S+', 'S', 'A', 'B', 'C', 'D') NOT NULL,
    win_rate DECIMAL(5,2) NULL,
    pick_rate DECIMAL(5,2) NULL,
    ban_rate DECIMAL(5,2) NULL,
    notes VARCHAR(500) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_tier_list_champion FOREIGN KEY (champion_id)
        REFERENCES champions (id) ON DELETE CASCADE,
    UNIQUE KEY uniq_tier_list_champion_role_patch (champion_id, role, patch),
    INDEX idx_tier_list_role (role),
    INDEX idx_tier_list_patch (patch),
    INDEX idx_tier_list_tier (tier)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données minimal pour développer/tester l'API sans attendre
-- l'admin de gestion de la tier list (à venir). champion_id résolu par
-- sous-requête sur le slug, pour rester indépendant de l'ordre
-- d'auto-incrément des champions. Couvre plusieurs rôles et deux patchs
-- (5.1 et 5.2) pour Yasuo, Jinx et Malphite, afin d'illustrer l'évolution
-- d'un classement d'un patch à l'autre (utile pour tester ?patch=).
INSERT INTO tier_list (champion_id, role, patch, tier, win_rate, pick_rate, ban_rate, notes)
SELECT id, 'baron', '5.2', 'S', 52.40, 18.30, 12.10,
       'Engage fiable et résistances élevées, incontournable en formation.'
FROM champions WHERE slug = 'malphite'
UNION ALL
SELECT id, 'baron', '5.1', 'A', 50.80, 15.60, 6.40, NULL
FROM champions WHERE slug = 'malphite'
UNION ALL
SELECT id, 'baron', '5.2', 'A', 51.10, 14.20, 8.50,
       'Toujours solide en lane mais moins prioritaire que Malphite.'
FROM champions WHERE slug = 'darius'
UNION ALL
SELECT id, 'jungle', '5.2', 'S+', 53.60, 21.70, 15.90,
       'Clear rapide et snowball difficile à arrêter une fois lancé.'
FROM champions WHERE slug = 'master-yi'
UNION ALL
SELECT id, 'jungle', '5.2', 'A', 50.20, 13.40, 9.80,
       'Ganks puissants mais demande une bonne exécution.'
FROM champions WHERE slug = 'lee-sin'
UNION ALL
SELECT id, 'mid', '5.2', 'A', 51.50, 16.90, 7.30,
       'Bon burst et mobilité, reste une valeur sûre en milieu.'
FROM champions WHERE slug = 'ahri'
UNION ALL
SELECT id, 'mid', '5.1', 'A', 52.90, 19.80, 22.10, NULL
FROM champions WHERE slug = 'yasuo'
UNION ALL
SELECT id, 'mid', '5.2', 'B', 49.30, 17.20, 24.50,
       'Affaibli par les derniers ajustements, reste jouable en main experte.'
FROM champions WHERE slug = 'yasuo'
UNION ALL
SELECT id, 'mid', '5.2', 'B', 48.70, 11.30, 10.20,
       'Demande une bonne maîtrise pour rentabiliser sa fenêtre de burst.'
FROM champions WHERE slug = 'akali'
UNION ALL
SELECT id, 'dragon', '5.1', 'A', 51.30, 14.90, 5.60, NULL
FROM champions WHERE slug = 'jinx'
UNION ALL
SELECT id, 'dragon', '5.2', 'S', 52.80, 20.10, 9.40,
       'Dégâts soutenus très élevés en fin de partie une fois son passif lancé.'
FROM champions WHERE slug = 'jinx'
UNION ALL
SELECT id, 'dragon', '5.2', 'A', 50.60, 12.70, 4.30,
       'Bon gold rapide en early game, tenue correcte sur toute la partie.'
FROM champions WHERE slug = 'miss-fortune'
UNION ALL
SELECT id, 'support', '5.2', 'S', 53.10, 15.40, 6.90,
       'Protection et soutien constants pour le carry, très recherché en solo queue.'
FROM champions WHERE slug = 'lulu'
ON DUPLICATE KEY UPDATE
    tier      = VALUES(tier),
    win_rate  = VALUES(win_rate),
    pick_rate = VALUES(pick_rate),
    ban_rate  = VALUES(ban_rate),
    notes     = VALUES(notes);

-- ------------------------------------------------------------
-- Actualités (news)
-- Une ligne = un article d'actualité du site (pas de lien avec les
-- champions ou une autre ressource : la table est autonome). 'category'
-- classe l'article par nature ('patch' pour les notes de mise à jour,
-- 'esport' pour la compétition, 'evenement' pour les événements en jeu à
-- durée limitée, 'communaute' pour le reste — créateurs de contenu,
-- sondages...). 'excerpt' est le résumé affiché en liste (aperçu court) ;
-- 'content' est le corps complet de l'article, affiché uniquement dans le
-- détail (à venir). 'published_at' est la date de publication éditoriale
-- (distincte de 'created_at', qui est la date d'écriture en base) : NULL
-- tant que l'article n'est pas publié, ce qui permettra plus tard de
-- distinguer les brouillons des articles publiés.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS news (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(80) NOT NULL UNIQUE,
    title VARCHAR(150) NOT NULL,
    excerpt VARCHAR(300) NULL,
    content TEXT NULL,
    category ENUM('patch', 'esport', 'evenement', 'communaute') NOT NULL DEFAULT 'communaute',
    image_url VARCHAR(255) NULL,
    published_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_news_category (category),
    INDEX idx_news_published_at (published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Jeu de données minimal pour développer/tester l'API sans attendre
-- l'admin de gestion des actualités (à venir).
INSERT INTO news (slug, title, excerpt, content, category, image_url, published_at) VALUES
    ('patch-5-2-notes', 'Notes de patch 5.2',
     'Rééquilibrages de la voie du Baron et ajustements sur plusieurs champions dragon.',
     'Le patch 5.2 rééquilibre plusieurs champions de la voie du Baron et ajuste les taux de gains observés en dragon lors du patch précédent. Détail complet des changements à venir.',
     'patch', NULL, '2026-06-01 10:00:00'),
    ('wild-rift-championship-revient', 'Le Wild Rift Championship revient ce mois-ci',
     'La compétition officielle reprend avec un nouveau format de phases de groupes.',
     'Le Wild Rift Championship reprend ce mois-ci avec un nouveau format de phases de groupes et des équipes venues de toutes les régions.',
     'esport', NULL, '2026-06-03 09:00:00'),
    ('evenement-anniversaire', 'Événement anniversaire : récompenses exclusives',
     'Connectez-vous chaque jour pendant l''événement pour débloquer des récompenses exclusives.',
     'Pour célébrer son anniversaire, Wild Rift propose un événement à durée limitée avec des récompenses de connexion quotidienne et des défis exclusifs.',
     'evenement', NULL, '2026-05-20 08:00:00'),
    ('rencontre-createurs-contenu', 'Rencontre avec les créateurs de contenu de la communauté',
     'Plusieurs créateurs partagent leurs astuces et leur vision du jeu.',
     'Un tour d''horizon des créateurs de contenu les plus actifs de la communauté, qui partagent leurs astuces de jeu et leurs champions favoris.',
     'communaute', NULL, '2026-05-15 14:30:00'),
    ('brouillon-notes-patch-5-3', 'Notes de patch 5.3 (à venir)',
     NULL, NULL, 'patch', NULL, NULL)
ON DUPLICATE KEY UPDATE
    title        = VALUES(title),
    excerpt      = VALUES(excerpt),
    content      = VALUES(content),
    category     = VALUES(category),
    published_at = VALUES(published_at);

-- ------------------------------------------------------------
-- Étape 21.1 : architecture Riot (réception uniquement).
-- Ces deux tables préparent le stockage des données provenant de
-- l'API Riot, SANS que l'API soit connectée à ce stade (aucun appel
-- réseau n'existe encore dans le projet — voir includes/riot/).
--
-- riot_raw_payloads : dépôt brut. Chaque ligne correspond à une
-- réponse Riot reçue pour une ressource donnée (ex. 'champion',
-- 'item'), stockée telle quelle en JSON (colonne 'payload'), avant
-- tout traitement. 'external_id' est l'identifiant tel que fourni par
-- Riot (peut différer du 'slug'/'id' interne du site) ; 'patch' permet
-- de conserver plusieurs versions d'une même ressource dans le temps.
-- 'processed_at' reste NULL tant que la ligne n'a pas encore été
-- rapprochée des tables métier (champions, items...) — ce
-- rapprochement fait l'objet d'une étape ultérieure, pas de celle-ci.
--
-- riot_sync_log : historique des tentatives de synchronisation
-- (une ligne par exécution), indépendant du contenu réellement reçu.
-- Permet de savoir plus tard quand une ressource a été synchronisée
-- pour la dernière fois et si elle a réussi.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS riot_raw_payloads (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    resource_type VARCHAR(60) NOT NULL,
    external_id VARCHAR(100) NULL,
    patch VARCHAR(20) NULL,
    payload LONGTEXT NOT NULL,
    fetched_at TIMESTAMP NULL,
    processed_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_riot_raw_payloads_resource (resource_type),
    INDEX idx_riot_raw_payloads_external (external_id),
    INDEX idx_riot_raw_payloads_patch (patch)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS riot_sync_log (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    resource_type VARCHAR(60) NOT NULL,
    status ENUM('pending', 'running', 'success', 'failed') NOT NULL DEFAULT 'pending',
    message TEXT NULL,
    started_at TIMESTAMP NULL,
    finished_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_riot_sync_log_resource (resource_type),
    INDEX idx_riot_sync_log_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Étape 22.1 : architecture WRChina.gg (réception uniquement).
-- Mêmes tables, mêmes colonnes et même principe que riot_raw_payloads
-- et riot_sync_log ci-dessus (étape 21.1), pour une future source de
-- données supplémentaire : WRChina.gg. Comme pour Riot à l'époque,
-- AUCUN appel réseau n'existe encore dans le projet pour cette source
-- (voir includes/wrchina/) — et, à la différence de Riot, aucune
-- méthode d'accès autorisée à WRChina.gg n'a même été identifiée à ce
-- jour (pas d'API publique documentée, pas d'export officiel). Ces
-- tables ne préparent donc que le stockage, sans aucune garantie
-- qu'une connexion réelle sera possible un jour.
--
-- wrchina_raw_payloads : dépôt brut, une ligne par réponse WRChina.gg
-- reçue pour une ressource donnée (ex. 'tier-list', 'builds'), stockée
-- telle quelle en JSON. 'processed_at' reste NULL tant que la ligne
-- n'a pas été rapprochée des tables métier — étape ultérieure.
--
-- wrchina_sync_log : historique des tentatives de synchronisation.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS wrchina_raw_payloads (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    resource_type VARCHAR(60) NOT NULL,
    external_id VARCHAR(100) NULL,
    patch VARCHAR(20) NULL,
    payload LONGTEXT NOT NULL,
    fetched_at TIMESTAMP NULL,
    processed_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_wrchina_raw_payloads_resource (resource_type),
    INDEX idx_wrchina_raw_payloads_external (external_id),
    INDEX idx_wrchina_raw_payloads_patch (patch)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wrchina_sync_log (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    resource_type VARCHAR(60) NOT NULL,
    status ENUM('pending', 'running', 'success', 'failed') NOT NULL DEFAULT 'pending',
    message TEXT NULL,
    started_at TIMESTAMP NULL,
    finished_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_wrchina_sync_log_resource (resource_type),
    INDEX idx_wrchina_sync_log_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Étape 22.2 : import des patchs WRChina (uniquement les patchs —
-- pas les builds, voir includes/wrchina/WrChinaPatchImporter.php).
--
-- wrchina_patches : une ligne par patch WRChina.gg importé, sous forme
-- déjà structurée (contrairement à wrchina_raw_payloads, qui ne garde
-- que du JSON brut non exploité). Colonnes demandées : numéro du
-- patch, nom (facultatif, pas toujours communiqué), date, statut,
-- source ('WRChina.gg' par défaut — permet d'ajouter d'autres sources
-- plus tard sans changer la structure), URL de la source, et date de
-- récupération (fetched_at, différente de created_at/updated_at qui
-- suivent le cycle de vie de la ligne en base).
--
-- patch_number est UNIQUE : c'est ce qui permet à
-- importWrChinaPatch() (voir includes/wrchina/WrChinaRepository.php)
-- d'éviter les doublons — un même patch_number met à jour la ligne
-- existante au lieu d'en créer une nouvelle.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS wrchina_patches (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patch_number VARCHAR(20) NOT NULL,
    patch_name VARCHAR(150) NULL,
    patch_date DATE NULL,
    status VARCHAR(30) NULL,
    source VARCHAR(100) NOT NULL DEFAULT 'WRChina.gg',
    source_url VARCHAR(255) NULL,
    fetched_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_wrchina_patches_number (patch_number),
    INDEX idx_wrchina_patches_date (patch_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Comptes utilisateurs.
-- Table uniquement : le traitement serveur (inscription, connexion,
-- déconnexion, remplissage de SESSION_USER_KEY, page profil) reste
-- hors périmètre de cette étape et dépend toujours de pages/register.php,
-- pages/login.php, logout.php et pages/profile.php.
--
-- Colonnes alignées sur les formulaires déjà en place :
-- - pseudo : 3 à 20 caractères, lettres/chiffres/underscore (voir
--   pages/register.php et pages/profile.php, même pattern navigateur).
-- - email : identifiant de connexion (pages/login.php).
-- - password_hash : sortie de password_hash() (voir PASSWORD_HASH_OPTIONS
--   dans config/security.php) ; jamais le mot de passe en clair.
-- - role : ENUM plutôt qu'une table de comptes admin séparée, pour
--   couvrir aussi bien la connexion publique (pages/login.php) que la
--   connexion administrateur (admin/pages/login.php), qui envisage
--   explicitement « une colonne de rôle sur `users` ».
-- - favorite_champion_id : champion favori choisi depuis la page Profil
--   (section "Champion favori"), affiché en arrière-plan du profil ;
--   NULL = aucun choix. ON DELETE SET NULL : si le champion est
--   supprimé, le compte reste et revient simplement sans favori.
--   Base déjà installée : voir database/migration_favorite_champion.sql.
-- - bio, avatar : champs éditables depuis la page Profil
--   (pages/profile.php), tailles alignées sur ses contraintes
--   (bio : maxlength 280 ; avatar : nom de fichier généré par
--   generateSafeUploadFilename(), pas le fichier lui-même).
--
-- Hors périmètre : la table de liaison pour les champions favoris
-- (ex. `user_favorite_champions`), évoquée dans pages/profile.php mais
-- non demandée à cette étape. Les builds favoris, en revanche, ont
-- désormais leur table de liaison ci-dessous (`user_favorite_builds`).
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pseudo VARCHAR(20) NOT NULL,
    email VARCHAR(190) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
    bio VARCHAR(280) NULL,
    avatar VARCHAR(255) NULL,
    favorite_champion_id INT UNSIGNED NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_users_favorite_champion FOREIGN KEY (favorite_champion_id)
        REFERENCES champions (id) ON DELETE SET NULL,
    UNIQUE KEY uniq_users_pseudo (pseudo),
    UNIQUE KEY uniq_users_email (email),
    INDEX idx_users_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Builds favoris d'un utilisateur (user_favorite_builds)
-- Table de relation N-N entre `users` et `builds` : un utilisateur
-- connecté peut marquer/retirer un build de ses favoris (voir la
-- section "Builds favoris" de pages/profile.php et son traitement
-- dans profile.php). ON DELETE CASCADE des deux côtés : supprimer un
-- compte ou un build retire proprement les favoris associés, sans
-- ligne orpheline. Contrainte unique (user_id, build_id) : un même
-- build ne peut pas être ajouté deux fois aux favoris d'un même
-- utilisateur (upsert idempotent depuis le formulaire de profil).
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_favorite_builds (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    build_id INT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_user_favorite_builds_user FOREIGN KEY (user_id)
        REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_user_favorite_builds_build FOREIGN KEY (build_id)
        REFERENCES builds (id) ON DELETE CASCADE,
    UNIQUE KEY uniq_user_favorite_builds (user_id, build_id),
    INDEX idx_user_favorite_builds_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Comptes administrateurs (espace d'administration, voir admin/).
-- Table dédiée, séparée de `users` (comptes publics) : contrairement à
-- la piste évoquée plus haut dans le commentaire de `users` (« colonne
-- de rôle sur users » pour couvrir aussi l'admin), une table à part a
-- été explicitement demandée pour cette étape — les deux espaces de
-- connexion (public/admin) restent ainsi complètement indépendants, y
-- compris leurs identifiants.
--
-- - email : identifiant de connexion (admin/pages/login.php), unique.
--   Pas de colonne "pseudo" séparée : contrairement aux comptes
--   publics, l'email EST l'identifiant ici (pas de nom affiché en
--   public à gérer pour un compte admin).
-- - password_hash : sortie de password_hash() (voir PASSWORD_HASH_OPTIONS
--   dans config/security.php) ; jamais le mot de passe en clair ;
--   vérifié avec password_verify() à la connexion (admin/login.php).
--
-- Pas d'auto-inscription (voir le commentaire d'en-tête de
-- admin/pages/login.php) : le seul moyen de créer un compte est le
-- script CLI scripts/create-admin.php (jamais accessible depuis le
-- navigateur, voir scripts/.htaccess).
--
-- Les autres pages admin (admin/index.php, admin/champions.php, etc.)
-- sont protégées par requireAdminSession() (voir admin/includes/auth.php),
-- qui s'appuie sur ADMIN_SESSION_KEY pour vérifier qu'une ligne de
-- cette table est bien à l'origine de la session en cours.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admins (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(190) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_admins_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Patchs (versions du jeu Wild Rift gérées par le site)
-- Une ligne par version : 7.2e, 7.3, 7.3a, 7.3b, etc.
--   - version : numéro du patch, tel qu'il est écrit dans le jeu.
--     VARCHAR(10), même taille et même format que builds.patch et
--     tier_list.patch, pour pouvoir les rapprocher plus tard. UNIQUE :
--     un patch n'existe qu'une seule fois.
--   - is_active : 1 = patch actif du site, 0 = inactif. Le site n'est
--     censé avoir qu'UN SEUL patch actif à la fois ; MySQL/MariaDB ne
--     permettent pas de l'imposer par une simple contrainte (sans
--     colonne générée, non disponible sur toutes les versions), donc la
--     bascule d'un patch à l'autre doit désactiver l'ancien et activer
--     le nouveau dans une même transaction (exemple dans
--     docs/mysql.md, section `patches`).
--   - release_date : date de sortie du patch (facultative : NULL tant
--     qu'elle n'est pas renseignée).
--   - description : note libre facultative.
--   - created_at / updated_at : gérés automatiquement par MySQL.
--
-- Distincte de `wrchina_patches` (informations de patch importées
-- depuis WRChina.gg) : cette table-ci est la liste des versions que le
-- site gère lui-même. builds.patch et tier_list.patch restent des
-- textes ; leur rattachement à cette table (colonne patch_id) est fait
-- par migration_patch_links.sql (voir la fin de schema.sql).
--
-- Le patch 7.2e est créé et actif. Le INSERT est volontairement sans
-- effet s'il existe déjà (ON DUPLICATE KEY UPDATE version = version) :
-- réimporter ce script ne réactive jamais 7.2e une fois qu'un autre
-- patch est devenu actif, et ne modifie aucune ligne existante.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS patches (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    version VARCHAR(10) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 0,
    release_date DATE NULL,
    description VARCHAR(500) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_patches_version (version),
    INDEX idx_patches_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO patches (version, is_active, release_date, description)
VALUES ('7.2e', 1, NULL, 'Patch actif à la mise en place de la gestion des patchs.')
ON DUPLICATE KEY UPDATE version = version;


-- ============================================================
-- Rattachement des données aux patchs (patch_id)
-- ============================================================
-- Suite de la table `patches` ci-dessus. Ajoute `patch_id` (NULL
-- autorisé, clé étrangère vers `patches`, ON DELETE SET NULL) sur :
-- champions, items, runes, builds, tier_list, counters, synergies.
-- Les tables enfants (champion_abilities, item_recipes, build_items,
-- build_runes, build_skill_order, counter_items) dépendent de leur
-- table parente et n'ont pas de colonne propre.
-- NULL = non rattaché à un patch précis (valable pour tous les patchs).
-- builds.patch et tier_list.patch (texte) restent la référence ;
-- patch_id les suit (bloc 3 ci-dessous, rejouable).
-- Ajouté ici, à la fin, pour ne modifier aucune définition de table
-- existante ; les mêmes instructions sont dans
-- database/migration_patch_links.sql (bases déjà en place).
-- Si des seeds (ex. seed_wildriftfire_builds.sql) sont importés APRÈS
-- ce fichier, rejouer migration_patch_links.sql pour rattacher les
-- nouveaux builds à leur patch.
-- ============================================================

-- 1) Versions déjà utilisées par les données existantes : chaque valeur
--    distincte de builds.patch / tier_list.patch qui n'existe pas encore
--    dans `patches` y est ajoutée, INACTIVE (le patch actif ne change pas).
INSERT INTO patches (version, is_active, release_date, description)
SELECT s.version, 0, NULL, 'Version reprise automatiquement des données existantes (builds / tier list).'
FROM (
    SELECT patch AS version FROM builds
    UNION
    SELECT patch AS version FROM tier_list
) s
LEFT JOIN patches p ON p.version = s.version
WHERE p.id IS NULL AND s.version <> '';

-- 2) Colonne `patch_id` (NULL autorisé) + index + clé étrangère, sur chaque
--    table à versionner. Ajoutée seulement si elle n'existe pas déjà
--    (rejouable). ON DELETE SET NULL : supprimer un patch ne supprime
--    jamais de données, la ligne perd simplement son rattachement.

-- champions
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE champions ADD COLUMN patch_id INT UNSIGNED NULL, ADD INDEX idx_champions_patch_id (patch_id), ADD CONSTRAINT fk_champions_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'champions'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- items
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE items ADD COLUMN patch_id INT UNSIGNED NULL, ADD INDEX idx_items_patch_id (patch_id), ADD CONSTRAINT fk_items_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'items'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- runes
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE runes ADD COLUMN patch_id INT UNSIGNED NULL, ADD INDEX idx_runes_patch_id (patch_id), ADD CONSTRAINT fk_runes_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'runes'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- builds
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE builds ADD COLUMN patch_id INT UNSIGNED NULL AFTER patch, ADD INDEX idx_builds_patch_id (patch_id), ADD CONSTRAINT fk_builds_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'builds'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- tier_list
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE tier_list ADD COLUMN patch_id INT UNSIGNED NULL AFTER patch, ADD INDEX idx_tier_list_patch_id (patch_id), ADD CONSTRAINT fk_tier_list_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'tier_list'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- counters
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE counters ADD COLUMN patch_id INT UNSIGNED NULL, ADD INDEX idx_counters_patch_id (patch_id), ADD CONSTRAINT fk_counters_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'counters'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- synergies
SET @ddl = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE synergies ADD COLUMN patch_id INT UNSIGNED NULL, ADD INDEX idx_synergies_patch_id (patch_id), ADD CONSTRAINT fk_synergies_patch FOREIGN KEY (patch_id) REFERENCES patches (id) ON DELETE SET NULL',
        'DO 0'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'synergies'
      AND COLUMN_NAME = 'patch_id'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 3) Rattachement automatique de `builds` et `tier_list` : leur colonne
--    texte `patch` (inchangée) est la référence, `patch_id` la suit.
--    `updated_at = updated_at` évite que MySQL ne réécrive la date de
--    dernière modification de chaque ligne.

UPDATE builds t
INNER JOIN patches p ON p.version = t.patch
SET t.patch_id = p.id, t.updated_at = t.updated_at
WHERE t.patch_id IS NULL OR t.patch_id <> p.id;

UPDATE tier_list t
INNER JOIN patches p ON p.version = t.patch
SET t.patch_id = p.id, t.updated_at = t.updated_at
WHERE t.patch_id IS NULL OR t.patch_id <> p.id;

-- 4) Contrôle (lecture seule) : nombre de lignes par table et lignes
--    encore sans patch (`sans_patch`). Attendu : 0 pour builds et
--    tier_list ; les autres tables restent à NULL tant qu'aucun patch
--    ne leur est attribué (NULL = valable pour tous les patchs).
SELECT 'champions' AS table_name, COUNT(*) AS total, SUM(patch_id IS NULL) AS sans_patch FROM champions
UNION ALL SELECT 'items', COUNT(*), SUM(patch_id IS NULL) FROM items
UNION ALL SELECT 'runes', COUNT(*), SUM(patch_id IS NULL) FROM runes
UNION ALL SELECT 'builds', COUNT(*), SUM(patch_id IS NULL) FROM builds
UNION ALL SELECT 'tier_list', COUNT(*), SUM(patch_id IS NULL) FROM tier_list
UNION ALL SELECT 'counters', COUNT(*), SUM(patch_id IS NULL) FROM counters
UNION ALL SELECT 'synergies', COUNT(*), SUM(patch_id IS NULL) FROM synergies;
