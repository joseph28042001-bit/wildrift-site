-- ============================================================
-- Lot 2 — Builds patch 7.3 — source WildRiftFire.com
-- Champions : Ekko, Evelynn, Fiddlesticks, Gragas, Graves
-- (suite du rôle jungle après Amumu, Diana du lot 1).
-- À importer APRÈS schema.sql, seed_wildriftfire_builds.sql
-- ET seed_wildriftfire_builds_patch73_lot1.sql (complète les
-- objets/runes déjà présents plutôt que de les redéfinir).
--
-- Point bloquant conservé (voir méthode) : les sorts d'invocateur
-- de chaque build (Ekko : Flash/Smite ; Evelynn : Flash/Smite ;
-- Fiddlesticks : Flash/Smite ; Gragas : Flash/Smite ; Graves :
-- Flash/Smite) ne sont PAS importés ici, faute de colonne/table
-- pour les stocker — même limitation que le lot 1.
--
-- Ekko : le site met en avant la variante Mid Lane par défaut
-- (Tier A), avec une variante Jungle Build S en alternative. Comme
-- schema.sql classe Ekko en rôle 'jungle', on reprend la variante
-- Jungle (même principe que Jayce/Kayle/Kennen/Tryndamere au lot 1).
-- Sur la page, les sections Items/Runes affichées pour les deux
-- variantes sont strictement identiques ; seuls les sorts
-- d'invocateur diffèrent (Ignite en Mid vs Smite en Jungle), ce qui
-- n'a pas d'incidence sur les données importées ici.
--
-- Gragas : point d'attention — la balise <title> de la page
-- annonce encore "Patch 7.2e", mais le bandeau de patch affiché
-- sur la fiche du champion indique bien "Patch 7.3" (comme pour
-- tous les autres champions de ce lot). Les données de build ont
-- été reprises telles quelles depuis cette fiche ; à surveiller si
-- WildRiftFire republie une mise à jour Gragas dédiée au 7.3.
--
-- Items/Runes situationnels apparaissant aussi dans le Final
-- Build (ex. Infinity Orb pour Ekko/Evelynn, Zhonya's Hourglass
-- pour Gragas) : conservés en 'core' (ils font partie du Final
-- Build affiché), seuls les objets de remplacement propres à la
-- section "Situational Items" sont importés en 'situational' —
-- même convention que Diana au lot 1.
--
-- Point bloquant découvert en vérifiant ce lot (non corrigé ici,
-- hors périmètre des 5 champions demandés) : le lot 1 référence
-- dans build_items/build_runes plusieurs slugs jamais définis par
-- ses propres INSERT (items : 'sunfire-aegis' pour Amumu ; runes :
-- 'battle-zeal', 'brutal', 'demolish', 'last-stand', 'overgrowth',
-- 'perseverance', 'second-wind', 'transcendence', 'unshakeable').
-- Ces lignes sont silencieusement ignorées par les INNER JOIN du
-- lot 1 (aucune erreur SQL, mais les runes/objets correspondants
-- ne s'affichent pas). Les items/runes du présent lot 2 qui se
-- trouvaient être concernés par le même problème ('dusk-and-dawn',
-- 'chain-assault', 'eyeball-collector', 'legend-alacrity') sont
-- corrigés au passage puisqu'ils sont de toute façon nécessaires
-- ici ; les autres slugs listés ci-dessus restent à traiter dans
-- un correctif dédié au lot 1.
-- ============================================================

-- Nouveaux objets nécessaires (absents de schema.sql et des seeds existants)
INSERT INTO items (slug, name, category, price, description, image_url) VALUES
    ('dusk-and-dawn', 'Dusk and Dawn', 'magic', 2700, 'Puissance magique ; effet Lame enchantée ajoutant des dégâts bonus au prochain coup après un sort.', NULL),
    ('nashors-tooth', 'Nashor''s Tooth', 'magic', 2700, 'Puissance magique et vitesse d''attaque, dégâts magiques bonus sur les coups d''attaque.', NULL),
    ('stormsurge', 'Stormsurge', 'magic', 2900, 'Puissance magique ; vitesse de déplacement bonus après avoir affaibli un champion sous un seuil de PV.', NULL),
    ('hextech-rocketbelt', 'Hextech Rocketbelt', 'magic', 2600, 'Puissance magique et vitesse de déplacement ; effet actif de propulsion vers une zone ciblée.', NULL),
    ('malignance', 'Malignance', 'magic', 2800, 'Puissance magique et réduction des délais de récupération ; dégâts bonus contre les cibles sous contrôle de foule.', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Nouvelles runes nécessaires (Ekko, Evelynn, Fiddlesticks, Gragas, Graves)
INSERT INTO runes (slug, name, tree, slot, description, image_url) VALUES
    ('fleet-footwork', 'Bataille rangée', 'precision', 'keystone', 'Soin et vitesse de déplacement bonus déclenchés en enchaînant attaques et sorts.', NULL),
    ('hubris', 'Hybris', 'domination', 'keystone', 'Puissance/dégâts d''attaque bonus après une élimination, cumulable en combat.', NULL),
    ('eyeball-collector', 'Collectionneur de globes oculaires', 'domination', 'minor', 'Puissance ou dégâts d''attaque bonus permanents à chaque élimination ou assistance.', NULL),
    ('chain-assault', 'Assaut enchaîné', 'domination', 'minor', 'Dégâts bonus contre une cible récemment affligée d''un contrôle de foule.', NULL),
    ('axiom-arcanist', 'Arcaniste axiomatique', 'sorcery', 'keystone', 'Réduit le délai de récupération de la capacité ultime et augmente ses dégâts.', NULL),
    ('gathering-storm', 'Tempête grandissante', 'sorcery', 'minor', 'Puissance ou dégâts d''attaque bonus croissants au fil de la partie.', NULL),
    ('phase-rush', 'Ascension', 'sorcery', 'keystone', 'Vitesse de déplacement bonus et réduction des délais de récupération après 3 attaques/sorts sur une cible.', NULL),
    ('cut-down', 'Fauchage', 'precision', 'minor', 'Dégâts bonus contre les cibles ayant plus de PV maximum que soi.', NULL),
    ('legend-alacrity', 'Légende : célérité', 'precision', 'minor', 'Vitesse d''attaque bonus cumulable en prenant des éliminations/assistances ou du temps de jeu.', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Builds
INSERT INTO builds (champion_id, name, role, patch, description, source)
SELECT id, 'Assassin burst mobilité jungle', 'jungle', '7.3',
       'Build Jungle S de WildRiftFire : Dusk and Dawn et Nashor''s Tooth pour proc la passive Z-Drive Resonance, Rabadon''s Deathcap pour finir le burst, Void Staff et Infinity Orb en fin de Final Build contre les cibles résistantes/affaiblies.',
       'WildRiftFire.com' FROM champions WHERE slug = 'ekko'
UNION ALL
SELECT id, 'Assassin furtif burst AP', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Lich Bane et Stormsurge pour le combo sort-auto après une sortie de camouflage, Rabadon''s Deathcap pour le burst, Void Staff et Infinity Orb en fin de Final Build pour achever les cibles.',
       'WildRiftFire.com' FROM champions WHERE slug = 'evelynn'
UNION ALL
SELECT id, 'Assassin AP embuscade effroi', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Hextech Rocketbelt pour compenser le manque de mobilité, Malignance et Infinity Orb pour le burst à la sortie de Crowstorm, Rabadon''s Deathcap et Void Staff en fin de Final Build pour scaler.',
       'WildRiftFire.com' FROM champions WHERE slug = 'fiddlesticks'
UNION ALL
SELECT id, 'Bruiser AP contrôle de foule', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : Lich Bane pour le combo sort-auto après Body Slam/Barrel Roll, Rabadon''s Deathcap et Void Staff pour le scaling, Infinity Orb et Zhonya''s Hourglass en fin de Final Build pour sécuriser l''engagement.',
       'WildRiftFire.com' FROM champions WHERE slug = 'gragas'
UNION ALL
SELECT id, 'Marksman burst duelliste jungle', 'jungle', '7.3',
       'Build Jungle de WildRiftFire : The Collector et Immortal Shieldbow pour l''exécution et la survie, Lord Dominik''s Regard contre les cibles tanky, Infinity Edge/Bloodthirster/Galeforce en fin de Final Build pour le combat prolongé.',
       'WildRiftFire.com' FROM champions WHERE slug = 'graves'
ON DUPLICATE KEY UPDATE
    role = VALUES(role),
    patch = VALUES(patch),
    description = VALUES(description),
    source = VALUES(source);

-- Objets des builds
INSERT INTO build_items (build_id, item_id, slot, purchase_order, situation)
SELECT b.id, i.id, x.slot, x.purchase_order, x.situation
FROM (
    -- Ekko (jungle) — Assassin burst mobilité jungle
    SELECT 'ekko' AS champion_slug, 'Assassin burst mobilité jungle' AS build_name, 'amplifying-tome' AS item_slug, 'starting' AS slot, 1 AS purchase_order, NULL AS situation
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 'dusk-and-dawn', 'core', 2, NULL
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 'nashors-tooth', 'core', 3, NULL
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 'rabadons-deathcap', 'core', 4, NULL
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 'boots-of-mana', 'boots', 5, NULL
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 'void-staff', 'core', 6, NULL
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 'infinity-orb', 'core', 7, NULL
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 'oceanids-trident', 'situational', NULL, 'vs Shielding'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 'banshees-veil', 'situational', NULL, 'vs Crowd Control'
    -- Evelynn (jungle) — Assassin furtif burst AP
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'amplifying-tome', 'starting', 1, NULL
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'lich-bane', 'core', 2, NULL
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'stormsurge', 'core', 3, NULL
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'rabadons-deathcap', 'core', 4, NULL
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'boots-of-mana', 'boots', 5, NULL
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'void-staff', 'core', 6, NULL
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'infinity-orb', 'core', 7, NULL
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'oceanids-trident', 'situational', NULL, 'vs Shielding'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'banshees-veil', 'situational', NULL, 'vs Crowd Control'
    -- Fiddlesticks (jungle) — Assassin AP embuscade effroi
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'amplifying-tome', 'starting', 1, NULL
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'hextech-rocketbelt', 'core', 2, NULL
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'malignance', 'core', 3, NULL
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'infinity-orb', 'core', 4, NULL
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'boots-of-mana', 'boots', 5, NULL
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'rabadons-deathcap', 'core', 6, NULL
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'void-staff', 'core', 7, NULL
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'oceanids-trident', 'situational', NULL, 'vs Shielding'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'banshees-veil', 'situational', NULL, 'vs Crowd Control'
    -- Gragas (jungle) — Bruiser AP contrôle de foule
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'amplifying-tome', 'starting', 1, NULL
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'lich-bane', 'core', 2, NULL
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'rabadons-deathcap', 'core', 3, NULL
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'void-staff', 'core', 4, NULL
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'boots-of-mana', 'boots', 5, NULL
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'infinity-orb', 'core', 6, NULL
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'zhonyas-hourglass', 'core', 7, NULL
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'oceanids-trident', 'situational', NULL, 'vs Shielding'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'banshees-veil', 'situational', NULL, 'vs Crowd Control'
    -- Graves (jungle) — Marksman burst duelliste jungle
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'the-collector', 'core', 2, NULL
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'immortal-shieldbow', 'core', 3, NULL
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'lord-dominiks-regard', 'core', 4, NULL
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'gluttonous-greaves', 'boots', 5, NULL
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'infinity-edge', 'core', 6, NULL
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'bloodthirster', 'core', 7, NULL
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'galeforce', 'core', 8, NULL
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'mortal-reminder', 'situational', NULL, 'vs Healing'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'guardian-angel', 'situational', NULL, 'vs Burst Damage'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'mercurial-scimitar', 'situational', NULL, 'vs Crowd Control'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN items i ON i.slug = x.item_slug
ON DUPLICATE KEY UPDATE purchase_order = VALUES(purchase_order), situation = VALUES(situation);

-- Runes des builds
INSERT INTO build_runes (build_id, rune_id, position)
SELECT b.id, r.id, x.position
FROM (
    SELECT 'ekko' AS champion_slug, 'Assassin burst mobilité jungle' AS build_name, 'fleet-footwork' AS rune_slug, 1 AS position
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 'sudden-impact', 2
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 'hubris', 3
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 'eyeball-collector', 4
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 'absolute-focus', 5
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'electrocute', 1
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'sudden-impact', 2
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'chain-assault', 3
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'eyeball-collector', 4
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 'absolute-focus', 5
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'first-strike', 1
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'axiom-arcanist', 2
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'absolute-focus', 3
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'gathering-storm', 4
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 'sudden-impact', 5
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'phase-rush', 1
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'sudden-impact', 2
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'hubris', 3
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'eyeball-collector', 4
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 'absolute-focus', 5
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'fleet-footwork', 1
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'triumph', 2
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'cut-down', 3
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'legend-alacrity', 4
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 'absolute-focus', 5
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN runes r ON r.slug = x.rune_slug
ON DUPLICATE KEY UPDATE position = VALUES(position);

-- Ordre des compétences (1 point par niveau, 1 à 15)
INSERT INTO build_skill_order (build_id, level, skill)
SELECT b.id, x.level, x.skill
FROM (
    -- Ekko : Timewinder(1) > Phase Dive(3) > Parallel Convergence(2)
    SELECT 'ekko' AS champion_slug, 'Assassin burst mobilité jungle' AS build_name, 1 AS level, '1' AS skill
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 2, '1'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 3, '1'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 4, '1'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 5, 'ultimate'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 6, '1'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 7, '3'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 8, '3'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 9, 'ultimate'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 10, '3'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 11, '3'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 12, '2'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 13, 'ultimate'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 14, '2'
    UNION ALL SELECT 'ekko', 'Assassin burst mobilité jungle', 15, '2'
    -- Evelynn : Hate Spike(1) > Whiplash(3) > Allure(2)
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 1, '1'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 2, '1'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 3, '1'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 4, '1'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 5, 'ultimate'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 6, '1'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 7, '3'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 8, '3'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 9, 'ultimate'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 10, '3'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 11, '3'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 12, '2'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 13, 'ultimate'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 14, '2'
    UNION ALL SELECT 'evelynn', 'Assassin furtif burst AP', 15, '2'
    -- Fiddlesticks : Bountiful Harvest(2) > Terrify(1) > Reap(3)
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 1, '2'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 2, '2'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 3, '2'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 4, '2'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 5, 'ultimate'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 6, '2'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 7, '1'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 8, '1'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 9, 'ultimate'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 10, '1'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 11, '1'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 12, '3'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 13, 'ultimate'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 14, '3'
    UNION ALL SELECT 'fiddlesticks', 'Assassin AP embuscade effroi', 15, '3'
    -- Gragas : Barrel Roll(1) > Body Slam(3) > Drunken Rage(2)
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 1, '1'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 2, '1'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 3, '1'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 4, '1'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 5, 'ultimate'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 6, '1'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 7, '3'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 8, '3'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 9, 'ultimate'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 10, '3'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 11, '3'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 12, '2'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 13, 'ultimate'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 14, '2'
    UNION ALL SELECT 'gragas', 'Bruiser AP contrôle de foule', 15, '2'
    -- Graves : End of the Line(1) > Quickdraw(3) > Smoke Screen(2)
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 1, '1'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 2, '1'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 3, '1'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 4, '1'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 5, 'ultimate'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 6, '1'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 7, '3'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 8, '3'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 9, 'ultimate'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 10, '3'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 11, '3'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 12, '2'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 13, 'ultimate'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 14, '2'
    UNION ALL SELECT 'graves', 'Marksman burst duelliste jungle', 15, '2'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
ON DUPLICATE KEY UPDATE skill = VALUES(skill);
