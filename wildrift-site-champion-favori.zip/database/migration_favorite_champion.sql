-- ------------------------------------------------------------
-- Migration : champion favori d'un utilisateur
-- À exécuter UNE SEULE FOIS sur une base déjà installée (les
-- nouvelles installations l'obtiennent via database/schema.sql).
-- NULL = aucun champion favori ; si le champion est supprimé, la
-- colonne repasse à NULL (le compte n'est pas touché).
-- ------------------------------------------------------------
ALTER TABLE users
    ADD COLUMN favorite_champion_id INT UNSIGNED NULL AFTER avatar,
    ADD CONSTRAINT fk_users_favorite_champion FOREIGN KEY (favorite_champion_id)
        REFERENCES champions (id) ON DELETE SET NULL;
