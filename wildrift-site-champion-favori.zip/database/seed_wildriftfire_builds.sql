-- ============================================================
-- Lot 1 — Builds patch 7.3 — source WildRiftFire.com
-- Champions : Urgot, Volibear, Yone (complète le rôle baron),
-- Amumu, Diana (début du rôle jungle).
-- À importer APRÈS schema.sql et seed_wildriftfire_builds.sql
-- (dépend des champions déjà en base et complète les objets/
-- runes déjà présents plutôt que de les redéfinir).
--
-- Point bloquant conservé (voir rapport étape 4) : les sorts
-- d'invocateur de chaque build (Urgot : Flash/Ignite ; Volibear :
-- Flash/Smite ; Yone : Flash/Barrier ; Amumu : Flash/Smite ;
-- Diana : Flash/Ignite) ne sont PAS importés ici, faute de
-- colonne/table pour les stocker. Données conservées uniquement
-- dans ce commentaire en attendant la décision de schéma.
--
-- Volibear : le site propose 2 builds (Jungle A recommandé,
-- Solo S alternatif) ; seul le build Jungle est repris, conformément
-- à la méthode (1er build listé = rôle recommandé). Les objets
-- situationnels affichés sur la page appartiennent uniquement à la
-- section du build Solo (pas dupliqués pour le Jungle) : aucun objet
-- situationnel n'est donc importé pour ce build, pas de donnée
-- inventée pour compenser.
-- Yone / Diana : même principe, 1er build listé (Mid Lane) repris,
-- le build Jungle alternatif n'est pas importé dans ce lot.
-- ============================================================

-- Nouveaux objets nécessaires (absents de schema.sql et du seed existant)
INSERT INTO items (slug, name, category, price, description, image_url) VALUES
    ('navori-quickblades', 'Navori Quickblades', 'attack', 3000, 'Chance de coup critique et réduction des délais de récupération basée sur les coups critiques.', NULL),
    ('cosmic-drive', 'Cosmic Drive', 'magic', 2600, 'Puissance magique et vitesse de déplacement bonus après avoir touché une compétence sur un ennemi.', NULL),
    ('immortal-shieldbow', 'Immortal Shieldbow', 'attack', 3100, 'Dégâts d''attaque et critique ; bouclier unique par vie qui absorbe les dégâts fatals.', NULL),
    ('abyssal-mask', 'Abyssal Mask', 'defense', 2800, 'Résistance magique et PV ; marque les ennemis proches pour qu''ils subissent des dégâts magiques bonus.', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Nouvelles runes nécessaires (Amumu, Diana)
INSERT INTO runes (slug, name, tree, slot, description, image_url) VALUES
    ('ice-overlord', 'Ice Overlord', 'resolve', 'keystone', 'Octroie armure et résistance magique en ralentissant les ennemis proches lors de l''engagement.', NULL),
    ('absolute-focus', 'Absolute Focus', 'sorcery', 'minor', 'Convertit les PV au-dessus d''un seuil en dégâts d''attaque et puissance magique bonus.', NULL)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Builds
INSERT INTO builds (champion_id, name, role, patch, description, source)
SELECT id, 'Bruiser tank à exécution', 'baron', '7.3',
       'Build Solo Lane de WildRiftFire : Black Cleaver et Sterak''s Gage pour dégâts/survie, Amaranth''s Twinguard et Thornmail pour tenir en combat prolongé, Empowerment pour stacker les dégâts en trade.',
       'WildRiftFire.com' FROM champions WHERE slug = 'urgot'
UNION ALL
SELECT id, 'Bruiser hybride AP/AS jungle', 'jungle', '7.3',
       'Build Jungle A de WildRiftFire : Dusk and Dawn et Navori Quickblades pour l''hybride AP/vitesse d''attaque, Riftmaker pour le sustain, Lethal Tempo pour stacker la vitesse d''attaque en combat prolongé.',
       'WildRiftFire.com' FROM champions WHERE slug = 'volibear'
UNION ALL
SELECT id, 'Carry critique burst mi-voie', 'mid', '7.3',
       'Build Mid Lane S de WildRiftFire : Immortal Shieldbow et Infinity Edge pour le critique, Lord Dominik''s Regard contre les cibles tanky, Lethal Tempo pour scaler en combat prolongé.',
       'WildRiftFire.com' FROM champions WHERE slug = 'yone'
UNION ALL
SELECT id, 'Tank engage increvable', 'jungle', '7.3',
       'Build Jungle S de WildRiftFire : Sunfire Aegis et Abyssal Mask pour la présence en zone, Thornmail et Amaranth''s Twinguard pour tenir en combat prolongé, Ice Overlord pour ralentir en engage.',
       'WildRiftFire.com' FROM champions WHERE slug = 'amumu'
UNION ALL
SELECT id, 'Assassin burst AP plongeur', 'mid', '7.3',
       'Build Mid Lane B de WildRiftFire : Lich Bane et Infinity Orb pour le combo sort-auto, Rabadon''s Deathcap pour finir, Electrocute pour le burst à l''engagement.',
       'WildRiftFire.com' FROM champions WHERE slug = 'diana'
ON DUPLICATE KEY UPDATE
    role = VALUES(role),
    patch = VALUES(patch),
    description = VALUES(description),
    source = VALUES(source);

-- Objets des builds
INSERT INTO build_items (build_id, item_id, slot, purchase_order, situation)
SELECT b.id, i.id, x.slot, x.purchase_order, x.situation
FROM (
    -- Urgot (baron) — Bruiser tank à exécution
    SELECT 'urgot' AS champion_slug, 'Bruiser tank à exécution' AS build_name, 'ruby-crystal' AS item_slug, 'starting' AS slot, 1 AS purchase_order, NULL AS situation
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 'black-cleaver', 'core', 2, NULL
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 'steraks-gage', 'core', 3, NULL
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 'amaranths-twinguard', 'core', 4, NULL
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 'plated-steelcaps', 'boots', 5, NULL
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 'thornmail', 'core', 6, NULL
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 'guardian-angel', 'situational', NULL, 'vs Critical Strike Damage'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 'randuins-omen', 'situational', NULL, 'vs Critical Strike Damage'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 'mercurys-treads', 'situational', NULL, 'vs AP / CC'
    -- Volibear (jungle) — Bruiser hybride AP/AS jungle
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 'dusk-and-dawn', 'core', 2, NULL
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 'navori-quickblades', 'core', 3, NULL
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 'riftmaker', 'core', 4, NULL
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 'berserkers-greaves', 'boots', 5, NULL
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 'amaranths-twinguard', 'core', 6, NULL
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 'cosmic-drive', 'core', 7, NULL
    -- Yone (mid) — Carry critique burst mi-voie
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'long-sword', 'starting', 1, NULL
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'immortal-shieldbow', 'core', 2, NULL
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'infinity-edge', 'core', 3, NULL
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'lord-dominiks-regard', 'core', 4, NULL
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'berserkers-greaves', 'boots', 5, NULL
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'deaths-dance', 'core', 6, NULL
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'mortal-reminder', 'situational', NULL, 'vs Healing'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'guardian-angel', 'situational', NULL, 'vs Crowd Control'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'mercurial-scimitar', 'situational', NULL, 'vs Crowd Control'
    -- Amumu (jungle) — Tank engage increvable
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'ruby-crystal', 'starting', 1, NULL
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'sunfire-aegis', 'core', 2, NULL
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'abyssal-mask', 'core', 3, NULL
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'thornmail', 'core', 4, NULL
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'plated-steelcaps', 'boots', 5, NULL
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'amaranths-twinguard', 'core', 6, NULL
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'randuins-omen', 'situational', NULL, 'vs Critical Strike Damage'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'frozen-heart', 'situational', NULL, 'vs Attack Speed'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'mercurys-treads', 'situational', NULL, 'vs AP / CC'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'kaenic-rookern', 'situational', NULL, 'vs Critical Strike Damage / vs Attack Speed'
    -- Diana (mid) — Assassin burst AP plongeur
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'amplifying-tome', 'starting', 1, NULL
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'lich-bane', 'core', 2, NULL
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'infinity-orb', 'core', 3, NULL
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'rabadons-deathcap', 'core', 4, NULL
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'boots-of-mana', 'boots', 5, NULL
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'void-staff', 'core', 6, NULL
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'oceanids-trident', 'situational', NULL, 'vs Shielding'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'banshees-veil', 'situational', NULL, 'vs Crowd Control'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'zhonyas-hourglass', 'situational', NULL, 'vs Shielding / vs Crowd Control'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN items i ON i.slug = x.item_slug
ON DUPLICATE KEY UPDATE purchase_order = VALUES(purchase_order), situation = VALUES(situation);

-- Runes des builds
INSERT INTO build_runes (build_id, rune_id, position)
SELECT b.id, r.id, x.position
FROM (
    SELECT 'urgot' AS champion_slug, 'Bruiser tank à exécution' AS build_name, 'empowerment' AS rune_slug, 1 AS position
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 'demolish', 2
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 'second-wind', 3
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 'overgrowth', 4
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 'brutal', 5
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 'lethal-tempo', 1
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 'battle-zeal', 2
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 'last-stand', 3
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 'legend-alacrity', 4
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 'overgrowth', 5
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'lethal-tempo', 1
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'demolish', 2
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'second-wind', 3
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'perseverance', 4
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 'legend-alacrity', 5
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'ice-overlord', 1
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'unshakeable', 2
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'second-wind', 3
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'perseverance', 4
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 'transcendence', 5
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'electrocute', 1
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'sudden-impact', 2
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'chain-assault', 3
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'eyeball-collector', 4
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 'absolute-focus', 5
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
INNER JOIN runes r ON r.slug = x.rune_slug
ON DUPLICATE KEY UPDATE position = VALUES(position);

-- Ordre des compétences (1 point par niveau, 1 à 15)
INSERT INTO build_skill_order (build_id, level, skill)
SELECT b.id, x.level, x.skill
FROM (
    -- Urgot : Purge(2) > Disdain(3) > Corrosive Charge(1)
    SELECT 'urgot' AS champion_slug, 'Bruiser tank à exécution' AS build_name, 1 AS level, '2' AS skill
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 2, '2'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 3, '2'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 4, '2'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 5, 'ultimate'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 6, '2'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 7, '3'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 8, '3'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 9, 'ultimate'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 10, '3'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 11, '3'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 12, '1'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 13, 'ultimate'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 14, '1'
    UNION ALL SELECT 'urgot', 'Bruiser tank à exécution', 15, '1'
    -- Volibear : Frenzied Maul(2) > Thundering Smash(1) > Sky Splitter(3)
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 1, '2'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 2, '2'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 3, '2'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 4, '2'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 5, 'ultimate'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 6, '2'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 7, '1'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 8, '1'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 9, 'ultimate'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 10, '1'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 11, '1'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 12, '3'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 13, 'ultimate'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 14, '3'
    UNION ALL SELECT 'volibear', 'Bruiser hybride AP/AS jungle', 15, '3'
    -- Yone : Mortal Steel(1) > Soul Unbound(3) > Spirit Cleave(2)
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 1, '1'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 2, '1'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 3, '1'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 4, '1'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 5, 'ultimate'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 6, '1'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 7, '3'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 8, '3'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 9, 'ultimate'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 10, '3'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 11, '3'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 12, '2'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 13, 'ultimate'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 14, '2'
    UNION ALL SELECT 'yone', 'Carry critique burst mi-voie', 15, '2'
    -- Amumu : Tantrum(3) > Bandage Toss(1) > Despair(2)
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 1, '3'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 2, '3'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 3, '3'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 4, '3'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 5, 'ultimate'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 6, '3'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 7, '1'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 8, '1'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 9, 'ultimate'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 10, '1'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 11, '1'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 12, '2'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 13, 'ultimate'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 14, '2'
    UNION ALL SELECT 'amumu', 'Tank engage increvable', 15, '2'
    -- Diana : Crescent Strike(1) > Pale Cascade(2) > Lunar Rush(3)
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 1, '1'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 2, '1'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 3, '1'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 4, '1'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 5, 'ultimate'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 6, '1'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 7, '2'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 8, '2'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 9, 'ultimate'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 10, '2'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 11, '2'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 12, '3'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 13, 'ultimate'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 14, '3'
    UNION ALL SELECT 'diana', 'Assassin burst AP plongeur', 15, '3'
) x
INNER JOIN champions c ON c.slug = x.champion_slug
INNER JOIN builds b ON b.champion_id = c.id AND b.name = x.build_name
ON DUPLICATE KEY UPDATE skill = VALUES(skill);
