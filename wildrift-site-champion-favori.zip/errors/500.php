<?php
/**
 * Page d'erreur 500 — volontairement autonome (n'inclut PAS bootstrap.php).
 * -------------------------------------------------------------------------
 * C'est le filet de secours de dernier recours : elle ne s'affiche que si
 * Apache déclenche une 500 AVANT que includes/error_handler.php ait pu
 * s'enregistrer (ex. erreur fatale de syntaxe dans un fichier de config).
 * Dans tous les autres cas, error_handler.php gère déjà l'erreur et
 * affiche un message générique équivalent. Ne jamais faire dépendre cette
 * page de la config ou de la base de données : si l'app est cassée, cette
 * page doit rester fonctionnelle.
 */
http_response_code(500);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erreur — Wild Rift Platform</title>
    <style>
        body { font-family: system-ui, sans-serif; background: #0f1115; color: #e6e6e6; display: flex; min-height: 100vh; align-items: center; justify-content: center; margin: 0; }
        .box { text-align: center; padding: 2rem; }
        h1 { font-size: 2rem; margin-bottom: 0.5rem; }
        a { color: #7dd3fc; }
    </style>
</head>
<body>
    <div class="box">
        <h1>Une erreur est survenue</h1>
        <p>Le service est momentanément indisponible. Merci de réessayer plus tard.</p>
        <p><a href="/">Retour à l'accueil</a></p>
    </div>
</body>
</html>
