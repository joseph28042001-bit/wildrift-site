<?php
/**
 * Page d'erreur 404 — volontairement autonome (n'inclut PAS bootstrap.php).
 * Une erreur 404 est levée par Apache avant même que l'application ne
 * s'exécute : cette page ne doit dépendre d'aucune config, session ou
 * base de données pour rester fiable en toutes circonstances.
 */
http_response_code(404);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page introuvable — Wild Rift Platform</title>
    <style>
        body { font-family: system-ui, sans-serif; background: #0f1115; color: #e6e6e6; display: flex; min-height: 100vh; align-items: center; justify-content: center; margin: 0; }
        .box { text-align: center; padding: 2rem; }
        h1 { font-size: 3rem; margin-bottom: 0.5rem; }
        a { color: #7dd3fc; }
    </style>
</head>
<body>
    <div class="box">
        <h1>404</h1>
        <p>Cette page n'existe pas ou plus.</p>
        <p><a href="/">Retour à l'accueil</a></p>
    </div>
</body>
</html>
