<?php
/**
 * Page d'erreur 403 — volontairement autonome (n'inclut PAS bootstrap.php).
 * Voir errors/404.php pour l'explication de ce choix.
 */
http_response_code(403);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accès refusé — Wild Rift Platform</title>
    <style>
        body { font-family: system-ui, sans-serif; background: #0f1115; color: #e6e6e6; display: flex; min-height: 100vh; align-items: center; justify-content: center; margin: 0; }
        .box { text-align: center; padding: 2rem; }
        h1 { font-size: 3rem; margin-bottom: 0.5rem; }
        a { color: #7dd3fc; }
    </style>
</head>
<body>
    <div class="box">
        <h1>403</h1>
        <p>Accès refusé à cette ressource.</p>
        <p><a href="/">Retour à l'accueil</a></p>
    </div>
</body>
</html>
