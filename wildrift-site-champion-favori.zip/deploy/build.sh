#!/usr/bin/env bash
#
# build.sh — "build production" pour Wild Rift Platform (PHP/MySQL pur).
# ------------------------------------------------------------------------
# Ce projet n'a pas de code à compiler (pas de Node.js, pas de bundler) :
# le "build" consiste à VALIDER puis EMPAQUETER exactement ce qui doit
# être envoyé en FTP vers l'hébergement, sans les fichiers de dev.
#
# Utilisation :
#   ./deploy/build.sh
#
# Résultat :
#   deploy/dist/wildrift-site-<horodatage>.zip prêt à uploader dans htdocs/
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST_DIR="$ROOT_DIR/deploy/dist"
STAMP="$(date +%Y%m%d-%H%M%S)"
STAGE_DIR="$(mktemp -d)"
PACKAGE_NAME="wildrift-site-$STAMP.zip"

echo "==> Build production — Wild Rift Platform"
echo "    Racine du projet : $ROOT_DIR"

# --------------------------------------------------------------------
# 1. Validation : syntaxe PHP de tous les fichiers .php (si PHP dispo)
# --------------------------------------------------------------------
if command -v php >/dev/null 2>&1; then
    echo "==> Vérification de la syntaxe PHP (php -l)"
    ERRORS=0
    while IFS= read -r -d '' file; do
        if ! php -l "$file" > /dev/null; then
            ERRORS=$((ERRORS + 1))
        fi
    done < <(find "$ROOT_DIR" -name "*.php" -not -path "*/deploy/*" -print0)

    if [ "$ERRORS" -gt 0 ]; then
        echo "!! $ERRORS fichier(s) PHP invalide(s). Build interrompu." >&2
        exit 1
    fi
    echo "   OK — aucune erreur de syntaxe."
else
    echo "   (php introuvable en local — vérification de syntaxe ignorée,"
    echo "    pense à la faire au moins une fois avant un déploiement important)"
fi

# --------------------------------------------------------------------
# 2. Vérifications de configuration avant mise en production
# --------------------------------------------------------------------
echo "==> Vérification des fichiers de configuration locale"
MISSING=0
if [ ! -f "$ROOT_DIR/config/config.local.php" ]; then
    echo "   !! config/config.local.php absent (copie config.local.php.example et remplis-le)"
    MISSING=1
fi
if [ ! -f "$ROOT_DIR/config/database.local.php" ]; then
    echo "   !! config/database.local.php absent (copie database.local.php.example et remplis-le)"
    MISSING=1
fi
if [ "$MISSING" -eq 1 ]; then
    echo "!! Configuration locale incomplète. Le site tournera avec des valeurs de dev si tu déploies tel quel." >&2
    echo "   (voir README.md, section Variables d'environnement)" >&2
    exit 1
fi
echo "   OK — config.local.php et database.local.php présents."

# --------------------------------------------------------------------
# 3. Copie du projet dans un dossier temporaire, sans les fichiers de dev
# --------------------------------------------------------------------
echo "==> Préparation du paquet de déploiement"
cp -a "$ROOT_DIR/." "$STAGE_DIR/"
rm -rf "$STAGE_DIR/.git" "$STAGE_DIR/deploy" "$STAGE_DIR/.gitignore"
find "$STAGE_DIR" -name "*.example" -delete
find "$STAGE_DIR" -name ".DS_Store" -delete

# --------------------------------------------------------------------
# 4. Compression en zip, prêt pour upload FTP dans htdocs/
# --------------------------------------------------------------------
mkdir -p "$DIST_DIR"
(cd "$STAGE_DIR" && zip -rq "$DIST_DIR/$PACKAGE_NAME" .)
rm -rf "$STAGE_DIR"

echo "==> Build terminé."
echo "    Paquet : deploy/dist/$PACKAGE_NAME"
echo "    -> Décompresse-le à la racine de htdocs/ sur l'hébergement (FTP)."
