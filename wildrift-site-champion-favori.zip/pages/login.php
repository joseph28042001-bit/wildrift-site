<?php
/**
 * Page publique : Connexion.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans login.php.
 *
 * Étape actuelle : le formulaire de connexion (email, mot de passe),
 * avec validation à la fois côté navigateur (attributs HTML natifs +
 * assets/js/login.js) et côté serveur (voir le traitement dans
 * login.php, qui remplit $loginErrors / $oldEmail avant d'inclure ce
 * fichier) : vérification des identifiants, limitation des tentatives
 * (SECURITY_MAX_LOGIN_ATTEMPTS) puis connexion effective via
 * SESSION_USER_KEY et regenerateSessionId() (voir config/session.php)
 * en cas de succès, avec redirection vers profile.php.
 */
$loginErrors ??= [];
$oldEmail ??= '';

$fieldHasError = static function (string $field) use ($loginErrors): bool {
    return isset($loginErrors[$field]);
};
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container" style="max-width: 32rem;">
        <h1>Connexion</h1>
        <p class="text-muted" style="margin-bottom: var(--space-6);">
            Connecte-toi pour retrouver tes builds et ton profil d'invocateur.
        </p>

        <?php if ($fieldHasError('global')): ?>
            <div style="padding: var(--space-4); border: 1px solid var(--color-crimson); border-radius: var(--radius-md, 8px); color: var(--color-crimson); margin-bottom: var(--space-6);">
                <?= e($loginErrors['global']) ?>
            </div>
        <?php endif; ?>

        <form id="login-form" action="<?= asset('login.php') ?>" method="post" novalidate>
            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

            <div class="field<?= $fieldHasError('email') ? ' is-invalid' : '' ?>">
                <label for="login-email">Email</label>
                <input
                    type="email"
                    id="login-email"
                    name="email"
                    class="input"
                    placeholder="toi@exemple.com"
                    value="<?= e($oldEmail) ?>"
                    autocomplete="email"
                    required
                >
                <p class="field__error">Saisis une adresse email valide.</p>
            </div>

            <div class="field<?= $fieldHasError('password') ? ' is-invalid' : '' ?>">
                <label for="login-password">Mot de passe</label>
                <input
                    type="password"
                    id="login-password"
                    name="password"
                    class="input"
                    autocomplete="current-password"
                    required
                >
                <p class="field__error">Saisis ton mot de passe.</p>
            </div>

            <div class="field">
                <label class="checkbox">
                    <input type="checkbox" id="login-remember" name="remember">
                    Rester connecté
                </label>
            </div>

            <button type="submit" class="btn btn--block">Se connecter</button>
        </form>

        <p class="text-muted" style="margin-top: var(--space-5); text-align: center;">
            Pas encore de compte ? <a href="<?= asset('register.php') ?>">Créer un compte</a>
        </p>
    </div>
</section>

<script src="<?= asset('assets/js/login.js') ?>"></script>
