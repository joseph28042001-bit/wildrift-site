<?php
/**
 * Page publique : Champion (détail).
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans champion.php.
 *
 * Le contenu réel est entièrement injecté par assets/js/champion.js, qui
 * lit l'ID dans l'URL (?id=) et interroge GET /api/champions/?id= au
 * chargement de la page — voir ce fichier pour le détail de la
 * connexion à l'API. Ce fichier PHP ne fait que poser la structure : un
 * état de chargement (visible en premier), une zone d'erreur (cachée
 * par défaut, couvrant aussi bien l'ID absent/invalide que le champion
 * introuvable) et le conteneur du détail (vide tant que l'API n'a pas
 * répondu) — même principe que les pages de liste (pages/champions.php,
 * etc.), mais pour une seule fiche plutôt qu'une grille. Une seconde
 * section, plus bas, affiche les statistiques du champion (tier list) —
 * voir assets/js/champion.js pour le détail de cette seconde connexion.
 * Une troisième section, sous les statistiques, affiche les capacités du
 * champion (passive + Q/W/E/R) — voir assets/js/champion.js pour le
 * détail de cette troisième connexion (GET /api/abilities/?champion=<slug>).
 * Une quatrième section, sous les capacités, affiche les builds du
 * champion — voir assets/js/champion.js pour le détail de cette
 * quatrième connexion (GET /api/builds/?champion=<slug>, filtre déjà
 * pris en charge par la ressource existante — voir api/builds/index.php).
 * Une cinquième section, sous les builds, affiche les counters du
 * champion (Matchups & counters) — voir assets/js/champion.js pour le
 * détail de cette cinquième connexion (GET
 * /api/counters/?champion_id=<id>, filtre déjà pris en charge par la
 * ressource existante — voir api/counters/index.php).
 * Une sixième section, sous les counters, affiche les synergies
 * d'équipe du champion — voir assets/js/champion.js pour le détail de
 * cette sixième connexion (GET /api/synergies/?champion_id=<id>,
 * filtre déjà pris en charge par la ressource existante — voir
 * api/synergies/index.php).
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <div id="champion-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement du champion…</span>
        </div>

        <p id="champion-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <article id="champion-detail" class="card card--champion" style="max-width: 40rem;" hidden></article>
    </div>
</section>

<!--
    Section "Statistiques".
    Une fois la fiche du champion chargée (bloc ci-dessus), son slug sert
    à interroger GET /api/tier-list/?champion=<slug> (voir
    api/tier-list/index.php et api/tier-list/repository.php) : les
    entrées de tier list associées à ce champion (une par rôle/patch),
    avec leur tier et leurs taux de victoire/sélection/bannissement.
    Section séparée avec son propre état de chargement/erreur, puisqu'il
    s'agit d'un second appel API, indépendant du premier (voir
    assets/js/champion.js).
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Statistiques</h2>
        </div>

        <div id="champion-stats-loading" class="stack" hidden>
            <div class="spinner"></div>
            <span class="text-muted">Chargement des statistiques…</span>
        </div>

        <p id="champion-stats-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <p id="champion-stats-empty" class="text-muted" hidden>Aucune statistique disponible pour ce champion.</p>

        <div id="champion-stats-grid" class="grid"></div>
    </div>
</section>

<!--
    Section "Capacités".
    Une fois la fiche du champion chargée (première section ci-dessus),
    son slug sert à interroger GET /api/abilities/?champion=<slug> (voir
    api/abilities/index.php et api/abilities/repository.php) : les 5
    capacités du champion (passive puis Q/W/E/R), déjà triées par l'API
    dans l'ordre naturel du kit. Section séparée avec son propre état de
    chargement/erreur, indépendante des statistiques ci-dessus (voir
    assets/js/champion.js).
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Capacités</h2>
        </div>

        <div id="champion-abilities-loading" class="stack" hidden>
            <div class="spinner"></div>
            <span class="text-muted">Chargement des capacités…</span>
        </div>

        <p id="champion-abilities-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <p id="champion-abilities-empty" class="text-muted" hidden>Aucune capacité disponible pour ce champion.</p>

        <div id="champion-abilities-grid" class="grid"></div>
    </div>
</section>

<!--
    Section "Builds".
    Une fois la fiche du champion chargée (première section ci-dessus),
    son slug sert à interroger GET /api/builds/?champion=<slug> (voir
    api/builds/index.php et api/builds/repository.php) : les builds
    recommandés pour ce champion (nom, rôle, patch) — même ressource que
    pages/builds.php, mais avec le filtre ?champion= (déjà pris en
    charge par l'API, non utilisé par pages/builds.php qui affiche la
    liste complète paginée). Peu de builds par champion à ce stade : pas
    de pagination câblée ici. Section séparée avec son propre état de
    chargement/erreur/vide, indépendante des statistiques et des
    capacités ci-dessus (voir assets/js/champion.js).
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Builds</h2>
        </div>

        <div id="champion-builds-loading" class="stack" hidden>
            <div class="spinner"></div>
            <span class="text-muted">Chargement des builds…</span>
        </div>

        <p id="champion-builds-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <p id="champion-builds-empty" class="text-muted" hidden>Aucun build disponible pour ce champion.</p>

        <div id="champion-builds-grid" class="grid"></div>
    </div>
</section>

<!--
    Section "Counters".
    Une fois la fiche du champion chargée (première section ci-dessus),
    son ID sert à interroger GET /api/counters/?champion_id=<id> (voir
    api/counters/index.php et api/counters/repository.php) : les
    champions qui contrent ce champion, avec l'explication, les
    conseils, la difficulté du matchup et les objets recommandés
    associés (relation `counter_items`). Même ressource et même filtre
    que ceux déjà pris en charge par l'API mais non exploités par
    pages/counters.php (qui affiche tous les counters, sans filtre).
    Comme sur pages/counters.php, l'API ne résout pas le nom du champion
    qui contre (`counter_champion_id` reste un ID brut, voir
    assets/js/counters.js) : même limite reprise ici, sans appel
    supplémentaire à /api/champions/ pour le résoudre en nom — hors
    périmètre de cette étape. Section séparée avec son propre état de
    chargement/erreur/vide, indépendante des sections précédentes (voir
    assets/js/champion.js).
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Counters</h2>
        </div>

        <div id="champion-counters-loading" class="stack" hidden>
            <div class="spinner"></div>
            <span class="text-muted">Chargement des counters…</span>
        </div>

        <p id="champion-counters-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <p id="champion-counters-empty" class="text-muted" hidden>Aucun counter disponible pour ce champion.</p>

        <div id="champion-counters-grid" class="grid"></div>
    </div>
</section>

<!--
    Section "Synergies".
    Une fois la fiche du champion chargée (première section ci-dessus),
    son ID sert à interroger GET /api/synergies/?champion_id=<id> (voir
    api/synergies/index.php et api/synergies/repository.php) : les
    champions qui forment une bonne synergie d'équipe avec ce champion,
    avec l'explication associée. Même ressource et même principe de
    filtre que /api/counters/ ci-dessus, mais sans difficulté ni objets
    recommandés (une synergie n'a que son explication). Comme pour les
    counters, l'API ne résout pas le nom du champion partenaire
    (`synergy_champion_id` reste un ID brut, voir assets/js/champion.js)
    : même limite reprise ici, sans appel supplémentaire à
    /api/champions/ pour le résoudre en nom — hors périmètre de cette
    étape. Section séparée avec son propre état de chargement/erreur/vide,
    indépendante des sections précédentes (voir assets/js/champion.js).
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Synergies</h2>
        </div>

        <div id="champion-synergies-loading" class="stack" hidden>
            <div class="spinner"></div>
            <span class="text-muted">Chargement des synergies…</span>
        </div>

        <p id="champion-synergies-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <p id="champion-synergies-empty" class="text-muted" hidden>Aucune synergie disponible pour ce champion.</p>

        <div id="champion-synergies-grid" class="grid"></div>
    </div>
</section>

<script src="<?= asset('assets/js/champion.js') ?>"></script>
