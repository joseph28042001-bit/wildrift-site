<?php
/**
 * Page publique : Objets.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans items.php.
 *
 * Le contenu réel (la liste des objets) est entièrement injecté par
 * assets/js/items.js, qui interroge GET /api/items/ au chargement de la
 * page — voir ce fichier pour le détail de la connexion à l'API. Ce
 * fichier PHP ne fait que poser la structure : un formulaire de
 * recherche par nom et de filtre par catégorie (#items-search-form, voir
 * GET /api/items/?search= et ?category= dans api/items/repository.php
 * — combinables), un état de chargement (visible en premier), une zone
 * d'erreur (cachée par défaut) et le conteneur de la grille de résultats
 * (vide tant que l'API n'a pas répondu) — même structure que
 * pages/champions.php.
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <p class="eyebrow">Wild Rift</p>
        <h1>Objets</h1>
        <p style="max-width: 60ch; font-size: var(--text-md);">
            Tous les objets disponibles sur la plateforme, avec leur
            catégorie et leur prix.
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <form id="items-search-form" class="stack" style="flex-direction: row; flex-wrap: wrap; align-items: center; gap: var(--space-3); margin-bottom: var(--space-6);">
            <label for="items-search-input" class="text-muted" style="font-size: var(--text-sm);">Rechercher un objet</label>
            <input
                type="search"
                id="items-search-input"
                name="search"
                placeholder="Nom de l'objet…"
                maxlength="60"
                class="input"
            >

            <label for="items-category-filter" class="text-muted" style="font-size: var(--text-sm);">Catégorie</label>
            <select id="items-category-filter" name="category" class="select">
                <option value="">Toutes les catégories</option>
                <option value="attack">Attaque</option>
                <option value="magic">Magie</option>
                <option value="defense">Défense</option>
                <option value="boots">Bottes</option>
                <option value="jungle">Jungle</option>
                <option value="consumable">Consommable</option>
            </select>

            <button type="submit" class="btn btn--sm">Rechercher</button>
            <button type="button" id="items-search-reset" class="btn btn--secondary btn--sm">Réinitialiser</button>
        </form>

        <div id="items-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des objets…</span>
        </div>

        <p id="items-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="items-grid" class="grid"></div>
    </div>
</section>

<script src="<?= asset('assets/js/items.js') ?>"></script>
