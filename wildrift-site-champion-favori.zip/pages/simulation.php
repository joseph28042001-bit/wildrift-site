<?php
/**
 * Page publique : Simulation 5v5.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans simulation.php.
 *
 * Étape actuelle : uniquement la structure visuelle des 5 emplacements
 * de la Blue Team et des 5 emplacements de la Red Team (un slot de
 * champion par rôle, pour chaque équipe), avec la sélection d'un
 * champion pour chaque emplacement (menu déroulant peuplé depuis
 * GET /api/champions/, voir assets/js/simulation.js) et des filtres
 * (recherche par nom + rôle, combinables — #simulation-champion-search
 * et #simulation-champion-role-filter) qui affinent en direct les
 * champions proposés dans les 10 emplacements, ainsi qu'un bouton de
 * verrouillage par emplacement (data-simulation-lock-toggle) qui fige
 * la sélection en cours une fois un champion choisi, ainsi que le
 * calcul des synergies entre les champions sélectionnés au sein de
 * chaque équipe (#simulation-blue-synergies et
 * #simulation-red-synergies, voir assets/js/simulation.js — basé sur
 * l'API existante GET /api/synergies/?champion_id=), ainsi que le
 * calcul des counters entre les champions des deux équipes
 * (#simulation-counters — basé sur l'API existante
 * GET /api/counters/?champion_id=), ainsi que l'analyse de la
 * composition de chaque équipe (#simulation-blue-analysis et
 * #simulation-red-analysis — nombre de champions sélectionnés, rôles
 * manquants et difficulté moyenne, calculés côté client à partir des
 * champions déjà chargés, sans appel API supplémentaire), ainsi que
 * l'analyse de la frontline de chaque équipe (#simulation-blue-frontline
 * et #simulation-red-frontline — couverture des rôles traditionnellement
 * frontline en Wild Rift, Voie Baron et Jungle, avec le champion qui
 * l'occupe le cas échéant), ainsi que l'analyse du contrôle de foule de
 * chaque équipe (#simulation-blue-cc et #simulation-red-cc — niveau de
 * CC de chaque champion sélectionné, colonne cc_level exposée par
 * GET /api/champions/, et score d'équipe pondéré), ainsi que l'analyse
 * de l'engage et du disengage de chaque équipe (#simulation-blue-engage /
 * #simulation-red-engage et #simulation-blue-disengage /
 * #simulation-red-disengage — niveau de chaque champion sélectionné,
 * colonnes engage_level et disengage_level exposées par
 * GET /api/champions/, et score d'équipe pondéré pour chacun), ainsi
 * que l'analyse Early Game / Late Game de chaque équipe
 * (#simulation-blue-early-game / #simulation-red-early-game et
 * #simulation-blue-late-game / #simulation-red-late-game — niveau de
 * chaque champion sélectionné, colonnes early_game_level et
 * late_game_level exposées par GET /api/champions/, et score d'équipe
 * pondéré pour chacun), ainsi que le score global de chaque équipe
 * (#simulation-blue-global-score et #simulation-red-global-score —
 * combine les scores des analyses ci-dessus, CC + engage + disengage +
 * early game + late game, en un seul total avec le détail par métrique,
 * entièrement calculé côté client), ainsi que des recommandations de
 * champions par équipe (#simulation-blue-recommendations et
 * #simulation-red-recommendations — pour chaque rôle encore vacant,
 * jusqu'à 2 champions disponibles de ce rôle, en priorité ceux qui
 * renforcent la métrique la plus faible de l'équipe, entièrement
 * calculé côté client), ainsi que l'analyse finale une fois les 10
 * emplacements pourvus (#simulation-final-analysis — verdict global et
 * détail par métrique entre les deux équipes, reste sur son message
 * d'attente, data-simulation-final-analysis-empty, tant que la
 * composition n'est pas complète). Aucune autre logique n'est câblée à
 * cette étape : pas encore de bouton "Lancer la
 * simulation" ni de calcul du résultat — ils viendront dans une
 * prochaine étape dédiée. La simulation 1v1 mentionnée par une
 * précédente version de cette page reste hors périmètre ici : voir
 * pages/matchup.php pour l'analyse de matchup 1v1 déjà existante
 * (contres), fonctionnellement différente d'une simulation de partie.
 *
 * Chaque emplacement est un <select> (name="<équipe>[<rôle>]", valeur =
 * slug du champion), peuplé côté client par assets/js/simulation.js —
 * pas de logique de sélection ou de validation ici, seulement le
 * balisage (options vides jusqu'au chargement de la page).
 */

/**
 * Libellés français des rôles Wild Rift, un slot par rôle — mêmes
 * libellés que CHAMPION_ROLE_LABELS (assets/js/champions.js) et
 * l'énumération getChampionRoles() côté API
 * (api/champions/repository.php), pour rester cohérent avec le reste du
 * site.
 */
$simulationRoles = [
    'baron'   => 'Voie Baron',
    'jungle'  => 'Jungle',
    'mid'     => 'Voie du Milieu',
    'dragon'  => 'Voie Dragon',
    'support' => 'Support',
];

/**
 * Construit les 5 emplacements de champion (un par rôle) d'une équipe.
 * Factorisé pour éviter de dupliquer deux fois la même structure
 * (équipe bleue / équipe rouge ci-dessous) — chaque emplacement est un
 * <select> vide (seule l'option par défaut est présente ici) : le
 * peuplement avec la liste des champions se fait côté client, voir
 * assets/js/simulation.js. Un bouton de verrouillage accompagne chaque
 * <select> (voir data-simulation-lock-toggle ci-dessous) : désactivé
 * tant qu'aucun champion n'est choisi dans cet emplacement, câblé
 * uniquement côté client.
 */
function renderSimulationTeamSlots(string $teamSlug, array $roles): void
{
    foreach ($roles as $role => $label) {
        $selectId = "simulation-{$teamSlug}-{$role}";
        $lockId = "{$selectId}-lock";
        ?>
        <div class="stack" style="gap: var(--space-2);">
            <label for="<?= e($selectId) ?>" class="text-muted" style="font-size: var(--text-sm);"><?= e($label) ?></label>
            <div class="stack" style="flex-direction: row; align-items: center; gap: var(--space-2);">
                <select
                    id="<?= e($selectId) ?>"
                    name="<?= e($teamSlug) ?>[<?= e($role) ?>]"
                    class="select"
                    data-simulation-champion-select
                >
                    <option value="">Choisir un champion</option>
                </select>
                <button
                    type="button"
                    id="<?= e($lockId) ?>"
                    class="btn btn--secondary btn--sm"
                    data-simulation-lock-toggle
                    data-target="<?= e($selectId) ?>"
                    disabled
                >Verrouiller</button>
            </div>
        </div>
        <?php
    }
}
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <p class="eyebrow">Wild Rift</p>
        <h1>Simulation 5v5</h1>
        <p style="max-width: 60ch; font-size: var(--text-md);">
            Composez deux équipes de 5 champions, un par rôle, pour
            préparer une simulation de partie. Le calcul du résultat
            n'est pas encore disponible : cette étape permet uniquement
            de sélectionner les champions des deux équipes.
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="stack" style="flex-direction: row; flex-wrap: wrap; align-items: center; gap: var(--space-3); margin-bottom: var(--space-6);">
            <label for="simulation-champion-search" class="text-muted" style="font-size: var(--text-sm);">Rechercher un champion</label>
            <input
                type="search"
                id="simulation-champion-search"
                placeholder="Nom du champion…"
                maxlength="60"
                class="input"
            >

            <label for="simulation-champion-role-filter" class="text-muted" style="font-size: var(--text-sm);">Rôle</label>
            <select id="simulation-champion-role-filter" class="select">
                <option value="">Tous les rôles</option>
                <option value="baron">Voie Baron</option>
                <option value="jungle">Jungle</option>
                <option value="mid">Voie du Milieu</option>
                <option value="dragon">Voie Dragon</option>
                <option value="support">Support</option>
            </select>
        </div>

        <div class="grid" style="grid-template-columns: repeat(2, 1fr);">
            <div class="card">
                <div class="card__eyebrow">Équipe Bleue</div>
                <h2 class="card__title">Composition</h2>

                <div class="stack" style="gap: var(--space-4); margin-top: var(--space-4);">
                    <?php renderSimulationTeamSlots('blue', $simulationRoles); ?>
                </div>
            </div>

            <div class="card">
                <div class="card__eyebrow">Équipe Rouge</div>
                <h2 class="card__title">Composition</h2>

                <div class="stack" style="gap: var(--space-4); margin-top: var(--space-4);">
                    <?php renderSimulationTeamSlots('red', $simulationRoles); ?>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Analyse</p>
            <h2>Analyse de la composition de chaque équipe</h2>
        </div>

        <div class="grid" style="grid-template-columns: repeat(2, 1fr);">
            <div>
                <h3 class="card__title">Équipe Bleue</h3>
                <div id="simulation-blue-analysis" class="stack" style="gap: var(--space-2);"></div>
            </div>

            <div>
                <h3 class="card__title">Équipe Rouge</h3>
                <div id="simulation-red-analysis" class="stack" style="gap: var(--space-2);"></div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Analyse</p>
            <h2>Analyse de la frontline</h2>
        </div>

        <div class="grid" style="grid-template-columns: repeat(2, 1fr);">
            <div>
                <h3 class="card__title">Équipe Bleue</h3>
                <div id="simulation-blue-frontline" class="stack" style="gap: var(--space-2);"></div>
            </div>

            <div>
                <h3 class="card__title">Équipe Rouge</h3>
                <div id="simulation-red-frontline" class="stack" style="gap: var(--space-2);"></div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Analyse</p>
            <h2>Analyse du contrôle de foule</h2>
        </div>

        <div class="grid" style="grid-template-columns: repeat(2, 1fr);">
            <div>
                <h3 class="card__title">Équipe Bleue</h3>
                <div id="simulation-blue-cc" class="stack" style="gap: var(--space-2);"></div>
            </div>

            <div>
                <h3 class="card__title">Équipe Rouge</h3>
                <div id="simulation-red-cc" class="stack" style="gap: var(--space-2);"></div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Analyse</p>
            <h2>Analyse de l'engage</h2>
        </div>

        <div class="grid" style="grid-template-columns: repeat(2, 1fr);">
            <div>
                <h3 class="card__title">Équipe Bleue</h3>
                <div id="simulation-blue-engage" class="stack" style="gap: var(--space-2);"></div>
            </div>

            <div>
                <h3 class="card__title">Équipe Rouge</h3>
                <div id="simulation-red-engage" class="stack" style="gap: var(--space-2);"></div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Analyse</p>
            <h2>Analyse du disengage</h2>
        </div>

        <div class="grid" style="grid-template-columns: repeat(2, 1fr);">
            <div>
                <h3 class="card__title">Équipe Bleue</h3>
                <div id="simulation-blue-disengage" class="stack" style="gap: var(--space-2);"></div>
            </div>

            <div>
                <h3 class="card__title">Équipe Rouge</h3>
                <div id="simulation-red-disengage" class="stack" style="gap: var(--space-2);"></div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Analyse</p>
            <h2>Analyse Early Game</h2>
        </div>

        <div class="grid" style="grid-template-columns: repeat(2, 1fr);">
            <div>
                <h3 class="card__title">Équipe Bleue</h3>
                <div id="simulation-blue-early-game" class="stack" style="gap: var(--space-2);"></div>
            </div>

            <div>
                <h3 class="card__title">Équipe Rouge</h3>
                <div id="simulation-red-early-game" class="stack" style="gap: var(--space-2);"></div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Analyse</p>
            <h2>Analyse Late Game</h2>
        </div>

        <div class="grid" style="grid-template-columns: repeat(2, 1fr);">
            <div>
                <h3 class="card__title">Équipe Bleue</h3>
                <div id="simulation-blue-late-game" class="stack" style="gap: var(--space-2);"></div>
            </div>

            <div>
                <h3 class="card__title">Équipe Rouge</h3>
                <div id="simulation-red-late-game" class="stack" style="gap: var(--space-2);"></div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Score</p>
            <h2>Score global de l'équipe</h2>
        </div>

        <div class="grid" style="grid-template-columns: repeat(2, 1fr);">
            <div>
                <h3 class="card__title">Équipe Bleue</h3>
                <div id="simulation-blue-global-score" class="stack" style="gap: var(--space-2);"></div>
            </div>

            <div>
                <h3 class="card__title">Équipe Rouge</h3>
                <div id="simulation-red-global-score" class="stack" style="gap: var(--space-2);"></div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Recommandations</p>
            <h2>Champions recommandés</h2>
        </div>

        <div class="grid" style="grid-template-columns: repeat(2, 1fr);">
            <div>
                <h3 class="card__title">Équipe Bleue</h3>
                <div id="simulation-blue-recommendations" class="stack" style="gap: var(--space-2);"></div>
            </div>

            <div>
                <h3 class="card__title">Équipe Rouge</h3>
                <div id="simulation-red-recommendations" class="stack" style="gap: var(--space-2);"></div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Synergies</p>
            <h2>Synergies entre champions sélectionnés</h2>
        </div>

        <div class="grid" style="grid-template-columns: repeat(2, 1fr);">
            <div>
                <h3 class="card__title">Équipe Bleue</h3>
                <div id="simulation-blue-synergies" class="stack" style="gap: var(--space-3);">
                    <p class="text-muted" data-simulation-synergies-empty>Sélectionnez au moins deux champions pour voir leurs synergies.</p>
                </div>
            </div>

            <div>
                <h3 class="card__title">Équipe Rouge</h3>
                <div id="simulation-red-synergies" class="stack" style="gap: var(--space-3);">
                    <p class="text-muted" data-simulation-synergies-empty>Sélectionnez au moins deux champions pour voir leurs synergies.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Counters</p>
            <h2>Counters entre les deux équipes</h2>
        </div>

        <div id="simulation-counters" class="stack" style="gap: var(--space-3);">
            <p class="text-muted" data-simulation-counters-empty>Sélectionnez au moins un champion dans chaque équipe pour voir les counters.</p>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Analyse finale</p>
            <h2>Verdict de la composition</h2>
        </div>

        <div id="simulation-final-analysis" class="stack" style="gap: var(--space-2);">
            <p class="text-muted" data-simulation-final-analysis-empty>Sélectionnez les 10 champions (5 par équipe) pour voir l'analyse finale.</p>
        </div>
    </div>
</section>

<script src="<?= asset('assets/js/simulation.js') ?>"></script>
