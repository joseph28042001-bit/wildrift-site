<?php
/**
 * Page publique : Build (dynamique, par champion).
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans builds.php, qui
 * charge ce fichier à la place de pages/builds.php quand ?champion=
 * est présent dans l'URL (voir builds.php).
 *
 * Page dédiée complète pour un champion (ex. builds.php?champion=aatrox),
 * en six sections, chacune indépendante (chargement/erreur/vide propres),
 * toutes connectées par slug (via window.REQUESTED_CHAMPION_SLUG) et/ou
 * par id de champion — voir assets/js/champion-build.js pour la logique :
 *
 *   1. En-tête du champion — image, nom, rôle (recommandé, ou rôle de
 *      base à défaut de tier list), difficulté, courte présentation
 *      (reprend la description du build principal du champion, à
 *      défaut de champ dédié dans `champions` — voir
 *      renderBuildChampionDetail()).
 *   2. Build principal — objets de départ et objets principaux
 *      (slots 'starting'/'core' de build_items), avec icône, nom et
 *      ordre d'achat (purchase_order) pour chacun.
 *   3. Runes — rune principale (keystone) et runes secondaires
 *      (mineures) du build (build_runes) ; les fragments/statistiques
 *      ne sont pas encore représentés dans le modèle de données
 *      actuel (voir database/schema.sql), signalé tel quel plutôt que
 *      d'inventer une donnée absente.
 *   4. Bottes — bottes recommandées (slot 'boots') et enchantement de
 *      bottes si renseigné (slot 'enchantment').
 *   5. Build situationnel — objets alternatifs (slot 'situational'),
 *      avec leur situation d'achat quand elle est renseignée
 *      (build_items.situation, même principe que counter_items.situation
 *      en section 6) ; non encore renseignée dans le jeu de données
 *      actuel, donc pas encore affichée en pratique — le système est
 *      prêt à l'utiliser, sans rien inventer en attendant.
 *   6. Counters — champions difficiles à affronter (ce champion est
 *      contré par...) et champions favorables (ce champion contre...),
 *      table `counters` consultée dans les deux sens, avec portrait du
 *      champion adverse (résolu via /api/champions/, voir
 *      fetchAllChampions()) et explication courte quand elle existe.
 *
 * Un champion sans build associé (aucune ligne dans `builds` pour lui)
 * affiche un état vide dédié dans chacune des sections 2 à 5 plutôt
 * qu'une erreur : ce n'est pas un cas d'échec. Même principe pour la
 * section 6 si aucun counter n'est renseigné pour ce champion.
 *
 * Le slug demandé est transmis à assets/js/champion-build.js via
 * window.REQUESTED_CHAMPION_SLUG (voir script inline ci-dessous), lu
 * côté serveur depuis $_GET['champion'] (voir builds.php).
 */
?>
<script>
    window.REQUESTED_CHAMPION_SLUG = <?= json_encode($_GET['champion'] ?? '', JSON_UNESCAPED_UNICODE) ?>;
</script>

<!--
    Section 1 — En-tête du champion.
    Chargée automatiquement par son slug (voir assets/js/champion-build.js)
    dès l'arrivée sur la page : carte .card--featured du design system
    (bordure dégradée animée, réservée aux mises en avant) — voir
    assets/js/champion-build.js::renderBuildChampionDetail().
-->
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <p class="eyebrow">Wild Rift</p>
        <h1>Build</h1>

        <div id="build-champion-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement du champion…</span>
        </div>

        <p id="build-champion-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <article id="build-champion-detail" class="card card--featured" style="max-width: 56rem; padding: 0; overflow: hidden;" hidden></article>
    </div>
</section>

<!--
    Section 2 — Build principal.
    Objets de départ (Starting Item) et objets principaux (Core Items),
    avec ordre d'achat — voir assets/js/champion-build.js::
    renderMainBuildSection(). Les bottes (slot 'boots') et
    l'enchantement (slot 'enchantment') sont affichés séparément en
    section 4 ; les objets situationnels (slot 'situational') en
    section 5 — voir getBuildItemSlots(), api/builds/repository.php.
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Build principal</h2>
        </div>

        <div id="build-main-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement du build…</span>
        </div>

        <p id="build-main-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <p id="build-main-empty" class="text-muted" hidden>Aucun build principal n'est encore disponible pour ce champion.</p>

        <div id="build-main-groups" class="build-item-groups" hidden>
            <article class="card build-item-group">
                <p class="card__eyebrow">Emplacement</p>
                <h3 class="card__title">Starting Item</h3>
                <div id="build-main-starting" class="build-item-row"></div>
            </article>

            <article class="card build-item-group">
                <p class="card__eyebrow">Emplacement</p>
                <h3 class="card__title">Core Items</h3>
                <div id="build-main-core" class="build-item-row"></div>
            </article>
        </div>
    </div>
</section>

<!--
    Section 3 — Runes.
    Rune principale (keystone) et runes secondaires (mineures) du build
    (build_runes) — voir assets/js/champion-build.js::renderRunesSection().
    Les fragments/statistiques n'ont pas d'équivalent dans le modèle de
    données actuel (aucune table dédiée) : signalé explicitement plutôt
    qu'une donnée inventée.
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Runes</h2>
        </div>

        <div id="build-runes-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des runes…</span>
        </div>

        <p id="build-runes-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <p id="build-runes-empty" class="text-muted" hidden>Aucune rune n'est encore renseignée pour ce champion.</p>

        <div id="build-runes-content" class="build-item-groups" hidden>
            <article class="card build-item-group">
                <p class="card__eyebrow">Rune principale</p>
                <h3 class="card__title">Keystone</h3>
                <div id="build-runes-keystone" class="build-item-row"></div>
            </article>

            <article class="card build-item-group">
                <p class="card__eyebrow">Runes secondaires</p>
                <h3 class="card__title">Mineures</h3>
                <div id="build-runes-secondary" class="build-item-row"></div>
            </article>

            <article class="card build-item-group">
                <p class="card__eyebrow">Emplacement</p>
                <h3 class="card__title">Fragments / statistiques</h3>
                <p class="text-muted" style="margin-top: var(--space-4);">Non disponibles pour le moment : ce type de donnée n'existe pas encore dans le modèle actuel du projet.</p>
            </article>
        </div>
    </div>
</section>

<!--
    Section 4 — Bottes.
    Bottes recommandées (slot 'boots') et enchantement de bottes si
    renseigné (slot 'enchantment') — voir assets/js/champion-build.js::
    renderBootsSection().
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Bottes</h2>
        </div>

        <div id="build-boots-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des bottes…</span>
        </div>

        <p id="build-boots-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <p id="build-boots-empty" class="text-muted" hidden>Aucune botte n'est encore renseignée pour ce champion.</p>

        <div id="build-boots-groups" class="build-item-groups" hidden>
            <article class="card build-item-group">
                <p class="card__eyebrow">Emplacement</p>
                <h3 class="card__title">Bottes recommandées</h3>
                <div id="build-boots-main" class="build-item-row"></div>
            </article>

            <article class="card build-item-group">
                <p class="card__eyebrow">Emplacement</p>
                <h3 class="card__title">Enchantement</h3>
                <div id="build-boots-enchantment" class="build-item-row"></div>
            </article>
        </div>
    </div>
</section>

<!--
    Section 5 — Build situationnel.
    Objets alternatifs (slot 'situational'), avec leur situation
    d'achat quand elle est renseignée (build_items.situation, voir
    database/schema.sql — même principe que counter_items.situation en
    section 6) — voir assets/js/champion-build.js::
    renderSituationalSection(). Le jeu de données actuel ne renseigne
    encore ce champ pour aucun objet situationnel : rien n'est affiché
    en trop, le système est simplement prêt à l'utiliser dès qu'un
    build en aura un.
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Build situationnel</h2>
        </div>

        <div id="build-situational-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des objets situationnels…</span>
        </div>

        <p id="build-situational-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <p id="build-situational-empty" class="text-muted" hidden>Aucun objet situationnel n'est encore renseigné pour ce champion.</p>

        <article id="build-situational-card" class="card build-item-group" hidden>
            <p class="card__eyebrow">Emplacement</p>
            <h3 class="card__title">Objets alternatifs</h3>
            <div id="build-situational-items" class="build-item-row"></div>
        </article>
    </div>
</section>

<!--
    Section 6 — Counters.
    Champions difficiles à affronter (ce champion est contré) et
    champions favorables (ce champion contre) — table `counters`
    consultée dans les deux sens (voir assets/js/champion-build.js::
    renderCountersSection()), avec portrait du champion adverse,
    difficulté (colonne `counters.difficulty`) et explication courte
    quand elle existe (colonne `counters.explanation`). Change
    automatiquement selon le champion demandé (filtré par championId,
    voir renderCounterEntry()/renderCountersSection()).
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Counters</h2>
        </div>

        <div id="build-counters-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des counters…</span>
        </div>

        <p id="build-counters-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <p id="build-counters-empty" class="text-muted" hidden>Aucun counter n'est encore renseigné pour ce champion.</p>

        <div id="build-counters-content" class="build-item-groups" hidden>
            <article class="card build-item-group">
                <p class="card__eyebrow">Difficile à affronter</p>
                <h3 class="card__title">Contré par…</h3>
                <div id="build-counters-difficult" class="stack" style="margin-top: var(--space-4);"></div>
            </article>

            <article class="card build-item-group">
                <p class="card__eyebrow">Favorable</p>
                <h3 class="card__title">Contre…</h3>
                <div id="build-counters-favorable" class="stack" style="margin-top: var(--space-4);"></div>
            </article>
        </div>
    </div>
</section>

<!--
    Section "Ordre des compétences".
    Emplacement pour le futur ordre de montée des compétences (voir
    build_skill_order dans database/schema.sql). Hors périmètre de la
    structure demandée pour cette étape (non modifiée) : structure
    posée uniquement, aucune donnée chargée.
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Ordre des compétences</h2>
        </div>

        <div id="build-skill-order-placeholder" class="card" style="padding: var(--space-6);">
            <p class="text-muted">L'ordre de montée des compétences sera bientôt disponible ici.</p>
        </div>
    </div>
</section>

<script src="<?= asset('assets/js/champion-build.js') ?>"></script>
