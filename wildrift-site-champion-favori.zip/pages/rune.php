<?php
/**
 * Page publique : Rune (détail).
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans rune.php.
 *
 * Le contenu réel est entièrement injecté par assets/js/rune.js, qui lit
 * l'ID dans l'URL (?id=) et interroge GET /api/runes/?id= au chargement
 * de la page — voir ce fichier pour le détail de la connexion à l'API.
 * Ce fichier PHP ne fait que poser la structure : un état de chargement
 * (visible en premier), une zone d'erreur (cachée par défaut, couvrant
 * aussi bien l'ID absent/invalide que la rune introuvable) et le
 * conteneur du détail (vide tant que l'API n'a pas répondu) — même
 * principe que pages/item.php, mais pour une rune, sans section
 * supplémentaire (pas de statistiques, capacités, builds, counters ou
 * synergies pour une rune).
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <div id="rune-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement de la rune…</span>
        </div>

        <p id="rune-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <article id="rune-detail" class="card" style="max-width: 40rem;" hidden></article>
    </div>
</section>

<script src="<?= asset('assets/js/rune.js') ?>"></script>
