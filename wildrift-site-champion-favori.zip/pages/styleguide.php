<?php
/**
 * Page publique : Design system.
 * Vitrine de tous les composants d'interface (couleurs, typographie,
 * boutons, cartes, badges, formulaires, menus, modales, loaders,
 * notifications). Sert de référence visuelle pour construire les futures
 * pages Wild Rift sur des composants cohérents.
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <p class="eyebrow">Design system</p>
        <h1>Hextech UI</h1>
        <p style="max-width: 60ch; font-size: var(--text-md);">
            Système de composants sombre et premium pour la plateforme Wild Rift :
            plaques biseautées, laiton gravé et énergie arcanique turquoise.
            Chaque composant ci-dessous est prêt à être réutilisé tel quel.
        </p>
    </div>
</section>

<!-- ===================== COULEURS ===================== -->
<section class="section" id="couleurs">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Fondations</p>
            <h2>Palette de couleurs</h2>
            <p>Six teintes nommées, pensées pour un fond sombre et une lisibilité durable.</p>
        </div>
        <div class="grid" style="grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));">
            <?php
            $swatches = [
                ['Void', '--color-void', '#0a0e16', 'Fond de base'],
                ['Plate', '--color-plate', '#141a24', 'Surface / cartes'],
                ['Brass', '--color-brass', '#c89b3c', 'Accent primaire'],
                ['Teal', '--color-teal', '#35d0c1', 'Accent secondaire'],
                ['Crimson', '--color-crimson', '#e5484d', 'Danger'],
                ['Mist', '--color-mist', '#8b93a6', 'Texte secondaire'],
            ];
            foreach ($swatches as [$name, $var, $hex, $usage]):
            ?>
            <div class="card" style="padding: 0; overflow: hidden;">
                <div style="height: 90px; background: var(<?= e($var) ?>);"></div>
                <div style="padding: var(--space-4);">
                    <div class="card__title" style="margin: 0;"><?= e($name) ?></div>
                    <div class="text-mono text-muted" style="font-size: var(--text-xs);"><?= e($hex) ?></div>
                    <p style="font-size: var(--text-xs); margin-top: var(--space-2);"><?= e($usage) ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ===================== TYPOGRAPHIE ===================== -->
<section class="section" id="typographie">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Fondations</p>
            <h2>Typographie</h2>
            <p>Rajdhani (titres, anguleux et technique) — Manrope (texte courant) — JetBrains Mono (statistiques, données).</p>
        </div>
        <div class="stack" style="flex-direction: column; align-items: flex-start; gap: var(--space-4);">
            <h1 style="margin: 0;">Titre H1 — Rajdhani 700</h1>
            <h2 style="margin: 0;">Titre H2 — Rajdhani 700</h2>
            <h3 style="margin: 0;">Titre H3 — Rajdhani 600</h3>
            <p style="font-size: var(--text-md); max-width: 60ch;">Texte courant en Manrope : lisible, moderne, avec une bonne prise en charge des accents français — à utiliser pour tous les paragraphes.</p>
            <p class="text-mono" style="font-size: var(--text-lg); color: var(--color-teal);">KDA 12/3/8 — 00:42 — JetBrains Mono</p>
        </div>
    </div>
</section>

<!-- ===================== BOUTONS ===================== -->
<section class="section" id="boutons">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Composants</p>
            <h2>Boutons</h2>
            <p>Survol : la ligne de pouvoir se dessine sous le bouton. Clic : micro-tassement. Focus clavier toujours visible.</p>
        </div>
        <div class="stack">
            <button type="button" class="btn">Primaire</button>
            <button type="button" class="btn btn--secondary">Secondaire</button>
            <button type="button" class="btn btn--ghost">Discret</button>
            <button type="button" class="btn btn--danger">Danger</button>
            <button type="button" class="btn" disabled>Désactivé</button>
            <button type="button" class="btn btn--sm">Petit</button>
            <button type="button" class="btn btn--lg">Grand</button>
        </div>
        <div class="stack" style="margin-top: var(--space-4);">
            <button type="button" class="btn" data-loading-demo>Valider (démo chargement)</button>
        </div>
    </div>
</section>

<!-- ===================== CARTES ===================== -->
<section class="section" id="cartes">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Composants</p>
            <h2>Cartes</h2>
            <p>Coin biseauté signature. Survol : légère élévation et bordure laiton.</p>
        </div>
        <div class="grid">
            <article class="card">
                <div class="card__eyebrow">Champion</div>
                <h3 class="card__title">Jinx</h3>
                <p>Tireuse — dégâts à distance explosifs en fin de partie.</p>
                <div class="card__foot">
                    <span class="badge badge--brass">Voie Bas</span>
                    <span class="text-mono text-muted" style="font-size: var(--text-xs);">52 % WR</span>
                </div>
            </article>
            <article class="card">
                <div class="card__eyebrow">Build</div>
                <h3 class="card__title">Lame de l'Infini</h3>
                <p>Objet critique cœur de build pour les tireurs late-game.</p>
                <div class="card__foot">
                    <span class="badge badge--teal">Populaire</span>
                    <span class="text-mono text-muted" style="font-size: var(--text-xs);">3 200 or</span>
                </div>
            </article>
            <article class="card card--featured">
                <div class="card__eyebrow">Mise en avant</div>
                <h3 class="card__title">Carte premium</h3>
                <p>Bordure dégradée animée — à réserver aux contenus mis en avant.</p>
                <div class="card__foot">
                    <span class="badge badge--brass badge--live"><span class="badge__dot"></span> En direct</span>
                </div>
            </article>
        </div>
    </div>
</section>

<!-- ===================== BADGES ===================== -->
<section class="section" id="badges">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Composants</p>
            <h2>Badges</h2>
        </div>
        <div class="stack">
            <span class="badge badge--brass">Or III</span>
            <span class="badge badge--teal">Support</span>
            <span class="badge badge--crimson">Ennemi</span>
            <span class="badge badge--verdant">Victoire</span>
            <span class="badge badge--live"><span class="badge__dot"></span> Live</span>
        </div>
    </div>
</section>

<!-- ===================== FORMULAIRES ===================== -->
<section class="section" id="formulaires">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Composants</p>
            <h2>Formulaires</h2>
        </div>
        <form style="max-width: 480px;" onsubmit="return false;">
            <div class="field">
                <label for="sg-pseudo">Pseudo d'invocateur</label>
                <input type="text" id="sg-pseudo" class="input" placeholder="Ex. FauxJinx">
                <p class="field__hint">Visible sur ton profil public.</p>
            </div>
            <div class="field is-invalid">
                <label for="sg-email">Email</label>
                <input type="email" id="sg-email" class="input" value="pas-un-email">
                <p class="field__error">Adresse email invalide.</p>
            </div>
            <div class="field">
                <label for="sg-role">Rôle préféré</label>
                <select id="sg-role" class="select">
                    <option>Voie du haut</option>
                    <option>Jungle</option>
                    <option>Mid</option>
                    <option>Voie du bas</option>
                    <option>Support</option>
                </select>
            </div>
            <div class="field">
                <label for="sg-notes">Notes</label>
                <textarea id="sg-notes" class="textarea" placeholder="Optionnel"></textarea>
            </div>
            <div class="field" style="display: flex; flex-direction: column; gap: var(--space-3);">
                <label class="checkbox"><input type="checkbox" checked> Me notifier des mises à jour</label>
                <label class="radio"><input type="radio" name="sg-radio" checked> Solo/Duo</label>
                <label class="radio"><input type="radio" name="sg-radio"> Flexible</label>
                <label class="toggle"><input type="checkbox" checked><span class="toggle__track"></span> Profil public</label>
            </div>
            <button type="submit" class="btn btn--block">Enregistrer</button>
        </form>
    </div>
</section>

<!-- ===================== MENUS ===================== -->
<section class="section" id="menus">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Composants</p>
            <h2>Menus</h2>
            <p>La navigation principale (en haut de page) est aussi un exemple de menu responsive. Ci-dessous : menu déroulant et onglets.</p>
        </div>

        <div class="stack" style="margin-bottom: var(--space-6);">
            <div class="dropdown" data-dropdown>
                <button type="button" class="dropdown__trigger">
                    Rôles
                    <svg class="chevron" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M2 4l4 4 4-4"/></svg>
                </button>
                <div class="dropdown__menu">
                    <a href="#">Voie du haut</a>
                    <a href="#">Jungle</a>
                    <a href="#">Mid</a>
                    <a href="#">Voie du bas</a>
                    <a href="#">Support</a>
                </div>
            </div>
        </div>

        <div data-tabs>
            <div class="tabs__list" role="tablist">
                <button type="button" class="tabs__tab" role="tab" aria-selected="true">Builds</button>
                <button type="button" class="tabs__tab" role="tab" aria-selected="false">Runes</button>
                <button type="button" class="tabs__tab" role="tab" aria-selected="false">Matchups</button>
            </div>
            <div class="tabs__panel" role="tabpanel"><p>Contenu de l'onglet Builds.</p></div>
            <div class="tabs__panel" role="tabpanel" hidden><p>Contenu de l'onglet Runes.</p></div>
            <div class="tabs__panel" role="tabpanel" hidden><p>Contenu de l'onglet Matchups.</p></div>
        </div>
    </div>
</section>

<!-- ===================== MODALES ===================== -->
<section class="section" id="modales">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Composants</p>
            <h2>Modales</h2>
        </div>
        <button type="button" class="btn btn--secondary" data-modal-open="sg-modal">Ouvrir la modale</button>

        <div class="modal-backdrop" id="sg-modal" data-open="false">
            <div class="modal" role="dialog" aria-modal="true" aria-labelledby="sg-modal-title">
                <div class="modal__head">
                    <h3 id="sg-modal-title" style="margin: 0;">Confirmer l'action</h3>
                    <button type="button" class="modal__close" data-modal-close aria-label="Fermer">&times;</button>
                </div>
                <p>Cette action est irréversible. Veux-tu continuer ?</p>
                <div class="modal__foot">
                    <button type="button" class="btn btn--ghost" data-modal-close>Annuler</button>
                    <button type="button" class="btn btn--danger" data-modal-close>Confirmer</button>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ===================== LOADERS ===================== -->
<section class="section" id="loaders">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Composants</p>
            <h2>Loaders</h2>
        </div>
        <div class="stack" style="margin-bottom: var(--space-5);">
            <div class="spinner"></div>
            <div class="spinner spinner--sm"></div>
        </div>
        <div style="max-width: 320px; margin-bottom: var(--space-5);">
            <p class="field__hint" style="margin-bottom: var(--space-2);">Progression déterminée</p>
            <div class="progress"><div class="progress__bar" style="--value: 65%;"></div></div>
        </div>
        <div style="max-width: 320px; margin-bottom: var(--space-5);">
            <p class="field__hint" style="margin-bottom: var(--space-2);">Progression indéterminée</p>
            <div class="progress progress--indeterminate"><div class="progress__bar"></div></div>
        </div>
        <div class="grid" style="grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); max-width: 640px;">
            <div class="skeleton" style="height: 120px;"></div>
            <div class="skeleton" style="height: 120px;"></div>
        </div>
    </div>
</section>

<!-- ===================== NOTIFICATIONS ===================== -->
<section class="section" id="notifications">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Composants</p>
            <h2>Notifications</h2>
            <p>Empilables, se referment automatiquement (barre de progression) ou au clic.</p>
        </div>
        <div class="stack">
            <button type="button" class="btn btn--secondary" data-toast data-toast-variant="brass" data-toast-title="Build sauvegardé" data-toast-body="Ton build a été ajouté à tes favoris.">Notification par défaut</button>
            <button type="button" class="btn btn--secondary" data-toast data-toast-variant="success" data-toast-title="Partie terminée" data-toast-body="Victoire en 24 minutes.">Succès</button>
            <button type="button" class="btn btn--secondary" data-toast data-toast-variant="danger" data-toast-title="Connexion perdue" data-toast-body="Reconnexion en cours…">Erreur</button>
        </div>
    </div>
</section>
