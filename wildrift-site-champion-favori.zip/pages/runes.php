<?php
/**
 * Page publique : Runes.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans runes.php.
 *
 * Le contenu réel (la liste des runes) est entièrement injecté par
 * assets/js/runes.js, qui interroge GET /api/runes/ au chargement de la
 * page — voir ce fichier pour le détail de la connexion à l'API. Ce
 * fichier PHP ne fait que poser la structure : un formulaire de
 * recherche par nom, de filtre par arbre et de filtre par emplacement
 * (#runes-search-form, voir GET /api/runes/?search=, ?tree= et ?slot=
 * dans api/runes/repository.php — tous combinables), un état de
 * chargement (visible en premier), une zone d'erreur (cachée par
 * défaut) et le conteneur de la grille de résultats (vide tant que
 * l'API n'a pas répondu) — même structure que pages/items.php.
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <p class="eyebrow">Wild Rift</p>
        <h1>Runes</h1>
        <p style="max-width: 60ch; font-size: var(--text-md);">
            Toutes les runes disponibles sur la plateforme, classées par
            arbre.
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <form id="runes-search-form" class="stack" style="flex-direction: row; flex-wrap: wrap; align-items: center; gap: var(--space-3); margin-bottom: var(--space-6);">
            <label for="runes-search-input" class="text-muted" style="font-size: var(--text-sm);">Rechercher une rune</label>
            <input
                type="search"
                id="runes-search-input"
                name="search"
                placeholder="Nom de la rune…"
                maxlength="60"
                class="input"
            >

            <label for="runes-tree-filter" class="text-muted" style="font-size: var(--text-sm);">Arbre</label>
            <select id="runes-tree-filter" name="tree" class="select">
                <option value="">Tous les arbres</option>
                <!-- Une <option> par arbre est ajoutée dynamiquement par
                     assets/js/runes.js::populateRuneTreeFilter(), à partir
                     de GET /api/rune-trees/ (voir api/rune-trees/index.php)
                     — l'ENUM runes.tree n'est plus dupliqué ici. -->
            </select>

            <label for="runes-slot-filter" class="text-muted" style="font-size: var(--text-sm);">Emplacement</label>
            <select id="runes-slot-filter" name="slot" class="select">
                <option value="">Tous les emplacements</option>
                <option value="keystone">Rune majeure</option>
                <option value="minor">Rune mineure</option>
            </select>

            <button type="submit" class="btn btn--sm">Rechercher</button>
            <button type="button" id="runes-search-reset" class="btn btn--secondary btn--sm">Réinitialiser</button>
        </form>

        <div id="runes-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des runes…</span>
        </div>

        <p id="runes-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="runes-grid" class="grid"></div>
    </div>
</section>

<script src="<?= asset('assets/js/runes.js') ?>"></script>
