<?php
/**
 * Page publique : Inscription.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans register.php.
 *
 * Étape actuelle : le formulaire d'inscription (pseudo, email, mot de
 * passe, confirmation, acceptation des conditions) avec validation à la
 * fois côté navigateur (attributs HTML natifs + assets/js/register.js
 * pour la confirmation du mot de passe) et côté serveur (voir le
 * traitement dans register.php, qui remplit $registerErrors /
 * $registerSuccess / $oldPseudo / $oldEmail avant d'inclure ce fichier) :
 * validation des champs, unicité du pseudo/email, hachage sécurisé du
 * mot de passe (password_hash()) et création du compte dans `users`.
 *
 * En cas de succès : message de confirmation affiché puis redirection
 * automatique vers login.php (délai court, avec lien manuel en secours
 * si la redirection JS ne se déclenche pas).
 *
 * Hors périmètre de cette étape : la connexion automatique après
 * inscription (SESSION_USER_KEY, voir config/session.php) — l'utilisateur
 * est simplement invité à se connecter une fois son compte créé.
 */
$registerErrors ??= [];
$registerSuccess ??= false;
$oldPseudo ??= '';
$oldEmail ??= '';

$fieldHasError = static function (string $field) use ($registerErrors): bool {
    return isset($registerErrors[$field]);
};
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container" style="max-width: 32rem;">
        <h1>Créer un compte</h1>
        <p class="text-muted" style="margin-bottom: var(--space-6);">
            Rejoins la communauté pour sauvegarder tes builds et suivre tes champions favoris.
        </p>

        <?php if ($registerSuccess): ?>
            <div style="padding: var(--space-4); border: 1px solid var(--color-verdant); border-radius: var(--radius-md, 8px); color: var(--color-verdant); margin-bottom: var(--space-6);">
                Ton compte a bien été créé. Tu vas être redirigé vers la page de connexion...
                Si rien ne se passe, <a href="<?= asset('login.php') ?>">clique ici pour te connecter</a>.
            </div>
            <script>
                setTimeout(function () {
                    window.location.href = <?= json_encode(asset('login.php'), JSON_UNESCAPED_SLASHES) ?>;
                }, 2500);
            </script>
        <?php else: ?>
            <?php if ($fieldHasError('global')): ?>
                <div style="padding: var(--space-4); border: 1px solid var(--color-crimson); border-radius: var(--radius-md, 8px); color: var(--color-crimson); margin-bottom: var(--space-6);">
                    <?= e($registerErrors['global']) ?>
                </div>
            <?php elseif (!empty($registerErrors)): ?>
                <div style="padding: var(--space-4); border: 1px solid var(--color-crimson); border-radius: var(--radius-md, 8px); color: var(--color-crimson); margin-bottom: var(--space-6);">
                    Corrige les champs indiqués ci-dessous avant de continuer.
                </div>
            <?php endif; ?>

            <form id="register-form" action="<?= asset('register.php') ?>" method="post" novalidate>
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

                <div class="field<?= $fieldHasError('pseudo') ? ' is-invalid' : '' ?>">
                    <label for="register-pseudo">Pseudo d'invocateur</label>
                    <input
                        type="text"
                        id="register-pseudo"
                        name="pseudo"
                        class="input"
                        placeholder="Ex. FauxJinx"
                        value="<?= e($oldPseudo) ?>"
                        minlength="3"
                        maxlength="20"
                        pattern="[A-Za-z0-9_]+"
                        autocomplete="username"
                        required
                    >
                    <p class="field__hint">3 à 20 caractères : lettres, chiffres et underscore uniquement.</p>
                    <p class="field__error">Choisis un pseudo de 3 à 20 caractères (lettres, chiffres, underscore).</p>
                </div>

                <div class="field<?= $fieldHasError('email') ? ' is-invalid' : '' ?>">
                    <label for="register-email">Email</label>
                    <input
                        type="email"
                        id="register-email"
                        name="email"
                        class="input"
                        placeholder="toi@exemple.com"
                        value="<?= e($oldEmail) ?>"
                        autocomplete="email"
                        required
                    >
                    <p class="field__hint">Utilisée uniquement pour la connexion à ton compte.</p>
                    <p class="field__error">Saisis une adresse email valide.</p>
                </div>

                <div class="field<?= $fieldHasError('password') ? ' is-invalid' : '' ?>">
                    <label for="register-password">Mot de passe</label>
                    <input
                        type="password"
                        id="register-password"
                        name="password"
                        class="input"
                        minlength="8"
                        maxlength="72"
                        autocomplete="new-password"
                        required
                    >
                    <p class="field__hint">Entre 8 et 72 caractères.</p>
                    <p class="field__error"><?= $fieldHasError('password') ? e($registerErrors['password']) : 'Le mot de passe doit contenir au moins 8 caractères.' ?></p>
                </div>

                <div class="field<?= $fieldHasError('password_confirm') ? ' is-invalid' : '' ?>">
                    <label for="register-password-confirm">Confirmation du mot de passe</label>
                    <input
                        type="password"
                        id="register-password-confirm"
                        name="password_confirm"
                        class="input"
                        minlength="8"
                        maxlength="72"
                        autocomplete="new-password"
                        required
                    >
                    <p class="field__error">Les deux mots de passe ne correspondent pas.</p>
                </div>

                <div class="field<?= $fieldHasError('terms') ? ' is-invalid' : '' ?>">
                    <label class="checkbox">
                        <input type="checkbox" id="register-terms" name="terms" required>
                        J'accepte les conditions d'utilisation
                    </label>
                    <p class="field__error">Tu dois accepter les conditions d'utilisation pour créer un compte.</p>
                </div>

                <button type="submit" class="btn btn--block">Créer mon compte</button>
            </form>

            <p class="text-muted" style="margin-top: var(--space-5); text-align: center;">
                Déjà un compte ? <a href="<?= asset('login.php') ?>">Se connecter</a>
            </p>
        <?php endif; ?>
    </div>
</section>

<script src="<?= asset('assets/js/register.js') ?>"></script>
