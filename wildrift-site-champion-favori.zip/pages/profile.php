<?php
/**
 * Page publique : Profil.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans profile.php.
 *
 * Étape actuelle : la page affiche les vraies informations du compte
 * connecté (pseudo, email, bio, avatar, date d'inscription — voir
 * $currentUser, préparé par profile.php) et traite réellement les
 * trois formulaires de modification (pseudo, bio, avatar) : validation,
 * unicité du pseudo, stockage sécurisé de l'avatar, mise à jour dans
 * `users` (tout le traitement vit dans profile.php, avant l'inclusion
 * du header — voir son commentaire d'en-tête). La vérification de
 * session (redirection vers login.php si non connecté) vit elle aussi
 * désormais dans profile.php, avant tout affichage.
 *
 * La section "Builds favoris" affiche désormais directement les builds
 * réellement en favoris pour ce compte (voir $favoriteBuilds, préparé
 * par profile.php par jointure sur `builds`/`champions`) : chacun avec
 * un lien pour l'ouvrir (build.php?id=) et un bouton "Retirer" qui
 * poste son ID seul vers profile.php (voir le traitement du formulaire
 * "remove_favorite_build").
 *
 * Hors périmètre : la section "Champions favoris" reste sans
 * sauvegarde réelle (dépend d'une table de liaison — ex.
 * `user_favorite_champions` — toujours pas ajoutée à
 * database/schema.sql).
 */
$profileErrors ??= [];
$oldPseudo ??= $currentUser['pseudo'];
$oldBio ??= ($currentUser['bio'] ?? '');
$savedFlag ??= '';
$favoriteBuilds ??= [];
$favoriteChampion ??= null;
$championChoices ??= [];

$buildRoleLabels = [
    'baron' => 'Voie Baron',
    'jungle' => 'Jungle',
    'mid' => 'Voie du Milieu',
    'dragon' => 'Voie Dragon',
    'support' => 'Support',
];

$fieldHasError = static function (string $field) use ($profileErrors): bool {
    return isset($profileErrors[$field]);
};

$memberSince = null;
if (!empty($currentUser['created_at'])) {
    $memberSinceDate = date_create($currentUser['created_at']);
    if ($memberSinceDate !== false) {
        $memberSince = $memberSinceDate->format('d/m/Y');
    }
}
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container" style="max-width: 32rem;">
        <h1>Profil</h1>

        <?php if ($fieldHasError('global')): ?>
            <div style="padding: var(--space-4); border: 1px solid var(--color-crimson); border-radius: var(--radius-md, 8px); color: var(--color-crimson); margin-bottom: var(--space-5);">
                <?= e($profileErrors['global']) ?>
            </div>
        <?php endif; ?>

        <div
            class="card<?= $favoriteChampion ? ' profile-hero' : '' ?>"
            style="padding: var(--space-6);"
            <?= $favoriteChampion ? 'data-role="' . e($favoriteChampion['role']) . '"' : '' ?>
        >
            <?php if ($favoriteChampion): ?>
                <div class="profile-hero__bg" aria-hidden="true">
                    <?php if (!empty($favoriteChampion['image_url'])): ?>
                        <img
                            class="profile-hero__img"
                            src="<?= e($favoriteChampion['image_url']) ?>"
                            alt=""
                            loading="lazy"
                            onerror="this.remove()"
                        >
                    <?php endif; ?>
                    <span class="profile-hero__glow"></span>
                    <span class="profile-hero__ember profile-hero__ember--1"></span>
                    <span class="profile-hero__ember profile-hero__ember--2"></span>
                    <span class="profile-hero__ember profile-hero__ember--3"></span>
                </div>
            <?php endif; ?>

            <?php if ($currentUser['avatar']): ?>
                <img
                    src="<?= e(asset('uploads/' . $currentUser['avatar'])) ?>"
                    alt="Avatar de <?= e($currentUser['pseudo']) ?>"
                    style="width: 4.5rem; height: 4.5rem; border-radius: 50%; object-fit: cover; margin-bottom: var(--space-4);"
                >
            <?php endif; ?>

            <p><strong><?= e($currentUser['pseudo']) ?></strong></p>
            <p class="text-muted"><?= e($currentUser['email']) ?></p>
            <?php if ($memberSince): ?>
                <p class="text-muted">Membre depuis le <?= e($memberSince) ?></p>
            <?php endif; ?>
            <?php if (!empty($currentUser['bio'])): ?>
                <p style="margin-top: var(--space-4);"><?= nl2br(e($currentUser['bio'])) ?></p>
            <?php endif; ?>

            <form action="<?= asset('logout.php') ?>" method="post" style="margin-top: var(--space-5);">
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <button type="submit" class="btn btn--secondary">Se déconnecter</button>
            </form>
        </div>

        <div class="card" style="padding: var(--space-6); margin-top: var(--space-5);">
            <h2>Modifier le pseudo</h2>

            <?php if ($savedFlag === 'pseudo'): ?>
                <p style="color: var(--color-verdant); margin-bottom: var(--space-4);">Pseudo mis à jour.</p>
            <?php endif; ?>

            <form id="profile-pseudo-form" action="<?= asset('profile.php') ?>" method="post" novalidate>
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="form" value="pseudo">

                <div class="field<?= $fieldHasError('pseudo') ? ' is-invalid' : '' ?>">
                    <label for="profile-pseudo">Nouveau pseudo d'invocateur</label>
                    <input
                        type="text"
                        id="profile-pseudo"
                        name="pseudo"
                        class="input"
                        placeholder="Ex. FauxJinx"
                        value="<?= e($oldPseudo) ?>"
                        minlength="3"
                        maxlength="20"
                        pattern="[A-Za-z0-9_]+"
                        autocomplete="username"
                        required
                    >
                    <p class="field__hint">3 à 20 caractères : lettres, chiffres et underscore uniquement.</p>
                    <p class="field__error"><?= $fieldHasError('pseudo') ? e($profileErrors['pseudo']) : "Choisis un pseudo de 3 à 20 caractères (lettres, chiffres, underscore)." ?></p>
                </div>

                <button type="submit" class="btn btn--sm">Enregistrer</button>
            </form>
        </div>

        <div class="card" style="padding: var(--space-6); margin-top: var(--space-5);">
            <h2>Modifier la bio</h2>

            <?php if ($savedFlag === 'bio'): ?>
                <p style="color: var(--color-verdant); margin-bottom: var(--space-4);">Bio mise à jour.</p>
            <?php endif; ?>

            <form id="profile-bio-form" action="<?= asset('profile.php') ?>" method="post" novalidate>
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="form" value="bio">

                <div class="field<?= $fieldHasError('bio') ? ' is-invalid' : '' ?>">
                    <label for="profile-bio">Bio</label>
                    <textarea
                        id="profile-bio"
                        name="bio"
                        class="textarea"
                        placeholder="Quelques mots sur toi, ton style de jeu, tes champions favoris..."
                        maxlength="280"
                    ><?= e($oldBio) ?></textarea>
                    <p class="field__hint">280 caractères maximum. Visible sur ton profil public.</p>
                    <p class="field__error">La bio ne peut pas dépasser 280 caractères.</p>
                </div>

                <button type="submit" class="btn btn--sm">Enregistrer</button>
            </form>
        </div>

        <div class="card" style="padding: var(--space-6); margin-top: var(--space-5);">
            <h2>Modifier l'avatar</h2>

            <?php if ($savedFlag === 'avatar'): ?>
                <p style="color: var(--color-verdant); margin-bottom: var(--space-4);">Avatar mis à jour.</p>
            <?php endif; ?>

            <form id="profile-avatar-form" action="<?= asset('profile.php') ?>" method="post" enctype="multipart/form-data" novalidate>
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="form" value="avatar">

                <div class="field<?= $fieldHasError('avatar') ? ' is-invalid' : '' ?>">
                    <label for="profile-avatar">Nouvel avatar</label>
                    <input
                        type="file"
                        id="profile-avatar"
                        name="avatar"
                        class="input"
                        accept="<?= e($avatarAcceptAttr) ?>"
                        data-max-size-bytes="<?= (int) UPLOAD_MAX_SIZE_BYTES ?>"
                        data-allowed-extensions="<?= e(implode(',', $avatarAllowedExtensions)) ?>"
                        required
                    >
                    <p class="field__hint">
                        Formats acceptés : <?= e(strtoupper(implode(', ', $avatarAllowedExtensions))) ?>
                        — <?= (int) UPLOAD_MAX_SIZE_MB ?> Mo maximum.
                    </p>
                    <p class="field__error"><?= $fieldHasError('avatar') ? e($profileErrors['avatar']) : 'Fichier invalide : vérifie le format et la taille.' ?></p>
                </div>

                <button type="submit" class="btn btn--sm">Enregistrer</button>
            </form>
        </div>

        <div class="card" style="padding: var(--space-6); margin-top: var(--space-5);">
            <h2>Champion favori</h2>
            <p class="text-muted" style="margin-bottom: var(--space-5);">
                Ton champion apparaît en arrière-plan de ton profil.
            </p>

            <?php if ($savedFlag === 'favorite_champion'): ?>
                <p style="color: var(--color-verdant); margin-bottom: var(--space-4);">Champion favori mis à jour.</p>
            <?php endif; ?>

            <form id="profile-favorite-champion-form" action="<?= asset('profile.php') ?>" method="post" novalidate>
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="form" value="favorite_champion">

                <div class="field<?= $fieldHasError('favorite_champion') ? ' is-invalid' : '' ?>">
                    <label for="profile-favorite-champion">Mon champion favori</label>
                    <select id="profile-favorite-champion" name="champion_id" class="select">
                        <option value="0">Aucun</option>
                        <?php foreach ($championChoices as $championChoice): ?>
                            <option
                                value="<?= (int) $championChoice['id'] ?>"
                                <?= $favoriteChampion && (int) $favoriteChampion['id'] === (int) $championChoice['id'] ? 'selected' : '' ?>
                            ><?= e($championChoice['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="field__error"><?= $fieldHasError('favorite_champion') ? e($profileErrors['favorite_champion']) : 'Champion invalide.' ?></p>
                </div>

                <button type="submit" class="btn btn--sm">Enregistrer</button>
            </form>
        </div>

        <div class="card" style="padding: var(--space-6); margin-top: var(--space-5);">
            <h2>Champions favoris</h2>
            <p class="text-muted" style="margin-bottom: var(--space-5);">
                Sélectionne les champions que tu joues le plus souvent.
            </p>

            <form id="profile-favorites-form" action="<?= asset('profile.php') ?>" method="post" novalidate>
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

                <div id="profile-favorites-loading" class="stack">
                    <div class="spinner"></div>
                    <span class="text-muted">Chargement des champions…</span>
                </div>

                <p id="profile-favorites-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

                <div
                    id="profile-favorites-list"
                    class="field"
                    style="display: flex; flex-direction: column; gap: var(--space-3);"
                    hidden
                ></div>

                <button type="submit" class="btn btn--sm" style="margin-top: var(--space-5);">Enregistrer</button>
            </form>
        </div>

        <div class="card" style="padding: var(--space-6); margin-top: var(--space-5);">
            <h2>Builds favoris</h2>

            <?php if ($savedFlag === 'favorite_build_removed'): ?>
                <p style="color: var(--color-verdant); margin-bottom: var(--space-4);">Build retiré des favoris.</p>
            <?php endif; ?>

            <?php if (empty($favoriteBuilds)): ?>
                <p class="text-muted">Tu n'as pas encore de build favori.</p>
            <?php else: ?>
                <div style="display: flex; flex-direction: column; gap: var(--space-3);">
                    <?php foreach ($favoriteBuilds as $favoriteBuild): ?>
                        <div
                            class="card"
                            style="padding: var(--space-4); display: flex; align-items: center; justify-content: space-between; gap: var(--space-4);"
                        >
                            <div>
                                <a href="<?= e(asset('build.php?id=' . $favoriteBuild['id'])) ?>">
                                    <strong><?= e($favoriteBuild['name']) ?></strong>
                                </a>
                                <p class="text-muted" style="margin-top: var(--space-1);">
                                    <?= e($favoriteBuild['champion']) ?>
                                    · <?= e($buildRoleLabels[$favoriteBuild['role']] ?? $favoriteBuild['role']) ?>
                                    · Patch <?= e($favoriteBuild['patch']) ?>
                                </p>
                            </div>

                            <form action="<?= asset('profile.php') ?>" method="post">
                                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                <input type="hidden" name="form" value="remove_favorite_build">
                                <input type="hidden" name="build_id" value="<?= (int) $favoriteBuild['id'] ?>">
                                <button type="submit" class="btn btn--danger btn--sm">Retirer</button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<script src="<?= asset('assets/js/profile.js') ?>"></script>
