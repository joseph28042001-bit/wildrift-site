<?php
/**
 * Page publique : Champions.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans champions.php.
 *
 * Le contenu réel (la liste des champions) est entièrement injecté par
 * assets/js/champions.js, qui interroge GET /api/champions/ au chargement
 * de la page — voir ce fichier pour le détail de la connexion à l'API.
 * Ce fichier PHP ne fait que poser la structure : un formulaire de
 * recherche par nom et de filtre par rôle (#champions-search-form, voir
 * GET /api/champions/?search= et ?role= dans api/champions/repository.php
 * — combinables), un état de chargement (visible en premier), une zone
 * d'erreur (cachée par défaut) et le conteneur de la grille de résultats
 * (vide tant que l'API n'a pas répondu).
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <p class="eyebrow">Wild Rift</p>
        <h1>Champions</h1>
        <p style="max-width: 60ch; font-size: var(--text-md);">
            Tous les champions disponibles sur la plateforme, avec leur rôle
            et leur niveau de difficulté.
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <form id="champions-search-form" class="stack" style="flex-direction: row; flex-wrap: wrap; align-items: center; gap: var(--space-3); margin-bottom: var(--space-6);">
            <label for="champions-search-input" class="text-muted" style="font-size: var(--text-sm);">Rechercher un champion</label>
            <input
                type="search"
                id="champions-search-input"
                name="search"
                placeholder="Nom du champion…"
                maxlength="60"
                class="input"
            >

            <label for="champions-role-filter" class="text-muted" style="font-size: var(--text-sm);">Rôle</label>
            <select id="champions-role-filter" name="role" class="select">
                <option value="">Tous les rôles</option>
                <option value="baron">Voie Baron</option>
                <option value="jungle">Jungle</option>
                <option value="mid">Voie du Milieu</option>
                <option value="dragon">Voie Dragon</option>
                <option value="support">Support</option>
            </select>

            <button type="submit" class="btn btn--sm">Rechercher</button>
            <button type="button" id="champions-search-reset" class="btn btn--secondary btn--sm">Réinitialiser</button>
        </form>

        <div id="champions-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des champions…</span>
        </div>

        <p id="champions-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="champions-grid" class="grid"></div>
    </div>
</section>

<script src="<?= asset('assets/js/champions.js') ?>"></script>
