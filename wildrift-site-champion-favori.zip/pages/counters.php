<?php
/**
 * Page publique : Matchups & counters.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans counters.php.
 *
 * Le contenu réel (la liste des counters) est entièrement injecté par
 * assets/js/counters.js, qui interroge GET /api/counters/ au chargement
 * de la page — voir ce fichier pour le détail de la connexion à l'API.
 * Ce fichier PHP ne fait que poser la structure : un état de chargement
 * (visible en premier), une zone d'erreur (cachée par défaut) et le
 * conteneur de la grille de résultats (vide tant que l'API n'a pas
 * répondu) — même structure que pages/builds.php et pages/runes.php.
 *
 * GET /api/counters/ (sans paramètre) renvoie tous les counters : pas de
 * filtre par champion (?champion_id=, ?counter_champion_id=) câblé côté
 * client à ce stade, même limite volontaire que la page Builds (pas de
 * filtre champion/rôle/patch).
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <p class="eyebrow">Wild Rift</p>
        <h1>Matchups &amp; counters</h1>
        <p style="max-width: 60ch; font-size: var(--text-md);">
            Comment contrer chaque champion : explication, conseils et
            objets recommandés.
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div id="counters-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des counters…</span>
        </div>

        <p id="counters-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="counters-grid" class="grid"></div>
    </div>
</section>

<script src="<?= asset('assets/js/counters.js') ?>"></script>
