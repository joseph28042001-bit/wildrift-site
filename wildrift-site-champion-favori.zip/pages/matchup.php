<?php
/**
 * Page publique : Matchup (détail).
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans matchup.php.
 *
 * Le contenu réel est entièrement injecté par assets/js/matchup.js, qui
 * lit l'ID du matchup dans l'URL (?id=, celui du counter — voir
 * matchup.php) et interroge GET /api/counters/?id= au chargement de la
 * page — voir ce fichier pour le détail de la connexion à l'API. Ce
 * fichier PHP ne fait que poser la structure : un état de chargement
 * (visible en premier), une zone d'erreur (cachée par défaut, couvrant
 * aussi bien l'ID absent/invalide que le matchup introuvable) et les
 * conteneurs du détail (vides tant que l'API n'a pas répondu) — même
 * principe que pages/champion.php, mais pour un matchup plutôt qu'un
 * champion.
 *
 * Le détail se découpe en cinq blocs, tous remplis par la même réponse
 * API (un seul appel, GET /api/counters/?id=, contrairement à
 * pages/champion.php qui enchaîne plusieurs appels) :
 *   1. Les deux champions du matchup (celui qui est contré et celui qui
 *      contre), chacun résolu séparément via GET /api/champions/?id=
 *      (l'API /api/counters/ ne renvoie que des ID bruts, voir
 *      COUNTER_SELECT_COLUMNS, api/counters/repository.php) ;
 *   2. L'analyse du matchup : explication et difficulté (colonnes
 *      `explanation`/`difficulty` de la table `counters`) ;
 *   3. Les conseils pratiques du matchup (colonne `tips` de la table
 *      `counters`), dans leur propre section — voir plus bas ;
 *   4. Les objets recommandés de base pour contrer le champion adverse
 *      (relation `counter_items`, déjà incluse dans la réponse de
 *      GET /api/counters/?id= — voir findCounterItems(),
 *      api/counters/repository.php), avec leur ordre d'achat conseillé
 *      — uniquement ceux sans `situation` renseignée (voir point 5) ;
 *   5. Les recommandations d'objets situationnels : les objets de la
 *      même relation `counter_items` dont la colonne `situation` est
 *      renseignée (contexte de jeu précis justifiant l'achat, plutôt
 *      qu'un objet systématique), dans leur propre section — voir plus
 *      bas.
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <div id="matchup-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement du matchup…</span>
        </div>

        <p id="matchup-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="matchup-detail" hidden>
            <p class="eyebrow">Wild Rift · Matchups &amp; counters</p>
            <h1 id="matchup-title"></h1>

            <div id="matchup-champions" class="grid" style="grid-template-columns: repeat(2, 1fr); margin-top: var(--space-6);"></div>
        </div>
    </div>
</section>

<!--
    Section "Analyse".
    Explication du contre (colonne `explanation` de la table `counters`),
    ainsi que la difficulté du matchup (badge) — mêmes données que sur
    une carte de pages/counters.php (assets/js/counters.js::renderCounterCard()),
    mais présentées ici en détail plutôt qu'en carte compacte. Cachée
    tant que le matchup n'est pas chargé (voir assets/js/matchup.js).
    Les conseils pratiques (`tips`) sont affichés dans leur propre
    section, juste en dessous, plutôt qu'ici.
-->
<section class="section" id="matchup-analysis-section" hidden>
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Analyse du matchup</h2>
        </div>

        <div class="card" style="max-width: 60rem;">
            <p id="matchup-explanation" class="text-muted" hidden></p>

            <div class="card__foot" id="matchup-difficulty-foot" hidden>
                <span id="matchup-difficulty-badge" class="badge"></span>
            </div>
        </div>
    </div>
</section>

<!--
    Section "Conseils".
    Conseils pratiques pour jouer le matchup (colonne `tips` de la table
    `counters` — timing, objets, positionnement..., distincts de
    `explanation` ci-dessus, voir api/counters/repository.php). Section
    séparée de "Analyse du matchup", sur le même principe que les
    sections indépendantes de pages/champion.php (une section par
    concept). Cachée tant que le matchup n'est pas chargé ; le message
    "vide" reste utile, un matchup pouvant n'avoir encore aucun conseil
    renseigné (colonne nullable).
-->
<section class="section" id="matchup-tips-section" hidden>
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Conseils</h2>
        </div>

        <p id="matchup-tips-empty" class="text-muted" hidden>Aucun conseil n'est encore renseigné pour ce matchup.</p>

        <div class="card" id="matchup-tips-card" style="max-width: 60rem;" hidden>
            <p id="matchup-tips"></p>
        </div>
    </div>
</section>

<!--
    Section "Objets recommandés".
    Objets de base à acheter pour contrer le champion adverse (relation
    `counter_items`, jointe à `items` — voir findCounterItems(),
    api/counters/repository.php), triés par ordre d'achat conseillé.
    Ne contient que les objets sans `situation` renseignée : les objets
    situationnels (avec `situation`) ont leur propre section juste en
    dessous, plutôt que d'être mélangés ici. Même principe de bloc que
    les sections de pages/champion.php : chargement/erreur/vide propres
    à cette section, bien qu'ici les objets fassent déjà partie de la
    réponse GET /api/counters/?id= (pas d'appel réseau supplémentaire)
    — l'état "vide" reste utile, un matchup pouvant n'avoir encore
    aucun objet de base associé (par ex. si tous ses objets sont
    situationnels).
-->
<section class="section" id="matchup-items-section" hidden>
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Objets recommandés</h2>
        </div>

        <p id="matchup-items-empty" class="text-muted" hidden>Aucun objet recommandé n'est encore associé à ce matchup.</p>

        <div id="matchup-items-grid" class="grid"></div>
    </div>
</section>

<!--
    Section "Recommandations d'objets situationnels".
    Objets de la même relation `counter_items` dont la colonne
    `situation` est renseignée : à acheter seulement dans un contexte de
    jeu précis (l'adversaire prend l'avantage, une menace particulière
    apparaît en face...), plutôt que systématiquement — voir
    findCounterItems(), api/counters/repository.php, et
    database/schema.sql pour le détail de la colonne. Section séparée
    des objets de base ci-dessus, sur le même principe qu'une section
    par concept (voir la section "Conseils" plus haut). Chaque carte
    affiche, en plus du nom et de la catégorie de l'objet, le texte de
    `situation` expliquant quand et pourquoi l'acheter. Le message
    "vide" reste utile, un matchup pouvant n'avoir encore aucun objet
    situationnel renseigné.
-->
<section class="section" id="matchup-situational-items-section" hidden>
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Recommandations d'objets situationnels</h2>
        </div>

        <p id="matchup-situational-items-empty" class="text-muted" hidden>Aucune recommandation d'objet situationnel n'est encore associée à ce matchup.</p>

        <div id="matchup-situational-items-grid" class="grid"></div>
    </div>
</section>

<script src="<?= asset('assets/js/matchup.js') ?>"></script>
