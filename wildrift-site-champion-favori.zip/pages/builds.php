<?php
/**
 * Page publique : Builds.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans builds.php.
 *
 * Le contenu réel (la liste des builds) est entièrement injecté par
 * assets/js/builds.js, qui interroge GET /api/builds/ au chargement de
 * la page — voir ce fichier pour le détail de la connexion à l'API. Ce
 * fichier PHP ne fait que poser la structure : un formulaire de
 * recherche par nom et de filtre par champion (slug), rôle et patch
 * (#builds-search-form, voir GET /api/builds/?search=, ?champion=,
 * ?role= et ?patch= dans api/builds/repository.php — tous combinables),
 * un état de chargement (visible en premier), une zone d'erreur (cachée
 * par défaut), le conteneur de la grille de résultats (vide tant que
 * l'API n'a pas répondu) et des contrôles de pagination (Précédent/
 * Suivant, voir ?page= — même API, meta.pagination) — même structure
 * que pages/items.php et pages/runes.php, pagination en plus.
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <p class="eyebrow">Wild Rift</p>
        <h1>Builds</h1>
        <p style="max-width: 60ch; font-size: var(--text-md);">
            Une sélection de builds recommandés, avec le champion, le
            rôle et le patch associés.
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <form id="builds-search-form" class="stack" style="flex-direction: row; flex-wrap: wrap; align-items: center; gap: var(--space-3); margin-bottom: var(--space-6);">
            <label for="builds-search-input" class="text-muted" style="font-size: var(--text-sm);">Rechercher un build</label>
            <input
                type="search"
                id="builds-search-input"
                name="search"
                placeholder="Nom du build…"
                maxlength="60"
                class="input"
            >

            <label for="builds-champion-input" class="text-muted" style="font-size: var(--text-sm);">Champion</label>
            <input
                type="text"
                id="builds-champion-input"
                name="champion"
                placeholder="Slug du champion, ex. jinx"
                maxlength="60"
                class="input"
            >

            <label for="builds-role-filter" class="text-muted" style="font-size: var(--text-sm);">Rôle</label>
            <select id="builds-role-filter" name="role" class="select">
                <option value="">Tous les rôles</option>
                <option value="baron">Voie Baron</option>
                <option value="jungle">Jungle</option>
                <option value="mid">Voie du Milieu</option>
                <option value="dragon">Voie Dragon</option>
                <option value="support">Support</option>
            </select>

            <label for="builds-patch-input" class="text-muted" style="font-size: var(--text-sm);">Patch</label>
            <input
                type="text"
                id="builds-patch-input"
                name="patch"
                placeholder="ex. 5.2"
                maxlength="10"
                class="input"
            >

            <button type="submit" class="btn btn--sm">Rechercher</button>
            <button type="button" id="builds-search-reset" class="btn btn--secondary btn--sm">Réinitialiser</button>
        </form>

        <div id="builds-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des builds…</span>
        </div>

        <p id="builds-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="builds-grid" class="grid"></div>

        <div id="builds-pagination" class="stack" style="flex-direction: row; align-items: center; justify-content: center; gap: var(--space-3); margin-top: var(--space-6);" hidden>
            <button type="button" id="builds-page-prev" class="btn btn--secondary btn--sm">Précédent</button>
            <span id="builds-page-info" class="text-mono text-muted" style="font-size: var(--text-sm);"></span>
            <button type="button" id="builds-page-next" class="btn btn--secondary btn--sm">Suivant</button>
        </div>
    </div>
</section>

<script src="<?= asset('assets/js/builds.js') ?>"></script>
