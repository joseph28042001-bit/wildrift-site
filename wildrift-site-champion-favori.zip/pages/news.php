<?php
/**
 * Page publique : Actualités.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans news.php.
 *
 * Le contenu réel (la liste des articles) est entièrement injecté par
 * assets/js/news.js, déjà chargé globalement (voir
 * includes/components/footer.php) et qui interrogeait déjà GET
 * /api/news/ (fetchNewsList()) sans encore l'afficher — voir ce fichier
 * pour le détail de la connexion à l'API. Ce fichier PHP ne fait que
 * poser la structure : un état de chargement (visible en premier), une
 * zone d'erreur (cachée par défaut) et le conteneur de la grille de
 * résultats (vide tant que l'API n'a pas répondu) — même structure que
 * pages/builds.php et pages/runes.php.
 *
 * GET /api/news/ (sans paramètre) renvoie toutes les actualités
 * publiées. La recherche par titre (?search=) et le filtre par
 * catégorie (?category=) sont câblés côté client à ce stade
 * (#news-search-form, combinables — voir ?search= et ?category= dans
 * api/news/repository.php) : la limite reste volontairement non
 * exposée, même limite que la page Builds pour le filtre champion.
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <p class="eyebrow">Wild Rift</p>
        <h1>Actualités</h1>
        <p style="max-width: 60ch; font-size: var(--text-md);">
            Les dernières actualités de la plateforme : patchs, esport,
            événements et communauté.
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <form id="news-search-form" class="stack" style="flex-direction: row; flex-wrap: wrap; align-items: center; gap: var(--space-3); margin-bottom: var(--space-6);">
            <label for="news-search-input" class="text-muted" style="font-size: var(--text-sm);">Rechercher un article</label>
            <input
                type="search"
                id="news-search-input"
                name="search"
                placeholder="Titre de l'article…"
                maxlength="150"
                class="input"
            >

            <label for="news-category-filter" class="text-muted" style="font-size: var(--text-sm);">Catégorie</label>
            <select id="news-category-filter" name="category" class="select">
                <option value="">Toutes les catégories</option>
                <option value="patch">Patch</option>
                <option value="esport">Esport</option>
                <option value="evenement">Événement</option>
                <option value="communaute">Communauté</option>
            </select>

            <button type="submit" class="btn btn--sm">Rechercher</button>
            <button type="button" id="news-search-reset" class="btn btn--secondary btn--sm">Réinitialiser</button>
        </form>

        <div id="news-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des actualités…</span>
        </div>

        <p id="news-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="news-grid" class="grid"></div>
    </div>
</section>
