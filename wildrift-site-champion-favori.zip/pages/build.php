<?php
/**
 * Page publique : Build (détail).
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans build.php.
 *
 * Le contenu réel est entièrement injecté par assets/js/build.js, qui
 * lit l'ID dans l'URL (?id=) et interroge GET /api/builds/?id= au
 * chargement de la page — voir ce fichier pour le détail de la
 * connexion à l'API. Ce fichier PHP ne fait que poser la structure : un
 * état de chargement (visible en premier), une zone d'erreur (cachée
 * par défaut, couvrant aussi bien l'ID absent/invalide que le build
 * introuvable) et le conteneur de la fiche (vide tant que l'API n'a pas
 * répondu) — même principe que pages/champion.php.
 *
 * Contrairement à la page Champion, où les statistiques/capacités/
 * builds/counters/synergies proviennent chacune d'une requête séparée
 * vers une autre ressource, le détail d'un build (objets, runes, ordre
 * des compétences) est déjà renvoyé en une seule fois par
 * GET /api/builds/?id= (voir api/builds/index.php ::
 * findBuildItemsGrouped()/findBuildRunes()/findBuildSkillOrder()) :
 * les trois sections ci-dessous sont donc remplies par la même requête
 * que la fiche, pas par des appels supplémentaires.
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <div id="build-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement du build…</span>
        </div>

        <p id="build-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <article id="build-detail" class="card" style="max-width: 40rem;" hidden></article>
    </div>
</section>

<!--
    Section "Objets".
    Remplie à partir du même appel API que la fiche ci-dessus (voir
    build.items dans assets/js/build.js) : les objets du build,
    regroupés par emplacement (départ, principaux, bottes, enchantement,
    situationnels), puis l'ordre d'achat conseillé.
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Objets</h2>
        </div>

        <p id="build-items-empty" class="text-muted" hidden>Aucun objet renseigné pour ce build.</p>

        <div id="build-items"></div>
    </div>
</section>

<!--
    Section "Runes".
    Remplie à partir du même appel API que la fiche ci-dessus (voir
    build.runes dans assets/js/build.js), triées par position (1 =
    première choisie, typiquement la keystone).
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Runes</h2>
        </div>

        <p id="build-runes-empty" class="text-muted" hidden>Aucune rune renseignée pour ce build.</p>

        <div id="build-runes-grid" class="grid"></div>
    </div>
</section>

<!--
    Section "Ordre des compétences".
    Remplie à partir du même appel API que la fiche ci-dessus (voir
    build.skill_order dans assets/js/build.js), un point par niveau
    (1 à 15), triée par niveau croissant.
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Ordre des compétences</h2>
        </div>

        <p id="build-skill-order-empty" class="text-muted" hidden>Aucun ordre de compétences renseigné pour ce build.</p>

        <ol id="build-skill-order-list" class="stack" style="flex-direction: row; flex-wrap: wrap; gap: var(--space-2); list-style: none; padding: 0;"></ol>
    </div>
</section>

<script src="<?= asset('assets/js/build.js') ?>"></script>
