<?php
/**
 * Page publique : Objet (détail).
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans item.php.
 *
 * Le contenu réel est entièrement injecté par assets/js/item.js, qui lit
 * l'ID dans l'URL (?id=) et interroge GET /api/items/?id= au chargement
 * de la page — voir ce fichier pour le détail de la connexion à l'API.
 * Ce fichier PHP ne fait que poser la structure : un état de chargement
 * (visible en premier), une zone d'erreur (cachée par défaut, couvrant
 * aussi bien l'ID absent/invalide que l'objet introuvable) et le
 * conteneur du détail (vide tant que l'API n'a pas répondu) — même
 * principe que pages/champion.php, mais pour un objet, sans la plupart
 * des sections supplémentaires d'une fiche champion (pas de
 * statistiques, capacités, builds, counters ou synergies pour un
 * objet). Seule exception : la recette (composants), injectée par
 * assets/js/item.js::renderItemRecipe() directement dans #item-detail
 * quand l'objet en a une.
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <div id="item-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement de l'objet…</span>
        </div>

        <p id="item-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <article id="item-detail" class="card" style="max-width: 40rem;" hidden></article>
    </div>
</section>

<script src="<?= asset('assets/js/item.js') ?>"></script>
