<?php
/**
 * Page publique : Accueil.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans index.php.
 */
?>
<section class="hero">
    <div class="hero__glow" aria-hidden="true"></div>
    <div class="container hero__inner">
        <p class="eyebrow">Plateforme d'analyse Wild Rift</p>
        <h1 class="hero__title">Préparez chaque partie<br>comme un pro.</h1>
        <p class="hero__lead">
            Contre-picks, synergies d'équipe, builds réels et simulations de duel :
            tout ce qu'il faut pour prendre l'avantage avant même le lancement
            du chargement.
        </p>
        <div class="hero__actions">
            <a href="<?= asset('champions.php') ?>" class="btn">Explorer les champions</a>
            <a href="<?= asset('counters.php') ?>" class="btn btn--secondary">Trouver un contre-pick</a>
        </div>
        <div class="hero__highlights">
            <span class="badge badge--brass">Contre-picks détaillés</span>
            <span class="badge badge--teal">Synergies d'équipe</span>
            <span class="badge badge--brass">Builds réels</span>
            <span class="badge badge--teal">Simulation 1v1 / 5v5</span>
        </div>
    </div>
</section>

<!--
    Section "Champions populaires".
    Le contenu réel est injecté par assets/js/home.js, qui interroge
    GET /api/champions/ (la même API que la page Champions) au chargement
    de la page — voir ce fichier pour le détail.
    Étape actuelle : aucune notion de popularité n'existe encore côté
    données (pas de compteur de vues/parties, pas de classement) — la
    section affiche donc simplement les 4 premiers champions renvoyés par
    l'API (triés par nom, voir findChampions() dans
    api/champions/repository.php), en attendant un vrai indicateur de
    popularité dans une prochaine étape.
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Champions populaires</h2>
            <p>Un aperçu des champions à connaître pour bien démarrer.</p>
        </div>

        <div id="popular-champions-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des champions…</span>
        </div>

        <p id="popular-champions-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="popular-champions-grid" class="grid"></div>

        <div class="stack" style="margin-top: var(--space-6);">
            <a href="<?= asset('champions.php') ?>" class="btn btn--secondary btn--sm">Voir tous les champions</a>
        </div>
    </div>
</section>

<!--
    Section "Builds populaires".
    Même principe que la section Champions populaires ci-dessus : le
    contenu réel est injecté par assets/js/home.js, qui interroge
    GET /api/builds/ (la même API que la page Builds) au chargement de
    la page.
    Étape actuelle : comme pour les champions, aucune notion de
    popularité n'existe encore côté données — la section affiche donc
    simplement les 4 premiers builds renvoyés par la première page de
    l'API (voir findBuilds() dans api/builds/repository.php), en
    attendant un vrai indicateur de popularité dans une prochaine étape.
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Builds populaires</h2>
            <p>Des builds prêts à l'emploi pour vos champions préférés.</p>
        </div>

        <div id="popular-builds-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des builds…</span>
        </div>

        <p id="popular-builds-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="popular-builds-grid" class="grid"></div>

        <div class="stack" style="margin-top: var(--space-6);">
            <a href="<?= asset('builds.php') ?>" class="btn btn--secondary btn--sm">Voir tous les builds</a>
        </div>
    </div>
</section>

<!--
    Section "Tier List".
    Même principe que les sections précédentes : le contenu réel est
    injecté par assets/js/home.js, qui interroge GET /api/tier-list/ (la
    même API que la page Tier List) au chargement de la page.
    Contrairement à Champions populaires et Builds populaires, cette
    section reflète un vrai classement : l'API trie déjà par patch le
    plus récent puis par tier (S en tête — voir findTierList() dans
    api/tier-list/repository.php), donc les 4 premières entrées
    renvoyées sont déjà les mieux classées du patch actuel, sans filtre
    ni logique supplémentaire côté client.
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Tier List</h2>
            <p>Les champions les mieux classés du patch actuel.</p>
        </div>

        <div id="home-tier-list-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement de la tier list…</span>
        </div>

        <p id="home-tier-list-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="home-tier-list-grid" class="grid"></div>

        <div class="stack" style="margin-top: var(--space-6);">
            <a href="<?= asset('tier-list.php') ?>" class="btn btn--secondary btn--sm">Voir la tier list complète</a>
        </div>
    </div>
</section>

<!--
    Section "Counters".
    Même principe que les sections précédentes : le contenu réel est
    injecté par assets/js/home.js, qui interroge GET /api/counters/ (la
    même API que la page Counters) au chargement de la page.
    Comme pour Champions populaires et Builds populaires, aucune notion
    de popularité n'existe encore côté données — la section affiche donc
    simplement les 4 premiers counters renvoyés par l'API, en attendant
    un vrai indicateur de popularité dans une prochaine étape. L'API ne
    résout pas les noms de champions (champion_id/counter_champion_id
    bruts, voir api/counters/repository.php) : mêmes IDs bruts affichés
    ici, sans appel supplémentaire à /api/champions/, comme sur la page
    Counters elle-même.
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Counters</h2>
            <p>Un aperçu des matchups à connaître pour contrer vos adversaires.</p>
        </div>

        <div id="popular-counters-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des counters…</span>
        </div>

        <p id="popular-counters-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="popular-counters-grid" class="grid"></div>

        <div class="stack" style="margin-top: var(--space-6);">
            <a href="<?= asset('counters.php') ?>" class="btn btn--secondary btn--sm">Voir tous les counters</a>
        </div>
    </div>
</section>

<!--
    Section "Actualités".
    Même principe que les sections précédentes, avec une différence :
    assets/js/news.js est déjà chargé globalement sur toutes les pages
    (voir includes/components/footer.php), pas seulement via le
    <script> de cette page. Cette section réutilise donc directement ses
    fonctions génériques (fetchNewsList(), renderNewsCard(),
    formatNewsDate()) — qui ne dépendent d'aucun id particulier —
    plutôt que de les dupliquer dans assets/js/home.js, contrairement
    aux sections Champions/Builds/Tier List/Counters ci-dessus, dont les
    équivalents (assets/js/champions.js, etc.) sont chargés uniquement
    sur leur propre page et ne peuvent donc pas être réutilisés tels
    quels ici.
    Aucune notion de popularité n'existe encore côté données : la
    section affiche simplement les 4 articles les plus récents renvoyés
    par l'API (déjà triés par date de publication décroissante côté
    serveur, voir findNews() dans api/news/repository.php).
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Actualités</h2>
            <p>Les dernières nouvelles de la plateforme : patchs, esport et communauté.</p>
        </div>

        <div id="popular-news-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement des actualités…</span>
        </div>

        <p id="popular-news-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="popular-news-grid" class="grid"></div>

        <div class="stack" style="margin-top: var(--space-6);">
            <a href="<?= asset('news.php') ?>" class="btn btn--secondary btn--sm">Voir toutes les actualités</a>
        </div>
    </div>
</section>

<!--
    Section "Simulation 5v5".
    Simple bouton d'accès à la page Simulation (pages/simulation.php),
    qui n'est encore qu'un placeholder (voir ce fichier) : la simulation
    1v1 / 5v5 elle-même (formulaire, appel API, résultats) n'existe pas
    encore, donc pas de contenu à charger ici (pas d'appel API, pas
    d'état de chargement/erreur, contrairement aux sections
    précédentes) — uniquement un bouton d'accès, comme demandé.
-->
<section class="section">
    <div class="container">
        <div class="section__head">
            <p class="eyebrow">Wild Rift</p>
            <h2>Simulation 5v5</h2>
            <p>Anticipez le combat d'équipe avant même de lancer la partie.</p>
        </div>

        <div class="stack">
            <a href="<?= asset('simulation.php') ?>" class="btn">Lancer une simulation 5v5</a>
        </div>
    </div>
</section>

<script src="<?= asset('assets/js/home.js') ?>"></script>
