<?php
/**
 * Page publique : Article (détail).
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans article.php.
 *
 * Le contenu réel est entièrement injecté par assets/js/article.js, qui
 * lit l'ID dans l'URL (?id=) et interroge GET /api/news/?id= au
 * chargement de la page — voir ce fichier pour le détail de la
 * connexion à l'API. Ce fichier PHP ne fait que poser la structure : un
 * état de chargement (visible en premier), une zone d'erreur (cachée
 * par défaut, couvrant aussi bien l'ID absent/invalide que l'article
 * introuvable ou non publié) et le conteneur du détail (vide tant que
 * l'API n'a pas répondu) — même principe que pages/item.php, mais pour
 * un article : pas de recette bien sûr, à la place le corps complet de
 * l'article (content), injecté par assets/js/article.js directement
 * dans #article-detail.
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <div id="article-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement de l'article…</span>
        </div>

        <p id="article-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <article id="article-detail" class="card" style="max-width: 40rem;" hidden></article>
    </div>
</section>

<script src="<?= asset('assets/js/article.js') ?>"></script>
