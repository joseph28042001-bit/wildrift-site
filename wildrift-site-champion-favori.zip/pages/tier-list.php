<?php
/**
 * Page publique : Tier list.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer) et l'initialisation restent dans tier-list.php.
 *
 * Le contenu réel (la tier list) est entièrement injecté par
 * assets/js/tier-list.js, qui interroge GET /api/tier-list/ au
 * chargement de la page — voir ce fichier pour le détail de la
 * connexion à l'API. Ce fichier PHP ne fait que poser la structure : un
 * état de chargement (visible en premier), une zone d'erreur (cachée
 * par défaut) et le conteneur de la grille de résultats (vide tant que
 * l'API n'a pas répondu) — même structure que pages/builds.php et
 * pages/runes.php.
 *
 * GET /api/tier-list/ prend en charge ?champion=, ?role=, ?patch=,
 * ?tier= et ?search=, mais seuls les filtres par rôle, par patch et la
 * recherche par nom sont câblés côté client à ce stade
 * (#tier-list-filter-form, tous combinables — voir ?role=, ?patch= et
 * ?search= dans api/tier-list/repository.php) : champion/tier restent
 * volontairement non exposés, même limite que la page Builds pour ces
 * critères-là.
 */
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container">
        <p class="eyebrow">Wild Rift</p>
        <h1>Tier list</h1>
        <p style="max-width: 60ch; font-size: var(--text-md);">
            Le classement des champions par rôle et par patch, avec leurs
            taux de victoire, de sélection et de bannissement.
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <form id="tier-list-filter-form" class="stack" style="flex-direction: row; flex-wrap: wrap; align-items: center; gap: var(--space-3); margin-bottom: var(--space-6);">
            <label for="tier-list-search-input" class="text-muted" style="font-size: var(--text-sm);">Rechercher un champion</label>
            <input
                type="search"
                id="tier-list-search-input"
                name="search"
                placeholder="Nom du champion…"
                maxlength="60"
                class="input"
            >

            <label for="tier-list-role-filter" class="text-muted" style="font-size: var(--text-sm);">Rôle</label>
            <select id="tier-list-role-filter" name="role" class="select">
                <option value="">Tous les rôles</option>
                <option value="baron">Voie Baron</option>
                <option value="jungle">Jungle</option>
                <option value="mid">Voie du Milieu</option>
                <option value="dragon">Voie Dragon</option>
                <option value="support">Support</option>
            </select>

            <label for="tier-list-patch-input" class="text-muted" style="font-size: var(--text-sm);">Patch</label>
            <input
                type="text"
                id="tier-list-patch-input"
                name="patch"
                placeholder="ex. 5.2"
                maxlength="10"
                class="input"
            >

            <button type="submit" class="btn btn--sm">Filtrer</button>
            <button type="button" id="tier-list-filter-reset" class="btn btn--secondary btn--sm">Réinitialiser</button>
        </form>

        <div id="tier-list-loading" class="stack">
            <div class="spinner"></div>
            <span class="text-muted">Chargement de la tier list…</span>
        </div>

        <p id="tier-list-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

        <div id="tier-list-grid" class="grid"></div>
    </div>
</section>

<script src="<?= asset('assets/js/tier-list.js') ?>"></script>
