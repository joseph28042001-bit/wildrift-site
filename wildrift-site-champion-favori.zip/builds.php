<?php
/**
 * Point d'entrée public : Builds.
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/. Toute la logique/contenu vit dans pages/.
 *
 * Deux contenus possibles, selon la présence de ?champion= :
 *   - builds.php (sans ?champion=)      → pages/builds.php, la liste
 *     de tous les builds, avec recherche/filtres (formulaire
 *     #builds-search-form).
 *   - builds.php?champion=<slug>        → pages/champion-build.php, la
 *     page Build dynamique d'un champion (voir .htaccess à la racine :
 *     /builds/<slug-du-champion>, ex. /builds/syndra, réécrit en
 *     interne vers cette URL). Même point d'entrée, layout et
 *     $pageTitle que la liste : les deux contenus relèvent de la même
 *     section "Builds" du site (voir includes/components/header.php,
 *     lien de nav actif sur $pageTitle === 'Builds').
 */

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Builds';
require __DIR__ . '/includes/components/header.php';

if (isset($_GET['champion']) && $_GET['champion'] !== '') {
    require __DIR__ . '/pages/champion-build.php';
} else {
    require __DIR__ . '/pages/builds.php';
}

require __DIR__ . '/includes/components/footer.php';
