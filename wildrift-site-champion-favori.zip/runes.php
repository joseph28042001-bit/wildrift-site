<?php
/**
 * Point d'entrée public : Runes.
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/runes.php. Toute la logique/contenu vit dans pages/.
 */

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Runes';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/runes.php';
require __DIR__ . '/includes/components/footer.php';
