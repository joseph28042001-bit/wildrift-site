<?php
/**
 * Point d'entrée public : Champion (détail).
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/champion.php. Toute la logique/contenu vit dans pages/.
 *
 * Accessible via champion.php?id=5 (voir GET /api/champions/?id=,
 * api/champions/index.php). L'ID n'est pas validé ici : c'est
 * assets/js/champion.js qui le lit depuis l'URL et gère les cas absents
 * ou invalides (voir ce fichier).
 *
 * Étape actuelle : uniquement la page de détail elle-même. Aucune carte
 * de la liste des champions (pages/champions.php, pages/home.php) ne
 * pointe encore vers cette page — hors périmètre de cette étape.
 */

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Champion';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/champion.php';
require __DIR__ . '/includes/components/footer.php';
