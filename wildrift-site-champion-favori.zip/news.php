<?php
/**
 * Point d'entrée public : Actualités.
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/news.php. Toute la logique/contenu vit dans pages/.
 *
 * Pas de <script> à ajouter ici : assets/js/news.js est déjà chargé
 * globalement par includes/components/footer.php sur toutes les pages
 * (contrairement à assets/js/items.js, assets/js/runes.js, etc., propres
 * à leur page).
 */

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Actualités';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/news.php';
require __DIR__ . '/includes/components/footer.php';
