<?php
/**
 * Point d'entrée public : Design system.
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/styleguide.php. Toute la logique/contenu vit dans pages/.
 */

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Design System';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/styleguide.php';
require __DIR__ . '/includes/components/footer.php';
