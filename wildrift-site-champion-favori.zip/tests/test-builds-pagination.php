<?php

declare(strict_types=1);

/**
 * Test manuel (CLI, sans framework — cohérent avec le choix du projet de
 * ne dépendre ni de Node ni de PHPUnit) de la pagination de l'API Builds
 * introduite à cette étape.
 *
 * Ne teste QUE la pagination (?page=) : les autres comportements de
 * /api/builds/ (détail par ID, filtres, erreurs...) ne sont pas concernés
 * et ne sont pas re-testés ici.
 *
 * Exécute directement les fonctions de api/builds/repository.php (même
 * logique que celle utilisée par api/builds/index.php) plutôt que de
 * passer par une vraie requête HTTP : plus simple, pas de serveur à
 * démarrer, et suffisant pour couvrir la pagination elle-même.
 *
 * Prérequis : une base de données accessible avec le schéma + le jeu de
 * données de démonstration importés (voir database/schema.sql) — mêmes
 * réglages que pour faire tourner le site normalement (config/database.php
 * / config/database.local.php).
 *
 * Usage : php tests/test-builds-pagination.php
 * Code de sortie : 0 si tous les tests passent, 1 sinon.
 */

require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/core/exceptions.php';
require_once __DIR__ . '/../api/core/validator.php';
require_once __DIR__ . '/../api/builds/repository.php';

$failures = 0;
$total_tests = 0;

/**
 * Vérifie une condition, affiche PASS/FAIL et incrémente les compteurs.
 * N'interrompt jamais l'exécution : tous les tests sont toujours joués.
 */
function check(string $label, bool $condition): void
{
    global $failures, $total_tests;

    $total_tests++;

    if ($condition) {
        echo "  [PASS] $label\n";
        return;
    }

    $failures++;
    echo "  [FAIL] $label\n";
}

/**
 * Vérifie qu'un appel lève bien une ApiException de validation (422),
 * comme le ferait GET /api/builds/?page=... via apiValidateInt() dans
 * index.php pour une valeur de page invalide.
 */
function checkRejected(string $label, callable $callback): void
{
    global $failures, $total_tests;

    $total_tests++;

    try {
        $callback();
        $failures++;
        echo "  [FAIL] $label (aucune exception levée)\n";
    } catch (ApiException $e) {
        if ($e->getStatusCode() === 422) {
            echo "  [PASS] $label\n";
        } else {
            $failures++;
            echo "  [FAIL] $label (code HTTP {$e->getStatusCode()} au lieu de 422)\n";
        }
    }
}

echo "=== Test de la pagination de l'API Builds (BUILD_PAGE_SIZE = " . BUILD_PAGE_SIZE . ") ===\n\n";

// --- Connectivité DB, avant tout --------------------------------------
try {
    getDbConnection();
} catch (Throwable $e) {
    echo "Impossible de se connecter à la base de données. Configurez "
        . "config/database.local.php (voir database.local.php.example) et "
        . "importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

// --- 1. Validation du paramètre ?page= (même règles que index.php) ----
echo "1. Validation de ?page=\n";
check('page=1 est accepté', apiValidateInt('1', 'page', 1) === 1);
check('page=3 est accepté', apiValidateInt('3', 'page', 1) === 3);
checkRejected('page=0 est rejeté (< 1)', fn () => apiValidateInt('0', 'page', 1));
checkRejected('page=-1 est rejeté (négatif)', fn () => apiValidateInt('-1', 'page', 1));
checkRejected("page='abc' est rejeté (non numérique)", fn () => apiValidateInt('abc', 'page', 1));

// --- 2. Cohérence liste complète / total ------------------------------
echo "\n2. Cohérence avec le total de résultats\n";
$all = findBuilds(null, null, null, null);
$total = countBuilds(null, null, null, null);
check('countBuilds() correspond au nombre réel de builds (sans filtre)', $total === count($all));

$totalPages = $total > 0 ? (int) ceil($total / BUILD_PAGE_SIZE) : 0;
echo "   → total = $total build(s), soit $totalPages page(s) de " . BUILD_PAGE_SIZE . "\n";

// --- 3. Contenu de la page 1 -------------------------------------------
echo "\n3. Page 1\n";
$page1 = findBuilds(null, null, null, null, 1);
check(
    'la page 1 contient au plus BUILD_PAGE_SIZE résultats',
    count($page1) <= BUILD_PAGE_SIZE
);
check(
    'la page 1 correspond aux ' . min(BUILD_PAGE_SIZE, $total) . ' premiers résultats de la liste complète',
    array_slice($all, 0, BUILD_PAGE_SIZE) === $page1
);

// --- 4. Page 2 et absence de recouvrement avec la page 1 ---------------
echo "\n4. Page 2\n";
$page2 = findBuilds(null, null, null, null, 2);

if ($total > BUILD_PAGE_SIZE) {
    check('la page 2 contient bien des résultats', count($page2) > 0);

    $ids1 = array_column($page1, 'id');
    $ids2 = array_column($page2, 'id');
    check('la page 2 ne recoupe pas la page 1 (aucun ID en commun)', empty(array_intersect($ids1, $ids2)));

    check(
        'la page 2 correspond aux résultats suivants de la liste complète',
        array_slice($all, BUILD_PAGE_SIZE, BUILD_PAGE_SIZE) === $page2
    );
} else {
    check(
        'moins de BUILD_PAGE_SIZE+1 builds au total → la page 2 est vide',
        $page2 === []
    );
}

// --- 5. Reconstitution de la liste complète à partir de toutes les pages
echo "\n5. Reconstitution page par page\n";
$reconstructed = [];
for ($p = 1; $p <= max($totalPages, 1); $p++) {
    $reconstructed = array_merge($reconstructed, findBuilds(null, null, null, null, $p));
}
check(
    'concaténer toutes les pages redonne exactement la liste complète (même ordre)',
    $reconstructed === $all
);

// --- 6. Page au-delà du total ------------------------------------------
echo "\n6. Page au-delà des résultats disponibles\n";
$farPage = findBuilds(null, null, null, null, $totalPages + 10);
check('une page très au-delà du total renvoie une liste vide (pas une erreur)', $farPage === []);

// --- 7. Pagination combinée à un filtre existant (?role=) --------------
echo "\n7. Pagination combinée à un filtre (role=dragon)\n";
$roleAll = findBuilds(null, 'dragon', null, null);
$roleTotal = countBuilds(null, 'dragon', null, null);
$roleTotalPages = $roleTotal > 0 ? (int) ceil($roleTotal / BUILD_PAGE_SIZE) : 0;

$roleReconstructed = [];
for ($p = 1; $p <= max($roleTotalPages, 1); $p++) {
    $roleReconstructed = array_merge($roleReconstructed, findBuilds(null, 'dragon', null, null, $p));
}
check(
    'la pagination respecte le filtre role=dragon (reconstitution identique)',
    $roleReconstructed === $roleAll
);
check('countBuilds() respecte aussi le filtre role=dragon', $roleTotal === count($roleAll));

// --- Résumé --------------------------------------------------------------
echo "\n=== Résumé : " . ($total_tests - $failures) . "/$total_tests test(s) réussi(s) ===\n";

exit($failures > 0 ? 1 : 0);
