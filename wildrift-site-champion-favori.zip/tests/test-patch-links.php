<?php

declare(strict_types=1);

/**
 * Test manuel (CLI, sans framework — même approche que les autres
 * fichiers tests/test-*.php) du rattachement des données aux patchs
 * (colonne patch_id, table patches).
 *
 * Couvre :
 *   - la présence de patch_id sur les 7 tables versionnées (migration
 *     database/migration_patch_links.sql importée) ;
 *   - les fonctions de includes/patches.php (patch actif, recherche par
 *     version) ;
 *   - la cohérence patch / patch_id sur builds et tier_list ;
 *   - la compatibilité : l'API builds renvoie toujours la colonne texte
 *     `patch`, et l'écriture (insertBuild()/updateBuild()) resynchronise
 *     patch_id ;
 *   - la clé étrangère ON DELETE SET NULL : supprimer un patch ne
 *     supprime jamais le build qui y était rattaché.
 *
 * Écrit en base uniquement des lignes de test (builds nommés
 * « TEST-patch-link-… », patch « T-9.9z »), nettoyées avant et après
 * l'exécution : aucune donnée existante n'est modifiée ni supprimée.
 *
 * Prérequis : base accessible (config/database.local.php) avec
 * database/schema.sql (ou migration_patch_links.sql) importé.
 *
 * Usage : php tests/test-patch-links.php
 * Code de sortie : 0 si tous les tests passent, 1 sinon.
 */

require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/patches.php';
require_once __DIR__ . '/../api/builds/repository.php';

const TEST_BUILD_PREFIX = 'TEST-patch-link-';
const TEST_PATCH_VERSION = 'T-9.9z';

$failures = 0;
$total_tests = 0;

/**
 * Vérifie une condition, affiche PASS/FAIL et incrémente les compteurs.
 * N'interrompt jamais l'exécution : tous les tests sont toujours joués.
 */
function check(string $label, bool $condition): void
{
    global $failures, $total_tests;

    $total_tests++;

    if ($condition) {
        echo "  [PASS] $label\n";
        return;
    }

    $failures++;
    echo "  [FAIL] $label\n";
}

/**
 * Supprime les lignes de test éventuellement laissées par une exécution
 * précédente interrompue (builds de test, puis patch de test).
 */
function cleanupTestData(): void
{
    dbExecute('DELETE FROM builds WHERE name LIKE :prefix', ['prefix' => TEST_BUILD_PREFIX . '%']);
    dbExecute('DELETE FROM patches WHERE version = :version', ['version' => TEST_PATCH_VERSION]);
}

/**
 * Lit patch et patch_id d'un build, ou null s'il n'existe pas.
 */
function readBuildPatch(int $buildId): ?array
{
    return dbFetchOne('SELECT patch, patch_id FROM builds WHERE id = :id', ['id' => $buildId]);
}

/**
 * Données valides pour insertBuild()/updateBuild().
 */
function testBuildData(int $championId, string $name, string $patch): array
{
    return [
        'champion_id' => $championId,
        'name'        => $name,
        'role'        => 'mid',
        'patch'       => $patch,
        'description' => null,
        'source'      => null,
    ];
}

echo "=== Test du rattachement des données aux patchs (patch_id) ===\n\n";

// --- Connectivité DB, avant tout --------------------------------------
try {
    getDbConnection();
} catch (Throwable $e) {
    echo "Impossible de se connecter à la base de données. Configurez "
        . "config/database.local.php (voir database.local.php.example) et "
        . "importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

// --- 1. Migration en place -------------------------------------------------
echo "1. Colonne patch_id présente sur les tables versionnées\n";
$missing = [];
foreach (PATCH_LINKED_TABLES as $table) {
    $present = tableHasPatchLink($table);
    check("$table possède patch_id", $present);
    if (!$present) {
        $missing[] = $table;
    }
}

if ($missing !== []) {
    echo "\nMigration absente sur : " . implode(', ', $missing)
        . ". Importez database/migration_patch_links.sql puis relancez ce test.\n";
    exit(1);
}

cleanupTestData();

// --- 2. Table patches -------------------------------------------------------
echo "\n2. Table patches\n";
$active = findActivePatch();
check('un patch actif existe', $active !== null);
check('le patch actif a une version non vide', $active !== null && $active['version'] !== '');

$patch72e = findPatchByVersion('7.2e');
check('le patch 7.2e existe', $patch72e !== null);
check('une version inconnue renvoie null', findPatchByVersion(TEST_PATCH_VERSION) === null);
check('findPatchIdByVersion() d\'une version inconnue renvoie null', findPatchIdByVersion(TEST_PATCH_VERSION) === null);

$allPatches = findAllPatches();
check('findAllPatches() renvoie au moins un patch', count($allPatches) > 0);

// --- 3. Cohérence patch / patch_id ----------------------------------------
echo "\n3. Cohérence entre la colonne texte `patch` et `patch_id`\n";
foreach (['builds', 'tier_list'] as $table) {
    $row = dbFetchOne(
        'SELECT COUNT(*) AS total
         FROM ' . $table . ' t
         INNER JOIN patches p ON p.version = t.patch
         WHERE t.patch_id IS NULL OR t.patch_id <> p.id'
    );
    check("$table : aucune ligne dont patch_id ne suit pas `patch`", $row !== null && (int) $row['total'] === 0);

    $orphans = dbFetchOne(
        'SELECT COUNT(*) AS total
         FROM ' . $table . ' t
         LEFT JOIN patches p ON p.version = t.patch
         WHERE p.id IS NULL'
    );
    check("$table : chaque version utilisée existe dans patches", $orphans !== null && (int) $orphans['total'] === 0);
}

// --- 4. Compatibilité de l'API builds --------------------------------------
echo "\n4. Compatibilité de l'API builds\n";
$allBuilds = findAllBuilds();
check('findAllBuilds() renvoie des builds', count($allBuilds) > 0);
check(
    "chaque build expose toujours la colonne texte `patch`",
    $allBuilds !== [] && !in_array(false, array_map(fn (array $b): bool => array_key_exists('patch', $b) && $b['patch'] !== '', $allBuilds), true)
);
check("l'API n'expose pas patch_id (réponse inchangée)", $allBuilds !== [] && !array_key_exists('patch_id', $allBuilds[0]));

// --- 5. Écriture : insertBuild() / updateBuild() ---------------------------
echo "\n5. Écriture d'un build : patch_id suit `patch`\n";
$champion = dbFetchOne('SELECT id FROM champions ORDER BY id ASC LIMIT 1');

if ($champion === null || $patch72e === null) {
    echo "  [SKIP] aucun champion ou patch 7.2e absent : test d'écriture ignoré\n";
} else {
    $championId = (int) $champion['id'];
    $buildId = 0;

    try {
        $name = TEST_BUILD_PREFIX . bin2hex(random_bytes(4));
        $buildId = insertBuild(testBuildData($championId, $name, '7.2e'));

        $after = readBuildPatch($buildId);
        check('insertBuild() : patch texte conservé', $after !== null && $after['patch'] === '7.2e');
        check('insertBuild() : patch_id rattaché au patch 7.2e', $after !== null && (int) $after['patch_id'] === $patch72e['id']);

        updateBuild($buildId, testBuildData($championId, $name, '9.9z'));
        $after = readBuildPatch($buildId);
        check('updateBuild() vers une version inconnue : patch texte conservé', $after !== null && $after['patch'] === '9.9z');
        check('updateBuild() vers une version inconnue : patch_id remis à NULL', $after !== null && $after['patch_id'] === null);

        updateBuild($buildId, testBuildData($championId, $name, '7.2e'));
        $after = readBuildPatch($buildId);
        check('updateBuild() vers 7.2e : patch_id de nouveau rattaché', $after !== null && (int) $after['patch_id'] === $patch72e['id']);
    } finally {
        if ($buildId > 0) {
            deleteBuild($buildId);
        }
    }

    // --- 6. Clé étrangère ON DELETE SET NULL -------------------------------
    echo "\n6. Suppression d'un patch : le build rattaché est conservé\n";
    $buildId = 0;

    try {
        dbExecute('INSERT INTO patches (version, is_active) VALUES (:version, 0)', ['version' => TEST_PATCH_VERSION]);
        $testPatchId = findPatchIdByVersion(TEST_PATCH_VERSION);
        check('le patch de test est créé', $testPatchId !== null);

        $name = TEST_BUILD_PREFIX . bin2hex(random_bytes(4));
        $buildId = insertBuild(testBuildData($championId, $name, TEST_PATCH_VERSION));
        $linked = readBuildPatch($buildId);
        check('le build est rattaché au patch de test', $linked !== null && (int) $linked['patch_id'] === $testPatchId);

        dbExecute('DELETE FROM patches WHERE version = :version', ['version' => TEST_PATCH_VERSION]);
        $kept = readBuildPatch($buildId);
        check('le build existe toujours après suppression du patch', $kept !== null);
        check('son patch_id est remis à NULL', $kept !== null && $kept['patch_id'] === null);
        check('sa colonne texte `patch` est intacte', $kept !== null && $kept['patch'] === TEST_PATCH_VERSION);
    } finally {
        if ($buildId > 0) {
            deleteBuild($buildId);
        }
    }
}

// --- 7. Garde-fous ---------------------------------------------------------
echo "\n7. Garde-fous\n";
check('une table hors liste blanche est refusée', tableHasPatchLink('users') === false);
check('linkRowToPatch() refuse une table hors liste blanche (aucune écriture)', linkRowToPatch('users', 1, '7.2e') === false);

cleanupTestData();

// --- Résumé --------------------------------------------------------------
echo "\n=== Résumé : " . ($total_tests - $failures) . "/$total_tests test(s) réussi(s) ===\n";

exit($failures > 0 ? 1 : 0);
