<?php

declare(strict_types=1);

/**
 * Test manuel (CLI, sans framework — même approche que
 * tests/test-builds-pagination.php, tests/test-builds-search.php et
 * tests/test-builds-champion-filter.php) du filtre des builds par rôle
 * (GET /api/builds/?role=...).
 *
 * Cette fonctionnalité existait déjà avant cette étape (introduite en même
 * temps que la recherche et les filtres champion/patch) : rien n'a été
 * modifié dans le code de l'API pour cette étape, seul ce test a été
 * ajouté pour la couvrir explicitement.
 *
 * Ne teste QUE le filtre par rôle (?role=) : les autres comportements de
 * /api/builds/ (détail par ID, pagination, recherche par nom, filtres
 * champion/patch pris isolément, erreurs...) ne sont pas concernés et ne
 * sont pas re-testés ici — voir les autres fichiers tests/test-builds-*.php
 * pour ces autres fonctionnalités.
 *
 * Exécute directement les fonctions de api/builds/repository.php et
 * api/core/validator.php (même logique que celle utilisée par
 * api/builds/index.php) plutôt que de passer par une vraie requête HTTP :
 * plus simple, pas de serveur à démarrer.
 *
 * Prérequis : une base de données accessible avec le schéma + le jeu de
 * données de démonstration importés (voir database/schema.sql) — mêmes
 * réglages que pour faire tourner le site normalement (config/database.php
 * / config/database.local.php). Le jeu de données de démonstration associe
 * un rôle à chaque build (voir getBuildRoles() : baron, jungle, mid,
 * dragon, support), avec au moins un build par rôle.
 *
 * Usage : php tests/test-builds-role-filter.php
 * Code de sortie : 0 si tous les tests passent, 1 sinon.
 */

require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/core/exceptions.php';
require_once __DIR__ . '/../api/core/validator.php';
require_once __DIR__ . '/../api/builds/repository.php';

$failures = 0;
$total_tests = 0;

/**
 * Vérifie une condition, affiche PASS/FAIL et incrémente les compteurs.
 * N'interrompt jamais l'exécution : tous les tests sont toujours joués.
 */
function check(string $label, bool $condition): void
{
    global $failures, $total_tests;

    $total_tests++;

    if ($condition) {
        echo "  [PASS] $label\n";
        return;
    }

    $failures++;
    echo "  [FAIL] $label\n";
}

/**
 * Vérifie qu'un appel lève bien une ApiException de validation (422),
 * comme le ferait GET /api/builds/?role=... via apiValidateEnum() dans
 * index.php pour une valeur hors de la liste autorisée.
 */
function checkRejected(string $label, callable $callback): void
{
    global $failures, $total_tests;

    $total_tests++;

    try {
        $callback();
        $failures++;
        echo "  [FAIL] $label (aucune exception levée)\n";
    } catch (ApiException $e) {
        if ($e->getStatusCode() === 422) {
            echo "  [PASS] $label\n";
        } else {
            $failures++;
            echo "  [FAIL] $label (code HTTP {$e->getStatusCode()} au lieu de 422)\n";
        }
    }
}

/**
 * Simule exactement le traitement de ?role= tel que fait par
 * api/builds/index.php : validation (enum) puis appel à findBuilds().
 */
function filterByRole(string $rawRole): array
{
    $role = apiValidateEnum($rawRole, 'role', getBuildRoles());

    return findBuilds(null, $role, null, null);
}

echo "=== Test du filtre des builds par rôle (?role=) ===\n\n";

// --- Connectivité DB, avant tout --------------------------------------
try {
    getDbConnection();
} catch (Throwable $e) {
    echo "Impossible de se connecter à la base de données. Configurez "
        . "config/database.local.php (voir database.local.php.example) et "
        . "importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

// --- 1. Chaque rôle valide renvoie des résultats cohérents --------------
echo "1. Chaque rôle valide (getBuildRoles())\n";
foreach (getBuildRoles() as $role) {
    $builds = filterByRole($role);

    $allMatch = true;
    foreach ($builds as $build) {
        if ($build['role'] !== $role) {
            $allMatch = false;
            break;
        }
    }
    check("role=$role : tous les résultats ont bien role='$role'", $allMatch);
}

// --- 2. Cohérence avec countBuilds() -------------------------------------
echo "\n2. Cohérence avec countBuilds()\n";
$dragonBuilds = filterByRole('dragon');
$dragonCount = countBuilds(null, 'dragon', null, null);
check('countBuilds() correspond au nombre réel de résultats pour role=dragon', $dragonCount === count($dragonBuilds));

// --- 3. Deux rôles distincts ne se mélangent pas -------------------------
echo "\n3. Deux rôles distincts, résultats disjoints\n";
$midBuilds = filterByRole('mid');
$dragonIds = array_column($dragonBuilds, 'id');
$midIds = array_column($midBuilds, 'id');
check('role=dragon et role=mid renvoient des builds différents', empty(array_intersect($dragonIds, $midIds)));
check('role=dragon renvoie au moins un résultat', count($dragonBuilds) > 0);
check('role=mid renvoie au moins un résultat', count($midBuilds) > 0);

// --- 4. La somme des rôles reconstitue la liste complète -----------------
echo "\n4. Somme de tous les rôles = liste complète (sans filtre)\n";
$all = findBuilds(null, null, null, null);
$sumIds = [];
foreach (getBuildRoles() as $role) {
    $sumIds = array_merge($sumIds, array_column(filterByRole($role), 'id'));
}
sort($sumIds);
$allIds = array_column($all, 'id');
sort($allIds);
check(
    'concaténer les résultats de tous les rôles retrouve exactement tous les builds (mêmes IDs)',
    $sumIds === $allIds
);

// --- 5. Filtre combiné à un autre filtre existant (champion=) ------------
echo "\n5. Filtre combiné à un autre filtre (champion=)\n";
$role = apiValidateEnum('baron', 'role', getBuildRoles());
$combinedMatch = findBuilds('darius', $role, null, null); // darius est bien 'baron' dans le jeu de données
$combinedMismatch = findBuilds('darius', 'support', null, null); // darius n'est pas 'support'

check('champion=darius + role=baron (rôle correct) renvoie au moins un résultat', count($combinedMatch) > 0);
check('champion=darius + role=support (rôle incorrect) ne renvoie rien', $combinedMismatch === []);

// --- 6. Validation de ?role= (mêmes règles que index.php) ----------------
echo "\n6. Validation de ?role=\n";
checkRejected(
    "un rôle hors liste ('inexistant') est rejeté",
    fn () => filterByRole('inexistant')
);
checkRejected(
    "un rôle valide mais mal orthographié ('Dragon' avec majuscule) est rejeté",
    fn () => filterByRole('Dragon')
);

// --- Résumé --------------------------------------------------------------
echo "\n=== Résumé : " . ($total_tests - $failures) . "/$total_tests test(s) réussi(s) ===\n";

exit($failures > 0 ? 1 : 0);
