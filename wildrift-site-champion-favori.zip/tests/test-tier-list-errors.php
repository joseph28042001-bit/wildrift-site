<?php

declare(strict_types=1);

/**
 * Test manuel (CLI, sans framework — même approche que les autres fichiers
 * tests/test-builds-*.php et tests/test-tier-list-champion-filter.php) de
 * la gestion des erreurs de l'API Tier List (GET /api/tier-list/).
 *
 * Contrairement à tests/test-tier-list-champion-filter.php, qui teste le
 * cas nominal du filtre par champion, celui-ci ne teste QUE les cas
 * d'erreur de /api/tier-list/ :
 *   - ID invalide et entrée de tier list inexistante (détail par ?id=)
 *   - Paramètres de filtre incorrects (?role=, ?tier=, ?champion=, ?patch=)
 *   - Méthode HTTP non autorisée
 *
 * Relecture complète de api/tier-list/index.php, api/tier-list/repository.php
 * et api/core/{validator,exceptions,runner}.php à cette étape : la
 * validation (apiValidateInt/apiValidateEnum/apiValidateString), le 404
 * explicite sur ?id= absent (ApiException::notFound) et le 405 sur méthode
 * non autorisée (apiRequireMethod) étaient déjà en place et corrects —
 * même constat que pour tests/test-builds-errors.php. Aucun code n'a été
 * modifié pour corriger un bug — ce fichier ajoute la couverture de test
 * qui manquait sur ces cas d'erreur, jusqu'ici jamais testés explicitement
 * pour la ressource Tier List.
 *
 * Exécute directement les fonctions de api/tier-list/repository.php et
 * api/core/validator.php (même logique que celle utilisée par
 * api/tier-list/index.php) plutôt que de passer par une vraie requête
 * HTTP : plus simple, pas de serveur à démarrer — même choix que les
 * autres fichiers tests/test-*.php.
 *
 * Prérequis : une base de données accessible avec le schéma + le jeu de
 * données de démonstration importés (voir database/schema.sql) — mêmes
 * réglages que pour faire tourner le site normalement (config/database.php
 * / config/database.local.php).
 *
 * Usage : php tests/test-tier-list-errors.php
 * Code de sortie : 0 si tous les tests passent, 1 sinon.
 */

require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/core/exceptions.php';
require_once __DIR__ . '/../api/core/validator.php';
require_once __DIR__ . '/../api/tier-list/repository.php';

$failures = 0;
$total_tests = 0;

/**
 * Vérifie une condition, affiche PASS/FAIL et incrémente les compteurs.
 * N'interrompt jamais l'exécution : tous les tests sont toujours joués.
 */
function check(string $label, bool $condition): void
{
    global $failures, $total_tests;

    $total_tests++;

    if ($condition) {
        echo "  [PASS] $label\n";
        return;
    }

    $failures++;
    echo "  [FAIL] $label\n";
}

/**
 * Vérifie qu'un appel lève bien une ApiException avec le code HTTP attendu
 * (422 par défaut, pour les erreurs de validation). Affiche le code réel en
 * cas d'échec pour faciliter le diagnostic.
 */
function checkRejected(string $label, callable $callback, int $expectedStatusCode = 422): void
{
    global $failures, $total_tests;

    $total_tests++;

    try {
        $callback();
        $failures++;
        echo "  [FAIL] $label (aucune exception levée)\n";
    } catch (ApiException $e) {
        if ($e->getStatusCode() === $expectedStatusCode) {
            echo "  [PASS] $label\n";
        } else {
            $failures++;
            echo "  [FAIL] $label (code HTTP {$e->getStatusCode()} au lieu de $expectedStatusCode)\n";
        }
    }
}

/**
 * Simule exactement le traitement de GET /api/tier-list/?id=... tel que
 * fait par api/tier-list/index.php : validation de l'ID, recherche de
 * l'entrée, ApiException::notFound (404) si elle n'existe pas.
 */
function getTierListDetail(string $rawId): array
{
    $id = apiValidateInt($rawId, 'id', 1);

    $entry = findTierListById($id);

    if ($entry === null) {
        throw ApiException::notFound("Aucune entrée de tier list trouvée avec l'ID $id.");
    }

    return $entry;
}

/**
 * Simule exactement le traitement de la méthode HTTP tel que fait par
 * api/tier-list/index.php : apiRequireMethod(['GET']) en tout premier.
 * Manipule $_SERVER['REQUEST_METHOD'] le temps de l'appel puis le restaure,
 * pour ne pas polluer le reste du script (exécuté en CLI, où cette clé
 * n'est normalement pas définie).
 *
 * apiRequireMethod() envoie un en-tête HTTP (Allow:) avant de lever son
 * exception 405 — correct et sans effet en usage normal (avant tout
 * affichage), mais ce script CLI a déjà produit du texte à l'écran à ce
 * stade, ce qui déclenche un simple avertissement PHP ("headers already
 * sent"), sans rapport avec la validité du test. On l'ignore ici, le temps
 * de l'appel, pour garder une sortie de test propre.
 */
function callWithMethod(string $method, callable $callback): void
{
    $previous = $_SERVER['REQUEST_METHOD'] ?? null;
    $_SERVER['REQUEST_METHOD'] = $method;

    set_error_handler(static function (int $errno, string $errstr): bool {
        return str_contains($errstr, 'headers already sent');
    }, E_WARNING);

    try {
        $callback();
    } finally {
        restore_error_handler();
        if ($previous === null) {
            unset($_SERVER['REQUEST_METHOD']);
        } else {
            $_SERVER['REQUEST_METHOD'] = $previous;
        }
    }
}

echo "=== Test de la gestion des erreurs de l'API Tier List ===\n\n";

// --- Connectivité DB, avant tout --------------------------------------
try {
    getDbConnection();
} catch (Throwable $e) {
    echo "Impossible de se connecter à la base de données. Configurez "
        . "config/database.local.php (voir database.local.php.example) et "
        . "importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

// --- 1. ID invalide (détail par ?id=) -------------------------------------
echo "1. Validation de ?id= (détail)\n";
checkRejected("id='abc' (non numérique) est rejeté", fn () => getTierListDetail('abc'));
checkRejected("id='1.5' (décimal) est rejeté", fn () => getTierListDetail('1.5'));
checkRejected("id='5abc' (numérique + texte) est rejeté", fn () => getTierListDetail('5abc'));
checkRejected("id='-1' (négatif) est rejeté", fn () => getTierListDetail('-1'));
checkRejected("id='0' (inférieur au minimum autorisé) est rejeté", fn () => getTierListDetail('0'));
check(
    "id='5.0' est en réalité accepté (équivalent numérique de 5, comportement existant conservé)",
    apiValidateInt('5.0', 'id', 1) === 5
);
check(
    "id=' 5 ' (espaces superflus) est accepté (comportement existant conservé)",
    apiValidateInt(' 5 ', 'id', 1) === 5
);

// --- 2. Entrée inexistante (ID syntaxiquement valide, mais absent) --------
echo "\n2. Entrée de tier list inexistante (ID valide, aucune ligne correspondante)\n";
checkRejected(
    "id=999999 (format valide, entrée absente) déclenche bien une erreur 404, pas 422",
    fn () => getTierListDetail('999999'),
    404
);
check(
    "findTierListById() renvoie bien null pour un ID inexistant (avant que index.php ne lève l'exception)",
    findTierListById(999999) === null
);

// --- 3. Entrée existante : pas d'erreur, détail complet --------------------
echo "\n3. Entrée existante (cas passant, pour contraste avec les cas d'erreur ci-dessus)\n";
$anyEntry = findTierList(null, null, null, null)[0] ?? null;
if ($anyEntry === null) {
    echo "  Jeu de données de démonstration introuvable (aucune entrée de tier list). "
        . "Importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}
$existingId = (int) $anyEntry['id'];
$detail = getTierListDetail((string) $existingId);
check("id=$existingId (existant) ne lève aucune erreur et renvoie le détail", $detail['id'] === $existingId);
check(
    "le détail d'une entrée existante contient bien ses champs propres à la vue détail (notes/dates)",
    array_key_exists('notes', $detail) && array_key_exists('created_at', $detail) && array_key_exists('updated_at', $detail)
);

// --- 4. Paramètres de filtre incorrects (role=, tier=, champion=, patch=) --
echo "\n4. Paramètres de filtre incorrects (?role=, ?tier=, ?champion=, ?patch=)\n";
checkRejected(
    "role='inexistant' (hors énumération) est rejeté",
    fn () => apiValidateEnum('inexistant', 'role', getTierListRoles())
);
checkRejected(
    "role='Baron' (casse incorrecte) est rejeté",
    fn () => apiValidateEnum('Baron', 'role', getTierListRoles())
);
checkRejected(
    "tier='X' (hors énumération S+/S/A/B/C/D) est rejeté",
    fn () => apiValidateEnum('X', 'tier', getTierListTiers())
);
checkRejected(
    "tier='s' (casse incorrecte, minuscule) est rejeté",
    fn () => apiValidateEnum('s', 'tier', getTierListTiers())
);
checkRejected(
    "champion trop long (> 60 caractères) est rejeté",
    fn () => apiValidateString(str_repeat('a', 61), 'champion', 1, 60)
);
checkRejected(
    "patch trop long (> 10 caractères) est rejeté",
    fn () => apiValidateString(str_repeat('9', 11), 'patch', 1, 10)
);

// --- 5. Plusieurs paramètres invalides à la fois ---------------------------
// index.php valide chaque paramètre indépendamment et s'arrête à la
// première erreur rencontrée : on vérifie ici qu'une combinaison de
// paramètres invalides échoue bien (peu importe lequel est signalé en
// premier), plutôt que d'être silencieusement acceptée.
echo "\n5. Combinaison de plusieurs paramètres invalides\n";
checkRejected(
    "role invalide + tier invalide en même temps : rejeté dès le premier problème rencontré",
    function (): void {
        apiValidateEnum('inexistant', 'role', getTierListRoles());
        apiValidateEnum('X', 'tier', getTierListTiers()); // jamais atteint si le rôle est déjà rejeté
    }
);

// --- 6. Méthode HTTP non autorisée -----------------------------------------
echo "\n6. Méthode HTTP non autorisée\n";
checkRejected(
    'POST sur /api/tier-list/ (lecture seule, GET uniquement) est rejeté avec 405',
    fn () => callWithMethod('POST', fn () => apiRequireMethod(['GET'])),
    405
);
checkRejected(
    'DELETE sur /api/tier-list/ est rejeté avec 405',
    fn () => callWithMethod('DELETE', fn () => apiRequireMethod(['GET'])),
    405
);
check(
    'GET sur /api/tier-list/ (méthode autorisée) ne lève aucune erreur',
    (function (): bool {
        try {
            callWithMethod('GET', fn () => apiRequireMethod(['GET']));
            return true;
        } catch (ApiException $e) {
            return false;
        }
    })()
);

// --- 7. Forme de l'erreur : code machine-readable cohérent -----------------
// Vérifie que chaque famille d'erreur porte le bon errorCode (voir
// ApiException et api/core/response.php pour la forme JSON finale
// { success: false, error: { code, message } }), pas seulement le bon code
// HTTP.
echo "\n7. Code d'erreur machine-readable (details de la réponse JSON)\n";
try {
    getTierListDetail('abc');
    check("id invalide : errorCode = 'validation_error'", false);
} catch (ApiException $e) {
    check("id invalide : errorCode = 'validation_error'", $e->getErrorCode() === 'validation_error');
}
try {
    getTierListDetail('999999');
    check("entrée inexistante : errorCode = 'not_found'", false);
} catch (ApiException $e) {
    check("entrée inexistante : errorCode = 'not_found'", $e->getErrorCode() === 'not_found');
}
try {
    apiValidateEnum('X', 'tier', getTierListTiers());
    check("tier invalide : errorCode = 'validation_error'", false);
} catch (ApiException $e) {
    check("tier invalide : errorCode = 'validation_error'", $e->getErrorCode() === 'validation_error');
}
try {
    callWithMethod('POST', fn () => apiRequireMethod(['GET']));
    check("méthode non autorisée : errorCode = 'method_not_allowed'", false);
} catch (ApiException $e) {
    check("méthode non autorisée : errorCode = 'method_not_allowed'", $e->getErrorCode() === 'method_not_allowed');
}

// --- Résumé --------------------------------------------------------------
echo "\n=== Résumé : " . ($total_tests - $failures) . "/$total_tests test(s) réussi(s) ===\n";

exit($failures > 0 ? 1 : 0);
