<?php

declare(strict_types=1);

/**
 * Test manuel (CLI, sans framework — même approche que les autres fichiers
 * tests/test-builds-*.php) des relations d'un build : champion (jointure
 * simple), objets (build_items -> items, regroupés par slot), runes
 * (build_runes -> runes) et ordre des compétences (build_skill_order).
 *
 * Vérification demandée à cette étape : relecture complète de
 * api/builds/repository.php (findBuildById(), findBuildItemsGrouped(),
 * findBuildItems(), findBuildRunes(), findBuildSkillOrder()) et des
 * jointures/clés étrangères de database/schema.sql. Aucun problème trouvé
 * sur ces relations : ce fichier ne fait donc que les tester, aucun code
 * de l'API n'a été modifié pour cette étape.
 *
 * Ne teste QUE ces 4 relations : pagination, recherche, filtres
 * champion/rôle/patch pris isolément ne sont pas re-testés ici — voir les
 * autres fichiers tests/test-builds-*.php.
 *
 * Exécute directement les fonctions de api/builds/repository.php (même
 * logique que celle utilisée par api/builds/index.php) plutôt que de
 * passer par une vraie requête HTTP : plus simple, pas de serveur à
 * démarrer.
 *
 * Prérequis : une base de données accessible avec le schéma + le jeu de
 * données de démonstration importés (voir database/schema.sql). Seuls 4
 * des 9 builds du jeu de données ont des objets/runes/compétences
 * (jinx, ahri, malphite, lulu) — c'est voulu (voir schema.sql) : les 5
 * autres builds servent justement à vérifier le cas "aucune relation".
 *
 * Usage : php tests/test-builds-relations.php
 * Code de sortie : 0 si tous les tests passent, 1 sinon.
 */

require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/core/exceptions.php';
require_once __DIR__ . '/../api/builds/repository.php';

$failures = 0;
$total_tests = 0;

/**
 * Vérifie une condition, affiche PASS/FAIL et incrémente les compteurs.
 * N'interrompt jamais l'exécution : tous les tests sont toujours joués.
 */
function check(string $label, bool $condition): void
{
    global $failures, $total_tests;

    $total_tests++;

    if ($condition) {
        echo "  [PASS] $label\n";
        return;
    }

    $failures++;
    echo "  [FAIL] $label\n";
}

/**
 * Retrouve l'ID d'un build par le slug de son champion et son nom exact
 * (mêmes couples utilisés dans les INSERT de démonstration de
 * database/schema.sql). Simple utilitaire pour ce test, pas une fonction
 * de l'API.
 */
function findDemoBuildId(string $championSlug, string $buildName): ?int
{
    $builds = findBuilds($championSlug, null, null, null);

    foreach ($builds as $build) {
        if ($build['name'] === $buildName) {
            return (int) $build['id'];
        }
    }

    return null;
}

echo "=== Test des relations d'un build : champion, objets, runes, compétences ===\n\n";

// --- Connectivité DB, avant tout --------------------------------------
try {
    getDbConnection();
} catch (Throwable $e) {
    echo "Impossible de se connecter à la base de données. Configurez "
        . "config/database.local.php (voir database.local.php.example) et "
        . "importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

$jinxId = findDemoBuildId('jinx', 'Carry critique full attaque');
$dariusId = findDemoBuildId('darius', 'Bruiser off-tank Baron');

if ($jinxId === null || $dariusId === null) {
    echo "Jeu de données de démonstration introuvable (builds de jinx/darius "
        . "absents). Importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

// --- 1. Relation champion --------------------------------------------------
echo "1. Relation build → champion\n";
$jinxBuild = findBuildById($jinxId);
check('le build existe et porte le bon nom', $jinxBuild !== null && $jinxBuild['name'] === 'Carry critique full attaque');
check("le champion résolu par jointure est bien 'Jinx'", $jinxBuild['champion'] === 'Jinx');
check("le champion en liste (findBuilds) correspond au champion en détail (findBuildById)", (function () use ($jinxId, $jinxBuild): bool {
    foreach (findBuilds(null, null, null, null) as $row) {
        if ((int) $row['id'] === $jinxId) {
            return $row['champion'] === $jinxBuild['champion'];
        }
    }
    return false;
})());

// --- 2. Relation objets (build_items -> items, regroupés par slot) -------
echo "\n2. Relation build → objets (regroupés par slot)\n";
$items = findBuildItemsGrouped($jinxId);

check('les 5 slots existent toujours, même vides', array_keys($items) === ['starting', 'core', 'boots', 'enchantment', 'situational', 'purchase_order']);

$startingSlugs = array_column($items['starting'], 'slug');
sort($startingSlugs);
check(
    "le slot 'starting' contient bien long-sword",
    $startingSlugs === ['long-sword']
);

$coreSlugs = array_column($items['core'], 'slug');
sort($coreSlugs);
check(
    "le slot 'core' contient bien magnetic-blaster, mortal-reminder et the-collector",
    $coreSlugs === ['magnetic-blaster', 'mortal-reminder', 'the-collector']
);

check(
    "le slot 'boots' contient bien berserkers-greaves",
    array_column($items['boots'], 'slug') === ['berserkers-greaves']
);

check(
    "le slot 'enchantment' est vide (le build réel WildRiftFire n'utilise pas d'enchantement de bottes)",
    $items['enchantment'] === []
);

$situationalSlugs = array_column($items['situational'], 'slug');
sort($situationalSlugs);
check(
    "le slot 'situational' contient bien guardian-angel, infinity-edge, lord-dominiks-regard et mercurial-scimitar",
    $situationalSlugs === ['guardian-angel', 'infinity-edge', 'lord-dominiks-regard', 'mercurial-scimitar']
);

$allSituationalHaveNullOrder = true;
foreach ($items['situational'] as $item) {
    if ($item['purchase_order'] !== null) {
        $allSituationalHaveNullOrder = false;
        break;
    }
}
check("les objets 'situational' ont bien un purchase_order à null", $allSituationalHaveNullOrder);

$purchaseOrderNumbers = array_column($items['purchase_order'], 'order');
check(
    "la séquence d'achat globale est bien 1..5, dans l'ordre (situational exclus)",
    $purchaseOrderNumbers === [1, 2, 3, 4, 5]
);
check(
    "la séquence d'achat globale ne contient aucun objet 'situational'",
    !in_array('guardian-angel', array_column($items['purchase_order'], 'item'), true)
    && !in_array('lord-dominiks-regard', array_column($items['purchase_order'], 'item'), true)
);

// --- 3. Relation runes (build_runes -> runes) -----------------------------
echo "\n3. Relation build → runes\n";
$runes = findBuildRunes($jinxId);
check('3 runes sont associées à ce build', count($runes) === 3);

$positions = array_column($runes, 'position');
check('les positions sont bien 1, 2, 3 dans cet ordre', $positions === [1, 2, 3]);

check(
    "la première rune (position 1) est bien 'press-the-attack'",
    $runes[0]['slug'] === 'press-the-attack'
);
check(
    "l'arbre et le slot de cette rune sont bien résolus (precision / keystone)",
    $runes[0]['tree'] === 'precision' && $runes[0]['slot'] === 'keystone'
);

$runeSlugs = array_column($runes, 'slug');
sort($runeSlugs);
check(
    'les 3 runes attendues sont présentes (press-the-attack, sudden-impact, triumph)',
    $runeSlugs === ['press-the-attack', 'sudden-impact', 'triumph']
);

// --- 4. Relation ordre des compétences (build_skill_order) ----------------
echo "\n4. Relation build → ordre des compétences\n";
$skillOrder = findBuildSkillOrder($jinxId);
check('15 points de compétence sont associés à ce build (niveaux 1 à 15)', count($skillOrder) === 15);

$levels = array_column($skillOrder, 'level');
check('les niveaux sont bien 1 à 15, dans l\'ordre croissant', $levels === range(1, 15));

$ultimateLevels = [];
foreach ($skillOrder as $entry) {
    if ($entry['skill'] === 'ultimate') {
        $ultimateLevels[] = $entry['level'];
    }
}
check(
    "l'ultime est bien monté aux niveaux 5, 9 et 13 (règle Wild Rift)",
    $ultimateLevels === [5, 9, 13]
);

// --- 5. Build sans relations : cas valide, pas une erreur -----------------
echo "\n5. Build sans objets/runes/compétences (cas valide)\n";
$dariusItems = findBuildItemsGrouped($dariusId);
$dariusItemCount = array_sum(array_map('count', array_diff_key($dariusItems, ['purchase_order' => true])));
check(
    "les 5 slots existent mais sont tous vides pour un build sans objets",
    $dariusItemCount === 0 && $dariusItems['purchase_order'] === []
);
check('aucune rune pour un build sans runes (liste vide, pas une erreur)', findBuildRunes($dariusId) === []);
check('aucun ordre de compétences pour un build sans compétences (liste vide, pas une erreur)', findBuildSkillOrder($dariusId) === []);

// --- 6. Isolation entre builds : pas de contamination croisée -------------
echo "\n6. Isolation entre builds (pas de contamination croisée)\n";
$ahriId = findDemoBuildId('ahri', 'One-shot burst magique');
check("le build d'Ahri est bien retrouvé", $ahriId !== null);

if ($ahriId !== null) {
    $ahriItems = findBuildItemsGrouped($ahriId);
    $ahriAllSlugs = array_merge(
        array_column($ahriItems['starting'], 'slug'),
        array_column($ahriItems['core'], 'slug'),
        array_column($ahriItems['boots'], 'slug'),
        array_column($ahriItems['enchantment'], 'slug'),
        array_column($ahriItems['situational'], 'slug')
    );
    $jinxAllSlugs = array_merge(
        array_column($items['starting'], 'slug'),
        array_column($items['core'], 'slug'),
        array_column($items['boots'], 'slug'),
        array_column($items['enchantment'], 'slug'),
        array_column($items['situational'], 'slug')
    );
    check(
        "les objets du build de Jinx (infinity-edge...) ne fuitent pas dans celui d'Ahri",
        !in_array('infinity-edge', $ahriAllSlugs, true)
    );
    check(
        "les objets du build d'Ahri (rabadons-deathcap...) ne fuitent pas dans celui de Jinx",
        !in_array('rabadons-deathcap', $jinxAllSlugs, true)
    );

    $ahriRuneSlugs = array_column(findBuildRunes($ahriId), 'slug');
    $jinxRuneSlugs = array_column($runes, 'slug');
    check(
        "'arcane-comet' (rune d'Ahri) n'apparaît pas dans les runes de Jinx",
        !in_array('arcane-comet', $jinxRuneSlugs, true) && in_array('arcane-comet', $ahriRuneSlugs, true)
    );
}

// --- Résumé --------------------------------------------------------------
echo "\n=== Résumé : " . ($total_tests - $failures) . "/$total_tests test(s) réussi(s) ===\n";

exit($failures > 0 ? 1 : 0);
