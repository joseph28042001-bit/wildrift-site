<?php

declare(strict_types=1);

/**
 * Test manuel (CLI, sans framework — même approche que les autres fichiers
 * tests/test-builds-*.php) du filtre des builds par patch
 * (GET /api/builds/?patch=...).
 *
 * Cette fonctionnalité existait déjà avant cette étape (introduite en même
 * temps que la recherche et les filtres champion/rôle) : rien n'a été
 * modifié dans le code de l'API pour cette étape, seul ce test a été
 * ajouté pour la couvrir explicitement.
 *
 * Ne teste QUE le filtre par patch (?patch=) : les autres comportements de
 * /api/builds/ (détail par ID, pagination, recherche par nom, filtres
 * champion/rôle pris isolément, erreurs...) ne sont pas concernés et ne
 * sont pas re-testés ici — voir les autres fichiers tests/test-builds-*.php
 * pour ces autres fonctionnalités.
 *
 * Exécute directement les fonctions de api/builds/repository.php et
 * api/core/validator.php (même logique que celle utilisée par
 * api/builds/index.php) plutôt que de passer par une vraie requête HTTP :
 * plus simple, pas de serveur à démarrer.
 *
 * Prérequis : une base de données accessible avec le schéma + le jeu de
 * données de démonstration importés (voir database/schema.sql) — mêmes
 * réglages que pour faire tourner le site normalement (config/database.php
 * / config/database.local.php). Le jeu de données de démonstration ne
 * comporte que deux patchs : 5.1 et 5.2, répartis sur les 9 builds.
 *
 * Usage : php tests/test-builds-patch-filter.php
 * Code de sortie : 0 si tous les tests passent, 1 sinon.
 */

require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/core/exceptions.php';
require_once __DIR__ . '/../api/core/validator.php';
require_once __DIR__ . '/../api/builds/repository.php';

$failures = 0;
$total_tests = 0;

/**
 * Vérifie une condition, affiche PASS/FAIL et incrémente les compteurs.
 * N'interrompt jamais l'exécution : tous les tests sont toujours joués.
 */
function check(string $label, bool $condition): void
{
    global $failures, $total_tests;

    $total_tests++;

    if ($condition) {
        echo "  [PASS] $label\n";
        return;
    }

    $failures++;
    echo "  [FAIL] $label\n";
}

/**
 * Vérifie qu'un appel lève bien une ApiException de validation (422),
 * comme le ferait GET /api/builds/?patch=... via apiValidateString() dans
 * index.php pour une valeur invalide (ex. trop longue).
 */
function checkRejected(string $label, callable $callback): void
{
    global $failures, $total_tests;

    $total_tests++;

    try {
        $callback();
        $failures++;
        echo "  [FAIL] $label (aucune exception levée)\n";
    } catch (ApiException $e) {
        if ($e->getStatusCode() === 422) {
            echo "  [PASS] $label\n";
        } else {
            $failures++;
            echo "  [FAIL] $label (code HTTP {$e->getStatusCode()} au lieu de 422)\n";
        }
    }
}

/**
 * Simule exactement le traitement de ?patch= tel que fait par
 * api/builds/index.php : validation puis appel à findBuilds().
 */
function filterByPatch(string $rawPatch): array
{
    $patch = apiValidateString($rawPatch, 'patch', 1, 10);

    return findBuilds(null, null, $patch, null);
}

echo "=== Test du filtre des builds par patch (?patch=) ===\n\n";

// --- Connectivité DB, avant tout --------------------------------------
try {
    getDbConnection();
} catch (Throwable $e) {
    echo "Impossible de se connecter à la base de données. Configurez "
        . "config/database.local.php (voir database.local.php.example) et "
        . "importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

// --- 1. Filtre sur un patch connu ----------------------------------------
echo "1. Filtre sur un patch existant (5.2)\n";
$patch52 = filterByPatch('5.2');
check('patch=5.2 renvoie au moins un résultat', count($patch52) > 0);

$allAre52 = true;
foreach ($patch52 as $build) {
    if ($build['patch'] !== '5.2') {
        $allAre52 = false;
        break;
    }
}
check("tous les résultats de patch=5.2 ont bien patch='5.2'", $allAre52);

// --- 2. Cohérence avec countBuilds() -------------------------------------
echo "\n2. Cohérence avec countBuilds()\n";
$patch52Count = countBuilds(null, null, '5.2', null);
check('countBuilds() correspond au nombre réel de résultats pour patch=5.2', $patch52Count === count($patch52));

// --- 3. Deux patchs distincts ne se mélangent pas -------------------------
echo "\n3. Deux patchs distincts, résultats disjoints\n";
$patch51 = filterByPatch('5.1');
check('patch=5.1 renvoie au moins un résultat', count($patch51) > 0);

$ids52 = array_column($patch52, 'id');
$ids51 = array_column($patch51, 'id');
check('patch=5.2 et patch=5.1 ne renvoient pas les mêmes builds', empty(array_intersect($ids52, $ids51)));

// --- 4. patch=5.2 + patch=5.1 reconstitue la liste complète ---------------
echo "\n4. patch=5.2 + patch=5.1 = liste complète (jeu de données à 2 patchs)\n";
$all = findBuilds(null, null, null, null);
$sumIds = array_merge($ids52, $ids51);
sort($sumIds);
$allIds = array_column($all, 'id');
sort($allIds);
check(
    "additionner patch=5.2 et patch=5.1 retrouve tous les builds (jeu de données démo limité à ces 2 patchs)",
    $sumIds === $allIds
);

// --- 5. Correspondance exacte, pas partielle ------------------------------
echo "\n5. Comparaison exacte du patch (pas de correspondance partielle)\n";
$partial = filterByPatch('5');
check("patch='5' ne matche PAS '5.1' ni '5.2' par préfixe (comparaison exacte, pas LIKE)", $partial === []);

// --- 6. Patch inexistant ---------------------------------------------------
echo "\n6. Patch inexistant\n";
$unknown = filterByPatch('9.9');
check('un patch inexistant renvoie une liste vide (pas une erreur)', $unknown === []);

// --- 7. Filtre combiné à un autre filtre existant (champion=) ------------
echo "\n7. Filtre combiné à un autre filtre (champion=)\n";
$patch = apiValidateString('5.2', 'patch', 1, 10);
$combinedMatch = findBuilds('jinx', null, $patch, null); // le build de jinx est bien patch 5.2
$combinedMismatch = findBuilds('jinx', null, '5.1', null); // jinx n'a pas de build en 5.1

check('champion=jinx + patch=5.2 (patch correct) renvoie au moins un résultat', count($combinedMatch) > 0);
check('champion=jinx + patch=5.1 (patch incorrect) ne renvoie rien', $combinedMismatch === []);

// --- 8. Validation de ?patch= (mêmes règles que index.php) ---------------
echo "\n8. Validation de ?patch=\n";
checkRejected(
    'un patch trop long (> 10 caractères) est rejeté',
    fn () => filterByPatch(str_repeat('9', 11) . '.9')
);

// --- Résumé --------------------------------------------------------------
echo "\n=== Résumé : " . ($total_tests - $failures) . "/$total_tests test(s) réussi(s) ===\n";

exit($failures > 0 ? 1 : 0);
