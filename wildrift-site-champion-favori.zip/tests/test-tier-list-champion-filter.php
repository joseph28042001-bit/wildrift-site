<?php

declare(strict_types=1);

/**
 * Test manuel (CLI, sans framework — même approche que
 * tests/test-builds-champion-filter.php et les autres tests de
 * tests/) du filtre de la tier list par champion
 * (GET /api/tier-list/?champion=...), c'est-à-dire la récupération du
 * classement d'un champion donné.
 *
 * Cette fonctionnalité existait déjà avant cette étape (introduite en
 * même temps que les filtres rôle/patch/tier de /api/tier-list/) : rien
 * n'a été modifié dans le code de l'API pour cette étape, seul ce test a
 * été ajouté pour la couvrir explicitement — même démarche que
 * tests/test-builds-champion-filter.php pour /api/builds/.
 *
 * Ne teste QUE le filtre par champion (?champion=) de la tier list : les
 * autres comportements de /api/tier-list/ (détail par ID, filtres
 * rôle/patch/tier pris isolément, erreurs...) ne sont pas concernés et ne
 * sont pas re-testés ici.
 *
 * Exécute directement les fonctions de api/tier-list/repository.php et
 * api/core/validator.php (même logique que celle utilisée par
 * api/tier-list/index.php) plutôt que de passer par une vraie requête
 * HTTP : plus simple, pas de serveur à démarrer.
 *
 * Prérequis : une base de données accessible avec le schéma + le jeu de
 * données de démonstration importés (voir database/schema.sql) — mêmes
 * réglages que pour faire tourner le site normalement (config/database.php
 * / config/database.local.php). Le jeu de données de démonstration place
 * notamment Malphite en 'baron' sur les patchs 5.1 (tier A) et 5.2
 * (tier S), et Lulu en 'support' sur le patch 5.2 (tier S).
 *
 * Usage : php tests/test-tier-list-champion-filter.php
 * Code de sortie : 0 si tous les tests passent, 1 sinon.
 */

require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/core/exceptions.php';
require_once __DIR__ . '/../api/core/validator.php';
require_once __DIR__ . '/../api/tier-list/repository.php';

$failures = 0;
$total_tests = 0;

/**
 * Vérifie une condition, affiche PASS/FAIL et incrémente les compteurs.
 * N'interrompt jamais l'exécution : tous les tests sont toujours joués.
 */
function check(string $label, bool $condition): void
{
    global $failures, $total_tests;

    $total_tests++;

    if ($condition) {
        echo "  [PASS] $label\n";
        return;
    }

    $failures++;
    echo "  [FAIL] $label\n";
}

/**
 * Vérifie qu'un appel lève bien une ApiException de validation (422),
 * comme le ferait GET /api/tier-list/?champion=... via
 * apiValidateString() dans index.php pour une valeur invalide (ex. trop
 * longue).
 */
function checkRejected(string $label, callable $callback): void
{
    global $failures, $total_tests;

    $total_tests++;

    try {
        $callback();
        $failures++;
        echo "  [FAIL] $label (aucune exception levée)\n";
    } catch (ApiException $e) {
        if ($e->getStatusCode() === 422) {
            echo "  [PASS] $label\n";
        } else {
            $failures++;
            echo "  [FAIL] $label (code HTTP {$e->getStatusCode()} au lieu de 422)\n";
        }
    }
}

/**
 * Simule exactement le traitement de ?champion= tel que fait par
 * api/tier-list/index.php : validation puis appel à findTierList(), les
 * autres filtres (rôle, patch, tier) restant à null.
 */
function filterByChampion(string $rawChampion): array
{
    $champion = apiValidateString($rawChampion, 'champion', 1, 60);

    return findTierList($champion, null, null, null);
}

echo "=== Test du filtre de la tier list par champion (?champion=) ===\n";
echo "=== (récupération du classement d'un champion) ===\n\n";

// --- Connectivité DB, avant tout --------------------------------------
try {
    getDbConnection();
} catch (Throwable $e) {
    echo "Impossible de se connecter à la base de données. Configurez "
        . "config/database.local.php (voir database.local.php.example) et "
        . "importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

// --- 1. Filtre sur un champion connu (slug) -----------------------------
echo "1. Filtre sur un champion existant\n";
$malphiteEntries = filterByChampion('malphite');
check('champion=malphite renvoie au moins un résultat', count($malphiteEntries) > 0);

$allAreMalphite = true;
foreach ($malphiteEntries as $entry) {
    if ($entry['champion'] !== 'Malphite') {
        $allAreMalphite = false;
        break;
    }
}
check("tous les résultats de champion=malphite ont bien 'Malphite' comme champion", $allAreMalphite);

// --- 2. Un champion présent sur plusieurs patchs ---------------------------
// Le classement d'un champion peut couvrir plusieurs entrées (historique
// d'un patch à l'autre) : le filtre doit toutes les renvoyer, pas
// seulement la plus récente.
echo "\n2. Classement complet d'un champion sur plusieurs patchs\n";
check(
    "champion=malphite renvoie ses 2 entrées de classement (patchs 5.1 et 5.2)",
    count($malphiteEntries) === 2
);

$malphitePatches = array_column($malphiteEntries, 'patch');
sort($malphitePatches);
check(
    'champion=malphite couvre bien les patchs 5.1 et 5.2',
    $malphitePatches === ['5.1', '5.2']
);

// --- 3. Filtre par slug, pas par nom affiché -----------------------------
echo "\n3. Filtre par slug (pas par nom affiché ni casse libre)\n";
$byDisplayName = filterByChampion('Malphite');
check(
    "champion='Malphite' (nom affiché, pas le slug) ne renvoie rien : le filtre compare c.slug",
    $byDisplayName === []
);

// --- 4. Un deuxième champion, pour vérifier qu'on ne mélange pas ---------
echo "\n4. Un deuxième champion, résultats distincts\n";
$luluEntries = filterByChampion('lulu');
check('champion=lulu renvoie au moins un résultat', count($luluEntries) > 0);

$malphiteIds = array_column($malphiteEntries, 'id');
$luluIds = array_column($luluEntries, 'id');
check('champion=malphite et champion=lulu ne renvoient pas les mêmes entrées', empty(array_intersect($malphiteIds, $luluIds)));

$allAreLulu = true;
foreach ($luluEntries as $entry) {
    if ($entry['champion'] !== 'Lulu') {
        $allAreLulu = false;
        break;
    }
}
check("tous les résultats de champion=lulu ont bien 'Lulu' comme champion", $allAreLulu);

// --- 5. Champion inexistant ------------------------------------------------
echo "\n5. Champion inexistant\n";
$unknown = filterByChampion('champion-qui-nexiste-pas');
check('un slug de champion inexistant renvoie une liste vide (pas une erreur)', $unknown === []);

// --- 6. Filtre combiné à un autre filtre existant (role=) -----------------
echo "\n6. Filtre combiné à un autre filtre (role=)\n";
$champion = apiValidateString('malphite', 'champion', 1, 60);
$combinedMatch = findTierList($champion, 'baron', null, null); // Malphite est bien 'baron' dans le jeu de données
$combinedMismatch = findTierList($champion, 'support', null, null); // Malphite n'est pas 'support'

check('champion=malphite + role=baron (rôle correct) renvoie des résultats', count($combinedMatch) > 0);
check('champion=malphite + role=support (rôle incorrect) ne renvoie rien', $combinedMismatch === []);

// --- 7. Filtre combiné à patch= et tier=, pour cibler une seule entrée ----
// Contrairement à /api/builds/, une entrée de tier list se distingue par
// le triplet (champion, rôle, patch) : combiner champion= à patch=
// permet de retrouver le classement d'un champion à un instant précis.
echo "\n7. Filtre combiné à patch= et tier=, pour cibler une seule entrée\n";
$onLatestPatch = findTierList($champion, null, '5.2', null);
check('champion=malphite + patch=5.2 cible une seule entrée', count($onLatestPatch) === 1);
check("champion=malphite + patch=5.2 renvoie bien le tier 'S'", ($onLatestPatch[0]['tier'] ?? null) === 'S');

$onOlderPatch = findTierList($champion, null, null, 'A');
check('champion=malphite + tier=A cible bien le patch 5.1 (tier plus faible)', ($onOlderPatch[0]['patch'] ?? null) === '5.1');

// --- 8. Validation de ?champion= (mêmes règles que index.php) -------------
echo "\n8. Validation de ?champion=\n";
checkRejected(
    'un slug de champion trop long (> 60 caractères) est rejeté',
    fn () => filterByChampion(str_repeat('a', 61))
);

// --- Résumé --------------------------------------------------------------
echo "\n=== Résumé : " . ($total_tests - $failures) . "/$total_tests test(s) réussi(s) ===\n";

exit($failures > 0 ? 1 : 0);
