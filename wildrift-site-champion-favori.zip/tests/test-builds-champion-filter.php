<?php

declare(strict_types=1);

/**
 * Test manuel (CLI, sans framework — même approche que
 * tests/test-builds-pagination.php et tests/test-builds-search.php) du
 * filtre des builds par champion (GET /api/builds/?champion=...).
 *
 * Cette fonctionnalité existait déjà avant cette étape (introduite en même
 * temps que la recherche et les filtres rôle/patch) : rien n'a été modifié
 * dans le code de l'API pour cette étape, seul ce test a été ajouté pour la
 * couvrir explicitement.
 *
 * Ne teste QUE le filtre par champion (?champion=) : les autres
 * comportements de /api/builds/ (détail par ID, pagination, recherche par
 * nom, filtres rôle/patch pris isolément, erreurs...) ne sont pas concernés
 * et ne sont pas re-testés ici — voir tests/test-builds-pagination.php et
 * tests/test-builds-search.php pour ces autres fonctionnalités.
 *
 * Exécute directement les fonctions de api/builds/repository.php et
 * api/core/validator.php (même logique que celle utilisée par
 * api/builds/index.php) plutôt que de passer par une vraie requête HTTP :
 * plus simple, pas de serveur à démarrer.
 *
 * Prérequis : une base de données accessible avec le schéma + le jeu de
 * données de démonstration importés (voir database/schema.sql) — mêmes
 * réglages que pour faire tourner le site normalement (config/database.php
 * / config/database.local.php). Le jeu de données de démonstration associe
 * un build à chacun des champions suivants : jinx, miss-fortune, ahri,
 * akali, darius, malphite, master-yi, lee-sin, lulu.
 *
 * Usage : php tests/test-builds-champion-filter.php
 * Code de sortie : 0 si tous les tests passent, 1 sinon.
 */

require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/core/exceptions.php';
require_once __DIR__ . '/../api/core/validator.php';
require_once __DIR__ . '/../api/builds/repository.php';

$failures = 0;
$total_tests = 0;

/**
 * Vérifie une condition, affiche PASS/FAIL et incrémente les compteurs.
 * N'interrompt jamais l'exécution : tous les tests sont toujours joués.
 */
function check(string $label, bool $condition): void
{
    global $failures, $total_tests;

    $total_tests++;

    if ($condition) {
        echo "  [PASS] $label\n";
        return;
    }

    $failures++;
    echo "  [FAIL] $label\n";
}

/**
 * Vérifie qu'un appel lève bien une ApiException de validation (422),
 * comme le ferait GET /api/builds/?champion=... via apiValidateString()
 * dans index.php pour une valeur invalide (ex. trop longue).
 */
function checkRejected(string $label, callable $callback): void
{
    global $failures, $total_tests;

    $total_tests++;

    try {
        $callback();
        $failures++;
        echo "  [FAIL] $label (aucune exception levée)\n";
    } catch (ApiException $e) {
        if ($e->getStatusCode() === 422) {
            echo "  [PASS] $label\n";
        } else {
            $failures++;
            echo "  [FAIL] $label (code HTTP {$e->getStatusCode()} au lieu de 422)\n";
        }
    }
}

/**
 * Simule exactement le traitement de ?champion= tel que fait par
 * api/builds/index.php : validation puis appel à findBuilds().
 */
function filterByChampion(string $rawChampion): array
{
    $champion = apiValidateString($rawChampion, 'champion', 1, 60);

    return findBuilds($champion, null, null, null);
}

echo "=== Test du filtre des builds par champion (?champion=) ===\n\n";

// --- Connectivité DB, avant tout --------------------------------------
try {
    getDbConnection();
} catch (Throwable $e) {
    echo "Impossible de se connecter à la base de données. Configurez "
        . "config/database.local.php (voir database.local.php.example) et "
        . "importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

// --- 1. Filtre sur un champion connu (slug) -----------------------------
echo "1. Filtre sur un champion existant\n";
$jinxBuilds = filterByChampion('jinx');
check('champion=jinx renvoie au moins un résultat', count($jinxBuilds) > 0);

$allAreJinx = true;
foreach ($jinxBuilds as $build) {
    if ($build['champion'] !== 'Jinx') {
        $allAreJinx = false;
        break;
    }
}
check("tous les résultats de champion=jinx ont bien 'Jinx' comme champion", $allAreJinx);

// --- 2. Cohérence avec countBuilds() -------------------------------------
echo "\n2. Cohérence avec countBuilds()\n";
$jinxCount = countBuilds('jinx', null, null, null);
check('countBuilds() correspond au nombre réel de résultats pour champion=jinx', $jinxCount === count($jinxBuilds));

// --- 3. Filtre par slug, pas par nom affiché -----------------------------
echo "\n3. Filtre par slug (pas par nom affiché ni casse libre)\n";
$byDisplayName = filterByChampion('Jinx');
check(
    "champion='Jinx' (nom affiché, pas le slug) ne renvoie rien : le filtre compare c.slug",
    $byDisplayName === []
);

// --- 4. Un deuxième champion, pour vérifier qu'on ne mélange pas ---------
echo "\n4. Un deuxième champion, résultats distincts\n";
$luluBuilds = filterByChampion('lulu');
check('champion=lulu renvoie au moins un résultat', count($luluBuilds) > 0);

$jinxIds = array_column($jinxBuilds, 'id');
$luluIds = array_column($luluBuilds, 'id');
check('champion=jinx et champion=lulu ne renvoient pas les mêmes builds', empty(array_intersect($jinxIds, $luluIds)));

$allAreLulu = true;
foreach ($luluBuilds as $build) {
    if ($build['champion'] !== 'Lulu') {
        $allAreLulu = false;
        break;
    }
}
check("tous les résultats de champion=lulu ont bien 'Lulu' comme champion", $allAreLulu);

// --- 5. Champion inexistant ------------------------------------------------
echo "\n5. Champion inexistant\n";
$unknown = filterByChampion('champion-qui-nexiste-pas');
check('un slug de champion inexistant renvoie une liste vide (pas une erreur)', $unknown === []);

// --- 6. Filtre combiné à un autre filtre existant (role=) -----------------
echo "\n6. Filtre combiné à un autre filtre (role=)\n";
$champion = apiValidateString('darius', 'champion', 1, 60);
$combinedMatch = findBuilds($champion, 'baron', null, null); // darius est bien 'baron' dans le jeu de données
$combinedMismatch = findBuilds($champion, 'support', null, null); // darius n'est pas 'support'

check('champion=darius + role=baron (rôle correct) renvoie au moins un résultat', count($combinedMatch) > 0);
check('champion=darius + role=support (rôle incorrect) ne renvoie rien', $combinedMismatch === []);

// --- 7. Validation de ?champion= (mêmes règles que index.php) -------------
echo "\n7. Validation de ?champion=\n";
checkRejected(
    'un slug de champion trop long (> 60 caractères) est rejeté',
    fn () => filterByChampion(str_repeat('a', 61))
);

// --- Résumé --------------------------------------------------------------
echo "\n=== Résumé : " . ($total_tests - $failures) . "/$total_tests test(s) réussi(s) ===\n";

exit($failures > 0 ? 1 : 0);
