<?php

declare(strict_types=1);

/**
 * Test manuel (CLI, sans framework — même approche que les autres fichiers
 * tests/test-builds-*.php et tests/test-tier-list-*.php) de l'ensemble de
 * l'API Actualités (GET /api/news/) : liste, recherche, filtre par
 * catégorie, articles récents, détail par ID, ainsi que tous les cas
 * d'erreur associés.
 *
 * Contrairement aux fichiers tests/test-builds-*.php, ajoutés au fil de
 * chaque étape ayant introduit la fonctionnalité correspondante, l'API
 * Actualités n'avait encore aucun test : ce fichier couvre donc d'un coup
 * l'ensemble de ce qui existe aujourd'hui sur /api/news/ (liste, ?search=,
 * ?category=, ?limit=, ?id=, méthode HTTP, codes d'erreur) plutôt que
 * d'être scindé par fonctionnalité comme pour builds.
 *
 * Relecture complète de api/news/index.php, api/news/repository.php et
 * api/core/{validator,exceptions,runner,response}.php à cette étape :
 * aucun bug n'a été trouvé dans le comportement testé ici — validation
 * (apiValidateInt/apiValidateString/apiValidateEnum), priorité/exclusivité
 * de ?id=, combinaison de ?search=/?category=/?limit=, exclusion des
 * brouillons (published_at NULL) en liste comme par ID, 404 explicite,
 * 405 sur méthode non autorisée : tout était déjà correct. Aucun code n'a
 * donc été modifié pour corriger un bug — ce fichier ajoute uniquement la
 * couverture de test qui manquait.
 *
 * Exécute directement les fonctions de api/news/repository.php et
 * api/core/validator.php (même logique que celle utilisée par
 * api/news/index.php) plutôt que de passer par une vraie requête HTTP :
 * plus simple, pas de serveur à démarrer — même choix que les autres
 * fichiers tests/test-builds-*.php.
 *
 * Prérequis : une base de données accessible avec le schéma + le jeu de
 * données de démonstration importés (voir database/schema.sql) — mêmes
 * réglages que pour faire tourner le site normalement (config/database.php
 * / config/database.local.php). Le jeu de données de démonstration
 * comporte 4 actualités publiées (une par catégorie : patch, esport,
 * evenement, communaute) et 1 brouillon non publié (published_at NULL,
 * slug 'brouillon-notes-patch-5-3', catégorie 'patch').
 *
 * Usage : php tests/test-news-api.php
 * Code de sortie : 0 si tous les tests passent, 1 sinon.
 */

require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/core/exceptions.php';
require_once __DIR__ . '/../api/core/validator.php';
require_once __DIR__ . '/../api/news/repository.php';

$failures = 0;
$total_tests = 0;

/**
 * Vérifie une condition, affiche PASS/FAIL et incrémente les compteurs.
 * N'interrompt jamais l'exécution : tous les tests sont toujours joués.
 */
function check(string $label, bool $condition): void
{
    global $failures, $total_tests;

    $total_tests++;

    if ($condition) {
        echo "  [PASS] $label\n";
        return;
    }

    $failures++;
    echo "  [FAIL] $label\n";
}

/**
 * Vérifie qu'un appel lève bien une ApiException avec le code HTTP attendu
 * (422 par défaut, pour les erreurs de validation). Affiche le code réel en
 * cas d'échec pour faciliter le diagnostic.
 */
function checkRejected(string $label, callable $callback, int $expectedStatusCode = 422): void
{
    global $failures, $total_tests;

    $total_tests++;

    try {
        $callback();
        $failures++;
        echo "  [FAIL] $label (aucune exception levée)\n";
    } catch (ApiException $e) {
        if ($e->getStatusCode() === $expectedStatusCode) {
            echo "  [PASS] $label\n";
        } else {
            $failures++;
            echo "  [FAIL] $label (code HTTP {$e->getStatusCode()} au lieu de $expectedStatusCode)\n";
        }
    }
}

/**
 * Simule exactement le traitement de GET /api/news/?id=... tel que fait
 * par api/news/index.php : validation de l'ID, recherche de l'article,
 * ApiException::notFound (404) s'il n'existe pas (ou n'est pas publié).
 */
function getNewsDetail(string $rawId): array
{
    $id = apiValidateInt($rawId, 'id', 1);

    $article = findNewsById($id);

    if ($article === null) {
        throw ApiException::notFound("Aucun article publié trouvé avec l'ID $id.");
    }

    return $article;
}

/**
 * Simule exactement le traitement de la méthode HTTP tel que fait par
 * api/news/index.php : apiRequireMethod(['GET']) en tout premier.
 * Manipule $_SERVER['REQUEST_METHOD'] le temps de l'appel puis le restaure,
 * pour ne pas polluer le reste du script (exécuté en CLI, où cette clé
 * n'est normalement pas définie).
 *
 * apiRequireMethod() envoie un en-tête HTTP (Allow:) avant de lever son
 * exception 405 — correct et sans effet en usage normal (avant tout
 * affichage), mais ce script CLI a déjà produit du texte à l'écran à ce
 * stade, ce qui déclenche un simple avertissement PHP ("headers already
 * sent"), sans rapport avec la validité du test. On l'ignore ici, le temps
 * de l'appel, pour garder une sortie de test propre.
 */
function callWithMethod(string $method, callable $callback): void
{
    $previous = $_SERVER['REQUEST_METHOD'] ?? null;
    $_SERVER['REQUEST_METHOD'] = $method;

    set_error_handler(static function (int $errno, string $errstr): bool {
        return str_contains($errstr, 'headers already sent');
    }, E_WARNING);

    try {
        $callback();
    } finally {
        restore_error_handler();
        if ($previous === null) {
            unset($_SERVER['REQUEST_METHOD']);
        } else {
            $_SERVER['REQUEST_METHOD'] = $previous;
        }
    }
}

echo "=== Test de l'API Actualités (/api/news/) ===\n\n";

// --- Connectivité DB, avant tout --------------------------------------
try {
    getDbConnection();
} catch (Throwable $e) {
    echo "Impossible de se connecter à la base de données. Configurez "
        . "config/database.local.php (voir database.local.php.example) et "
        . "importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

// --- 0. Jeu de données de démonstration présent -----------------------
$allNews = findAllNews();
if (count($allNews) === 0) {
    echo "Jeu de données de démonstration introuvable (aucune actualité "
        . "publiée). Importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

// --- 1. Liste complète (cas nominal) -----------------------------------
echo "1. Liste complète des actualités publiées (sans filtre)\n";
check(
    "exactement 4 actualités publiées dans le jeu de données de démonstration (le brouillon est exclu)",
    count($allNews) === 4
);
check(
    "aucun article renvoyé n'a de published_at vide (les brouillons sont exclus)",
    !in_array(null, array_column($allNews, 'published_at'), true)
);
$publishedDates = array_column($allNews, 'published_at');
$sortedDates = $publishedDates;
rsort($sortedDates);
check(
    "les actualités sont triées par date de publication décroissante (la plus récente d'abord)",
    $publishedDates === $sortedDates
);
check(
    "un article en liste ne contient pas le corps complet ('content'), réservé au détail",
    !array_key_exists('content', $allNews[0])
);

// --- 2. Recherche par titre (?search=) ----------------------------------
echo "\n2. Recherche par titre (?search=)\n";
check(
    "search='patch' ne trouve que l'article publié dont le titre contient 'patch' (le brouillon 'patch' est exclu)",
    count(findAllNews('patch')) === 1
);
check(
    "search='Wild Rift' trouve l'article Championship",
    count(findAllNews('Wild Rift')) === 1
);
check(
    "search='xyznexistepas' ne trouve aucun article (liste vide, pas une erreur)",
    findAllNews('xyznexistepas') === []
);
checkRejected(
    "search trop long (> 150 caractères) est rejeté",
    fn () => apiValidateString(str_repeat('a', 151), 'search', 1, 150)
);
check(
    "search de 150 caractères exactement est accepté (limite incluse)",
    apiValidateString(str_repeat('a', 150), 'search', 1, 150) === str_repeat('a', 150)
);

// --- 3. Filtre par catégorie (?category=) -------------------------------
echo "\n3. Filtre par catégorie (?category=)\n";
foreach (getNewsCategories() as $category) {
    check(
        "category='$category' ne renvoie que des articles de cette catégorie",
        array_reduce(
            findAllNews(null, $category),
            fn (bool $carry, array $article): bool => $carry && $article['category'] === $category,
            true
        )
    );
}
check(
    "category='patch' ne renvoie qu'un seul article publié (le brouillon 'patch' est exclu)",
    count(findAllNews(null, 'patch')) === 1
);
checkRejected(
    "category='inexistant' (hors énumération) est rejeté",
    fn () => apiValidateEnum('inexistant', 'category', getNewsCategories())
);
checkRejected(
    "category='Patch' (casse incorrecte) est rejeté",
    fn () => apiValidateEnum('Patch', 'category', getNewsCategories())
);

// --- 4. Articles récents (?limit=) ---------------------------------------
echo "\n4. Articles récents (?limit=)\n";
check(
    "limit=2 renvoie exactement 2 articles",
    count(findAllNews(null, null, 2)) === 2
);
check(
    "limit=2 renvoie bien les 2 plus récents (mêmes 2 premiers que la liste complète)",
    array_slice(array_column($allNews, 'id'), 0, 2) === array_column(findAllNews(null, null, 2), 'id')
);
check(
    "limit supérieur au nombre total d'articles ne provoque pas d'erreur (renvoie tout ce qui existe)",
    count(findAllNews(null, null, NEWS_MAX_RECENT_LIMIT)) === count($allNews)
);
checkRejected("limit='0' (inférieur au minimum) est rejeté", fn () => apiValidateInt('0', 'limit', 1, NEWS_MAX_RECENT_LIMIT));
checkRejected("limit='-1' (négatif) est rejeté", fn () => apiValidateInt('-1', 'limit', 1, NEWS_MAX_RECENT_LIMIT));
checkRejected("limit='abc' (non numérique) est rejeté", fn () => apiValidateInt('abc', 'limit', 1, NEWS_MAX_RECENT_LIMIT));
checkRejected(
    'limit dépassant NEWS_MAX_RECENT_LIMIT (21) est rejeté',
    fn () => apiValidateInt((string) (NEWS_MAX_RECENT_LIMIT + 1), 'limit', 1, NEWS_MAX_RECENT_LIMIT)
);
check(
    'limit=NEWS_MAX_RECENT_LIMIT exactement est accepté (limite incluse)',
    apiValidateInt((string) NEWS_MAX_RECENT_LIMIT, 'limit', 1, NEWS_MAX_RECENT_LIMIT) === NEWS_MAX_RECENT_LIMIT
);

// --- 5. Filtres combinés (?search=&?category=&?limit=) -------------------
echo "\n5. Filtres combinés\n";
check(
    "category='esport'&limit=1 renvoie bien l'unique article esport",
    (findAllNews(null, 'esport', 1)[0]['category'] ?? null) === 'esport'
);
check(
    "search='patch'&category='esport' (catégories incompatibles) ne renvoie aucun résultat",
    findAllNews('patch', 'esport') === []
);

// --- 6. Détail par ID (?id=) ----------------------------------------------
echo "\n6. Détail d'un article précis (?id=)\n";
$anyPublished = $allNews[0];
$existingId = (int) $anyPublished['id'];
$detail = getNewsDetail((string) $existingId);
check("id=$existingId (existant, publié) ne lève aucune erreur et renvoie le détail", $detail['id'] === $existingId);
check(
    "le détail d'un article publié contient bien le corps complet ('content')",
    array_key_exists('content', $detail) && $detail['content'] !== null
);
check(
    "le détail d'un article publié contient bien les dates ('created_at', 'updated_at')",
    array_key_exists('created_at', $detail) && array_key_exists('updated_at', $detail)
);

checkRejected("id='abc' (non numérique) est rejeté", fn () => getNewsDetail('abc'));
checkRejected("id='1.5' (décimal) est rejeté", fn () => getNewsDetail('1.5'));
checkRejected("id='5abc' (numérique + texte) est rejeté", fn () => getNewsDetail('5abc'));
checkRejected("id='-1' (négatif) est rejeté", fn () => getNewsDetail('-1'));
checkRejected("id='0' (inférieur au minimum autorisé) est rejeté", fn () => getNewsDetail('0'));

checkRejected(
    "id=999999 (format valide, article absent) déclenche bien une erreur 404, pas 422",
    fn () => getNewsDetail('999999'),
    404
);
check(
    "findNewsById() renvoie bien null pour un ID inexistant (avant que index.php ne lève l'exception)",
    findNewsById(999999) === null
);

// --- 7. Un brouillon n'est jamais accessible, même par son propre ID ------
// Cas spécifique à Actualités (pas d'équivalent "brouillon" chez builds/
// tier-list) : un article existe bel et bien en base avec cet ID, la
// différence avec le cas #6 ci-dessus (999999, qui n'existe pas du tout)
// est essentielle à vérifier séparément.
echo "\n7. Brouillon non publié : jamais renvoyé, même par son propre ID\n";
$draftRow = dbFetchOne('SELECT id FROM news WHERE slug = :slug', ['slug' => 'brouillon-notes-patch-5-3']);
if ($draftRow === null) {
    echo "  Brouillon de démonstration introuvable (slug 'brouillon-notes-patch-5-3'). "
        . "Importez database/schema.sql avant de lancer ce test.\n";
    $failures++;
    $total_tests++;
} else {
    $draftId = (int) $draftRow['id'];
    check(
        "l'article brouillon existe bien en base (id=$draftId) mais findNewsById() renvoie null",
        findNewsById($draftId) === null
    );
    checkRejected(
        "id=$draftId (brouillon existant mais non publié) déclenche bien une erreur 404, pas un succès",
        fn () => getNewsDetail((string) $draftId),
        404
    );
    check(
        "le brouillon n'apparaît jamais dans findAllNews(), quels que soient les filtres (ex. category='patch')",
        !in_array($draftId, array_column(findAllNews(null, 'patch'), 'id'), true)
    );
}

// --- 8. Méthode HTTP non autorisée -----------------------------------------
echo "\n8. Méthode HTTP non autorisée\n";
checkRejected(
    'POST sur /api/news/ (lecture seule, GET uniquement) est rejeté avec 405',
    fn () => callWithMethod('POST', fn () => apiRequireMethod(['GET'])),
    405
);
checkRejected(
    'DELETE sur /api/news/ est rejeté avec 405',
    fn () => callWithMethod('DELETE', fn () => apiRequireMethod(['GET'])),
    405
);
check(
    'GET sur /api/news/ (méthode autorisée) ne lève aucune erreur',
    (function (): bool {
        try {
            callWithMethod('GET', fn () => apiRequireMethod(['GET']));
            return true;
        } catch (ApiException $e) {
            return false;
        }
    })()
);

// --- 9. Code d'erreur machine-readable (détails de la réponse JSON) -------
// Vérifie que chaque famille d'erreur porte le bon errorCode (voir
// ApiException et api/core/response.php pour la forme JSON finale
// { success: false, error: { code, message } }), pas seulement le bon code
// HTTP.
echo "\n9. Code d'erreur machine-readable\n";
try {
    getNewsDetail('abc');
    check("id invalide : errorCode = 'validation_error'", false);
} catch (ApiException $e) {
    check("id invalide : errorCode = 'validation_error'", $e->getErrorCode() === 'validation_error');
}
try {
    getNewsDetail('999999');
    check("article inexistant : errorCode = 'not_found'", false);
} catch (ApiException $e) {
    check("article inexistant : errorCode = 'not_found'", $e->getErrorCode() === 'not_found');
}
try {
    apiValidateEnum('inexistant', 'category', getNewsCategories());
    check("catégorie invalide : errorCode = 'validation_error'", false);
} catch (ApiException $e) {
    check("catégorie invalide : errorCode = 'validation_error'", $e->getErrorCode() === 'validation_error');
}
try {
    callWithMethod('POST', fn () => apiRequireMethod(['GET']));
    check("méthode non autorisée : errorCode = 'method_not_allowed'", false);
} catch (ApiException $e) {
    check("méthode non autorisée : errorCode = 'method_not_allowed'", $e->getErrorCode() === 'method_not_allowed');
}

// --- Résumé --------------------------------------------------------------
echo "\n=== Résumé : " . ($total_tests - $failures) . "/$total_tests test(s) réussi(s) ===\n";

exit($failures > 0 ? 1 : 0);
