<?php
/**
 * Test de connexion à la base de données MySQL.
 * ------------------------------------------------------------
 * Vérifie, avec exactement les réglages que le site utilise
 * (config/database.local.php via config/database.php) :
 *   1. que la connexion MySQL s'établit et que la base connectée est
 *      bien DB_NAME ;
 *   2. que les tables et colonnes lues par l'API Builds existent
 *      (dont build_items.situation, absente des anciennes bases) ;
 *   3. que la chaîne de requêtes de GET /api/builds/?champion=jinx puis
 *      GET /api/builds/?id=<id> s'exécute sans erreur SQL.
 *
 * Le mot de passe n'est jamais affiché (seulement "renseigné"/"VIDE").
 *
 * Réservé à la ligne de commande : ce fichier ne fait rien s'il est
 * appelé via le web (au cas où le dossier tests/ serait envoyé sur le
 * serveur par erreur).
 *
 * Attention : InfinityFree n'accepte en général les connexions MySQL
 * que depuis son propre hébergement, pas depuis un ordinateur
 * personnel. Ce test sert donc surtout en local (base locale) ; sur
 * InfinityFree, la vérification équivalente est d'ouvrir
 * /api/builds/?champion=jinx dans le navigateur (réponse JSON avec
 * "success": true si tout va bien).
 *
 * Usage : php tests/test-db-connection.php
 * Code de sortie : 0 si tous les tests passent, 1 sinon.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/core/exceptions.php';
require_once __DIR__ . '/../api/builds/repository.php';

$failures = 0;
$total_tests = 0;

/**
 * Vérifie une condition, affiche PASS/FAIL et incrémente les compteurs.
 * N'interrompt jamais l'exécution (même convention que les autres
 * tests/test-*.php).
 */
function check(string $label, bool $condition): void
{
    global $failures, $total_tests;

    $total_tests++;

    if ($condition) {
        echo "  [PASS] $label\n";
        return;
    }

    $failures++;
    echo "  [FAIL] $label\n";
}

echo "Configuration active (le mot de passe n'est jamais affiché) :\n";
echo '  Hôte        : ' . DB_HOST . "\n";
echo '  Port        : ' . DB_PORT . "\n";
echo '  Base        : ' . DB_NAME . "\n";
echo '  Utilisateur : ' . DB_USER . "\n";
echo '  Mot de passe: ' . (DB_PASS !== '' ? 'renseigné' : 'VIDE') . "\n";
echo '  SITE_URL    : ' . SITE_URL . "\n\n";

echo "1. Connexion\n";

check(
    'Fichier config/database.local.php présent',
    file_exists(__DIR__ . '/../config/database.local.php')
);

try {
    $pdo = new PDO(getDbDsn(), DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    check('Connexion MySQL établie', true);
} catch (PDOException $e) {
    check('Connexion MySQL établie', false);
    // Le message PDO ne contient jamais le mot de passe (ex. "Access
    // denied for user ... (using password: YES)").
    echo '  Cause : ' . $e->getMessage() . "\n";
    echo "\n$failures échec(s) sur $total_tests test(s).\n";
    exit(1);
}

$connectedDatabase = $pdo->query('SELECT DATABASE()')->fetchColumn();
check('La base connectée est bien DB_NAME', $connectedDatabase === DB_NAME);

echo "\n2. Tables et colonnes utilisées par l'API Builds\n";

$tables = array_map('strtolower', $pdo->query(
    'SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE()'
)->fetchAll(PDO::FETCH_COLUMN));

foreach (['champions', 'items', 'runes', 'builds', 'build_items', 'build_runes', 'build_skill_order', 'counters', 'counter_items'] as $table) {
    check("Table $table présente", in_array($table, $tables, true));
}

$columns = [];
$columnRows = $pdo->query(
    'SELECT table_name, column_name FROM information_schema.columns WHERE table_schema = DATABASE()'
)->fetchAll(PDO::FETCH_NUM);
foreach ($columnRows as $columnRow) {
    $columns[strtolower($columnRow[0])][strtolower($columnRow[1])] = true;
}

$requiredColumns = [
    'champions'     => ['slug', 'image_url'],
    'items'         => ['slug', 'description', 'image_url'],
    'runes'         => ['slug', 'slot', 'image_url'],
    'builds'        => ['description', 'source'],
    'build_items'   => ['slot', 'purchase_order', 'situation'],
    'build_runes'   => ['position'],
    'counter_items' => ['purchase_order', 'situation'],
];
foreach ($requiredColumns as $table => $tableColumns) {
    foreach ($tableColumns as $column) {
        check("Colonne $table.$column présente", isset($columns[$table][$column]));
    }
}

echo "\n3. Requêtes de l'API Builds (page build de Jinx)\n";

try {
    $championCount = (int) $pdo->query('SELECT COUNT(*) FROM champions')->fetchColumn();
    $buildCount = (int) $pdo->query('SELECT COUNT(*) FROM builds')->fetchColumn();
    echo "  ($championCount champions, $buildCount builds en base)\n";

    $builds = findBuilds('jinx', null, null, null);
    check('GET /api/builds/?champion=jinx : au moins un build', count($builds) > 0);

    if (count($builds) > 0) {
        $buildId = (int) $builds[0]['id'];

        check('GET /api/builds/?id=' . $buildId . ' : détail trouvé', findBuildById($buildId) !== null);

        findBuildItemsGrouped($buildId);
        findBuildRunes($buildId);
        findBuildSkillOrder($buildId);
        check('Objets, runes et ordre des compétences lus sans erreur SQL', true);
    }
} catch (DatabaseException $e) {
    check('Requêtes de l\'API Builds exécutées sans erreur SQL', false);
    echo "  Cause : voir la ligne \"[DB] Requête échouée\" dans le journal d'erreurs PHP.\n";
}

echo "\n$failures échec(s) sur $total_tests test(s).\n";
exit($failures > 0 ? 1 : 0);
