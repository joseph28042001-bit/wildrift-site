<?php

declare(strict_types=1);

/**
 * Test manuel (CLI, sans framework — même approche que les autres fichiers
 * tests/test-*.php) de l'import des patchs WRChina (étape 22.2).
 *
 * Ne teste QUE l'import des patchs (WrChinaPatchImporter, WrChinaRepository
 * côté wrchina_patches). Ne touche à rien d'autre (builds, tier-list,
 * payloads bruts wrchina_raw_payloads...).
 *
 * Utilise un fichier de staging FIXTURE dédié (voir $fixturePath
 * ci-dessous), jamais data/wrchina/patches.json, pour ne pas dépendre
 * de son contenu et pouvoir couvrir précisément : un patch valide
 * complet, un patch valide avec champs facultatifs absents, un patch
 * invalide (patch_number manquant), et — au deuxième import — la
 * mise à jour d'un patch déjà importé (anti-doublons).
 *
 * Nettoie ses propres données avant ET après exécution (patch_number
 * commençant par 'TEST-'), pour rester rejouable sans laisser de
 * résidus ni interférer avec de vraies données.
 *
 * Prérequis : une base de données accessible avec le schéma importé
 * (voir database/schema.sql) — mêmes réglages que pour faire tourner
 * le site normalement (config/database.php / config/database.local.php).
 *
 * Usage : php tests/test-wrchina-patch-import.php
 * Code de sortie : 0 si tous les tests passent, 1 sinon.
 */

require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/wrchina.php';
require_once __DIR__ . '/../includes/wrchina/WrChinaApiClient.php';
require_once __DIR__ . '/../includes/wrchina/WrChinaRepository.php';
require_once __DIR__ . '/../includes/wrchina/WrChinaPatchImporter.php';

$failures = 0;
$total_tests = 0;

/**
 * Vérifie une condition, affiche PASS/FAIL et incrémente les compteurs.
 * N'interrompt jamais l'exécution : tous les tests sont toujours joués.
 */
function check(string $label, bool $condition): void
{
    global $failures, $total_tests;

    $total_tests++;

    if ($condition) {
        echo "  [PASS] $label\n";
        return;
    }

    $failures++;
    echo "  [FAIL] $label\n";
}

/** Supprime toutes les lignes de test (patch_number LIKE 'TEST-%'). */
function cleanupTestPatches(): void
{
    dbExecute("DELETE FROM wrchina_patches WHERE patch_number LIKE 'TEST-%'");
}

echo "=== Test de l'import des patchs WRChina (étape 22.2) ===\n\n";

// --- Connectivité DB, avant tout --------------------------------------
try {
    getDbConnection();
} catch (Throwable $e) {
    echo "Impossible de se connecter à la base de données. Configurez "
        . "config/database.local.php (voir database.local.php.example) et "
        . "importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

cleanupTestPatches();

// --- Préparation du fichier de staging fixture ----------------------------
$fixturePath = sys_get_temp_dir() . '/wrchina-patches-test-' . uniqid() . '.json';
$fixtureFirstRun = [
    [
        'patch_number' => 'TEST-1.0',
        'patch_name' => 'Patch de test complet',
        'patch_date' => '2025-01-15',
        'status' => 'publié',
        'source' => 'WRChina.gg',
        'source_url' => 'https://www.wrchina.gg/patch-notes/test-1-0',
    ],
    [
        // Champs facultatifs absents : doit quand même être importé.
        'patch_number' => 'TEST-1.1',
    ],
    [
        // Invalide : patch_number manquant, doit être rejeté sans
        // bloquer l'import des deux entrées valides ci-dessus.
        'patch_name' => 'Patch sans numéro',
    ],
];
file_put_contents($fixturePath, json_encode($fixtureFirstRun, JSON_UNESCAPED_UNICODE));

$client = new WrChinaApiClient(null, null, null, $fixturePath);

// --- 1. Premier import : création --------------------------------------
echo "1. Premier import (2 patchs valides, 1 invalide)\n";
$result1 = importWrChinaPatches($client);

check('statut global = success', $result1['status'] === 'success');
check('2 patchs créés', $result1['created'] === 2);
check('0 patch mis à jour', $result1['updated'] === 0);
check('1 patch rejeté (patch_number manquant)', $result1['invalid'] === 1);
check('total = 3', $result1['total'] === 3);
check("message d'erreur mentionne le rejet", count($result1['errors']) === 1);
check('sync_log_id renvoyé', $result1['sync_log_id'] > 0);

$countAfterFirst = countWrChinaPatches();
check('wrchina_patches contient bien 2 lignes TEST-*', $countAfterFirst >= 2);

$testPatch10 = findWrChinaPatchByNumber('TEST-1.0');
check('TEST-1.0 retrouvé en base', $testPatch10 !== null);
check('TEST-1.0 : nom correct', ($testPatch10['patch_name'] ?? null) === 'Patch de test complet');
check('TEST-1.0 : date correcte', ($testPatch10['patch_date'] ?? null) === '2025-01-15');
check('TEST-1.0 : statut correct', ($testPatch10['status'] ?? null) === 'publié');
check('TEST-1.0 : source_url correcte', ($testPatch10['source_url'] ?? null) === 'https://www.wrchina.gg/patch-notes/test-1-0');
check('TEST-1.0 : fetched_at renseignée', !empty($testPatch10['fetched_at'] ?? null));

$testPatch11 = findWrChinaPatchByNumber('TEST-1.1');
check('TEST-1.1 retrouvé en base malgré les champs facultatifs absents', $testPatch11 !== null);
check('TEST-1.1 : source par défaut = WRChina.gg', ($testPatch11['source'] ?? null) === 'WRChina.gg');
check('TEST-1.1 : nom NULL (non communiqué)', ($testPatch11['patch_name'] ?? 'NON_NULL') === null);

// --- 2. Deuxième import : anti-doublons (mise à jour, pas de doublon) -----
echo "\n2. Deuxième import du même TEST-1.0, avec un statut modifié (anti-doublons)\n";
$fixtureSecondRun = [
    [
        'patch_number' => 'TEST-1.0',
        'patch_name' => 'Patch de test complet',
        'patch_date' => '2025-01-15',
        'status' => 'archivé',
        'source' => 'WRChina.gg',
        'source_url' => 'https://www.wrchina.gg/patch-notes/test-1-0',
    ],
];
file_put_contents($fixturePath, json_encode($fixtureSecondRun, JSON_UNESCAPED_UNICODE));

$countBeforeSecond = countWrChinaPatches();
$result2 = importWrChinaPatches($client);

check('statut global = success', $result2['status'] === 'success');
check('0 patch créé (déjà existant)', $result2['created'] === 0);
check('1 patch mis à jour', $result2['updated'] === 1);
check('0 patch rejeté', $result2['invalid'] === 0);

$countAfterSecond = countWrChinaPatches();
check(
    'aucun doublon créé : le nombre total de patchs ne change pas',
    $countAfterSecond === $countBeforeSecond
);

$testPatch10Updated = findWrChinaPatchByNumber('TEST-1.0');
check('TEST-1.0 : statut bien mis à jour (archivé)', ($testPatch10Updated['status'] ?? null) === 'archivé');
check(
    "TEST-1.0 : un seul identifiant, inchangé après mise à jour (pas de nouvelle ligne)",
    ($testPatch10Updated['id'] ?? null) === ($testPatch10['id'] ?? null)
);

// --- 3. Échec de récupération (fichier de staging introuvable) -----------
echo "\n3. Fichier de staging introuvable : échec propre, journalisé\n";
$missingClient = new WrChinaApiClient(null, null, null, sys_get_temp_dir() . '/wrchina-fichier-inexistant-' . uniqid() . '.json');
$result3 = importWrChinaPatches($missingClient);

check('statut global = failed', $result3['status'] === 'failed');
check('0 patch créé', $result3['created'] === 0);
check('0 patch mis à jour', $result3['updated'] === 0);
check('au moins une erreur remontée', count($result3['errors']) > 0);
check('sync_log_id renvoyé même en échec', $result3['sync_log_id'] > 0);

$syncLogEntries = findWrChinaSyncLog('patches', 5);
check('le journal de synchronisation contient bien nos tentatives', count($syncLogEntries) >= 3);
check(
    "la tentative la plus récente (fichier introuvable) est journalisée en 'failed'",
    ($syncLogEntries[0]['status'] ?? null) === 'failed'
);

// --- Nettoyage -------------------------------------------------------------
cleanupTestPatches();
if (file_exists($fixturePath)) {
    unlink($fixturePath);
}

// --- Résumé ------------------------------------------------------------
echo "\n=== Résumé ===\n";
echo "$total_tests tests exécutés, " . ($total_tests - $failures) . " réussis, $failures échoués.\n";

exit($failures > 0 ? 1 : 0);
