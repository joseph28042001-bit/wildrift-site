<?php

declare(strict_types=1);

/**
 * Test manuel (CLI, sans framework — même approche que
 * tests/test-builds-pagination.php) de la recherche de builds par nom
 * (GET /api/builds/?search=...).
 *
 * Cette fonctionnalité existait déjà avant cette étape (introduite en même
 * temps que les filtres champion/rôle/patch) : rien n'a été modifié dans
 * le code de l'API pour cette étape, seul ce test a été ajouté pour la
 * couvrir explicitement.
 *
 * Ne teste QUE la recherche par nom (?search=) : les autres comportements
 * de /api/builds/ (détail par ID, pagination, filtres champion/rôle/patch
 * pris isolément, erreurs...) ne sont pas concernés et ne sont pas
 * re-testés ici — voir tests/test-builds-pagination.php pour la pagination.
 *
 * Exécute directement les fonctions de api/builds/repository.php et
 * api/core/validator.php (même logique que celle utilisée par
 * api/builds/index.php) plutôt que de passer par une vraie requête HTTP :
 * plus simple, pas de serveur à démarrer.
 *
 * Prérequis : une base de données accessible avec le schéma + le jeu de
 * données de démonstration importés (voir database/schema.sql) — mêmes
 * réglages que pour faire tourner le site normalement (config/database.php
 * / config/database.local.php).
 *
 * Usage : php tests/test-builds-search.php
 * Code de sortie : 0 si tous les tests passent, 1 sinon.
 */

require_once __DIR__ . '/../config/environment.php';
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/core/exceptions.php';
require_once __DIR__ . '/../api/core/validator.php';
require_once __DIR__ . '/../api/builds/repository.php';

$failures = 0;
$total_tests = 0;

/**
 * Vérifie une condition, affiche PASS/FAIL et incrémente les compteurs.
 * N'interrompt jamais l'exécution : tous les tests sont toujours joués.
 */
function check(string $label, bool $condition): void
{
    global $failures, $total_tests;

    $total_tests++;

    if ($condition) {
        echo "  [PASS] $label\n";
        return;
    }

    $failures++;
    echo "  [FAIL] $label\n";
}

/**
 * Vérifie qu'un appel lève bien une ApiException de validation (422),
 * comme le ferait GET /api/builds/?search=... via apiValidateString() dans
 * index.php pour une valeur invalide (ex. trop longue).
 */
function checkRejected(string $label, callable $callback): void
{
    global $failures, $total_tests;

    $total_tests++;

    try {
        $callback();
        $failures++;
        echo "  [FAIL] $label (aucune exception levée)\n";
    } catch (ApiException $e) {
        if ($e->getStatusCode() === 422) {
            echo "  [PASS] $label\n";
        } else {
            $failures++;
            echo "  [FAIL] $label (code HTTP {$e->getStatusCode()} au lieu de 422)\n";
        }
    }
}

/**
 * Simule exactement le traitement de ?search= tel que fait par
 * api/builds/index.php : validation puis appel à findBuilds().
 */
function searchBuilds(string $rawSearch): array
{
    $search = apiValidateString($rawSearch, 'search', 1, 60);

    return findBuilds(null, null, null, $search);
}

echo "=== Test de la recherche de builds par nom (?search=) ===\n\n";

// --- Connectivité DB, avant tout --------------------------------------
try {
    getDbConnection();
} catch (Throwable $e) {
    echo "Impossible de se connecter à la base de données. Configurez "
        . "config/database.local.php (voir database.local.php.example) et "
        . "importez database/schema.sql avant de lancer ce test.\n";
    exit(1);
}

// --- 1. Recherche renvoyant plusieurs résultats -------------------------
echo "1. Recherche avec plusieurs correspondances\n";
$resultsFull = searchBuilds('full');
check('search=full renvoie au moins un résultat', count($resultsFull) > 0);

$allNamesContainFull = true;
foreach ($resultsFull as $build) {
    if (mb_stripos($build['name'], 'full') === false) {
        $allNamesContainFull = false;
        break;
    }
}
check("chaque résultat de search=full contient bien 'full' dans son nom", $allNamesContainFull);

// --- 2. Insensibilité à la casse ----------------------------------------
echo "\n2. Insensibilité à la casse\n";
$lower = searchBuilds('full');
$upper = searchBuilds('FULL');
$mixed = searchBuilds('FuLL');
check('search=FULL (majuscules) renvoie les mêmes résultats que search=full', $upper === $lower);
check('search=FuLL (casse mixte) renvoie les mêmes résultats que search=full', $mixed === $lower);

// --- 3. Recherche partielle (sous-chaîne, pas seulement en début de nom)
echo "\n3. Recherche sur une sous-chaîne (pas ancrée en début de nom)\n";
$jungleResults = searchBuilds('jungle');
$allContainJungleCaseInsensitive = true;
foreach ($jungleResults as $build) {
    if (mb_stripos($build['name'], 'jungle') === false) {
        $allContainJungleCaseInsensitive = false;
        break;
    }
}
check("search=jungle trouve des noms où 'jungle' n'est pas en tout début (ex. \"Diver AP jungle\")", count($jungleResults) > 0);
check('tous les résultats de search=jungle contiennent bien la sous-chaîne', $allContainJungleCaseInsensitive);

// --- 4. Aucune correspondance --------------------------------------------
echo "\n4. Aucune correspondance\n";
$noResults = searchBuilds('zzzzz-inexistant-zzzzz');
check('une recherche sans correspondance renvoie une liste vide', $noResults === []);

// --- 5. Recherche combinée à un autre filtre (role=) ---------------------
echo "\n5. Recherche combinée à un filtre existant (role=)\n";
$searchTerm = apiValidateString('full', 'search', 1, 60);
$combined = findBuilds(null, 'mid', null, $searchTerm);
$searchOnly = searchBuilds('full');

$combinedIds = array_column($combined, 'id');
$searchOnlyMidIds = array_column(
    array_filter($searchOnly, fn (array $b): bool => $b['role'] === 'mid'),
    'id'
);
sort($combinedIds);
sort($searchOnlyMidIds);
check(
    'search=full + role=mid ne renvoie que les résultats de search=full qui sont aussi role=mid',
    $combinedIds === $searchOnlyMidIds
);
check('search=full + role=mid ne renvoie que des builds du rôle mid', count($combined) > 0 && array_reduce(
    $combined,
    fn (bool $carry, array $b): bool => $carry && $b['role'] === 'mid',
    true
));

// --- 6. Validation de ?search= (mêmes règles que index.php) --------------
echo "\n6. Validation de ?search=\n";
check(
    'un terme de recherche valide (1 à 60 caractères) est accepté',
    searchBuilds('carry') !== null
);
checkRejected(
    'un terme de recherche trop long (> 60 caractères) est rejeté',
    fn () => searchBuilds(str_repeat('a', 61))
);

// --- 7. Recherche exacte du nom complet d'un build -----------------------
echo "\n7. Recherche sur le nom complet exact d'un build\n";
$exact = searchBuilds('Enchanteur soutien');
check(
    "le nom exact d'un build ('Enchanteur soutien') fait partie des résultats",
    in_array('Enchanteur soutien', array_column($exact, 'name'), true)
);

// --- Résumé --------------------------------------------------------------
echo "\n=== Résumé : " . ($total_tests - $failures) . "/$total_tests test(s) réussi(s) ===\n";

exit($failures > 0 ? 1 : 0);
