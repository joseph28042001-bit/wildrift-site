<?php
/**
 * Point d'entrée public : Build (détail).
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/build.php. Toute la logique/contenu vit dans pages/.
 *
 * Accessible via build.php?id=5 (voir GET /api/builds/?id=,
 * api/builds/index.php). L'ID n'est pas validé ici : c'est
 * assets/js/build.js qui le lit depuis l'URL et gère les cas absents
 * ou invalides (voir ce fichier) — même principe que champion.php.
 *
 * Étape actuelle : uniquement la page de détail elle-même. Aucune carte
 * de la liste des builds (pages/builds.php, pages/home.php,
 * pages/champion.php) ne pointe encore vers cette page — hors périmètre
 * de cette étape.
 */

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Build';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/build.php';
require __DIR__ . '/includes/components/footer.php';
