<?php
/**
 * Point d'entrée public : Objets.
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/items.php. Toute la logique/contenu vit dans pages/.
 */

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Objets';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/items.php';
require __DIR__ . '/includes/components/footer.php';
