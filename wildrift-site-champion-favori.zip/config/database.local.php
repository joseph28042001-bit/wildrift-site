<?php
define('DB_HOST', 'sql206.infinityfree.com');
define('DB_PORT', 3306);
define('DB_NAME', 'if0_43061106_WILDRIFT');
define('DB_USER', 'if0_43061106');
define('DB_PASS', 'ieBI9OYJsoWr');
define('DB_CHARSET', 'utf8mb4');
