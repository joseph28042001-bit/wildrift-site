<?php
/**
 * Configuration générale de l'application.
 * Dépend de config/environment.php (doit être chargé avant ce fichier).
 */

define('APP_NAME', 'Wild Rift Platform');
define('APP_VERSION', '0.2.0');

// Chemins utiles sur le serveur
define('ROOT_PATH', dirname(__DIR__));
define('UPLOADS_PATH', ROOT_PATH . '/uploads');

// Rapport d'erreurs selon l'environnement (voir environment.php)
if (APP_DEBUG) {
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
}

// Fuseau horaire par défaut
date_default_timezone_set('Europe/Paris');
