<?php
/**
 * Configuration des uploads.
 * Dépend de config/environment.php (UPLOAD_MAX_SIZE_MB,
 * UPLOAD_ALLOWED_EXTENSIONS y sont définis).
 */

// Taille maximale d'un fichier uploadé, en octets.
define('UPLOAD_MAX_SIZE_BYTES', UPLOAD_MAX_SIZE_MB * 1024 * 1024);

// Extensions autorisées, sous forme de tableau (dérivé de UPLOAD_ALLOWED_EXTENSIONS).
define('UPLOAD_ALLOWED_EXTENSIONS_LIST', array_map('trim', explode(',', UPLOAD_ALLOWED_EXTENSIONS)));

/**
 * Vérifie qu'un nom de fichier a une extension autorisée.
 */
function isAllowedUploadExtension(string $filename): bool
{
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($extension, UPLOAD_ALLOWED_EXTENSIONS_LIST, true);
}

/**
 * Vérifie qu'un fichier uploadé respecte la taille maximale autorisée.
 */
function isAllowedUploadSize(int $sizeInBytes): bool
{
    return $sizeInBytes > 0 && $sizeInBytes <= UPLOAD_MAX_SIZE_BYTES;
}

/**
 * Génère un nom de fichier sûr et unique pour le stockage,
 * en conservant l'extension d'origine.
 */
function generateSafeUploadFilename(string $originalFilename): string
{
    $extension = strtolower(pathinfo($originalFilename, PATHINFO_EXTENSION));
    return bin2hex(random_bytes(16)) . '.' . $extension;
}
