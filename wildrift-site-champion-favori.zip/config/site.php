<?php
/**
 * Configuration de l'URL du site.
 * Dépend de config/environment.php (SITE_URL, BASE_URL y sont définis).
 */

/**
 * Construit une URL absolue vers un chemin donné du site,
 * en combinant SITE_URL et BASE_URL.
 * Exemple : url('assets/css/style.css')
 */
function url(string $path = ''): string
{
    $base = rtrim(SITE_URL, '/') . BASE_URL;
    return $base . ltrim($path, '/');
}

/**
 * Construit une URL relative (utile pour les liens internes/assets),
 * basée uniquement sur BASE_URL.
 * Exemple : asset('assets/css/style.css')
 */
function asset(string $path): string
{
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}
