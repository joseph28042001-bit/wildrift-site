<?php
/**
 * Configuration de l'intégration Riot (données externes).
 * ---------------------------------------------------------------
 * Étape 21.1 : architecture (ce fichier ne fait lui-même AUCUN appel
 * réseau — il ne fait que définir les constantes que le client Riot,
 * voir includes/riot/RiotApiClient.php, utilise).
 *
 * Étape 21.3 : ajout de RIOT_DDRAGON_BASE_URL et RIOT_DDRAGON_LOCALE.
 * Étape 21.4 : les objets/items utilisent la même source.
 * Étape 21.6 : RIOT_API_CACHE_TTL_MINUTES (définie dès l'étape 21.1,
 * mais inutilisée jusqu'ici) sert désormais réellement de durée de vie
 * au cache disque du client Riot ; ajout de RIOT_CACHE_PATH, le
 * répertoire où ce cache est stocké.
 * Les données de champions et d'objets (nom, titre, lore, sorts,
 * statistiques, prix...) ne viennent pas de l'API Riot authentifiée
 * (RIOT_API_BASE_URL, qui sert à des données de joueur/partie et
 * nécessite une clé de production approuvée par Riot pour la plupart
 * de ses endpoints) mais de Data Dragon, le CDN statique et public de
 * Riot prévu justement pour ce type d'usage (fan sites) — aucune clé
 * n'y est nécessaire. RIOT_API_KEY reste donc inutilisée pour les
 * champions et les objets ; isRiotApiConfigured() sert seulement
 * d'interrupteur global (voir plus bas).
 *
 * Comme pour database.php, les vrais identifiants ne sont jamais codés
 * en dur ici : ils viennent de riot.local.php (non versionné, voir
 * riot.local.php.example). Sans ce fichier, RIOT_API_KEY reste vide et
 * isRiotApiConfigured() retourne false.
 */

// Charge une config locale non versionnée si elle existe (voir riot.local.php.example)
$localRiotConfigPath = __DIR__ . '/riot.local.php';
if (file_exists($localRiotConfigPath)) {
    require_once $localRiotConfigPath;
}

if (!defined('RIOT_API_BASE_URL')) {
    define('RIOT_API_BASE_URL', 'https://na1.api.riotgames.com');
}
if (!defined('RIOT_API_KEY')) {
    define('RIOT_API_KEY', '');
}
if (!defined('RIOT_API_REGION')) {
    define('RIOT_API_REGION', 'na1');
}
if (!defined('RIOT_API_TIMEOUT_SECONDS')) {
    define('RIOT_API_TIMEOUT_SECONDS', 10);
}
if (!defined('RIOT_API_CACHE_TTL_MINUTES')) {
    define('RIOT_API_CACHE_TTL_MINUTES', 60);
}

// Répertoire de stockage du cache disque des réponses Riot (voir
// includes/riot/RiotCache.php). En dehors de la racine publique du
// site, non versionné (voir .gitignore).
if (!defined('RIOT_CACHE_PATH')) {
    define('RIOT_CACHE_PATH', (defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__)) . '/cache/riot');
}

// Data Dragon : CDN statique et public de Riot (aucune clé requise),
// seule source utilisée à ce stade pour les données de champions et
// d'objets/items (voir includes/riot/RiotApiClient.php).
if (!defined('RIOT_DDRAGON_BASE_URL')) {
    define('RIOT_DDRAGON_BASE_URL', 'https://ddragon.leagueoflegends.com');
}
if (!defined('RIOT_DDRAGON_LOCALE')) {
    define('RIOT_DDRAGON_LOCALE', 'fr_FR');
}

/**
 * Indique si une clé d'API Riot a été renseignée (via riot.local.php).
 * Ne vérifie rien d'autre : ni sa validité, ni la joignabilité de
 * l'API — aucune requête réseau n'est faite ici. Sert uniquement de
 * garde-fou pour un futur code appelant, qui pourra refuser de
 * démarrer une synchronisation tant que la clé n'est pas configurée.
 */
function isRiotApiConfigured(): bool
{
    return RIOT_API_KEY !== '';
}
