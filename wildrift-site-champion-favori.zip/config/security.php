<?php
/**
 * Configuration de sécurité.
 * Dépend de config/environment.php (SECURITY_APP_KEY, SECURITY_PASSWORD_COST,
 * SECURITY_MAX_LOGIN_ATTEMPTS, SESSION_COOKIE_SECURE y sont définis).
 */

// Options par défaut pour password_hash() / password_verify()
define('PASSWORD_HASH_OPTIONS', ['cost' => SECURITY_PASSWORD_COST]);

/**
 * Envoie les en-têtes HTTP de sécurité de base.
 * À appeler tôt dans le cycle de requête (voir includes/bootstrap.php).
 */
function sendSecurityHeaders(): void
{
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');

    if (isProduction() && SESSION_COOKIE_SECURE) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

/**
 * Génère (ou réutilise) un jeton CSRF stocké en session.
 */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

/**
 * Vérifie qu'un jeton CSRF soumis correspond à celui de la session.
 */
function verifyCsrfToken(?string $submittedToken): bool
{
    if (empty($_SESSION['csrf_token']) || empty($submittedToken)) {
        return false;
    }

    return hash_equals($_SESSION['csrf_token'], $submittedToken);
}
