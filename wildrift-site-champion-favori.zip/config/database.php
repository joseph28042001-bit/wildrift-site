<?php
/**
 * Configuration de connexion à la base de données MySQL (PDO).
 * -------------------------------------------------------------
 * Sur InfinityFree, les identifiants ressemblent à :
 *   Serveur MySQL : sqlXXX.infinityfree.com (port 3306)
 *   Nom BDD       : epiz_XXXXXXXX_wildrift
 *   Utilisateur   : epiz_XXXXXXXX
 *   Mot de passe  : (celui défini dans le panneau InfinityFree)
 *
 * Règles de sécurité appliquées dans ce fichier :
 * - Les identifiants ne sont jamais codés en dur ici : ils viennent de
 *   database.local.php (non versionné, voir database.local.php.example).
 * - Toutes les requêtes passent par des requêtes préparées PDO (jamais
 *   de valeur utilisateur concaténée dans le SQL) via dbQuery()/dbFetchOne()/
 *   dbFetchAll()/dbExecute() ci-dessous.
 * - Aucune erreur de connexion ou de requête SQL n'est jamais affichée au
 *   visiteur : elle est journalisée côté serveur (error_log) et remplacée
 *   par un message générique, qui ne révèle ni identifiants, ni SQL, ni
 *   structure de la base.
 *
 * Ne jamais committer de vrais identifiants dans un dépôt public.
 * En local/dev, les valeurs par défaut ci-dessous suffisent pour initialiser le projet.
 */

// Charge une config locale non versionnée si elle existe (voir database.local.php.example)
$localConfigPath = __DIR__ . '/database.local.php';
if (file_exists($localConfigPath)) {
    require_once $localConfigPath;
}

if (!defined('DB_HOST')) {
    define('DB_HOST', 'localhost');
}
if (!defined('DB_PORT')) {
    define('DB_PORT', 3306);
}
if (!defined('DB_NAME')) {
    define('DB_NAME', 'wildrift_platform');
}
if (!defined('DB_USER')) {
    define('DB_USER', 'root');
}
if (!defined('DB_PASS')) {
    define('DB_PASS', '');
}
if (!defined('DB_CHARSET')) {
    define('DB_CHARSET', 'utf8mb4');
}

/**
 * DSN PDO de la base (hôte, port, nom, jeu de caractères), construit à
 * un seul endroit : utilisé par getDbConnection() ci-dessous et par
 * tests/test-db-connection.php, pour qu'ils visent toujours exactement
 * la même base. Ne contient jamais le mot de passe.
 */
function getDbDsn(): string
{
    return 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
}

/**
 * Retourne une connexion PDO unique (singleton) vers la base de données.
 * Utilise PDO plutôt que mysqli pour une API moderne, orientée objet,
 * et compatible avec les requêtes préparées (protection anti-injection SQL).
 */
function getDbConnection(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = getDbDsn();
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Le message d'exception PDO peut contenir le host, le nom de la
            // base, voire l'utilisateur : jamais affiché, seulement journalisé
            // côté serveur (visible dans les logs InfinityFree, pas au visiteur).
            error_log('[DB] Échec de connexion : ' . $e->getMessage());
            http_response_code(500);
            die('Le service est momentanément indisponible. Merci de réessayer plus tard.');
        }
    }

    return $pdo;
}

/**
 * Exception "sûre" pour les erreurs de base de données : le message qu'elle
 * porte est toujours générique et ne contient jamais de SQL, d'identifiants
 * ni de détail technique. À afficher tel quel si besoin, sans autre traitement.
 */
class DatabaseException extends RuntimeException
{
}

/**
 * Exécute une requête préparée (SELECT/INSERT/UPDATE/DELETE) et retourne
 * l'objet PDOStatement exécuté. Toute erreur SQL est journalisée côté
 * serveur uniquement ; le visiteur ne reçoit jamais le message PDO brut
 * (qui peut révéler la structure des tables ou des données sensibles).
 *
 * @param string $sql    Requête SQL avec marqueurs nommés ou positionnels (jamais de valeur concaténée)
 * @param array  $params Valeurs à lier aux marqueurs de la requête préparée
 */
function dbQuery(string $sql, array $params = []): PDOStatement
{
    try {
        $statement = getDbConnection()->prepare($sql);
        $statement->execute($params);
        return $statement;
    } catch (PDOException $e) {
        error_log('[DB] Requête échouée : ' . $e->getMessage());
        throw new DatabaseException('Une erreur est survenue lors de l\'accès aux données.');
    }
}

/**
 * Exécute une requête préparée et retourne une seule ligne (ou null si aucun résultat).
 */
function dbFetchOne(string $sql, array $params = []): ?array
{
    $row = dbQuery($sql, $params)->fetch();
    return $row === false ? null : $row;
}

/**
 * Exécute une requête préparée et retourne toutes les lignes du résultat.
 */
function dbFetchAll(string $sql, array $params = []): array
{
    return dbQuery($sql, $params)->fetchAll();
}

/**
 * Exécute une requête préparée d'écriture (INSERT/UPDATE/DELETE)
 * et retourne le nombre de lignes affectées.
 */
function dbExecute(string $sql, array $params = []): int
{
    return dbQuery($sql, $params)->rowCount();
}

/**
 * Retourne l'identifiant de la dernière ligne insérée.
 */
function dbLastInsertId(): string
{
    return getDbConnection()->lastInsertId();
}
