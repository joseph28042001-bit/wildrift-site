<?php
/**
 * Configuration des sessions.
 * Dépend de config/environment.php (SESSION_NAME, SESSION_LIFETIME_MINUTES,
 * SESSION_COOKIE_SECURE, SESSION_USER_KEY, SESSION_USER_REGENERATE_MINUTES
 * y sont définis).
 */

/**
 * Démarre la session PHP avec des paramètres sécurisés et cohérents
 * avec la configuration du site. À appeler une seule fois, en tête
 * de requête (voir includes/bootstrap.php).
 */
function startSecureSession(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    session_name(SESSION_NAME);

    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME_MINUTES * 60,
        'path'     => BASE_URL,
        'domain'   => '',
        'secure'   => SESSION_COOKIE_SECURE,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    ini_set('session.gc_maxlifetime', (string) (SESSION_LIFETIME_MINUTES * 60));
    ini_set('session.use_strict_mode', '1');

    session_start();
}

/**
 * Régénère l'identifiant de session (protection contre la fixation de
 * session) sans perdre les données déjà en session.
 * Prévue pour être appelée à la connexion d'un compte utilisateur —
 * la logique d'authentification elle-même n'est pas développée à cette
 * étape (voir SESSION_USER_KEY).
 */
function regenerateSessionId(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
        $_SESSION['_regenerated_at'] = time();
    }
}

/**
 * Régénère périodiquement l'identifiant de session d'un compte connecté
 * (au-delà de SESSION_USER_REGENERATE_MINUTES depuis la dernière
 * régénération), pour limiter la fenêtre d'exploitation en cas de vol
 * de session. Sans effet tant qu'aucun identifiant n'est stocké dans
 * $_SESSION[SESSION_USER_KEY] (pas de compte connecté).
 */
function maybeRegenerateUserSession(): void
{
    if (empty($_SESSION[SESSION_USER_KEY])) {
        return;
    }

    $lastRegeneration = $_SESSION['_regenerated_at'] ?? 0;
    $intervalSeconds  = SESSION_USER_REGENERATE_MINUTES * 60;

    if (time() - $lastRegeneration > $intervalSeconds) {
        regenerateSessionId();
    }
}

/**
 * Équivalent de maybeRegenerateUserSession() ci-dessus, pour un compte
 * administrateur connecté (ADMIN_SESSION_KEY, voir admin/login.php et
 * la table `admins`). Sans effet tant qu'aucun compte admin n'est
 * connecté — indépendante de maybeRegenerateUserSession() : les deux
 * espaces de connexion (public/admin) restent indépendants, y compris
 * pour cette protection.
 */
function maybeRegenerateAdminSession(): void
{
    if (empty($_SESSION[ADMIN_SESSION_KEY])) {
        return;
    }

    $lastRegeneration = $_SESSION['_regenerated_at'] ?? 0;
    $intervalSeconds  = SESSION_USER_REGENERATE_MINUTES * 60;

    if (time() - $lastRegeneration > $intervalSeconds) {
        regenerateSessionId();
    }
}

/**
 * Détruit proprement la session en cours : vide les données côté
 * serveur et invalide le cookie de session. Prévue pour être appelée
 * par la future déconnexion des comptes utilisateurs.
 */
function destroySession(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return;
    }

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            SESSION_NAME,
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();
}
