<?php
/**
 * Configuration de l'intégration WRChina.gg (données externes).
 * ---------------------------------------------------------------
 * Étape 22.1 : architecture uniquement (ce fichier ne fait lui-même
 * AUCUN appel réseau — il ne fait que définir les constantes que le
 * futur client WRChina, voir includes/wrchina/WrChinaApiClient.php,
 * pourra utiliser). Même principe que config/riot.php à l'étape 21.1.
 *
 * Différence importante avec Riot : pour Riot, une source publique et
 * explicitement autorisée pour les fan sites existe (Data Dragon), ce
 * qui a permis une vraie connexion dès l'étape 21.3. Pour WRChina.gg,
 * aucune méthode d'accès autorisée n'a été identifiée à ce jour —
 * WrChinaApiClient lève donc systématiquement une exception pour
 * toute ressource, indépendamment des valeurs définies ici (voir
 * WrChinaApiNotConnectedException). isWrChinaConfigured() n'autorise
 * donc rien à lui seul : c'est un futur interrupteur global, pas un
 * feu vert pour une méthode de récupération non identifiée.
 *
 * Comme pour riot.php, les vrais identifiants ne sont jamais codés en
 * dur ici : ils viendraient de wrchina.local.php (non versionné, voir
 * wrchina.local.php.example). Sans ce fichier, WRCHINA_API_KEY reste
 * vide et isWrChinaConfigured() retourne false.
 *
 * Étape 22.2 : ajoute WRCHINA_PATCHES_STAGING_FILE, sans rapport avec
 * l'API WRChina elle-même (toujours non connectée) — voir plus bas.
 */

// Charge une config locale non versionnée si elle existe (voir wrchina.local.php.example)
$localWrChinaConfigPath = __DIR__ . '/wrchina.local.php';
if (file_exists($localWrChinaConfigPath)) {
    require_once $localWrChinaConfigPath;
}

if (!defined('WRCHINA_BASE_URL')) {
    define('WRCHINA_BASE_URL', 'https://www.wrchina.gg');
}
if (!defined('WRCHINA_API_KEY')) {
    define('WRCHINA_API_KEY', '');
}
if (!defined('WRCHINA_API_TIMEOUT_SECONDS')) {
    define('WRCHINA_API_TIMEOUT_SECONDS', 10);
}
if (!defined('WRCHINA_API_CACHE_TTL_MINUTES')) {
    define('WRCHINA_API_CACHE_TTL_MINUTES', 60);
}

/**
 * Étape 22.2 : chemin du fichier JSON local d'où
 * WrChinaApiClient::fetchPatches() lit les informations de patch (voir
 * son commentaire pour le détail). Ce n'est PAS une méthode d'accès à
 * WRChina.gg : c'est un fichier tenu à jour à la main par le
 * webmaster, à partir de ce qu'il consulte lui-même sur WRChina.gg.
 * data/wrchina/ est bloqué à l'accès direct par .htaccess, comme
 * config/ (voir data/wrchina/.htaccess).
 */
if (!defined('WRCHINA_PATCHES_STAGING_FILE')) {
    define('WRCHINA_PATCHES_STAGING_FILE', __DIR__ . '/../data/wrchina/patches.json');
}

/**
 * Indique si des identifiants WRChina ont été renseignés (via
 * wrchina.local.php). Ne vérifie rien d'autre : ni leur validité, ni
 * la joignabilité du site, ni même qu'une méthode d'accès autorisée
 * existe — aucune requête réseau n'est faite ici. Comme pour
 * isRiotApiConfigured(), sert uniquement de garde-fou pour un futur
 * code appelant. À elle seule, cette fonction n'autorise jamais
 * WrChinaApiClient à faire une requête : voir le commentaire en tête
 * de ce fichier.
 */
function isWrChinaConfigured(): bool
{
    return WRCHINA_API_KEY !== '';
}
