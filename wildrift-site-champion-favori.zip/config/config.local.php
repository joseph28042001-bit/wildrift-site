<?php
define('ENVIRONMENT', 'production');
define('SITE_URL', 'https://wildriftultimate.gamer.gd');
define('BASE_URL', '/');
define('SESSION_NAME', 'wildrift_session');
define('SESSION_LIFETIME_MINUTES', 120);
define('SESSION_COOKIE_SECURE', true);
define('SESSION_USER_KEY', 'user_id');
define('SESSION_USER_REGENERATE_MINUTES', 30);
define('SECURITY_APP_KEY', 'c1777adcd6f84bf57043f267134de45317b7ea64d27e19dc91ce110432bbe50e');
define('SECURITY_PASSWORD_COST', 11);
define('SECURITY_MAX_LOGIN_ATTEMPTS', 5);

// Mot de passe unique pour accéder à /admin (pas d'email, pas de table
// `admins`). À changer ici avant d'envoyer ce fichier sur le serveur.
define('ADMIN_PASSWORD', 'Yoshimitsu28042001');
define('UPLOAD_MAX_SIZE_MB', 5);
define('UPLOAD_ALLOWED_EXTENSIONS', 'jpg,jpeg,png,webp,gif');
