<?php
/**
 * Environnement de l'application.
 * -------------------------------
 * Charge en premier la configuration locale (config.local.php) si elle
 * existe — c'est là que vivent les réglages propres à chaque installation
 * (voir config.local.php.example). Sans ce fichier, des valeurs par
 * défaut sûres pour le développement local sont utilisées.
 */

$localConfigPath = __DIR__ . '/config.local.php';
if (file_exists($localConfigPath)) {
    require_once $localConfigPath;
}

// Valeurs par défaut si config.local.php est absent (dev local uniquement).
if (!defined('ENVIRONMENT')) {
    define('ENVIRONMENT', 'development');
}
if (!defined('SITE_URL')) {
    define('SITE_URL', 'http://localhost');
}
if (!defined('BASE_URL')) {
    define('BASE_URL', '/');
}
if (!defined('SESSION_NAME')) {
    define('SESSION_NAME', 'wildrift_session');
}
if (!defined('SESSION_LIFETIME_MINUTES')) {
    define('SESSION_LIFETIME_MINUTES', 120);
}
if (!defined('SESSION_COOKIE_SECURE')) {
    define('SESSION_COOKIE_SECURE', false);
}
if (!defined('SESSION_USER_KEY')) {
    define('SESSION_USER_KEY', 'user_id');
}
if (!defined('ADMIN_SESSION_KEY')) {
    // Distincte de SESSION_USER_KEY : un compte administrateur connecté
    // (voir admin/login.php, table `admins`) et un compte public
    // connecté (voir login.php, table `users`) restent deux états
    // indépendants dans la même session PHP.
    define('ADMIN_SESSION_KEY', 'admin_id');
}
if (!defined('SESSION_USER_REGENERATE_MINUTES')) {
    define('SESSION_USER_REGENERATE_MINUTES', 30);
}
if (!defined('SECURITY_APP_KEY')) {
    define('SECURITY_APP_KEY', 'dev-only-key-do-not-use-in-production');
}
if (!defined('SECURITY_PASSWORD_COST')) {
    define('SECURITY_PASSWORD_COST', 10);
}
if (!defined('SECURITY_MAX_LOGIN_ATTEMPTS')) {
    define('SECURITY_MAX_LOGIN_ATTEMPTS', 5);
}
if (!defined('ADMIN_PASSWORD')) {
    // Mot de passe unique pour /admin (voir admin/login.php). Cette
    // valeur par défaut ne sert qu'en dev local ; en production elle
    // vient toujours de config.local.php.
    define('ADMIN_PASSWORD', 'dev-only-do-not-use-in-production');
}
if (!defined('UPLOAD_MAX_SIZE_MB')) {
    define('UPLOAD_MAX_SIZE_MB', 5);
}
if (!defined('UPLOAD_ALLOWED_EXTENSIONS')) {
    define('UPLOAD_ALLOWED_EXTENSIONS', 'jpg,jpeg,png,webp,gif');
}

// Le mode debug découle directement de l'environnement.
define('APP_DEBUG', ENVIRONMENT === 'development');

/**
 * Indique si l'application tourne en production.
 */
function isProduction(): bool
{
    return ENVIRONMENT === 'production';
}

/**
 * Garde-fou de mise en production.
 * ---------------------------------
 * Empêche de déployer accidentellement le site avec des réglages de
 * développement (clé de sécurité par défaut, URL non-HTTPS, cookie de
 * session non sécurisé). Si l'un de ces réglages dangereux est détecté
 * en environnement 'production', l'exécution s'arrête immédiatement :
 * - le détail est journalisé côté serveur (error_log), jamais affiché ;
 * - le visiteur ne voit qu'un message générique (aucune fuite d'info).
 * À appeler juste après le chargement de environment.php (voir bootstrap.php).
 */
function checkProductionReadiness(): void
{
    if (!isProduction()) {
        return;
    }

    $problems = [];

    if (SECURITY_APP_KEY === 'dev-only-key-do-not-use-in-production'
        || SECURITY_APP_KEY === 'remplace-moi-par-une-cle-aleatoire-longue-et-unique'
        || strlen(SECURITY_APP_KEY) < 32
    ) {
        $problems[] = 'SECURITY_APP_KEY est absente, par défaut ou trop courte.';
    }

    if (strpos(SITE_URL, 'https://') !== 0) {
        $problems[] = 'SITE_URL doit commencer par https:// en production.';
    }

    if (SESSION_COOKIE_SECURE !== true) {
        $problems[] = 'SESSION_COOKIE_SECURE doit être à true en production.';
    }

    if (!empty($problems)) {
        error_log('[Production Readiness] Déploiement bloqué : ' . implode(' | ', $problems));

        if (!headers_sent()) {
            http_response_code(500);
        }
        echo 'Le service est momentanément indisponible. Merci de réessayer plus tard.';
        exit;
    }
}
