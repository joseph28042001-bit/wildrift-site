<?php
/**
 * Version du jeu (patch Wild Rift) active sur le site.
 * ------------------------------------------------------------
 * SOURCE UNIQUE de la version du jeu utilisée par le site. Pour passer
 * à un nouveau patch, il suffit de modifier la valeur de CURRENT_PATCH
 * ci-dessous : aucun autre fichier n'est à toucher.
 *
 * Disponible partout une fois includes/bootstrap.php chargé (pages
 * publiques, API et administration) :
 *   - PHP        : la constante CURRENT_PATCH
 *                  ex. echo e(CURRENT_PATCH);
 *   - JavaScript : window.CURRENT_PATCH, définie dans le <head> de
 *                  includes/components/header.php et de
 *                  admin/includes/header.php (donc disponible dès le
 *                  chargement de n'importe quel script de la page)
 *                  ex. `Patch ${window.CURRENT_PATCH}`
 *
 * Format : même que la colonne `patch` des tables builds et tier_list
 * (10 caractères maximum, ex. "7.2e"), pour pouvoir comparer directement
 * CURRENT_PATCH aux patchs stockés en base.
 *
 * La constante n'est définie que si elle ne l'est pas déjà (même
 * convention que les autres fichiers de config/) : un config.local.php
 * peut donc la surcharger pour une installation particulière, mais la
 * valeur de référence du projet est celle-ci.
 *
 * Ce fichier ne change aucun affichage ni comportement par lui-même :
 * les patchs affichés aujourd'hui sur le site (cartes de builds, tier
 * list, fiche champion...) viennent toujours des données en base.
 */

if (!defined('CURRENT_PATCH')) {
    define('CURRENT_PATCH', '7.2e');
}
