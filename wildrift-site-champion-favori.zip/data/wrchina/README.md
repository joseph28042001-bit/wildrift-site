# Staging des patchs WRChina

`patches.json` est le fichier lu par `WrChinaApiClient::fetchPatches()`
(voir `includes/wrchina/WrChinaApiClient.php` et
`WRCHINA_PATCHES_STAGING_FILE` dans `config/wrchina.php`).

**Ce n'est pas une donnée récupérée automatiquement sur WRChina.gg.**
Aucune méthode d'accès autorisée à ce site n'a été identifiée à ce
jour (voir `includes/wrchina/WrChinaApiNotConnectedException.php`) :
c'est donc au webmaster de consulter WRChina.gg lui-même et de
reporter ici, pour chaque patch, les informations demandées.

Le contenu actuel de `patches.json` (patchs 5.3 et 5.4) est un
**exemple de démonstration** utilisé pour tester l'import
(`tests/test-wrchina-patch-import.php`) — les valeurs ne proviennent
pas d'une vérification réelle sur WRChina.gg et doivent être
remplacées avant une mise en production.

## Format attendu

Un tableau JSON d'objets, chacun avec les champs suivants :

| Champ          | Obligatoire | Description                                    |
|----------------|-------------|-------------------------------------------------|
| `patch_number` | oui         | Identifiant unique du patch (ex. `"5.3"`)        |
| `patch_name`   | non         | Nom du patch, `null` si non communiqué           |
| `patch_date`   | non         | Date au format `YYYY-MM-DD`, `null` si inconnue  |
| `status`       | non         | Statut tel qu'affiché sur WRChina.gg             |
| `source`       | non         | Nom de la source (`"WRChina.gg"` par défaut)     |
| `source_url`   | non         | URL de la page WRChina.gg correspondante         |

`fetched_at` n'est pas dans ce fichier : il est renseigné
automatiquement, à la date/heure de l'import, par
`WrChinaPatchImporter`.

Import : `php tests/test-wrchina-patch-import.php` (teste et importe
en une seule exécution — voir ce fichier pour le détail).
