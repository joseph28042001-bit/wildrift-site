/**
 * Wild Rift Platform — Page Article (détail).
 * Connecte la page pages/article.php à l'API existante
 * (GET /api/news/?id=, voir api/news/index.php et
 * api/news/repository.php :: findNewsById()) : lit l'ID de l'article
 * dans l'URL (?id=), récupère sa fiche complète au chargement de la
 * page et l'affiche — même principe que assets/js/item.js, mais pour un
 * article (corps complet à la place d'une recette).
 *
 * Ce fichier n'est chargé que sur la page Article (voir article.php) —
 * contrairement à assets/js/news.js, chargé globalement, il n'y a pas
 * lieu d'exécuter ce code sur les autres pages, qui n'ont pas les
 * éléments #article-* attendus ci-dessous.
 *
 * Reprend volontairement les libellés/classes de catégorie de
 * assets/js/news.js (mêmes NEWS_CATEGORY_LABELS/BADGE_CLASSES) plutôt
 * que de les importer : ce fichier est chargé séparément de news.js
 * (qui, lui, est global) — même principe que
 * assets/js/champion.js/champions.js et assets/js/item.js/items.js.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

const ARTICLE_DETAIL_CATEGORY_LABELS = {
    patch: 'Patch',
    esport: 'Esport',
    evenement: 'Événement',
    communaute: 'Communauté',
};

const ARTICLE_DETAIL_CATEGORY_BADGE_CLASSES = {
    patch: 'badge--teal',
    esport: 'badge--crimson',
    evenement: 'badge--brass',
    communaute: 'badge--verdant',
};

/**
 * Lit et valide l'ID d'article depuis l'URL courante (?id=).
 * Validation minimale côté client (entier positif) : l'API revalide de
 * toute façon l'ID (voir apiValidateInt(), api/news/index.php) et
 * renvoie une erreur explicite si besoin ; cette vérification évite
 * simplement un appel réseau inutile pour un cas manifestement invalide
 * — même principe que getRequestedItemId() (assets/js/item.js).
 *
 * @returns {number} L'ID demandé.
 * @throws {Error} Si l'ID est absent ou n'est pas un entier positif.
 */
function getRequestedArticleId() {
    const params = new URLSearchParams(window.location.search);
    const raw = params.get('id');

    if (!raw || !/^\d+$/.test(raw) || Number(raw) < 1) {
        throw new Error("Aucun article valide n'a été demandé.");
    }

    return Number(raw);
}

/**
 * Récupère la fiche complète d'un article depuis l'API
 * (GET /api/news/?id=). Reprend l'enveloppe JSON standard de l'API
 * ({ success, data, meta }) — voir api/core/response.php : en cas de
 * succès, renvoie l'article (data) ; en cas d'échec (HTTP, article
 * introuvable/non publié ou réseau), le rejette avec une erreur dont le
 * message est toujours sûr à afficher tel quel (voir notFound(),
 * ApiException, api/news/index.php).
 *
 * @param {number} id Identifiant de l'article.
 * @returns {Promise<Object>} L'article (id, slug, title, excerpt,
 *                             category, image_url, published_at,
 *                             content, dates).
 */
async function fetchArticleDetail(id) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/news/?id=${encodeURIComponent(id)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || "Erreur lors de la récupération de l'article.");
    }

    return payload.data;
}

/**
 * Formate une date de publication (colonne `published_at`, format ISO
 * renvoyé par l'API) en date lisible française (ex. "9 septembre
 * 2026"). Renvoie la valeur brute telle quelle si elle n'est pas une
 * date valide, plutôt que d'afficher "Invalid Date" — repris de
 * formatNewsDate() (assets/js/news.js), redéfini ici pour la même
 * raison que les libellés de catégorie ci-dessus (fichier séparé de
 * news.js).
 */
function formatArticleDate(publishedAt) {
    const date = new Date(publishedAt);

    if (Number.isNaN(date.getTime())) {
        return publishedAt;
    }

    return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
}

/**
 * Remplit #article-detail avec la fiche de l'article (composant .card
 * du design system — voir assets/js/news.js::renderNewsCard() pour le
 * modèle repris ici, complété par le corps entier de l'article). Visuel
 * (si l'API en fournit un), date de publication, titre, extrait (si
 * renseigné), corps complet, puis catégorie en pied de carte — même
 * ordre logique que renderNewsCard(), extrait en plus du corps complet.
 */
function renderArticleDetail(article) {
    const detail = document.getElementById('article-detail');
    detail.innerHTML = '';

    // Visuel de l'article (composant .card__media du design system —
    // voir assets/js/champions.js) : uniquement si l'API renvoie une
    // image_url ; retiré en cas d'échec de chargement (URL cassée),
    // même principe que renderChampionCard() (assets/js/champions.js).
    if (article.image_url) {
        const media = document.createElement('div');
        media.className = 'card__media';

        const image = document.createElement('img');
        image.src = article.image_url;
        image.alt = article.title;
        image.loading = 'lazy';
        image.addEventListener('error', () => {
            image.remove();
        });

        media.appendChild(image);
        detail.appendChild(media);
    }

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = formatArticleDate(article.published_at);
    detail.appendChild(eyebrow);

    const title = document.createElement('h1');
    title.className = 'card__title';
    title.textContent = article.title;
    detail.appendChild(title);

    if (article.excerpt) {
        const excerpt = document.createElement('p');
        excerpt.className = 'text-muted';
        excerpt.textContent = article.excerpt;
        detail.appendChild(excerpt);
    }

    if (article.content) {
        const content = document.createElement('p');
        content.textContent = article.content;
        detail.appendChild(content);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const categoryBadge = document.createElement('span');
    const categoryBadgeClass = ARTICLE_DETAIL_CATEGORY_BADGE_CLASSES[article.category] || '';
    categoryBadge.className = categoryBadgeClass ? `badge ${categoryBadgeClass}` : 'badge';
    categoryBadge.textContent = ARTICLE_DETAIL_CATEGORY_LABELS[article.category] || article.category;
    foot.appendChild(categoryBadge);

    detail.appendChild(foot);

    detail.hidden = false;
}

/**
 * Point d'entrée : lit l'ID demandé, déclenche la récupération et
 * bascule entre les trois états possibles (chargement → succès ou
 * erreur). Un ID absent/invalide est traité comme une erreur au même
 * titre qu'un échec réseau ou un article introuvable/non publié : même
 * zone d'erreur, même comportement pour l'utilisateur — même principe
 * que assets/js/item.js.
 */
document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('article-loading');
    const error = document.getElementById('article-error');

    Promise.resolve()
        .then(() => getRequestedArticleId())
        .then((id) => fetchArticleDetail(id))
        .then((article) => {
            renderArticleDetail(article);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
});
