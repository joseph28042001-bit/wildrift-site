/**
 * Page Connexion — validation du formulaire côté navigateur uniquement.
 * Aucun appel réseau ici : la vérification des identifiants et la
 * connexion effective (session, voir SESSION_USER_KEY dans
 * config/session.php) sont traitées côté serveur dans une prochaine
 * étape. Ce script se contente d'empêcher l'envoi d'un formulaire
 * manifestement invalide et d'afficher les messages d'erreur du design
 * system (voir .field.is-invalid dans assets/css/style.css) — même
 * principe que assets/js/register.js.
 */
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('login-form');
    if (!form) return;

    const email = document.getElementById('login-email');
    const password = document.getElementById('login-password');

    function setValidity(input, isValid) {
        const field = input.closest('.field');
        if (!field) return;
        field.classList.toggle('is-invalid', !isValid);
    }

    [email, password].forEach((input) => {
        input.addEventListener('input', () => setValidity(input, input.checkValidity()));
    });

    form.addEventListener('submit', (event) => {
        [email, password].forEach((input) => setValidity(input, input.checkValidity()));

        if (!form.checkValidity()) {
            event.preventDefault();
            form.reportValidity();
        }
    });
});
