/**
 * Page d'administration — Connexion — validation du formulaire côté
 * navigateur uniquement, sur le modèle exact de assets/js/login.js
 * (connexion publique). Aucun appel réseau ici : la vérification des
 * identifiants et la connexion effective (session administrateur) sont
 * traitées côté serveur dans une prochaine étape — voir le commentaire
 * d'en-tête de admin/pages/login.php pour ce qui en dépend encore. Ce
 * script se contente d'empêcher l'envoi d'un formulaire manifestement
 * invalide et d'afficher les messages d'erreur du design system (voir
 * .field.is-invalid dans assets/css/style.css).
 *
 * Ce fichier n'est chargé que sur la page de connexion administrateur
 * (voir admin/pages/login.php) — même principe que assets/js/login.js
 * pour la page de connexion publique.
 */
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('admin-login-form');
    if (!form) return;

    const password = document.getElementById('admin-login-password');
    if (!password) return;

    function setValidity(input, isValid) {
        const field = input.closest('.field');
        if (!field) return;
        field.classList.toggle('is-invalid', !isValid);
    }

    password.addEventListener('input', () => setValidity(password, password.checkValidity()));

    form.addEventListener('submit', (event) => {
        setValidity(password, password.checkValidity());

        if (!form.checkValidity()) {
            event.preventDefault();
            form.reportValidity();
        }
    });
});
