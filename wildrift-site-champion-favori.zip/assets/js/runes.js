/**
 * Wild Rift Platform — Page Runes.
 * Connecte la page pages/runes.php à l'API existante (GET /api/runes/,
 * voir api/runes/index.php et api/runes/repository.php) : récupère
 * toutes les runes au chargement de la page et les affiche sous forme
 * de cartes. Câble aussi le formulaire de recherche par nom, de
 * filtre par arbre et de filtre par emplacement (#runes-search-form)
 * sur les paramètres ?search=, ?tree= et ?slot= déjà supportés par
 * l'API (tous combinables), qui relancent simplement la même
 * récupération avec ces critères — même principe que
 * assets/js/items.js.
 *
 * Ce fichier n'est chargé que sur la page Runes (voir runes.php) —
 * contrairement à assets/js/news.js, chargé globalement, il n'y a pas
 * lieu d'exécuter ce code sur les autres pages, qui n'ont pas les
 * éléments #runes-* attendus ci-dessous.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

/**
 * Classes de badge associées à chaque arbre de runes (voir
 * assets/css/style.css) — 4 couleurs disponibles pour 5 arbres, deux
 * d'entre eux en partagent une. Pure préoccupation d'affichage, qui ne
 * dépend pas des données : contrairement au nom et à la description
 * (voir RUNE_TREE_LABELS ci-dessous), pas besoin de la faire dépendre
 * de l'API.
 */
const RUNE_TREE_BADGE_CLASSES = {
    precision: 'badge--brass',
    domination: 'badge--crimson',
    sorcery: 'badge--teal',
    resolve: 'badge--verdant',
    inspiration: 'badge--verdant',
};

/**
 * Libellés français des arbres de runes, indexés par slug — rempli au
 * chargement de la page à partir de GET /api/rune-trees/ (voir
 * fetchRuneTrees()/populateRuneTreeFilter() ci-dessous), plutôt que
 * codé en dur : les arbres sont désormais une vraie ressource
 * (table `rune_trees`, voir database/schema.sql), pas seulement les
 * valeurs de l'ENUM runes.tree. Vide tant que cette requête n'a pas
 * répondu ; renderRuneCard() se rabat alors sur le slug brut
 * (rune.tree) — dégradation sans erreur, jamais bloquante pour
 * afficher les runes elles-mêmes.
 */
const RUNE_TREE_LABELS = {};

/** Libellés français des emplacements de rune (colonne `slot` en base). */
const RUNE_SLOT_LABELS = {
    keystone: 'Rune majeure',
    minor: 'Rune mineure',
};

/**
 * Récupère la liste des arbres de runes depuis l'API (GET
 * /api/rune-trees/, voir api/rune-trees/index.php et
 * api/rune-trees/repository.php :: findRuneTrees()). Reprend
 * l'enveloppe JSON standard de l'API ({ success, data, meta }) — en
 * cas d'échec (HTTP ou réseau), le rejette avec une erreur ; à la
 * charge de l'appelant de décider si c'est bloquant (voir
 * DOMContentLoaded ci-dessous : ce n'est pas le cas ici, contrairement
 * à fetchRunes()).
 *
 * @returns {Promise<Array>} Arbres (id, slug, name, description,
 *                            image_url).
 */
async function fetchRuneTrees() {
    const base = window.API_BASE_URL || '/api';

    const response = await fetch(`${base}/rune-trees/`, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
    });

    const payload = await response.json();

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des arbres de runes.');
    }

    return payload.data;
}

/**
 * Remplit RUNE_TREE_LABELS (voir ci-dessus) et les options du filtre
 * #runes-tree-filter à partir des arbres récupérés (fetchRuneTrees()).
 * Conserve la première option ("Tous les arbres", déjà posée par
 * pages/runes.php) et ajoute une <option> par arbre ensuite — jamais
 * l'inverse, pour ne pas dupliquer les options à chaque appel.
 *
 * @param {Array<Object>} trees Arbres de runes (id, slug, name,
 *                                description, image_url).
 */
function populateRuneTreeFilter(trees) {
    const select = document.getElementById('runes-tree-filter');

    trees.forEach((tree) => {
        RUNE_TREE_LABELS[tree.slug] = tree.name;

        const option = document.createElement('option');
        option.value = tree.slug;
        option.textContent = tree.name;
        select.appendChild(option);
    });
}

/**
 * Récupère la liste des runes depuis l'API, avec un terme de recherche,
 * un filtre par arbre et un filtre par emplacement optionnels (GET
 * /api/runes/?search=&tree=&slot=, voir api/runes/index.php et
 * api/runes/repository.php :: findRunes() — les trois filtres sont
 * combinables côté API). Reprend l'enveloppe JSON standard de l'API
 * ({ success, data, meta }) — voir api/core/response.php : en cas de
 * succès, renvoie le tableau de runes (data) ; en cas d'échec (HTTP ou
 * réseau), le rejette avec une erreur dont le message est toujours sûr
 * à afficher tel quel.
 *
 * @param {string} [search] Terme recherché dans le nom de la rune.
 * @param {string} [tree] Arbre de runes (voir getRuneTrees() côté API).
 *                        Omis ou vide : pas de filtre par arbre.
 * @param {string} [slot] Emplacement de rune (voir getRuneSlots() côté
 *                        API : 'keystone' ou 'minor'). Omis ou vide :
 *                        pas de filtre par emplacement.
 * @returns {Promise<Array>} Runes (id, slug, name, tree, slot,
 *                            description, image_url).
 */
async function fetchRunes(search, tree, slot) {
    const base = window.API_BASE_URL || '/api';

    const params = new URLSearchParams();
    if (search) {
        params.set('search', search);
    }
    if (tree) {
        params.set('tree', tree);
    }
    if (slot) {
        params.set('slot', slot);
    }
    const query = params.toString();
    const url = `${base}/runes/${query ? `?${query}` : ''}`;

    let response;
    try {
        response = await fetch(url, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des runes.');
    }

    return payload.data;
}

/**
 * Construit la carte HTML d'une rune (composant .card du design system —
 * voir assets/css/style.css et pages/styleguide.php pour le modèle repris
 * ici). N'insère aucune valeur non échappée : toutes les données viennent
 * de l'API, mais restent traitées comme non sûres côté affichage
 * (textContent, jamais innerHTML sur une valeur dynamique).
 */
function renderRuneCard(rune) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = RUNE_SLOT_LABELS[rune.slot] || 'Rune';
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = rune.name;
    card.appendChild(title);

    if (rune.description) {
        const description = document.createElement('p');
        description.textContent = rune.description;
        card.appendChild(description);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const treeBadge = document.createElement('span');
    const treeBadgeClass = RUNE_TREE_BADGE_CLASSES[rune.tree] || '';
    treeBadge.className = treeBadgeClass ? `badge ${treeBadgeClass}` : 'badge';
    treeBadge.textContent = RUNE_TREE_LABELS[rune.tree] || rune.tree;
    foot.appendChild(treeBadge);

    card.appendChild(foot);

    return card;
}

/**
 * Affiche la liste des runes dans #runes-grid, un par un
 * (renderRuneCard() ci-dessus). Ne fait rien d'autre : la bascule de
 * l'état de chargement/erreur est gérée par l'appelant.
 */
function renderRunes(runes) {
    const grid = document.getElementById('runes-grid');
    grid.innerHTML = '';

    runes.forEach((rune) => {
        grid.appendChild(renderRuneCard(rune));
    });
}

/**
 * Déclenche la récupération des runes (avec le terme de recherche,
 * l'arbre et l'emplacement courants, s'il y en a) et bascule entre les
 * trois états possibles (chargement → succès ou erreur). Factorisé
 * pour être appelé aussi bien au chargement de la page qu'à chaque
 * soumission du formulaire de recherche/filtre ci-dessous — même
 * principe que loadItems() (assets/js/items.js).
 *
 * @param {string} [search] Terme recherché, voir fetchRunes().
 * @param {string} [tree] Arbre filtré, voir fetchRunes().
 * @param {string} [slot] Emplacement filtré, voir fetchRunes().
 */
function loadRunes(search, tree, slot) {
    const loading = document.getElementById('runes-loading');
    const error = document.getElementById('runes-error');

    loading.hidden = false;
    error.hidden = true;

    fetchRunes(search, tree, slot)
        .then((runes) => {
            renderRunes(runes);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Point d'entrée : peuple d'abord le filtre par arbre à partir de
 * GET /api/rune-trees/ (populateRuneTreeFilter() ci-dessus) — en
 * échec, se contente de laisser le filtre avec sa seule option "Tous
 * les arbres" et RUNE_TREE_LABELS vide (renderRuneCard() se rabat sur
 * le slug), ce n'est pas bloquant pour la suite. Déclenche ensuite la
 * récupération initiale des runes (sans filtre) au chargement de la
 * page, puis câble le formulaire de recherche/filtre
 * (#runes-search-form) pour relancer la récupération avec le terme,
 * l'arbre et/ou l'emplacement sélectionnés à chaque soumission, et le
 * bouton de réinitialisation (#runes-search-reset) pour revenir à la
 * liste complète — même principe que assets/js/items.js.
 */
document.addEventListener('DOMContentLoaded', () => {
    fetchRuneTrees()
        .then((trees) => {
            populateRuneTreeFilter(trees);
        })
        .catch(() => {
            // Non bloquant — voir docblock ci-dessus.
        });

    loadRunes();

    const form = document.getElementById('runes-search-form');
    const input = document.getElementById('runes-search-input');
    const treeFilter = document.getElementById('runes-tree-filter');
    const slotFilter = document.getElementById('runes-slot-filter');
    const reset = document.getElementById('runes-search-reset');

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        loadRunes(input.value.trim(), treeFilter.value, slotFilter.value);
    });

    reset.addEventListener('click', () => {
        input.value = '';
        treeFilter.value = '';
        slotFilter.value = '';
        loadRunes();
    });
});
