/**
 * Wild Rift Platform — Page Tier list.
 * Connecte la page pages/tier-list.php à l'API existante
 * (GET /api/tier-list/, voir api/tier-list/index.php et
 * api/tier-list/repository.php) : récupère toute la tier list au
 * chargement de la page et l'affiche sous forme de cartes. Même
 * structure que assets/js/builds.js (page Builds).
 *
 * GET /api/tier-list/ prend en charge ?champion=, ?role=, ?patch=,
 * ?tier= et ?search=, mais seuls ?role=, ?patch= et ?search= sont
 * câblés ici (#tier-list-filter-form, combinables) : champion/tier
 * restent volontairement non exposés côté client, même limite que
 * assets/js/builds.js pour ces critères-là. Le détail
 * d'une entrée (notes, dates — GET /api/tier-list/?id=) n'est pas non
 * plus affiché ici : seule la liste l'est, comme pour les autres
 * ressources connectées jusqu'ici.
 *
 * Ce fichier n'est chargé que sur la page Tier list (voir
 * tier-list.php) — contrairement à assets/js/news.js, chargé
 * globalement, il n'y a pas lieu d'exécuter ce code sur les autres
 * pages, qui n'ont pas les éléments #tier-list-* attendus ci-dessous.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

/**
 * Libellés français des rôles et classe de badge associée — repris tels
 * quels de assets/js/champions.js et assets/js/builds.js
 * (api/tier-list/repository.php dérive volontairement getTierListRoles()
 * de la même ENUM que champions.role) pour rester cohérent visuellement
 * entre les pages Champions, Builds et Tier list.
 */
const TIER_LIST_ROLE_LABELS = {
    baron: 'Voie Baron',
    jungle: 'Jungle',
    mid: 'Voie du Milieu',
    dragon: 'Voie Dragon',
    support: 'Support',
};

const TIER_LIST_ROLE_BADGE_CLASSES = {
    baron: 'badge--brass',
    jungle: 'badge--verdant',
    mid: 'badge--teal',
    dragon: 'badge--crimson',
    support: '',
};

/**
 * Classe de badge associée à chaque tier (du plus fort 'S+' au plus
 * faible 'D' — voir getTierListTiers(), repository.php), du plus au
 * moins engageant visuellement. 'S+' réutilise la même couleur que 'S'
 * (badge--crimson) : seules 4 couleurs de badge existent dans le design
 * system pour 6 tiers, même principe de partage qu'entre les 7
 * catégories d'objets (voir ITEM_CATEGORY_BADGE_CLASSES, items.js).
 */
const TIER_LIST_TIER_BADGE_CLASSES = {
    'S+': 'badge--crimson',
    S: 'badge--crimson',
    A: 'badge--brass',
    B: 'badge--teal',
    C: 'badge--verdant',
    D: '',
};

/**
 * Récupère la tier list depuis l'API, avec un terme de recherche et des
 * filtres par rôle et par patch optionnels (GET
 * /api/tier-list/?search=&role=&patch=, voir api/tier-list/index.php et
 * api/tier-list/repository.php :: findTierList() — les trois filtres
 * sont combinables côté API). Reprend l'enveloppe JSON standard de
 * l'API ({ success, data, meta }) — voir api/core/response.php : en cas
 * de succès, renvoie le tableau d'entrées (data) ; en cas d'échec (HTTP
 * ou réseau), le rejette avec une erreur dont le message est toujours
 * sûr à afficher tel quel.
 *
 * @param {string} [search] Terme recherché dans le nom du champion.
 * @param {string} [role] Rôle Wild Rift (voir getTierListRoles() côté
 *                        API). Omis ou vide : pas de filtre par rôle.
 * @param {string} [patch] Patch (ex. '5.2'). Omis ou vide : pas de
 *                         filtre par patch.
 * @returns {Promise<Array>} Entrées (id, champion, role, tier, patch,
 *                            win_rate, pick_rate, ban_rate — ces trois
 *                            derniers facultatifs, null si absents).
 */
async function fetchTierList(search, role, patch) {
    const base = window.API_BASE_URL || '/api';

    const params = new URLSearchParams();
    if (search) {
        params.set('search', search);
    }
    if (role) {
        params.set('role', role);
    }
    if (patch) {
        params.set('patch', patch);
    }
    const query = params.toString();
    const url = `${base}/tier-list/${query ? `?${query}` : ''}`;

    let response;
    try {
        response = await fetch(url, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération de la tier list.');
    }

    return payload.data;
}

/**
 * Formate un taux (win_rate/pick_rate/ban_rate) pour l'affichage :
 * pourcentage à une décimale, ou 'N/A' si absent (null — voir
 * castTierListRates(), repository.php).
 */
function formatRate(rate) {
    return rate !== null ? `${rate.toFixed(1)} %` : 'N/A';
}

/**
 * Construit la carte HTML d'une entrée de tier list (composant .card du
 * design system — voir assets/css/style.css et pages/styleguide.php
 * pour le modèle repris ici). N'insère aucune valeur non échappée :
 * toutes les données viennent de l'API, mais restent traitées comme non
 * sûres côté affichage (textContent, jamais innerHTML sur une valeur
 * dynamique).
 */
function renderTierListCard(entry) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = `Patch ${entry.patch}`;
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = entry.champion;
    card.appendChild(title);

    const rates = document.createElement('p');
    rates.className = 'text-mono text-muted';
    rates.style.fontSize = 'var(--text-xs)';
    rates.textContent = `Victoire : ${formatRate(entry.win_rate)} · Sélection : ${formatRate(entry.pick_rate)} · Bannissement : ${formatRate(entry.ban_rate)}`;
    card.appendChild(rates);

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const tierBadge = document.createElement('span');
    const tierBadgeClass = TIER_LIST_TIER_BADGE_CLASSES[entry.tier] || '';
    tierBadge.className = tierBadgeClass ? `badge ${tierBadgeClass}` : 'badge';
    tierBadge.textContent = `Tier ${entry.tier}`;
    foot.appendChild(tierBadge);

    const roleBadge = document.createElement('span');
    const roleBadgeClass = TIER_LIST_ROLE_BADGE_CLASSES[entry.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = TIER_LIST_ROLE_LABELS[entry.role] || entry.role;
    foot.appendChild(roleBadge);

    card.appendChild(foot);

    return card;
}

/**
 * Affiche la tier list dans #tier-list-grid, une entrée à la fois
 * (renderTierListCard() ci-dessus). Ne fait rien d'autre : la bascule
 * de l'état de chargement/erreur est gérée par l'appelant.
 */
function renderTierList(entries) {
    const grid = document.getElementById('tier-list-grid');
    grid.innerHTML = '';

    entries.forEach((entry) => {
        grid.appendChild(renderTierListCard(entry));
    });
}

/**
 * Déclenche la récupération de la tier list (avec le terme de recherche
 * et/ou le rôle et le patch courants, s'il y en a) et bascule entre les
 * trois états possibles (chargement → succès ou erreur). Factorisé pour
 * être appelé aussi bien au chargement de la page qu'à chaque
 * soumission du formulaire de filtre ci-dessous.
 *
 * @param {string} [search] Terme recherché, voir fetchTierList().
 * @param {string} [role] Rôle filtré, voir fetchTierList().
 * @param {string} [patch] Patch filtré, voir fetchTierList().
 */
function loadTierList(search, role, patch) {
    const loading = document.getElementById('tier-list-loading');
    const error = document.getElementById('tier-list-error');

    loading.hidden = false;
    error.hidden = true;

    fetchTierList(search, role, patch)
        .then((entries) => {
            renderTierList(entries);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Point d'entrée : déclenche la récupération initiale au chargement de
 * la page, filtrée par défaut sur le patch actif du site
 * (window.CURRENT_PATCH, voir includes/components/header.php et
 * config/patch.php), puis câble le formulaire de filtre
 * (#tier-list-filter-form) pour relancer la récupération avec le terme
 * de recherche, le rôle et/ou le patch saisis à chaque soumission, et
 * le bouton de réinitialisation (#tier-list-filter-reset) pour revenir
 * à cet état par défaut (patch actif, sans recherche ni rôle) — la
 * tier list affichée reste donc toujours dans le contexte du patch
 * actif tant que l'utilisateur ne choisit pas explicitement un autre
 * patch.
 */
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('tier-list-filter-form');
    const searchInput = document.getElementById('tier-list-search-input');
    const roleFilter = document.getElementById('tier-list-role-filter');
    const patchInput = document.getElementById('tier-list-patch-input');
    const reset = document.getElementById('tier-list-filter-reset');

    const defaultPatch = window.CURRENT_PATCH || '';
    patchInput.value = defaultPatch;

    loadTierList('', '', defaultPatch);

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        loadTierList(searchInput.value.trim(), roleFilter.value, patchInput.value.trim());
    });

    reset.addEventListener('click', () => {
        searchInput.value = '';
        roleFilter.value = '';
        patchInput.value = defaultPatch;
        loadTierList('', '', defaultPatch);
    });
});
