/**
 * Wild Rift Platform — Page Objet (détail).
 * Connecte la page pages/item.php à l'API existante
 * (GET /api/items/?id=, voir api/items/index.php et
 * api/items/repository.php :: findItemById()) : lit l'ID de l'objet
 * dans l'URL (?id=), récupère sa fiche au chargement de la page et
 * l'affiche — même principe que assets/js/champion.js, mais pour un
 * objet, sans la plupart des sections supplémentaires d'une fiche
 * champion (statistiques, capacités, builds, counters, synergies) qui
 * n'ont pas de sens pour un objet. Seule exception : la recette (voir
 * renderItemRecipe() ci-dessous), propre aux objets.
 *
 * Ce fichier n'est chargé que sur la page Objet (voir item.php) —
 * contrairement à assets/js/news.js, chargé globalement, il n'y a pas
 * lieu d'exécuter ce code sur les autres pages, qui n'ont pas les
 * éléments #item-* attendus ci-dessous.
 *
 * Reprend volontairement les libellés/classes de catégorie de
 * assets/js/items.js (mêmes ITEM_CATEGORY_LABELS/BADGE_CLASSES) plutôt
 * que de les importer : ce fichier n'est chargé que sur cette page,
 * séparément de items.js — même principe que
 * assets/js/champion.js/champions.js.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

const ITEM_DETAIL_CATEGORY_LABELS = {
    attack: 'Attaque',
    magic: 'Magie',
    defense: 'Défense',
    boots: 'Bottes',
    jungle: 'Jungle',
    consumable: 'Consommable',
    enchantment: 'Enchantement',
};

const ITEM_DETAIL_CATEGORY_BADGE_CLASSES = {
    attack: 'badge--crimson',
    magic: 'badge--teal',
    defense: 'badge--verdant',
    boots: 'badge--brass',
    jungle: 'badge--verdant',
    consumable: 'badge--brass',
    enchantment: 'badge--teal',
};

/**
 * Lit et valide l'ID d'objet depuis l'URL courante (?id=).
 * Validation minimale côté client (entier positif) : l'API revalide de
 * toute façon l'ID (voir apiValidateInt(), api/items/index.php) et
 * renvoie une erreur explicite si besoin ; cette vérification évite
 * simplement un appel réseau inutile pour un cas manifestement invalide
 * — même principe que getRequestedChampionId() (assets/js/champion.js).
 *
 * @returns {number} L'ID demandé.
 * @throws {Error} Si l'ID est absent ou n'est pas un entier positif.
 */
function getRequestedItemId() {
    const params = new URLSearchParams(window.location.search);
    const raw = params.get('id');

    if (!raw || !/^\d+$/.test(raw) || Number(raw) < 1) {
        throw new Error("Aucun objet valide n'a été demandé.");
    }

    return Number(raw);
}

/**
 * Récupère la fiche d'un objet depuis l'API (GET /api/items/?id=).
 * Reprend l'enveloppe JSON standard de l'API ({ success, data, meta }) —
 * voir api/core/response.php : en cas de succès, renvoie l'objet (data) ;
 * en cas d'échec (HTTP, objet introuvable ou réseau), le rejette avec
 * une erreur dont le message est toujours sûr à afficher tel quel (voir
 * notFound(), ApiException, api/items/index.php).
 *
 * @param {number} id Identifiant de l'objet.
 * @returns {Promise<Object>} L'objet (id, slug, name, category, price,
 *                             description, image_url, recipe — voir
 *                             renderItemRecipe() pour ce dernier champ).
 */
async function fetchItemDetail(id) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/items/?id=${encodeURIComponent(id)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || "Erreur lors de la récupération de l'objet.");
    }

    return payload.data;
}

/**
 * Remplit #item-detail avec la fiche de l'objet (composant .card du
 * design system — voir assets/js/items.js::renderItemCard() pour le
 * modèle repris ici). Nom, description (si renseignée), catégorie et
 * prix, dans le même ordre que les cartes de la liste.
 */
function renderItemDetail(item) {
    const detail = document.getElementById('item-detail');
    detail.innerHTML = '';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = 'Objet';
    detail.appendChild(eyebrow);

    const title = document.createElement('h1');
    title.className = 'card__title';
    title.textContent = item.name;
    detail.appendChild(title);

    if (item.description) {
        const description = document.createElement('p');
        description.textContent = item.description;
        detail.appendChild(description);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const categoryBadge = document.createElement('span');
    const categoryBadgeClass = ITEM_DETAIL_CATEGORY_BADGE_CLASSES[item.category] || '';
    categoryBadge.className = categoryBadgeClass ? `badge ${categoryBadgeClass}` : 'badge';
    categoryBadge.textContent = ITEM_DETAIL_CATEGORY_LABELS[item.category] || item.category;
    foot.appendChild(categoryBadge);

    const price = document.createElement('span');
    price.className = 'text-mono text-muted';
    price.style.fontSize = 'var(--text-xs)';
    price.textContent = item.price !== null ? `${item.price.toLocaleString('fr-FR')} or` : 'Prix inconnu';
    foot.appendChild(price);

    detail.appendChild(foot);

    renderItemRecipe(detail, item.recipe);

    detail.hidden = false;
}

/**
 * Ajoute la section "Recette" à #item-detail, listant les objets
 * composants (item.recipe — voir GET /api/items/?id=,
 * findItemRecipe(), api/items/repository.php). N'affiche rien si
 * l'objet n'a pas de recette connue (tableau vide) : objet de départ,
 * consommable ou composant de base — ce n'est pas une erreur, donc pas
 * de message d'erreur ni de zone vide, simplement rien à ajouter.
 *
 * Chaque composant renvoie vers sa propre fiche (item.php?id=), pour
 * naviguer d'un objet à ses composants — même principe que les liens
 * de champions dans une fiche de build (voir assets/js/champion.js).
 *
 * @param {HTMLElement} detail Conteneur #item-detail (déjà rempli par
 *                              renderItemDetail() ci-dessus).
 * @param {Array<Object>} recipe Composants de la recette (id, slug,
 *                                 name, category, price, image_url),
 *                                 éventuellement vide.
 */
function renderItemRecipe(detail, recipe) {
    if (!Array.isArray(recipe) || recipe.length === 0) {
        return;
    }

    const heading = document.createElement('h2');
    heading.className = 'card__title';
    heading.style.fontSize = 'var(--text-md)';
    heading.style.marginTop = 'var(--space-5)';
    heading.textContent = 'Recette';
    detail.appendChild(heading);

    const list = document.createElement('ul');
    list.className = 'stack';
    list.style.gap = 'var(--space-2)';

    recipe.forEach((component) => {
        const row = document.createElement('li');
        row.style.display = 'flex';
        row.style.alignItems = 'center';
        row.style.justifyContent = 'space-between';
        row.style.gap = 'var(--space-3)';

        const link = document.createElement('a');
        link.href = `item.php?id=${encodeURIComponent(component.id)}`;
        link.textContent = component.name;
        row.appendChild(link);

        const price = document.createElement('span');
        price.className = 'text-mono text-muted';
        price.style.fontSize = 'var(--text-xs)';
        price.textContent = component.price !== null
            ? `${component.price.toLocaleString('fr-FR')} or`
            : 'Prix inconnu';
        row.appendChild(price);

        list.appendChild(row);
    });

    detail.appendChild(list);
}

/**
 * Point d'entrée : lit l'ID demandé, déclenche la récupération et
 * bascule entre les trois états possibles (chargement → succès ou
 * erreur). Un ID absent/invalide est traité comme une erreur au même
 * titre qu'un échec réseau ou un objet introuvable : même zone d'erreur,
 * même comportement pour l'utilisateur — même principe que
 * assets/js/champion.js.
 */
document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('item-loading');
    const error = document.getElementById('item-error');

    Promise.resolve()
        .then(() => getRequestedItemId())
        .then((id) => fetchItemDetail(id))
        .then((item) => {
            renderItemDetail(item);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
});
