/**
 * Wild Rift Platform — Page Builds.
 * Connecte la page pages/builds.php à l'API existante (GET /api/builds/,
 * voir api/builds/index.php et api/builds/repository.php) : récupère
 * une page de builds au chargement de la page et les affiche sous
 * forme de cartes. Câble aussi le formulaire de recherche par nom et
 * de filtre par champion (slug), rôle et patch (#builds-search-form)
 * sur les paramètres ?search=, ?champion=, ?role= et ?patch= déjà
 * supportés par l'API (tous combinables), ainsi que la pagination
 * (#builds-pagination, ?page=) — même principe que assets/js/items.js
 * et assets/js/runes.js, pagination en plus.
 *
 * Le détail d'un build (objets, runes, ordre des compétences — GET
 * /api/builds/?id=) n'est pas affiché ici : seule la liste l'est,
 * comme pour les autres ressources connectées jusqu'ici.
 *
 * Ce fichier n'est chargé que sur la page Builds (voir builds.php) —
 * contrairement à assets/js/news.js, chargé globalement, il n'y a pas
 * lieu d'exécuter ce code sur les autres pages, qui n'ont pas les
 * éléments #builds-* attendus ci-dessous.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

/**
 * Libellés français des rôles et classe de badge associée — repris tels
 * quels de assets/js/champions.js (api/builds/repository.php dérive
 * volontairement getBuildRoles() de la même ENUM que champions.role,
 * voir son commentaire) pour rester cohérent visuellement entre les
 * pages Champions et Builds.
 */
const BUILD_ROLE_LABELS = {
    baron: 'Voie Baron',
    jungle: 'Jungle',
    mid: 'Voie du Milieu',
    dragon: 'Voie Dragon',
    support: 'Support',
};

const BUILD_ROLE_BADGE_CLASSES = {
    baron: 'badge--brass',
    jungle: 'badge--verdant',
    mid: 'badge--teal',
    dragon: 'badge--crimson',
    support: '',
};

/**
 * Récupère une page de builds depuis l'API, avec recherche et filtres
 * optionnels (GET /api/builds/?search=&champion=&role=&patch=&page=,
 * voir api/builds/index.php et api/builds/repository.php ::
 * findBuilds()/countBuilds() — tous combinables côté API). Reprend
 * l'enveloppe JSON standard de l'API ({ success, data, meta }) — voir
 * api/core/response.php : en cas de succès, renvoie à la fois les
 * builds (data) et le bloc de pagination (meta.pagination — page
 * courante, taille de page, total de résultats, total de pages) ; en
 * cas d'échec (HTTP ou réseau), le rejette avec une erreur dont le
 * message est toujours sûr à afficher tel quel.
 *
 * @param {string} [search] Terme recherché dans le nom du build.
 * @param {string} [champion] Slug du champion (voir GET /api/builds/).
 * @param {string} [role] Rôle (voir getBuildRoles() côté API). Omis ou
 *                        vide : pas de filtre par rôle.
 * @param {string} [patch] Patch (ex. "5.2"). Omis ou vide : pas de
 *                          filtre par patch.
 * @param {number} [page] Page demandée (1 par défaut côté API).
 * @returns {Promise<{builds: Array, pagination: Object}>}
 */
async function fetchBuilds(search, champion, role, patch, page) {
    const base = window.API_BASE_URL || '/api';

    const params = new URLSearchParams();
    if (search) {
        params.set('search', search);
    }
    if (champion) {
        params.set('champion', champion);
    }
    if (role) {
        params.set('role', role);
    }
    if (patch) {
        params.set('patch', patch);
    }
    if (page) {
        params.set('page', String(page));
    }
    const query = params.toString();
    const url = `${base}/builds/${query ? `?${query}` : ''}`;

    let response;
    try {
        response = await fetch(url, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des builds.');
    }

    return {
        builds: payload.data,
        pagination: payload.meta?.pagination || null,
    };
}

/**
 * Construit la carte HTML d'un build (composant .card du design system —
 * voir assets/css/style.css et pages/styleguide.php pour le modèle repris
 * ici). N'insère aucune valeur non échappée : toutes les données viennent
 * de l'API, mais restent traitées comme non sûres côté affichage
 * (textContent, jamais innerHTML sur une valeur dynamique).
 */
function renderBuildCard(build) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = build.champion;
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = build.name;
    card.appendChild(title);

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const roleBadge = document.createElement('span');
    const roleBadgeClass = BUILD_ROLE_BADGE_CLASSES[build.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = BUILD_ROLE_LABELS[build.role] || build.role;
    foot.appendChild(roleBadge);

    const patch = document.createElement('span');
    patch.className = 'text-mono text-muted';
    patch.style.fontSize = 'var(--text-xs)';
    patch.textContent = `Patch ${build.patch}`;
    foot.appendChild(patch);

    card.appendChild(foot);

    return card;
}

/**
 * Affiche la liste des builds dans #builds-grid, un par un
 * (renderBuildCard() ci-dessus). Ne fait rien d'autre : la bascule de
 * l'état de chargement/erreur est gérée par l'appelant.
 */
function renderBuilds(builds) {
    const grid = document.getElementById('builds-grid');
    grid.innerHTML = '';

    builds.forEach((build) => {
        grid.appendChild(renderBuildCard(build));
    });
}

/**
 * Affiche ou masque #builds-pagination selon le bloc pagination reçu
 * (voir fetchBuilds()), met à jour #builds-page-info ("Page X / Y") et
 * active/désactive les boutons Précédent/Suivant en conséquence.
 * Masqué entièrement si pagination est absent ou n'a aucune page
 * (total_pages === 0, liste vide) : rien à paginer, ce n'est pas une
 * erreur.
 *
 * @param {Object|null} pagination Voir meta.pagination, fetchBuilds().
 */
function renderBuildsPagination(pagination) {
    const container = document.getElementById('builds-pagination');

    if (!pagination || pagination.total_pages <= 1) {
        container.hidden = true;
        return;
    }

    const info = document.getElementById('builds-page-info');
    info.textContent = `Page ${pagination.page} / ${pagination.total_pages}`;

    const prev = document.getElementById('builds-page-prev');
    prev.disabled = pagination.page <= 1;

    const next = document.getElementById('builds-page-next');
    next.disabled = pagination.page >= pagination.total_pages;

    container.hidden = false;
}

/**
 * État courant de la recherche/des filtres/de la page affichée —
 * nécessaire pour que les boutons Précédent/Suivant (qui ne touchent
 * qu'à la page) conservent la recherche et les filtres en cours, sans
 * avoir à relire le formulaire à chaque clic. Mis à jour uniquement
 * par loadBuilds() ci-dessous, jamais lu ni modifié ailleurs.
 */
const buildsQueryState = {
    search: '',
    champion: '',
    role: '',
    patch: '',
    page: 1,
};

/**
 * Déclenche la récupération des builds (avec la recherche, les
 * filtres et la page fournis) et bascule entre les trois états
 * possibles (chargement → succès ou erreur), en mettant à jour
 * buildsQueryState et la pagination affichée au passage. Factorisé
 * pour être appelé aussi bien au chargement de la page qu'à chaque
 * soumission du formulaire de recherche/filtre ou clic sur
 * Précédent/Suivant — même principe que loadItems() (assets/js/items.js).
 *
 * @param {string} [search] Terme recherché, voir fetchBuilds().
 * @param {string} [champion] Slug du champion, voir fetchBuilds().
 * @param {string} [role] Rôle filtré, voir fetchBuilds().
 * @param {string} [patch] Patch filtré, voir fetchBuilds().
 * @param {number} [page] Page demandée (1 par défaut).
 */
function loadBuilds(search = '', champion = '', role = '', patch = '', page = 1) {
    const loading = document.getElementById('builds-loading');
    const error = document.getElementById('builds-error');

    loading.hidden = false;
    error.hidden = true;

    fetchBuilds(search, champion, role, patch, page)
        .then(({ builds, pagination }) => {
            buildsQueryState.search = search;
            buildsQueryState.champion = champion;
            buildsQueryState.role = role;
            buildsQueryState.patch = patch;
            buildsQueryState.page = page;

            renderBuilds(builds);
            renderBuildsPagination(pagination);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Point d'entrée : déclenche la récupération initiale (page 1) au
 * chargement de la page, filtrée par défaut sur le patch actif du site
 * (window.CURRENT_PATCH, voir includes/components/header.php et
 * config/patch.php), puis câble le formulaire de recherche/filtre
 * (#builds-search-form) pour relancer la récupération à la page 1 avec
 * les critères sélectionnés à chaque soumission, le bouton de
 * réinitialisation (#builds-search-reset) pour revenir à cet état par
 * défaut (patch actif, sans recherche ni autre filtre), et les boutons
 * Précédent/Suivant (#builds-page-prev/#builds-page-next) pour naviguer
 * entre les pages sans perdre la recherche ni les filtres en cours
 * (buildsQueryState) — même principe que assets/js/items.js et
 * assets/js/runes.js. Les builds affichés restent donc toujours dans
 * le contexte du patch actif tant que l'utilisateur ne choisit pas
 * explicitement un autre patch.
 */
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('builds-search-form');
    const searchInput = document.getElementById('builds-search-input');
    const championInput = document.getElementById('builds-champion-input');
    const roleFilter = document.getElementById('builds-role-filter');
    const patchInput = document.getElementById('builds-patch-input');
    const reset = document.getElementById('builds-search-reset');
    const prev = document.getElementById('builds-page-prev');
    const next = document.getElementById('builds-page-next');

    const defaultPatch = window.CURRENT_PATCH || '';
    patchInput.value = defaultPatch;

    loadBuilds('', '', '', defaultPatch, 1);

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        loadBuilds(
            searchInput.value.trim(),
            championInput.value.trim(),
            roleFilter.value,
            patchInput.value.trim(),
            1
        );
    });

    reset.addEventListener('click', () => {
        searchInput.value = '';
        championInput.value = '';
        roleFilter.value = '';
        patchInput.value = defaultPatch;
        loadBuilds('', '', '', defaultPatch, 1);
    });

    prev.addEventListener('click', () => {
        loadBuilds(
            buildsQueryState.search,
            buildsQueryState.champion,
            buildsQueryState.role,
            buildsQueryState.patch,
            buildsQueryState.page - 1
        );
    });

    next.addEventListener('click', () => {
        loadBuilds(
            buildsQueryState.search,
            buildsQueryState.champion,
            buildsQueryState.role,
            buildsQueryState.patch,
            buildsQueryState.page + 1
        );
    });
});
