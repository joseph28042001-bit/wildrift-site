/**
 * Wild Rift Platform — Page Accueil.
 * Connecte les sections "Champions populaires", "Builds populaires" et
 * "Tier List" (pages/home.php) aux API existantes (GET /api/champions/,
 * GET /api/builds/ et GET /api/tier-list/ — voir api/champions/,
 * api/builds/ et api/tier-list/).
 *
 * Ce fichier n'est chargé que sur la page Accueil (voir pages/home.php) —
 * comme assets/js/champions.js pour la page Champions, dont il reprend
 * volontairement la même logique de récupération/rendu de carte plutôt
 * que de la réutiliser depuis champions.js : ce dernier cible des
 * identifiants (#champions-*) différents de ceux de cette section
 * (#popular-champions-*) et s'exécute lui-même au chargement du DOM,
 * il ne s'intègre donc pas tel quel ici sans le modifier — hors périmètre
 * de cette étape.
 *
 * Aucune notion de popularité n'existe encore côté données (voir le
 * commentaire dans pages/home.php) : cette section affiche simplement les
 * 4 premiers champions renvoyés par l'API (déjà triés par nom côté
 * serveur), en attendant un vrai indicateur de popularité.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

const HOME_POPULAR_CHAMPIONS_COUNT = 4;

const HOME_CHAMPION_ROLE_LABELS = {
    baron: 'Voie Baron',
    jungle: 'Jungle',
    mid: 'Voie du Milieu',
    dragon: 'Voie Dragon',
    support: 'Support',
};

const HOME_CHAMPION_ROLE_BADGE_CLASSES = {
    baron: 'badge--brass',
    jungle: 'badge--verdant',
    mid: 'badge--teal',
    dragon: 'badge--crimson',
    support: '',
};

/**
 * Récupère la liste complète des champions depuis l'API (voir
 * assets/js/champions.js::fetchChampions(), logique identique).
 *
 * @returns {Promise<Array>} Champions (id, slug, name, title, role,
 *                            difficulty, image_url).
 */
async function fetchHomePopularChampions() {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/champions/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des champions.');
    }

    return payload.data;
}

/**
 * Construit la carte HTML d'un champion (composant .card du design
 * system, variante .card--champion — voir assets/js/champions.js pour le
 * modèle repris ici à l'identique).
 *
 * Navigation champion → build : même lien que
 * assets/js/champions.js::renderChampionCard() — la carte entière est un
 * lien <a> (classes .card .card--champion inchangées) dont l'URL vient de
 * la même fonction partagée, getChampionPageUrl() (assets/js/main.js),
 * donc toujours identique à celle de la page Champions
 * (builds.php?champion=<slug du champion>, routé par builds.php vers
 * pages/champion-build.php).
 */
function renderHomeChampionCard(champion, index) {
    const card = document.createElement('a');
    card.className = 'card card--champion';
    card.href = getChampionPageUrl(champion.slug);
    card.style.setProperty('--card-index', index);

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = 'Champion';
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = champion.name;
    card.appendChild(title);

    if (champion.title) {
        const subtitle = document.createElement('p');
        subtitle.textContent = champion.title;
        card.appendChild(subtitle);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const roleBadge = document.createElement('span');
    const roleBadgeClass = HOME_CHAMPION_ROLE_BADGE_CLASSES[champion.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = HOME_CHAMPION_ROLE_LABELS[champion.role] || champion.role;
    foot.appendChild(roleBadge);

    const difficulty = document.createElement('span');
    difficulty.className = 'text-mono text-muted';
    difficulty.style.fontSize = 'var(--text-xs)';
    difficulty.textContent = `Difficulté : ${champion.difficulty}`;
    foot.appendChild(difficulty);

    card.appendChild(foot);

    return card;
}

function renderHomePopularChampions(champions) {
    const grid = document.getElementById('popular-champions-grid');
    grid.innerHTML = '';

    champions
        .slice(0, HOME_POPULAR_CHAMPIONS_COUNT)
        .forEach((champion, index) => {
            grid.appendChild(renderHomeChampionCard(champion, index));
        });
}

document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('popular-champions-loading');
    const error = document.getElementById('popular-champions-error');

    fetchHomePopularChampions()
        .then((champions) => {
            renderHomePopularChampions(champions);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
});

/* --------------------------------------------------------------------
   Section "Builds populaires"
   -------------------------------------------------------------------- */

const HOME_POPULAR_BUILDS_COUNT = 4;

const HOME_BUILD_ROLE_LABELS = HOME_CHAMPION_ROLE_LABELS;
const HOME_BUILD_ROLE_BADGE_CLASSES = HOME_CHAMPION_ROLE_BADGE_CLASSES;

/**
 * Récupère la première page de builds depuis l'API (voir
 * assets/js/builds.js::fetchBuilds(), logique identique). GET
 * /api/builds/ sans paramètre renvoie déjà la première page
 * (BUILD_PAGE_SIZE résultats — voir api/builds/repository.php).
 *
 * @returns {Promise<Array>} Builds (id, name, champion, role, patch).
 */
async function fetchHomePopularBuilds() {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/builds/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des builds.');
    }

    return payload.data;
}

/**
 * Construit la carte HTML d'un build (voir assets/js/builds.js::
 * renderBuildCard(), modèle repris ici à l'identique).
 *
 * Seul le nom du champion (eyebrow) devient un lien de navigation vers
 * la page du champion (getChampionPageUrl(), assets/js/main.js — même
 * lien que renderHomeChampionCard() ci-dessus) : la carte représente un build,
 * pas un champion — contrairement à renderHomeChampionCard(), c'est
 * donc seulement cette partie de la carte qui doit être cliquable.
 * build.champion_slug vient de l'API (voir api/builds/repository.php,
 * BUILD_SELECT_COLUMNS).
 */
function renderHomeBuildCard(build) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('a');
    eyebrow.className = 'card__eyebrow';
    eyebrow.href = getChampionPageUrl(build.champion_slug);
    eyebrow.textContent = build.champion;
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = build.name;
    card.appendChild(title);

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const roleBadge = document.createElement('span');
    const roleBadgeClass = HOME_BUILD_ROLE_BADGE_CLASSES[build.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = HOME_BUILD_ROLE_LABELS[build.role] || build.role;
    foot.appendChild(roleBadge);

    const patch = document.createElement('span');
    patch.className = 'text-mono text-muted';
    patch.style.fontSize = 'var(--text-xs)';
    patch.textContent = `Patch ${build.patch}`;
    foot.appendChild(patch);

    card.appendChild(foot);

    return card;
}

function renderHomePopularBuilds(builds) {
    const grid = document.getElementById('popular-builds-grid');
    grid.innerHTML = '';

    builds
        .slice(0, HOME_POPULAR_BUILDS_COUNT)
        .forEach((build) => {
            grid.appendChild(renderHomeBuildCard(build));
        });
}

document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('popular-builds-loading');
    const error = document.getElementById('popular-builds-error');

    fetchHomePopularBuilds()
        .then((builds) => {
            renderHomePopularBuilds(builds);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
});

/* --------------------------------------------------------------------
   Section "Tier List"
   -------------------------------------------------------------------- */

const HOME_TOP_TIER_LIST_COUNT = 4;

const HOME_TIER_LIST_ROLE_LABELS = HOME_CHAMPION_ROLE_LABELS;
const HOME_TIER_LIST_ROLE_BADGE_CLASSES = HOME_CHAMPION_ROLE_BADGE_CLASSES;

const HOME_TIER_LIST_TIER_BADGE_CLASSES = {
    'S+': 'badge--crimson',
    S: 'badge--crimson',
    A: 'badge--brass',
    B: 'badge--teal',
    C: 'badge--verdant',
    D: '',
};

/**
 * Récupère toute la tier list depuis l'API (voir
 * assets/js/tier-list.js::fetchTierList(), logique identique). Déjà
 * triée par patch le plus récent puis par tier (S en tête) côté serveur
 * — voir findTierList(), api/tier-list/repository.php.
 *
 * @returns {Promise<Array>} Entrées (id, champion, role, tier, patch,
 *                            win_rate, pick_rate, ban_rate).
 */
async function fetchHomeTopTierList() {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/tier-list/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération de la tier list.');
    }

    return payload.data;
}

/**
 * Formate un taux (win_rate/pick_rate/ban_rate) pour l'affichage (voir
 * assets/js/tier-list.js::formatRate(), logique identique).
 */
function formatHomeRate(rate) {
    return rate !== null ? `${rate.toFixed(1)} %` : 'N/A';
}

/**
 * Construit la carte HTML d'une entrée de tier list (voir
 * assets/js/tier-list.js::renderTierListCard(), modèle repris ici à
 * l'identique).
 */
function renderHomeTierListCard(entry) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = `Patch ${entry.patch}`;
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = entry.champion;
    card.appendChild(title);

    const rates = document.createElement('p');
    rates.className = 'text-mono text-muted';
    rates.style.fontSize = 'var(--text-xs)';
    rates.textContent = `Victoire : ${formatHomeRate(entry.win_rate)} · Sélection : ${formatHomeRate(entry.pick_rate)} · Bannissement : ${formatHomeRate(entry.ban_rate)}`;
    card.appendChild(rates);

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const tierBadge = document.createElement('span');
    const tierBadgeClass = HOME_TIER_LIST_TIER_BADGE_CLASSES[entry.tier] || '';
    tierBadge.className = tierBadgeClass ? `badge ${tierBadgeClass}` : 'badge';
    tierBadge.textContent = `Tier ${entry.tier}`;
    foot.appendChild(tierBadge);

    const roleBadge = document.createElement('span');
    const roleBadgeClass = HOME_TIER_LIST_ROLE_BADGE_CLASSES[entry.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = HOME_TIER_LIST_ROLE_LABELS[entry.role] || entry.role;
    foot.appendChild(roleBadge);

    card.appendChild(foot);

    return card;
}

function renderHomeTopTierList(entries) {
    const grid = document.getElementById('home-tier-list-grid');
    grid.innerHTML = '';

    entries
        .slice(0, HOME_TOP_TIER_LIST_COUNT)
        .forEach((entry) => {
            grid.appendChild(renderHomeTierListCard(entry));
        });
}

document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('home-tier-list-loading');
    const error = document.getElementById('home-tier-list-error');

    fetchHomeTopTierList()
        .then((entries) => {
            renderHomeTopTierList(entries);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
});

/* --------------------------------------------------------------------
   Section "Counters"
   -------------------------------------------------------------------- */

const HOME_POPULAR_COUNTERS_COUNT = 4;

/**
 * Classe de badge associée à chaque niveau de difficulté (voir
 * assets/js/counters.js::COUNTER_DIFFICULTY_BADGE_CLASSES, modèle repris
 * ici à l'identique).
 */
const HOME_COUNTER_DIFFICULTY_BADGE_CLASSES = {
    facile: 'badge--verdant',
    moyen: 'badge--brass',
    difficile: 'badge--crimson',
};

/**
 * Récupère tous les counters depuis l'API (voir
 * assets/js/counters.js::fetchCounters(), logique identique). GET
 * /api/counters/ sans paramètre renvoie déjà tous les counters — voir
 * api/counters/repository.php.
 *
 * @returns {Promise<Array>} Counters (id, champion_id,
 *                            counter_champion_id, explanation, tips,
 *                            difficulty, items).
 */
async function fetchHomePopularCounters() {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/counters/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des counters.');
    }

    return payload.data;
}

/**
 * Construit la carte HTML d'un counter (voir
 * assets/js/counters.js::renderCounterCard(), modèle repris ici à
 * l'identique — mêmes IDs bruts, l'API ne résolvant pas les noms de
 * champions).
 */
function renderHomeCounterCard(counter) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = 'Matchup';
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = `Champion #${counter.counter_champion_id} contre champion #${counter.champion_id}`;
    card.appendChild(title);

    if (counter.explanation) {
        const explanation = document.createElement('p');
        explanation.textContent = counter.explanation;
        card.appendChild(explanation);
    }

    if (counter.difficulty) {
        const foot = document.createElement('div');
        foot.className = 'card__foot';

        const difficultyBadge = document.createElement('span');
        const difficultyBadgeClass = HOME_COUNTER_DIFFICULTY_BADGE_CLASSES[counter.difficulty] || '';
        difficultyBadge.className = difficultyBadgeClass ? `badge ${difficultyBadgeClass}` : 'badge';
        difficultyBadge.textContent = counter.difficulty;
        foot.appendChild(difficultyBadge);

        card.appendChild(foot);
    }

    return card;
}

function renderHomePopularCounters(counters) {
    const grid = document.getElementById('popular-counters-grid');
    grid.innerHTML = '';

    counters
        .slice(0, HOME_POPULAR_COUNTERS_COUNT)
        .forEach((counter) => {
            grid.appendChild(renderHomeCounterCard(counter));
        });
}

document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('popular-counters-loading');
    const error = document.getElementById('popular-counters-error');

    fetchHomePopularCounters()
        .then((counters) => {
            renderHomePopularCounters(counters);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
});

/* --------------------------------------------------------------------
   Section "Actualités"
   -------------------------------------------------------------------- */

const HOME_POPULAR_NEWS_COUNT = 4;

/**
 * Récupère les articles publiés les plus récents depuis l'API.
 * Réutilise directement fetchRecentNews() (assets/js/news.js, chargé
 * globalement avant ce fichier — voir includes/components/footer.php),
 * plutôt que de dupliquer un appel identique à GET /api/news/?limit= :
 * contrairement aux autres sections de cette page, cette fonction ne
 * dépend d'aucun id du DOM et peut donc être appelée telle quelle.
 *
 * @returns {Promise<Array>} Articles les plus récents (mêmes colonnes
 *                            que fetchNewsList(), voir news.js).
 */
async function fetchHomePopularNews() {
    return fetchRecentNews(HOME_POPULAR_NEWS_COUNT);
}

function renderHomePopularNews(articles) {
    const grid = document.getElementById('popular-news-grid');
    grid.innerHTML = '';

    articles.forEach((article) => {
        grid.appendChild(renderNewsCard(article));
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('popular-news-loading');
    const error = document.getElementById('popular-news-error');

    fetchHomePopularNews()
        .then((articles) => {
            renderHomePopularNews(articles);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
});
