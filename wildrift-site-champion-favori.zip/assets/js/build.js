/**
 * Wild Rift Platform — Page Build (détail).
 * Connecte la page pages/build.php à l'API existante
 * (GET /api/builds/?id=, voir api/builds/index.php et
 * api/builds/repository.php :: findBuildById()) : lit l'ID du build
 * dans l'URL (?id=), récupère sa fiche complète au chargement de la
 * page et l'affiche — même principe que assets/js/champion.js.
 *
 * Contrairement à champion.js, où les statistiques/capacités/builds/
 * counters/synergies proviennent chacune d'une requête séparée vers une
 * autre ressource, le détail d'un build (objets, runes, ordre des
 * compétences) est déjà renvoyé en une seule fois par la même requête
 * ?id= (voir repository.php :: findBuildItemsGrouped()/findBuildRunes()/
 * findBuildSkillOrder()) : il n'y a donc qu'un seul appel réseau ici,
 * pas de connexions supplémentaires à charger après coup.
 *
 * Ce fichier n'est chargé que sur la page Build (voir build.php) —
 * contrairement à assets/js/news.js, chargé globalement, il n'y a pas
 * lieu d'exécuter ce code sur les autres pages, qui n'ont pas les
 * éléments #build-* attendus ci-dessous.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

/**
 * Libellés français des rôles et classe de badge associée — repris tels
 * quels de assets/js/builds.js, pour rester cohérent visuellement entre
 * la liste des builds et cette page de détail.
 */
const BUILD_DETAIL_ROLE_LABELS = {
    baron: 'Voie Baron',
    jungle: 'Jungle',
    mid: 'Voie du Milieu',
    dragon: 'Voie Dragon',
    support: 'Support',
};

const BUILD_DETAIL_ROLE_BADGE_CLASSES = {
    baron: 'badge--brass',
    jungle: 'badge--verdant',
    mid: 'badge--teal',
    dragon: 'badge--crimson',
    support: '',
};

/**
 * Libellés français des catégories d'objets — repris de
 * assets/js/items.js (ITEM_CATEGORY_LABELS), pour rester cohérent avec
 * la page Objets. Affichés en eyebrow plutôt qu'en badge (BUILD_ITEM_*
 * n'a pas de variante badge propre) : chaque carte reste compacte, les
 * objets d'un build n'ayant pas de description à afficher en dessous.
 */
const BUILD_ITEM_CATEGORY_LABELS = {
    attack: 'Attaque',
    magic: 'Magie',
    defense: 'Défense',
    boots: 'Bottes',
    jungle: 'Jungle',
    consumable: 'Consommable',
    enchantment: 'Enchantement',
};

/**
 * Libellés français des emplacements d'objets de build (voir
 * getBuildItemSlots() côté API, api/builds/repository.php), dans
 * l'ordre où ils sont affichés.
 */
const BUILD_ITEM_SLOT_LABELS = {
    starting: 'Objets de départ',
    core: 'Objets principaux',
    boots: 'Bottes',
    enchantment: 'Enchantement',
    situational: 'Objets situationnels',
};

const BUILD_ITEM_SLOT_ORDER = ['starting', 'core', 'boots', 'enchantment', 'situational'];

/**
 * Libellés français des arbres de runes et classe de badge associée —
 * repris de la même palette que assets/js/runes.js (RUNE_TREE_BADGE_CLASSES),
 * avec des libellés statiques ici plutôt que chargés depuis
 * GET /api/rune-trees/ : ce fichier n'affiche qu'un petit nombre de
 * runes déjà connues par le build, pas de filtre à peupler.
 */
const BUILD_RUNE_TREE_LABELS = {
    precision: 'Précision',
    domination: 'Domination',
    sorcery: 'Sorcellerie',
    resolve: 'Résolution',
    inspiration: 'Inspiration',
};

const BUILD_RUNE_TREE_BADGE_CLASSES = {
    precision: 'badge--brass',
    domination: 'badge--crimson',
    sorcery: 'badge--teal',
    resolve: 'badge--verdant',
    inspiration: 'badge--verdant',
};

const BUILD_RUNE_SLOT_LABELS = {
    keystone: 'Rune majeure',
    minor: 'Rune mineure',
};

/**
 * Libellés français d'un emplacement de compétence (voir
 * findBuildSkillOrder() côté API, api/builds/repository.php : `skill`
 * vaut '1', '2', '3' ou 'ultimate').
 */
const BUILD_SKILL_LABELS = {
    1: 'Compétence 1',
    2: 'Compétence 2',
    3: 'Compétence 3',
    ultimate: 'Ultime',
};

/**
 * Lit et valide l'ID de build depuis l'URL courante (?id=).
 * Validation minimale côté client (entier positif) : l'API revalide de
 * toute façon l'ID (voir apiValidateInt(), api/builds/index.php) et
 * renvoie une erreur explicite si besoin ; cette vérification évite
 * simplement un appel réseau inutile pour un cas manifestement invalide
 * — même principe que assets/js/champion.js :: getRequestedChampionId().
 *
 * @returns {number} L'ID demandé.
 * @throws {Error} Si l'ID est absent ou n'est pas un entier positif.
 */
function getRequestedBuildId() {
    const params = new URLSearchParams(window.location.search);
    const raw = params.get('id');

    if (!raw || !/^\d+$/.test(raw) || Number(raw) < 1) {
        throw new Error("Aucun build valide n'a été demandé.");
    }

    return Number(raw);
}

/**
 * Récupère le détail d'un build depuis l'API (GET /api/builds/?id=).
 * Reprend l'enveloppe JSON standard de l'API ({ success, data, meta }) —
 * voir api/core/response.php : en cas de succès, renvoie le build
 * (data), avec ses objets (items), ses runes (runes) et son ordre de
 * compétences (skill_order) déjà inclus par l'API ; en cas d'échec
 * (HTTP, build introuvable ou réseau), le rejette avec une erreur dont
 * le message est toujours sûr à afficher tel quel.
 *
 * @param {number} id Identifiant du build.
 * @returns {Promise<Object>} Le build (id, name, champion, role, patch,
 *                             description, source, items, runes,
 *                             skill_order).
 */
async function fetchBuildDetail(id) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/builds/?id=${encodeURIComponent(id)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération du build.');
    }

    return payload.data;
}

/**
 * Remplit #build-detail avec la fiche du build (composant .card du
 * design system) : champion associé, nom, description (si fournie),
 * rôle, patch et source (si fournie) — même structure que
 * assets/js/champion.js :: renderChampionDetail().
 */
function renderBuildDetail(build) {
    const detail = document.getElementById('build-detail');
    detail.innerHTML = '';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = build.champion;
    detail.appendChild(eyebrow);

    const title = document.createElement('h1');
    title.className = 'card__title';
    title.textContent = build.name;
    detail.appendChild(title);

    if (build.description) {
        const description = document.createElement('p');
        description.textContent = build.description;
        detail.appendChild(description);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const roleBadge = document.createElement('span');
    const roleBadgeClass = BUILD_DETAIL_ROLE_BADGE_CLASSES[build.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = BUILD_DETAIL_ROLE_LABELS[build.role] || build.role;
    foot.appendChild(roleBadge);

    const patch = document.createElement('span');
    patch.className = 'text-mono text-muted';
    patch.style.fontSize = 'var(--text-xs)';
    patch.textContent = `Patch ${build.patch}`;
    foot.appendChild(patch);

    detail.appendChild(foot);

    if (build.source) {
        const source = document.createElement('p');
        source.className = 'text-mono text-muted';
        source.style.fontSize = 'var(--text-xs)';
        source.textContent = `Source : ${build.source}`;
        detail.appendChild(source);
    }

    detail.hidden = false;
}

/**
 * Construit la carte HTML d'un objet de build (même modèle allégé que
 * assets/js/items.js :: renderItemCard(), sans description : les
 * objets d'un build n'en renvoient pas, voir BUILD_ITEM_SELECT_COLUMNS,
 * api/builds/repository.php).
 */
function renderBuildItemCard(item) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = BUILD_ITEM_CATEGORY_LABELS[item.category] || item.category;
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = item.name;
    card.appendChild(title);

    const price = document.createElement('span');
    price.className = 'text-mono text-muted';
    price.style.fontSize = 'var(--text-xs)';
    price.textContent = item.price !== null && item.price !== undefined ? `${item.price} po` : 'N/A';
    card.appendChild(price);

    return card;
}

/**
 * Affiche #build-items : un sous-titre + une grille de cartes par
 * emplacement (BUILD_ITEM_SLOT_ORDER, dans cet ordre), suivi de l'ordre
 * d'achat conseillé (build.items.purchase_order — voir
 * findBuildItemsGrouped(), api/builds/repository.php) sous forme de
 * liste numérotée. N'affiche que les emplacements non vides. Affiche
 * #build-items-empty si aucun objet n'est renseigné (tous les
 * emplacements vides).
 *
 * @param {Object} items build.items — voir fetchBuildDetail().
 */
function renderBuildItems(items) {
    const container = document.getElementById('build-items');
    const empty = document.getElementById('build-items-empty');
    container.innerHTML = '';

    const nonEmptySlots = BUILD_ITEM_SLOT_ORDER.filter((slot) => (items[slot] || []).length > 0);

    if (nonEmptySlots.length === 0) {
        empty.hidden = false;
        return;
    }

    empty.hidden = true;

    nonEmptySlots.forEach((slot) => {
        const heading = document.createElement('h3');
        heading.style.marginTop = 'var(--space-5)';
        heading.textContent = BUILD_ITEM_SLOT_LABELS[slot] || slot;
        container.appendChild(heading);

        const grid = document.createElement('div');
        grid.className = 'grid';
        items[slot].forEach((item) => {
            grid.appendChild(renderBuildItemCard(item));
        });
        container.appendChild(grid);
    });

    if ((items.purchase_order || []).length > 0) {
        const heading = document.createElement('h3');
        heading.style.marginTop = 'var(--space-5)';
        heading.textContent = "Ordre d'achat conseillé";
        container.appendChild(heading);

        const list = document.createElement('ol');
        list.className = 'text-mono text-muted';
        items.purchase_order.forEach((step) => {
            const entry = document.createElement('li');
            entry.textContent = step.item;
            list.appendChild(entry);
        });
        container.appendChild(list);
    }
}

/**
 * Construit la carte HTML d'une rune de build (même modèle allégé que
 * assets/js/runes.js :: renderRuneCard(), sans description : les runes
 * d'un build n'en renvoient pas, voir BUILD_RUNE_SELECT_COLUMNS,
 * api/builds/repository.php).
 */
function renderBuildRuneCard(rune) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = BUILD_RUNE_SLOT_LABELS[rune.slot] || 'Rune';
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = rune.name;
    card.appendChild(title);

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const treeBadge = document.createElement('span');
    const treeBadgeClass = BUILD_RUNE_TREE_BADGE_CLASSES[rune.tree] || '';
    treeBadge.className = treeBadgeClass ? `badge ${treeBadgeClass}` : 'badge';
    treeBadge.textContent = BUILD_RUNE_TREE_LABELS[rune.tree] || rune.tree;
    foot.appendChild(treeBadge);

    card.appendChild(foot);

    return card;
}

/**
 * Affiche #build-runes-grid, dans l'ordre reçu (déjà trié par position
 * par l'API — voir findBuildRunes(), api/builds/repository.php).
 * Affiche #build-runes-empty si aucune rune n'est renseignée.
 *
 * @param {Array} runes build.runes — voir fetchBuildDetail().
 */
function renderBuildRunes(runes) {
    const grid = document.getElementById('build-runes-grid');
    const empty = document.getElementById('build-runes-empty');
    grid.innerHTML = '';

    if (runes.length === 0) {
        empty.hidden = false;
        return;
    }

    empty.hidden = true;
    runes.forEach((rune) => {
        grid.appendChild(renderBuildRuneCard(rune));
    });
}

/**
 * Affiche #build-skill-order-list, un badge par niveau (1 à 15), dans
 * l'ordre reçu (déjà trié par niveau croissant par l'API — voir
 * findBuildSkillOrder(), api/builds/repository.php). Affiche
 * #build-skill-order-empty si aucun ordre n'est renseigné.
 *
 * @param {Array} skillOrder build.skill_order — voir fetchBuildDetail().
 */
function renderBuildSkillOrder(skillOrder) {
    const list = document.getElementById('build-skill-order-list');
    const empty = document.getElementById('build-skill-order-empty');
    list.innerHTML = '';

    if (skillOrder.length === 0) {
        empty.hidden = false;
        return;
    }

    empty.hidden = true;
    skillOrder.forEach((entry) => {
        const item = document.createElement('li');
        item.className = 'badge';
        item.textContent = `${entry.level}. ${BUILD_SKILL_LABELS[entry.skill] || entry.skill}`;
        list.appendChild(item);
    });
}

/**
 * Point d'entrée : lit l'ID demandé, déclenche la récupération et
 * bascule entre les trois états possibles (chargement → succès ou
 * erreur). Un ID absent/invalide est traité comme une erreur au même
 * titre qu'un échec réseau ou un build introuvable : même zone
 * d'erreur, même comportement pour l'utilisateur — même principe que
 * assets/js/champion.js.
 *
 * Une fois la fiche affichée, les sections Objets/Runes/Ordre des
 * compétences sont remplies directement à partir de la même réponse
 * (build.items/build.runes/build.skill_order), sans requête
 * supplémentaire.
 */
document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('build-loading');
    const error = document.getElementById('build-error');

    Promise.resolve()
        .then(() => getRequestedBuildId())
        .then((id) => fetchBuildDetail(id))
        .then((build) => {
            renderBuildDetail(build);
            renderBuildItems(build.items || {});
            renderBuildRunes(build.runes || []);
            renderBuildSkillOrder(build.skill_order || []);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
});
