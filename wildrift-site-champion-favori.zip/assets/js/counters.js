/**
 * Wild Rift Platform — Page Matchups & counters.
 * Connecte la page pages/counters.php à l'API existante
 * (GET /api/counters/, voir api/counters/index.php et
 * api/counters/repository.php) : récupère tous les counters au
 * chargement de la page et les affiche sous forme de cartes. Même
 * structure que assets/js/builds.js (page Builds).
 *
 * GET /api/counters/ sans paramètre renvoie déjà tous les counters :
 * pas de filtre par champion (?champion_id=, ?counter_champion_id=)
 * câblé ici, même limite volontaire que assets/js/builds.js (pas de
 * filtre champion/rôle/patch).
 *
 * L'API ne résout pas les noms des champions dans la liste des
 * counters (contrairement à /api/builds/, qui renvoie `champion` par
 * jointure) : elle expose `champion_id` et `counter_champion_id` en
 * IDs bruts (voir COUNTER_SELECT_COLUMNS, repository.php). Ce fichier
 * résout donc ces IDs côté client, via un appel à GET /api/champions/
 * (voir fetchChampionNameMap() ci-dessous), pour afficher de vrais noms
 * de champions plutôt que des IDs bruts.
 *
 * Ce fichier n'est chargé que sur la page Counters (voir counters.php)
 * — contrairement à assets/js/news.js, chargé globalement, il n'y a
 * pas lieu d'exécuter ce code sur les autres pages, qui n'ont pas les
 * éléments #counters-* attendus ci-dessous.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

/**
 * Classe de badge associée à chaque niveau de difficulté (colonne
 * `difficulty`, ENUM('facile', 'moyen', 'difficile') nullable — voir
 * database/schema.sql). Déjà en français côté API, pas de table de
 * libellés nécessaire ici (contrairement aux autres pages, où les
 * valeurs de l'API sont en anglais).
 */
const COUNTER_DIFFICULTY_BADGE_CLASSES = {
    facile: 'badge--verdant',
    moyen: 'badge--brass',
    difficile: 'badge--crimson',
};

/**
 * Récupère la liste complète des counters depuis l'API.
 * Reprend l'enveloppe JSON standard de l'API ({ success, data, meta }) —
 * voir api/core/response.php : en cas de succès, renvoie le tableau de
 * counters (data) ; en cas d'échec (HTTP ou réseau), le rejette avec
 * une erreur dont le message est toujours sûr à afficher tel quel.
 *
 * @returns {Promise<Array>} Counters (id, champion_id,
 *                            counter_champion_id, explanation, tips,
 *                            difficulty, items).
 */
async function fetchCounters() {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/counters/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des counters.');
    }

    return payload.data;
}

/**
 * Récupère tous les champions depuis l'API et construit une map
 * id → name, pour résoudre côté client les `champion_id` et
 * `counter_champion_id` bruts renvoyés par /api/counters/ (voir
 * commentaire d'en-tête). Repose sur GET /api/champions/ (sans filtre) —
 * voir api/champions/index.php et repository.php (CHAMPION_SELECT_COLUMNS,
 * qui inclut `id` et `name`).
 * En cas d'échec (réseau ou API), retourne une map vide plutôt que de
 * rejeter : l'affichage des counters reste possible, avec un repli sur
 * l'ID brut (voir championName() ci-dessous) — l'échec de cette
 * résolution annexe ne doit pas empêcher l'affichage des counters
 * eux-mêmes.
 *
 * @returns {Promise<Map<number, string>>}
 */
async function fetchChampionNameMap() {
    const base = window.API_BASE_URL || '/api';

    try {
        const response = await fetch(`${base}/champions/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });

        const payload = await response.json();

        if (!response.ok || !payload?.success) {
            return new Map();
        }

        return new Map(payload.data.map((champion) => [champion.id, champion.name]));
    } catch (networkError) {
        return new Map();
    }
}

/**
 * Résout un ID de champion en son nom via la map fournie, avec repli sur
 * l'ID brut (« Champion #12 ») si la map est vide ou ne contient pas cet
 * ID (ex. échec de fetchChampionNameMap(), ou champion supprimé depuis).
 */
function championName(championNameMap, championId) {
    return championNameMap.get(championId) || `Champion #${championId}`;
}

/**
 * Construit la carte HTML d'un counter (composant .card du design
 * system — voir assets/css/style.css et pages/styleguide.php pour le
 * modèle repris ici). N'insère aucune valeur non échappée : toutes les
 * données viennent de l'API, mais restent traitées comme non sûres côté
 * affichage (textContent, jamais innerHTML sur une valeur dynamique).
 *
 * @param {Map<number, string>} championNameMap Voir fetchChampionNameMap().
 */
function renderCounterCard(counter, championNameMap) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = 'Matchup';
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    const counterName = championName(championNameMap, counter.counter_champion_id);
    const championNameValue = championName(championNameMap, counter.champion_id);
    title.textContent = `${counterName} contre ${championNameValue}`;
    card.appendChild(title);

    if (counter.explanation) {
        const explanation = document.createElement('p');
        explanation.textContent = counter.explanation;
        card.appendChild(explanation);
    }

    if (counter.tips) {
        const tips = document.createElement('p');
        tips.className = 'text-muted';
        tips.textContent = counter.tips;
        card.appendChild(tips);
    }

    if (Array.isArray(counter.items) && counter.items.length > 0) {
        const items = document.createElement('p');
        items.className = 'text-mono text-muted';
        items.style.fontSize = 'var(--text-xs)';
        items.textContent = `Objets recommandés : ${counter.items.map((item) => item.name).join(', ')}`;
        card.appendChild(items);
    }

    if (counter.difficulty) {
        const foot = document.createElement('div');
        foot.className = 'card__foot';

        const difficultyBadge = document.createElement('span');
        const difficultyBadgeClass = COUNTER_DIFFICULTY_BADGE_CLASSES[counter.difficulty] || '';
        difficultyBadge.className = difficultyBadgeClass ? `badge ${difficultyBadgeClass}` : 'badge';
        difficultyBadge.textContent = counter.difficulty;
        foot.appendChild(difficultyBadge);

        card.appendChild(foot);
    }

    return card;
}

/**
 * Affiche la liste des counters dans #counters-grid, un par un
 * (renderCounterCard() ci-dessus). Ne fait rien d'autre : la bascule de
 * l'état de chargement/erreur est gérée par l'appelant.
 *
 * @param {Map<number, string>} championNameMap Voir fetchChampionNameMap().
 */
function renderCounters(counters, championNameMap) {
    const grid = document.getElementById('counters-grid');
    grid.innerHTML = '';

    counters.forEach((counter) => {
        grid.appendChild(renderCounterCard(counter, championNameMap));
    });
}

/**
 * Point d'entrée : déclenche la récupération au chargement de la page et
 * bascule entre les trois états possibles (chargement → succès ou erreur).
 * Récupère les counters et la map des noms de champions en parallèle
 * (Promise.all) : les deux appels sont indépendants, pas besoin
 * d'attendre l'un pour lancer l'autre.
 */
document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('counters-loading');
    const error = document.getElementById('counters-error');

    Promise.all([fetchCounters(), fetchChampionNameMap()])
        .then(([counters, championNameMap]) => {
            renderCounters(counters, championNameMap);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
});
