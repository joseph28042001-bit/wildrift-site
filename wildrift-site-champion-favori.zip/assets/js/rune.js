/**
 * Wild Rift Platform — Page Rune (détail).
 * Connecte la page pages/rune.php à l'API existante
 * (GET /api/runes/?id=, voir api/runes/index.php et
 * api/runes/repository.php :: findRuneById()) : lit l'ID de la rune
 * dans l'URL (?id=), récupère sa fiche au chargement de la page et
 * l'affiche — même principe que assets/js/item.js, mais pour une
 * rune, sans les sections supplémentaires (statistiques, capacités,
 * builds, counters, synergies) qui n'ont pas de sens pour une rune.
 *
 * Ce fichier n'est chargé que sur la page Rune (voir rune.php) —
 * contrairement à assets/js/news.js, chargé globalement, il n'y a pas
 * lieu d'exécuter ce code sur les autres pages, qui n'ont pas les
 * éléments #rune-* attendus ci-dessous.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

/**
 * Classes de badge associées à chaque arbre de runes (voir
 * assets/css/style.css) — reprend volontairement les mêmes classes que
 * RUNE_TREE_BADGE_CLASSES (assets/js/runes.js) plutôt que de les
 * importer : ce fichier n'est chargé que sur cette page, séparément de
 * runes.js — même principe que assets/js/champion.js/champions.js.
 * Pure préoccupation d'affichage, indépendante des données (voir
 * RUNE_DETAIL_TREE_LABELS ci-dessous pour le nom affiché).
 */
const RUNE_DETAIL_TREE_BADGE_CLASSES = {
    precision: 'badge--brass',
    domination: 'badge--crimson',
    sorcery: 'badge--teal',
    resolve: 'badge--verdant',
    inspiration: 'badge--verdant',
};

/**
 * Libellés français des arbres de runes, indexés par slug — rempli au
 * chargement de la page à partir de GET /api/rune-trees/ (voir
 * api/rune-trees/index.php), même source que le filtre de
 * pages/runes.php (assets/js/runes.js::populateRuneTreeFilter()).
 * Vide tant que cette requête n'a pas répondu ; renderRuneDetail() se
 * rabat alors sur le slug brut (rune.tree) — dégradation sans erreur,
 * jamais bloquante pour afficher la rune elle-même.
 */
const RUNE_DETAIL_TREE_LABELS = {};

/** Libellés français des emplacements de rune (colonne `slot` en base). */
const RUNE_DETAIL_SLOT_LABELS = {
    keystone: 'Rune majeure',
    minor: 'Rune mineure',
};

/**
 * Lit et valide l'ID de rune depuis l'URL courante (?id=).
 * Validation minimale côté client (entier positif) : l'API revalide de
 * toute façon l'ID (voir apiValidateInt(), api/runes/index.php) et
 * renvoie une erreur explicite si besoin ; cette vérification évite
 * simplement un appel réseau inutile pour un cas manifestement invalide
 * — même principe que getRequestedItemId() (assets/js/item.js).
 *
 * @returns {number} L'ID demandé.
 * @throws {Error} Si l'ID est absent ou n'est pas un entier positif.
 */
function getRequestedRuneId() {
    const params = new URLSearchParams(window.location.search);
    const raw = params.get('id');

    if (!raw || !/^\d+$/.test(raw) || Number(raw) < 1) {
        throw new Error("Aucune rune valide n'a été demandée.");
    }

    return Number(raw);
}

/**
 * Récupère les arbres de runes depuis l'API (GET /api/rune-trees/,
 * voir api/rune-trees/index.php) pour peupler RUNE_DETAIL_TREE_LABELS.
 * Séparée de fetchRuneDetail() ci-dessous : un échec ici ne doit pas
 * empêcher l'affichage de la rune elle-même (voir DOMContentLoaded).
 *
 * @returns {Promise<Array>} Arbres (id, slug, name, description,
 *                            image_url).
 */
async function fetchRuneTreeLabels() {
    const base = window.API_BASE_URL || '/api';

    const response = await fetch(`${base}/rune-trees/`, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
    });

    const payload = await response.json();

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des arbres de runes.');
    }

    return payload.data;
}

/**
 * Récupère la fiche d'une rune depuis l'API (GET /api/runes/?id=).
 * Reprend l'enveloppe JSON standard de l'API ({ success, data, meta }) —
 * voir api/core/response.php : en cas de succès, renvoie la rune (data) ;
 * en cas d'échec (HTTP, rune introuvable ou réseau), le rejette avec
 * une erreur dont le message est toujours sûr à afficher tel quel (voir
 * notFound(), ApiException, api/runes/index.php).
 *
 * @param {number} id Identifiant de la rune.
 * @returns {Promise<Object>} La rune (id, slug, name, tree, slot,
 *                             description, image_url).
 */
async function fetchRuneDetail(id) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/runes/?id=${encodeURIComponent(id)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || "Erreur lors de la récupération de la rune.");
    }

    return payload.data;
}

/**
 * Remplit #rune-detail avec la fiche de la rune (composant .card du
 * design system — voir assets/js/runes.js::renderRuneCard() pour le
 * modèle repris ici). Nom, description (si renseignée), emplacement et
 * arbre, dans le même ordre que les cartes de la liste.
 */
function renderRuneDetail(rune) {
    const detail = document.getElementById('rune-detail');
    detail.innerHTML = '';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = RUNE_DETAIL_SLOT_LABELS[rune.slot] || 'Rune';
    detail.appendChild(eyebrow);

    const title = document.createElement('h1');
    title.className = 'card__title';
    title.textContent = rune.name;
    detail.appendChild(title);

    if (rune.description) {
        const description = document.createElement('p');
        description.textContent = rune.description;
        detail.appendChild(description);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const treeBadge = document.createElement('span');
    const treeBadgeClass = RUNE_DETAIL_TREE_BADGE_CLASSES[rune.tree] || '';
    treeBadge.className = treeBadgeClass ? `badge ${treeBadgeClass}` : 'badge';
    treeBadge.textContent = RUNE_DETAIL_TREE_LABELS[rune.tree] || rune.tree;
    foot.appendChild(treeBadge);

    detail.appendChild(foot);

    detail.hidden = false;
}

/**
 * Point d'entrée : peuple d'abord RUNE_DETAIL_TREE_LABELS à partir de
 * GET /api/rune-trees/ (fetchRuneTreeLabels() ci-dessus) — en échec, se
 * contente de laisser renderRuneDetail() se rabattre sur le slug brut,
 * ce n'est pas bloquant pour la suite. Lit ensuite l'ID demandé,
 * déclenche la récupération de la rune et bascule entre les trois
 * états possibles (chargement → succès ou erreur). Un ID absent/invalide
 * est traité comme une erreur au même titre qu'un échec réseau ou une
 * rune introuvable — même zone d'erreur, même comportement pour
 * l'utilisateur — même principe que assets/js/item.js.
 */
document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('rune-loading');
    const error = document.getElementById('rune-error');

    fetchRuneTreeLabels()
        .then((trees) => {
            trees.forEach((tree) => {
                RUNE_DETAIL_TREE_LABELS[tree.slug] = tree.name;
            });
        })
        .catch(() => {
            // Non bloquant — voir docblock ci-dessus.
        });

    Promise.resolve()
        .then(() => getRequestedRuneId())
        .then((id) => fetchRuneDetail(id))
        .then((rune) => {
            renderRuneDetail(rune);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
});
