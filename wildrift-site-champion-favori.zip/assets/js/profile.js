/**
 * Page Profil — validation des formulaires de modification du compte,
 * côté navigateur uniquement (pseudo, bio, avatar) et section
 * "Champions favoris" (récupération de la liste via l'API existante,
 * voir fetchChampionsForFavorites() ci-dessous). Aucun appel réseau
 * d'écriture ni upload réel ici : la sauvegarde de tous les
 * formulaires (pseudo, bio, avatar) se fait par soumission classique
 * vers profile.php, qui fait le traitement côté serveur — même
 * principe que assets/js/register.js pour son propre champ pseudo.
 * Seule la sauvegarde des champions favoris reste sans effet, faute de
 * table de liaison (voir pages/profile.php).
 *
 * La section "Builds favoris" n'a plus besoin de JavaScript : elle est
 * désormais entièrement rendue côté serveur par pages/profile.php
 * (voir $favoriteBuilds, préparé par profile.php), lien d'ouverture et
 * bouton de retrait inclus.
 */
document.addEventListener('DOMContentLoaded', () => {
    wireFieldValidation('profile-pseudo-form', ['profile-pseudo']);
    wireFieldValidation('profile-bio-form', ['profile-bio']);
    wireAvatarValidation('profile-avatar-form', 'profile-avatar');
    loadFavoriteChampions();
});

/**
 * Branche la validation native HTML5 d'un formulaire sur les classes du
 * design system : bascule `.field.is-invalid` (voir assets/css/style.css)
 * sur chaque champ listé, en direct puis à la soumission.
 */
function wireFieldValidation(formId, fieldIds) {
    const form = document.getElementById(formId);
    if (!form) return;

    const inputs = fieldIds
        .map((id) => document.getElementById(id))
        .filter(Boolean);

    function setValidity(input, isValid) {
        const field = input.closest('.field');
        if (!field) return;
        field.classList.toggle('is-invalid', !isValid);
    }

    inputs.forEach((input) => {
        input.addEventListener('input', () => setValidity(input, input.checkValidity()));
    });

    form.addEventListener('submit', (event) => {
        inputs.forEach((input) => setValidity(input, input.checkValidity()));

        if (!form.checkValidity()) {
            event.preventDefault();
            form.reportValidity();
        }
    });
}

/**
 * Validation dédiée au champ avatar (type="file") : la validité HTML5
 * native ne vérifie que le champ "required", pas le format ni la
 * taille du fichier choisi. Les limites (data-max-size-bytes,
 * data-allowed-extensions) viennent de config/uploads.php côté PHP
 * (voir pages/profile.php), pour rester la seule source de vérité.
 */
function wireAvatarValidation(formId, inputId) {
    const form = document.getElementById(formId);
    const input = document.getElementById(inputId);
    if (!form || !input) return;

    const maxSizeBytes = Number(input.dataset.maxSizeBytes || 0);
    const allowedExtensions = (input.dataset.allowedExtensions || '')
        .split(',')
        .map((extension) => extension.trim().toLowerCase())
        .filter(Boolean);

    function setValidity(isValid) {
        const field = input.closest('.field');
        if (!field) return;
        field.classList.toggle('is-invalid', !isValid);
    }

    function isValidFile(file) {
        if (!file) return false;
        const extension = file.name.split('.').pop().toLowerCase();
        const extensionOk = allowedExtensions.length === 0 || allowedExtensions.includes(extension);
        const sizeOk = maxSizeBytes === 0 || (file.size > 0 && file.size <= maxSizeBytes);
        return extensionOk && sizeOk;
    }

    input.addEventListener('change', () => {
        const file = input.files && input.files[0];
        setValidity(!file || isValidFile(file));
    });

    form.addEventListener('submit', (event) => {
        const file = input.files && input.files[0];
        const valid = Boolean(file) && isValidFile(file);
        setValidity(valid);

        if (!form.checkValidity() || !valid) {
            event.preventDefault();
            form.reportValidity();
        }
    });
}

/**
 * Récupère la liste complète des champions pour la sélection des
 * favoris (GET /api/champions/, voir api/champions/index.php). Reprend
 * l'enveloppe JSON standard de l'API ({ success, data } ou
 * { success: false, error }, voir api/core/response.php).
 *
 * Duplique volontairement une version minimale de la récupération déjà
 * faite par assets/js/champions.js plutôt que de la partager : ce
 * fichier n'est chargé que sur la page Champions (voir son propre
 * commentaire d'en-tête), pas ici — chaque page reste autonome dans ce
 * projet (un fichier JS par page).
 *
 * @returns {Promise<Array>} Champions (id, slug, name, title, role,
 *                            difficulty, image_url).
 */
async function fetchChampionsForFavorites() {
    const base = window.API_BASE_URL || '/api';
    let response;

    try {
        response = await fetch(`${base}/champions/`);
    } catch (err) {
        throw new Error('Impossible de contacter le serveur. Vérifie ta connexion.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (err) {
        throw new Error('Réponse invalide du serveur.');
    }

    if (!response.ok || !payload.success) {
        const message = payload && payload.error && payload.error.message;
        throw new Error(message || 'Impossible de récupérer les champions.');
    }

    return payload.data;
}

/**
 * Affiche une case à cocher par champion dans #profile-favorites-list.
 * Construction du DOM via createElement/textContent (jamais innerHTML
 * sur une valeur venant de l'API), même règle que
 * assets/js/champions.js::renderChampions().
 */
function renderFavoriteChampions(champions) {
    const list = document.getElementById('profile-favorites-list');
    if (!list) return;

    list.textContent = '';

    champions.forEach((champion) => {
        const label = document.createElement('label');
        label.className = 'checkbox';

        const input = document.createElement('input');
        input.type = 'checkbox';
        input.name = 'favorite_champions[]';
        input.value = String(champion.id);

        label.appendChild(input);
        label.appendChild(document.createTextNode(champion.name));
        list.appendChild(label);
    });

    list.hidden = false;
}

/**
 * Point d'entrée de la section "Champions favoris" : récupère la liste
 * au chargement de la page Profil et bascule entre les trois états
 * (chargement → succès ou erreur), même principe que
 * assets/js/champions.js::loadChampions(). Aucune présélection : la
 * sauvegarde des favoris actuels dépend de la table `users`, toujours
 * pas développée (voir pages/profile.php).
 */
function loadFavoriteChampions() {
    const loading = document.getElementById('profile-favorites-loading');
    const error = document.getElementById('profile-favorites-error');
    if (!loading || !error) return;

    loading.hidden = false;
    error.hidden = true;

    fetchChampionsForFavorites()
        .then((champions) => {
            renderFavoriteChampions(champions);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}
