/**
 * Wild Rift Platform — Page Build (dynamique, par champion).
 * Connecte pages/champion-build.php (builds.php?champion=<slug>) à
 * l'API existante : présentation du champion, build principal, runes,
 * bottes, build situationnel et counters — voir le docblock de
 * pages/champion-build.php pour le détail des six sections.
 *
 * L'API ne filtre pas encore les champions par slug (uniquement par
 * id, search ou role — voir api/champions/index.php) : ce fichier
 * récupère donc la liste complète des champions une seule fois (voir
 * fetchAllChampions()) et la réutilise à la fois pour trouver le
 * champion demandé (par son slug) et pour résoudre les noms de
 * champions de la section Counters (par id) — un seul appel réseau
 * pour les deux usages, plutôt que de dupliquer l'appel comme le
 * faisait assets/js/counters.js::fetchChampionNameMap().
 *
 * Le build du champion est retrouvé par son slug (GET
 * /api/builds/?champion=<slug>, voir api/builds/index.php), dont seul
 * l'id nous intéresse dans cette première réponse (la liste ne renvoie
 * pas les objets/runes — voir BUILD_SELECT_COLUMNS,
 * api/builds/repository.php) ; GET /api/builds/?id=<id> renvoie ensuite
 * le détail complet en une seule requête — description, objets déjà
 * regroupés par emplacement (starting/core/boots/enchantment/
 * situational, avec ordre d'achat — voir findBuildItemsGrouped()) et
 * runes (avec leur arbre et keystone/mineure — voir findBuildRunes()).
 * Ce détail est chargé une seule fois (voir fetchChampionBuildDetail())
 * et réutilisé par les sections Build principal, Bottes, Build
 * situationnel et Runes, plutôt que quatre requêtes séparées. Un
 * champion sans aucun build associé (id introuvable) résout ce détail
 * à `null` : chaque section affiche alors son propre état vide plutôt
 * qu'une erreur, ce n'est pas un cas d'échec.
 *
 * La section Counters interroge GET /api/counters/ sans filtre (l'API
 * exige `champion_id` dès que `counter_champion_id` est fourni — voir
 * api/counters/index.php — ce qui empêche de récupérer en un seul appel
 * les seuls counters où ce champion contre, sans connaître à l'avance
 * ceux où il est contré) puis filtre côté client dans les deux sens
 * (champion_id/counter_champion_id) — même principe que
 * assets/js/counters.js, qui résout déjà les noms de champions côté
 * client faute de jointure côté API.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 * `window.REQUESTED_CHAMPION_SLUG` est défini dans
 * pages/champion-build.php (le slug demandé, lu côté serveur depuis
 * ?champion=).
 */

const BUILD_CHAMPION_ROLE_LABELS = {
    baron: 'Voie Baron',
    jungle: 'Jungle',
    mid: 'Voie du Milieu',
    dragon: 'Voie Dragon',
    support: 'Support',
};

const BUILD_CHAMPION_ROLE_BADGE_CLASSES = {
    baron: 'badge--brass',
    jungle: 'badge--verdant',
    mid: 'badge--teal',
    dragon: 'badge--crimson',
    support: '',
};

/**
 * Classe de badge associée à chaque tier (S+→D), reprise de
 * assets/js/champion.js::CHAMPION_STATS_TIER_BADGE_CLASSES pour une
 * cohérence visuelle avec les pages Tier List et Champion.
 */
const BUILD_CHAMPION_TIER_BADGE_CLASSES = {
    'S+': 'badge--crimson',
    S: 'badge--crimson',
    A: 'badge--brass',
    B: 'badge--teal',
    C: 'badge--verdant',
    D: '',
};

/**
 * Libellés français des emplacements d'objets d'un build (voir
 * getBuildItemSlots(), api/builds/repository.php), pour les sections
 * Build principal / Bottes / Build situationnel.
 */
const BUILD_ITEM_SLOT_LABELS = {
    starting: 'Starting Item',
    core: 'Core Items',
    boots: 'Bottes',
    enchantment: 'Enchantement',
    situational: 'Objet alternatif',
};

/** Classe de badge associée à chaque emplacement d'objet ci-dessus. */
const BUILD_ITEM_SLOT_BADGE_CLASSES = {
    starting: 'badge--teal',
    core: 'badge--brass',
    boots: 'badge--verdant',
    enchantment: 'badge--verdant',
    situational: '',
};

/**
 * Libellés français des arbres de runes (voir rune_trees dans
 * database/schema.sql — name déjà en français, repris à l'identique
 * ici pour éviter une requête supplémentaire à /api/rune-trees/ dans
 * cette étape, même principe que les libellés de rôle ci-dessus, déjà
 * dupliqués côté client ailleurs dans le projet — ex. assets/js/
 * builds.js::BUILD_ROLE_LABELS).
 */
const RUNE_TREE_LABELS = {
    precision: 'Précision',
    domination: 'Domination',
    sorcery: 'Sorcellerie',
    resolve: 'Détermination',
    inspiration: 'Inspiration',
};

/** Classe de badge associée à chaque niveau de difficulté d'un counter
 * (colonne `difficulty`, ENUM nullable — voir database/schema.sql),
 * reprise à l'identique de assets/js/counters.js::
 * COUNTER_DIFFICULTY_BADGE_CLASSES pour une cohérence visuelle avec la
 * page Matchups & counters.
 */
const COUNTER_DIFFICULTY_BADGE_CLASSES = {
    facile: 'badge--verdant',
    moyen: 'badge--brass',
    difficile: 'badge--crimson',
};

/**
 * Lit et valide le slug de champion demandé (posé côté serveur dans
 * window.REQUESTED_CHAMPION_SLUG — voir pages/champion-build.php).
 * Validation minimale côté client (même format que la colonne `slug`
 * en base — voir api/champions/index.php) : l'API revalide de toute
 * façon les données qu'elle renvoie ; cette vérification évite
 * simplement une recherche inutile pour un cas manifestement invalide.
 *
 * @returns {string} Le slug demandé.
 * @throws {Error} Si le slug est absent ou mal formé.
 */
function getRequestedChampionSlug() {
    const slug = window.REQUESTED_CHAMPION_SLUG || '';

    if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(slug)) {
        throw new Error("Aucun champion valide n'a été demandé.");
    }

    return slug;
}

/**
 * Récupère la liste complète des champions depuis l'API (GET
 * /api/champions/, sans filtre) — une seule fois, réutilisée pour
 * trouver le champion demandé (par slug) et pour résoudre les noms de
 * champions de la section Counters (par id). Reprend l'enveloppe JSON
 * standard de l'API : en cas de succès, renvoie le tableau de
 * champions ; en cas d'échec (HTTP ou réseau), le rejette avec une
 * erreur dont le message est toujours sûr à afficher tel quel.
 *
 * @returns {Promise<Array>} Tous les champions (id, slug, name, title,
 *                            role, difficulty, image_url, ...).
 */
async function fetchAllChampions() {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/champions/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des champions.');
    }

    return Array.isArray(payload.data) ? payload.data : [];
}

/**
 * Récupère les entrées de tier list associées à un champion, par son
 * slug (GET /api/tier-list/?champion=, voir api/tier-list/index.php et
 * api/tier-list/repository.php :: findTierList()), et n'en garde que
 * la première : l'API trie déjà ces entrées par patch le plus récent
 * puis meilleur tier. Un champion sans encore aucune entrée (tableau
 * vide) reste géré : la présentation retombe alors sur le rôle de base
 * du champion et affiche "non classé" pour le tier/patch.
 *
 * Filtrée par défaut sur le patch actif du site (window.CURRENT_PATCH,
 * voir includes/components/header.php et config/patch.php).
 *
 * @param {string} slug Slug du champion (colonne `slug`, champions).
 * @returns {Promise<Object|null>} L'entrée la plus pertinente, ou null.
 */
async function fetchChampionTierEntry(slug) {
    const base = window.API_BASE_URL || '/api';

    const params = new URLSearchParams({ champion: slug });
    if (window.CURRENT_PATCH) {
        params.set('patch', window.CURRENT_PATCH);
    }

    let response;
    try {
        response = await fetch(`${base}/tier-list/?${params.toString()}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des statistiques.');
    }

    const entries = Array.isArray(payload.data) ? payload.data : [];
    return entries[0] || null;
}

/**
 * Récupère l'id du build associé à un champion, par son slug (GET
 * /api/builds/?champion=<slug>, voir api/builds/index.php et
 * api/builds/repository.php :: findBuilds()). Un champion peut avoir
 * plusieurs builds ; la première entrée (triée par nom — voir
 * findBuilds()) est utilisée.
 *
 * Filtrée par défaut sur le patch actif du site (window.CURRENT_PATCH,
 * voir includes/components/header.php et config/patch.php).
 *
 * @param {string} slug Slug du champion (colonne `slug`, champions).
 * @returns {Promise<number|null>} L'id du build trouvé, ou null.
 */
async function fetchChampionBuildId(slug) {
    const base = window.API_BASE_URL || '/api';

    const params = new URLSearchParams({ champion: slug });
    if (window.CURRENT_PATCH) {
        params.set('patch', window.CURRENT_PATCH);
    }

    let response;
    try {
        response = await fetch(`${base}/builds/?${params.toString()}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération du build.');
    }

    const builds = Array.isArray(payload.data) ? payload.data : [];
    return builds.length > 0 ? builds[0].id : null;
}

/**
 * Récupère le détail complet d'un build par son id (GET
 * /api/builds/?id=, voir api/builds/index.php) : description, objets
 * déjà regroupés par emplacement (voir findBuildItemsGrouped()) et
 * runes (voir findBuildRunes()).
 *
 * @param {number} id Identifiant du build.
 * @returns {Promise<Object>} Le build complet (id, name, champion,
 *                              champion_slug, role, patch, description,
 *                              source, items, runes, skill_order).
 */
async function fetchBuildDetailById(id) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/builds/?id=${encodeURIComponent(id)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération du build.');
    }

    return payload.data;
}

/**
 * Point d'entrée combiné : retrouve le build d'un champion par son
 * slug, puis en récupère le détail complet. Un champion sans aucun
 * build associé résout à `null` (pas une erreur) — voir
 * fetchChampionBuildId().
 *
 * @param {string} slug Slug du champion demandé.
 * @returns {Promise<Object|null>} Le build complet, ou null.
 */
async function fetchChampionBuildDetail(slug) {
    const buildId = await fetchChampionBuildId(slug);
    if (buildId === null) {
        return null;
    }
    return fetchBuildDetailById(buildId);
}

/**
 * Récupère tous les counters depuis l'API (GET /api/counters/, sans
 * filtre — voir docblock d'en-tête pour la raison). Reprend l'enveloppe
 * JSON standard de l'API : en cas de succès, renvoie le tableau de
 * counters ; en cas d'échec (HTTP ou réseau), le rejette avec une
 * erreur dont le message est toujours sûr à afficher tel quel.
 *
 * @returns {Promise<Array>} Tous les counters (id, champion_id,
 *                            counter_champion_id, explanation, tips,
 *                            difficulty, items).
 */
async function fetchAllCounters() {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/counters/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des counters.');
    }

    return Array.isArray(payload.data) ? payload.data : [];
}

/**
 * Construit la vignette HTML d'un objet de build (icône + nom +
 * emplacement, avec numéro d'ordre d'achat quand il existe) — utilisée
 * par les sections Build principal, Bottes et Build situationnel.
 * Un objet sans image_url renseignée retombe sur le même dégradé de
 * secours que .card__media (assets/css/style.css section 7).
 *
 * `options.showDescription` ajoute item.description sous le nom, quand
 * elle existe : réservé à la section Bottes (voir renderBootsSection()),
 * seul endroit où ce texte sert d'explication ("quand les utiliser").
 * `options.showSituation` ajoute item.situation sous le nom, quand elle
 * existe : réservé à la section Build situationnel (voir
 * renderSituationalSection()) — build_items.situation (voir
 * database/schema.sql), même principe que counter_items.situation,
 * facultatif et non renseigné pour le jeu de données actuel, donc pas
 * encore affiché en pratique, mais le système est prêt à l'utiliser dès
 * qu'un build en aura (voir admin/pages/builds.php pour la limite
 * actuelle : pas encore de formulaire d'édition des objets d'un build).
 * Les deux options sont indépendantes et mutuellement exclusives dans
 * l'usage actuel (une section n'active jamais les deux à la fois) ;
 * rien ne les empêche techniquement de l'être.
 *
 * @param {Object} item Un objet du build (id, slug, name, category,
 *                        price, description, image_url, purchase_order,
 *                        situation).
 * @param {string} slot Emplacement de cet objet (voir
 *                        BUILD_ITEM_SLOT_LABELS).
 * @param {Object} [options]
 * @param {boolean} [options.showDescription=false] Affiche
 *                    item.description sous le nom si présente.
 * @param {boolean} [options.showSituation=false] Affiche item.situation
 *                    sous le nom si présente.
 */
function renderBuildItemChip(item, slot, options = {}) {
    const { showDescription = false, showSituation = false } = options;

    const chip = document.createElement('div');
    chip.className = 'build-item-chip';

    const icon = document.createElement('div');
    icon.className = 'build-item-chip__icon';

    if (item.image_url) {
        const image = document.createElement('img');
        image.src = item.image_url;
        image.alt = item.name;
        image.loading = 'lazy';
        image.addEventListener('error', () => image.remove());
        icon.appendChild(image);
    }

    chip.appendChild(icon);

    const info = document.createElement('div');
    info.className = 'build-item-chip__info';

    const name = document.createElement('span');
    name.className = 'build-item-chip__name';
    name.textContent = item.name;
    info.appendChild(name);

    const slotBadge = document.createElement('span');
    const slotBadgeClass = BUILD_ITEM_SLOT_BADGE_CLASSES[slot] || '';
    slotBadge.className = slotBadgeClass ? `badge ${slotBadgeClass}` : 'badge';
    const label = BUILD_ITEM_SLOT_LABELS[slot] || slot;
    slotBadge.textContent = item.purchase_order ? `${label} · Achat n°${item.purchase_order}` : label;
    info.appendChild(slotBadge);

    if (showDescription && item.description) {
        const description = document.createElement('p');
        description.className = 'build-item-chip__description';
        description.textContent = item.description;
        info.appendChild(description);
    }

    if (showSituation && item.situation) {
        const situation = document.createElement('p');
        situation.className = 'build-item-chip__description';
        situation.textContent = item.situation;
        info.appendChild(situation);
    }

    chip.appendChild(info);

    return chip;
}

/**
 * Remplit #build-champion-detail avec la présentation complète du
 * champion (carte .card--featured du design system) : bannière en
 * artwork agrandi, portrait, nom, titre, rôle recommandé/tier/patch
 * (issus de tierEntry, voir fetchChampionTierEntry()), difficulté et
 * courte présentation.
 *
 * `champions` n'a pas de colonne de description dédiée (voir
 * database/schema.sql) : la courte présentation reprend donc la
 * description du build principal du champion (build?.description),
 * quand elle existe — sinon un message neutre plutôt qu'un texte
 * inventé.
 *
 * @param {Object} champion Le champion (voir fetchAllChampions()).
 * @param {Object|null} tierEntry Son entrée de tier list la plus
 *                                 pertinente, ou null.
 * @param {Object|null} build Le build principal du champion (voir
 *                              fetchChampionBuildDetail()), ou null.
 */
function renderBuildChampionDetail(champion, tierEntry, build) {
    const detail = document.getElementById('build-champion-detail');
    detail.innerHTML = '';

    // --- Bannière : artwork agrandi (même image_url que le portrait,
    // assombri) — dégradé de secours de .card__media si le champion
    // n'a pas encore d'image renseignée (colonne nullable, voir
    // api/champions/repository.php).
    const banner = document.createElement('div');
    banner.style.position = 'relative';
    banner.style.aspectRatio = '21 / 7';
    banner.style.overflow = 'hidden';
    banner.style.background = 'linear-gradient(160deg, #1e2636, #0d121b)';

    if (champion.image_url) {
        const bannerImage = document.createElement('img');
        bannerImage.src = champion.image_url;
        bannerImage.alt = '';
        bannerImage.setAttribute('aria-hidden', 'true');
        bannerImage.style.width = '100%';
        bannerImage.style.height = '100%';
        bannerImage.style.objectFit = 'cover';
        bannerImage.style.filter = 'brightness(0.55) saturate(1.15)';
        bannerImage.style.transform = 'scale(1.1)';
        bannerImage.addEventListener('error', () => bannerImage.remove());
        banner.appendChild(bannerImage);
    }

    const bannerOverlay = document.createElement('div');
    bannerOverlay.style.position = 'absolute';
    bannerOverlay.style.inset = '0';
    bannerOverlay.style.background = 'linear-gradient(180deg, rgba(10, 14, 22, 0) 0%, rgba(10, 14, 22, 0.35) 55%, var(--color-plate) 100%)';
    banner.appendChild(bannerOverlay);

    detail.appendChild(banner);

    // --- Corps : portrait qui chevauche la bannière, identité et badges.
    const body = document.createElement('div');
    body.style.position = 'relative';
    body.style.padding = '0 var(--space-6) var(--space-6)';
    body.style.marginTop = '-64px';

    const identity = document.createElement('div');
    identity.style.display = 'flex';
    identity.style.alignItems = 'flex-end';
    identity.style.gap = 'var(--space-4)';

    const portrait = document.createElement('div');
    portrait.style.width = '112px';
    portrait.style.height = '112px';
    portrait.style.flexShrink = '0';
    portrait.style.border = '2px solid var(--color-brass)';
    portrait.style.boxShadow = 'var(--shadow-glow-brass)';
    portrait.style.background = 'linear-gradient(160deg, #1e2636, #0d121b)';
    portrait.style.overflow = 'hidden';

    if (champion.image_url) {
        const portraitImage = document.createElement('img');
        portraitImage.src = champion.image_url;
        portraitImage.alt = champion.name;
        portraitImage.style.width = '100%';
        portraitImage.style.height = '100%';
        portraitImage.style.objectFit = 'cover';
        portraitImage.addEventListener('error', () => portraitImage.remove());
        portrait.appendChild(portraitImage);
    }

    identity.appendChild(portrait);

    const identityText = document.createElement('div');
    identityText.style.minWidth = '0';
    identityText.style.paddingBottom = 'var(--space-1)';

    const eyebrow = document.createElement('p');
    eyebrow.className = 'card__eyebrow';
    eyebrow.style.margin = '0';
    eyebrow.textContent = 'Champion';
    identityText.appendChild(eyebrow);

    // h2, pas h1 : le titre de page "Build" (voir pages/champion-build.php)
    // est déjà le seul h1 de cette page.
    const name = document.createElement('h2');
    name.style.margin = '0';
    name.textContent = champion.name;
    identityText.appendChild(name);

    identity.appendChild(identityText);
    body.appendChild(identity);

    if (champion.title) {
        const subtitle = document.createElement('p');
        subtitle.style.marginTop = 'var(--space-3)';
        subtitle.style.marginBottom = '0';
        subtitle.style.fontStyle = 'italic';
        subtitle.style.color = 'var(--color-mist)';
        subtitle.textContent = champion.title;
        body.appendChild(subtitle);
    }

    // --- Badges : rôle recommandé, tier, patch.
    const badgesRow = document.createElement('div');
    badgesRow.style.display = 'flex';
    badgesRow.style.flexWrap = 'wrap';
    badgesRow.style.gap = 'var(--space-2)';
    badgesRow.style.marginTop = 'var(--space-4)';

    const recommendedRole = tierEntry ? tierEntry.role : champion.role;
    const roleBadge = document.createElement('span');
    const roleBadgeClass = BUILD_CHAMPION_ROLE_BADGE_CLASSES[recommendedRole] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = `Rôle recommandé : ${BUILD_CHAMPION_ROLE_LABELS[recommendedRole] || recommendedRole}`;
    badgesRow.appendChild(roleBadge);

    const tierBadge = document.createElement('span');
    if (tierEntry) {
        const tierBadgeClass = BUILD_CHAMPION_TIER_BADGE_CLASSES[tierEntry.tier] || '';
        tierBadge.className = tierBadgeClass ? `badge ${tierBadgeClass}` : 'badge';
        tierBadge.textContent = `Tier ${tierEntry.tier}`;
    } else {
        tierBadge.className = 'badge';
        tierBadge.textContent = 'Tier non classé';
    }
    badgesRow.appendChild(tierBadge);

    const patchBadge = document.createElement('span');
    patchBadge.className = 'badge';
    patchBadge.textContent = tierEntry ? `Patch ${tierEntry.patch}` : 'Patch —';
    badgesRow.appendChild(patchBadge);

    body.appendChild(badgesRow);

    const difficulty = document.createElement('p');
    difficulty.className = 'text-mono text-muted';
    difficulty.style.fontSize = 'var(--text-xs)';
    difficulty.style.marginTop = 'var(--space-3)';
    difficulty.style.marginBottom = '0';
    difficulty.textContent = `Difficulté : ${champion.difficulty}/5`;
    body.appendChild(difficulty);

    // --- Courte présentation : description du build principal, à
    // défaut de champ dédié sur le champion lui-même (voir docblock).
    const presentation = document.createElement('p');
    presentation.style.marginTop = 'var(--space-4)';
    presentation.style.marginBottom = '0';
    presentation.style.maxWidth = '60ch';
    if (build && build.description) {
        presentation.textContent = build.description;
    } else {
        presentation.className = 'text-muted';
        presentation.textContent = "Aucune présentation n'est encore disponible pour ce champion.";
    }
    body.appendChild(presentation);

    detail.appendChild(body);

    detail.hidden = false;
}

/**
 * Section 2 — Build principal (starting + core, avec ordre d'achat).
 * Affiche #build-main-empty si le champion n'a aucun build (build null
 * ou dépourvu de ces deux emplacements) plutôt qu'une erreur.
 *
 * @param {Object|null} build Voir fetchChampionBuildDetail().
 */
function renderMainBuildSection(build) {
    const groups = document.getElementById('build-main-groups');
    const empty = document.getElementById('build-main-empty');

    const items = build?.items || {};
    const slots = ['starting', 'core'];
    const hasAnyItem = slots.some((slot) => (items[slot] || []).length > 0);

    if (!hasAnyItem) {
        groups.hidden = true;
        empty.hidden = false;
        return;
    }

    empty.hidden = true;

    slots.forEach((slot) => {
        const row = document.getElementById(`build-main-${slot}`);
        row.innerHTML = '';
        (items[slot] || []).forEach((item) => {
            row.appendChild(renderBuildItemChip(item, slot));
        });
    });

    groups.hidden = false;
}

/**
 * Section 4 — Bottes (boots + enchantement).
 * Affiche #build-boots-empty si le champion n'a aucune botte renseignée
 * (l'enchantement seul, sans botte, resterait un cas incomplet : les
 * deux colonnes s'affichent dès qu'au moins l'une des deux a une
 * donnée, chaque colonne vide affichant son propre message).
 *
 * Les deux colonnes affichent item.description sous le nom quand elle
 * existe (voir renderBuildItemChip(), showDescription=true) : c'est le
 * seul texte disponible dans le modèle de données actuel pour expliquer
 * quand utiliser une botte/un enchantement donné (ex. "Bottes
 * défensives : réduction des dégâts d'attaque des champions ennemis.",
 * voir database/schema.sql) ; une botte sans description ne montre
 * simplement pas cette ligne, plutôt qu'une explication inventée.
 *
 * @param {Object|null} build Voir fetchChampionBuildDetail().
 */
function renderBootsSection(build) {
    const groups = document.getElementById('build-boots-groups');
    const empty = document.getElementById('build-boots-empty');

    const items = build?.items || {};
    const boots = items.boots || [];
    const enchantments = items.enchantment || [];

    if (boots.length === 0 && enchantments.length === 0) {
        groups.hidden = true;
        empty.hidden = false;
        return;
    }

    empty.hidden = true;

    const bootsRow = document.getElementById('build-boots-main');
    bootsRow.innerHTML = '';
    if (boots.length > 0) {
        boots.forEach((item) => bootsRow.appendChild(renderBuildItemChip(item, 'boots', { showDescription: true })));
    } else {
        const message = document.createElement('p');
        message.className = 'text-muted';
        message.textContent = 'Aucune botte renseignée pour ce build.';
        bootsRow.appendChild(message);
    }

    const enchantRow = document.getElementById('build-boots-enchantment');
    enchantRow.innerHTML = '';
    if (enchantments.length > 0) {
        enchantments.forEach((item) => enchantRow.appendChild(renderBuildItemChip(item, 'enchantment', { showDescription: true })));
    } else {
        const message = document.createElement('p');
        message.className = 'text-muted';
        message.textContent = 'Aucun enchantement renseigné pour ce build.';
        enchantRow.appendChild(message);
    }

    groups.hidden = false;
}

/**
 * Section 5 — Build situationnel (objets alternatifs).
 * Affiche #build-situational-empty si le champion n'a aucun objet
 * situationnel renseigné.
 *
 * Chaque vignette affiche item.situation sous le nom quand elle existe
 * (voir renderBuildItemChip(), showSituation=true) : build_items.situation
 * (voir database/schema.sql), facultative, précise dans quel contexte
 * prendre cet objet (menace rencontrée, type de composition adverse...)
 * — même principe que counter_items.situation déjà utilisée en section
 * 6 (Counters). Le jeu de données actuel ne renseigne encore ce champ
 * pour aucun objet situationnel : la section reste donc identique à
 * avant en pratique (objets listés sans texte), sans rien inventer ;
 * elle affichera ce texte dès qu'un build en aura un renseigné (par
 * import SQL direct pour l'instant, l'admin ne gérant pas encore les
 * objets d'un build — voir admin/pages/builds.php).
 *
 * @param {Object|null} build Voir fetchChampionBuildDetail().
 */
function renderSituationalSection(build) {
    const card = document.getElementById('build-situational-card');
    const empty = document.getElementById('build-situational-empty');

    const items = build?.items?.situational || [];

    if (items.length === 0) {
        card.hidden = true;
        empty.hidden = false;
        return;
    }

    empty.hidden = true;

    const row = document.getElementById('build-situational-items');
    row.innerHTML = '';
    items.forEach((item) => row.appendChild(renderBuildItemChip(item, 'situational', { showSituation: true })));

    card.hidden = false;
}

/**
 * Construit la vignette HTML d'une rune (icône + nom + arbre, voir
 * RUNE_TREE_LABELS) — même structure que renderBuildItemChip(). L'icône
 * provient de rune.image_url (voir BUILD_RUNE_SELECT_COLUMNS,
 * api/builds/repository.php), alimentée depuis l'admin Runes
 * (admin/pages/runes.php) ; une rune sans image renseignée retombe sur
 * le même dégradé de secours que .build-item-chip__icon.
 *
 * @param {Object} rune Une rune du build (id, slug, name, tree, slot,
 *                        position, image_url).
 */
function renderRuneChip(rune) {
    const chip = document.createElement('div');
    chip.className = 'build-item-chip';

    const icon = document.createElement('div');
    icon.className = 'build-item-chip__icon';

    if (rune.image_url) {
        const image = document.createElement('img');
        image.src = rune.image_url;
        image.alt = rune.name;
        image.loading = 'lazy';
        image.addEventListener('error', () => image.remove());
        icon.appendChild(image);
    }

    chip.appendChild(icon);

    const info = document.createElement('div');
    info.className = 'build-item-chip__info';

    const name = document.createElement('span');
    name.className = 'build-item-chip__name';
    name.textContent = rune.name;
    info.appendChild(name);

    const treeBadge = document.createElement('span');
    treeBadge.className = 'badge';
    treeBadge.textContent = RUNE_TREE_LABELS[rune.tree] || rune.tree;
    info.appendChild(treeBadge);

    chip.appendChild(info);

    return chip;
}

/**
 * Section 3 — Runes (keystone + mineures).
 * Affiche #build-runes-empty si le champion n'a aucune rune renseignée.
 *
 * @param {Object|null} build Voir fetchChampionBuildDetail().
 */
function renderRunesSection(build) {
    const content = document.getElementById('build-runes-content');
    const empty = document.getElementById('build-runes-empty');

    const runes = build?.runes || [];

    if (runes.length === 0) {
        content.hidden = true;
        empty.hidden = false;
        return;
    }

    empty.hidden = true;

    const keystone = runes.find((rune) => rune.slot === 'keystone') || null;
    const minors = runes.filter((rune) => rune.slot !== 'keystone');

    const keystoneRow = document.getElementById('build-runes-keystone');
    keystoneRow.innerHTML = '';
    if (keystone) {
        keystoneRow.appendChild(renderRuneChip(keystone));
    } else {
        const message = document.createElement('p');
        message.className = 'text-muted';
        message.textContent = 'Rune principale non renseignée pour ce build.';
        keystoneRow.appendChild(message);
    }

    const secondaryRow = document.getElementById('build-runes-secondary');
    secondaryRow.innerHTML = '';
    if (minors.length > 0) {
        minors.forEach((rune) => secondaryRow.appendChild(renderRuneChip(rune)));
    } else {
        const message = document.createElement('p');
        message.className = 'text-muted';
        message.textContent = 'Runes secondaires non renseignées pour ce build.';
        secondaryRow.appendChild(message);
    }

    content.hidden = false;
}

/**
 * Construit la carte HTML d'un counter pour ce champion, dans un sens
 * donné (difficile à affronter ou favorable) — voir
 * renderCountersSection(). Reprend la structure de assets/js/
 * counters.js::renderCounterCard(), simplifiée (un seul champion
 * adverse à afficher ici, déjà résolu par l'appelant via championMap,
 * contrairement à la page Counters qui affiche les deux camps du
 * matchup), avec en plus le portrait du champion adverse (opponent.image_url,
 * absent de counters.js::renderCounterCard()) : disposition icône + nom
 * + difficulté/explication, même principe que .build-item-chip
 * (assets/css/style.css) mais en plus grand format pour un portrait de
 * champion (voir .counter-entry__portrait).
 *
 * @param {Object} counter Un counter (voir fetchAllCounters()).
 * @param {Object} opponent Le champion adverse déjà résolu (voir
 *                            championMap, fetchAllChampions()) — id,
 *                            slug, name, image_url, ...
 */
function renderCounterEntry(counter, opponent) {
    const entry = document.createElement('article');
    entry.className = 'card counter-entry';

    const portrait = document.createElement('div');
    portrait.className = 'counter-entry__portrait';
    if (opponent.image_url) {
        const image = document.createElement('img');
        image.src = opponent.image_url;
        image.alt = opponent.name;
        image.loading = 'lazy';
        image.addEventListener('error', () => image.remove());
        portrait.appendChild(image);
    }
    entry.appendChild(portrait);

    const body = document.createElement('div');
    body.className = 'counter-entry__body';

    const title = document.createElement('h4');
    title.style.margin = '0';
    title.textContent = opponent.name;
    body.appendChild(title);

    if (counter.explanation) {
        const explanation = document.createElement('p');
        explanation.style.marginBottom = '0';
        explanation.textContent = counter.explanation;
        body.appendChild(explanation);
    }

    if (counter.difficulty) {
        const foot = document.createElement('div');
        foot.className = 'card__foot';

        const difficultyBadge = document.createElement('span');
        const difficultyBadgeClass = COUNTER_DIFFICULTY_BADGE_CLASSES[counter.difficulty] || '';
        difficultyBadge.className = difficultyBadgeClass ? `badge ${difficultyBadgeClass}` : 'badge';
        difficultyBadge.textContent = counter.difficulty;
        foot.appendChild(difficultyBadge);

        body.appendChild(foot);
    }

    entry.appendChild(body);

    return entry;
}

/**
 * Section 6 — Counters (difficiles à affronter + favorables).
 * `counters` contient tous les counters du site (voir
 * fetchAllCounters()), filtrés ici dans les deux sens pour ce champion
 * précis : champion_id === championId (ce champion est contré, donc
 * "difficile à affronter" du point de vue de l'adversaire qui le
 * contre) et counter_champion_id === championId (ce champion contre
 * l'autre, donc "favorable"). `championMap` résout les noms des
 * champions adverses (voir fetchAllChampions()). Affiche
 * #build-counters-empty si aucun des deux sens n'a de résultat.
 *
 * @param {number} championId Id du champion de cette page.
 * @param {Array} counters Tous les counters (voir fetchAllCounters()).
 * @param {Map<number, Object>} championMap id → champion (voir
 *                                            fetchAllChampions()).
 */
function renderCountersSection(championId, counters, championMap) {
    const content = document.getElementById('build-counters-content');
    const empty = document.getElementById('build-counters-empty');

    const difficult = counters.filter((counter) => counter.champion_id === championId);
    const favorable = counters.filter((counter) => counter.counter_champion_id === championId);

    if (difficult.length === 0 && favorable.length === 0) {
        content.hidden = true;
        empty.hidden = false;
        return;
    }

    empty.hidden = true;

    const difficultRow = document.getElementById('build-counters-difficult');
    difficultRow.innerHTML = '';
    if (difficult.length > 0) {
        difficult.forEach((counter) => {
            const opponent = championMap.get(counter.counter_champion_id)
                || { name: `Champion #${counter.counter_champion_id}`, image_url: null };
            difficultRow.appendChild(renderCounterEntry(counter, opponent));
        });
    } else {
        const message = document.createElement('p');
        message.className = 'text-muted';
        message.textContent = "Aucun champion difficile à affronter n'est encore renseigné pour ce champion.";
        difficultRow.appendChild(message);
    }

    const favorableRow = document.getElementById('build-counters-favorable');
    favorableRow.innerHTML = '';
    if (favorable.length > 0) {
        favorable.forEach((counter) => {
            const opponent = championMap.get(counter.champion_id)
                || { name: `Champion #${counter.champion_id}`, image_url: null };
            favorableRow.appendChild(renderCounterEntry(counter, opponent));
        });
    } else {
        const message = document.createElement('p');
        message.className = 'text-muted';
        message.textContent = "Aucun champion favorable n'est encore renseigné pour ce champion.";
        favorableRow.appendChild(message);
    }

    content.hidden = false;
}

/**
 * Point d'entrée : lit le slug demandé, puis orchestre les six
 * sections — chacune bascule indépendamment entre ses trois états
 * (chargement → contenu/vide, ou erreur), pour qu'un échec sur l'une
 * n'empêche pas l'affichage des autres :
 *
 *   - Section 1 (En-tête) : champion (par slug, voir
 *     fetchAllChampions()) + tier list (échec silencieux, tier/patch
 *     complémentaires) + description du build (voir renderBuildChampionDetail()).
 *   - Sections 2/3/4/5 (Build principal/Runes/Bottes/Build situationnel) :
 *     un seul détail de build chargé (voir fetchChampionBuildDetail()),
 *     réutilisé par les quatre.
 *   - Section 6 (Counters) : id du champion + tous les counters (voir
 *     fetchAllCounters()), filtrés dans les deux sens.
 *
 * Un slug invalide dès le départ échoue toutes les sections d'un coup
 * (rien n'est cohérent à afficher sans champion valide).
 */
document.addEventListener('DOMContentLoaded', () => {
    const sections = [
        { loading: 'build-champion-loading', error: 'build-champion-error' },
        { loading: 'build-main-loading', error: 'build-main-error' },
        { loading: 'build-runes-loading', error: 'build-runes-error' },
        { loading: 'build-boots-loading', error: 'build-boots-error' },
        { loading: 'build-situational-loading', error: 'build-situational-error' },
        { loading: 'build-counters-loading', error: 'build-counters-error' },
    ];

    let slug;
    try {
        slug = getRequestedChampionSlug();
    } catch (err) {
        sections.forEach(({ loading, error }) => {
            document.getElementById(loading).hidden = true;
            const errorEl = document.getElementById(error);
            errorEl.textContent = err.message;
            errorEl.hidden = false;
        });
        return;
    }

    // Un seul appel à /api/champions/, réutilisé pour trouver le
    // champion demandé (En-tête) et pour résoudre les noms de
    // champions adverses (Counters) — voir docblock d'en-tête.
    const championsPromise = fetchAllChampions();

    const championPromise = championsPromise.then((champions) => {
        const champion = champions.find((item) => item.slug === slug) || null;
        if (!champion) {
            throw new Error('Aucun champion ne correspond à cette page.');
        }
        return champion;
    });

    // Un seul détail de build, réutilisé par les sections 2/3/4/5.
    const buildPromise = fetchChampionBuildDetail(slug);

    // --- Section 1 : En-tête -------------------------------------------
    const headerLoading = document.getElementById('build-champion-loading');
    const headerError = document.getElementById('build-champion-error');

    Promise.all([championPromise, buildPromise])
        .then(([champion, build]) => fetchChampionTierEntry(champion.slug)
            .catch(() => null)
            .then((tierEntry) => renderBuildChampionDetail(champion, tierEntry, build)))
        .catch((err) => {
            headerError.textContent = err.message;
            headerError.hidden = false;
        })
        .finally(() => {
            headerLoading.hidden = true;
        });

    // --- Sections 2/3/4/5 : Build principal, Runes, Bottes, Situationnel
    const mainLoading = document.getElementById('build-main-loading');
    const mainError = document.getElementById('build-main-error');
    const runesLoading = document.getElementById('build-runes-loading');
    const runesError = document.getElementById('build-runes-error');
    const bootsLoading = document.getElementById('build-boots-loading');
    const bootsError = document.getElementById('build-boots-error');
    const situationalLoading = document.getElementById('build-situational-loading');
    const situationalError = document.getElementById('build-situational-error');

    buildPromise
        .then((build) => {
            renderMainBuildSection(build);
            renderRunesSection(build);
            renderBootsSection(build);
            renderSituationalSection(build);
        })
        .catch((err) => {
            [
                [mainError, mainLoading],
                [runesError, runesLoading],
                [bootsError, bootsLoading],
                [situationalError, situationalLoading],
            ].forEach(([errorEl]) => {
                errorEl.textContent = err.message;
                errorEl.hidden = false;
            });
        })
        .finally(() => {
            mainLoading.hidden = true;
            runesLoading.hidden = true;
            bootsLoading.hidden = true;
            situationalLoading.hidden = true;
        });

    // --- Section 6 : Counters -------------------------------------------
    const countersLoading = document.getElementById('build-counters-loading');
    const countersError = document.getElementById('build-counters-error');

    Promise.all([championPromise, championsPromise, fetchAllCounters()])
        .then(([champion, champions, counters]) => {
            const championMap = new Map(champions.map((item) => [item.id, item]));
            renderCountersSection(champion.id, counters, championMap);
        })
        .catch((err) => {
            countersError.textContent = err.message;
            countersError.hidden = false;
        })
        .finally(() => {
            countersLoading.hidden = true;
        });
});
