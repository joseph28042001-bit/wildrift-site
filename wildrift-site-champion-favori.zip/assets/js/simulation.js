/**
 * Wild Rift Platform — Page Simulation 5v5.
 * Connecte la page pages/simulation.php à l'API existante
 * (GET /api/champions/, voir api/champions/index.php et
 * api/champions/repository.php :: findChampions()) : récupère la liste
 * complète des champions au chargement de la page et peuple les 10
 * emplacements de sélection (5 par équipe, voir
 * [data-simulation-champion-select] et renderSimulationTeamSlots(),
 * pages/simulation.php).
 *
 * Étape actuelle : uniquement la sélection d'un champion par
 * emplacement, avec des filtres (recherche par nom + rôle, combinables)
 * qui affinent en direct les champions proposés dans les 10
 * emplacements, l'empêchement de choisir un même champion dans
 * plusieurs emplacements (voir updateSimulationChampionAvailability()),
 * et le verrouillage d'un champion sélectionné (voir
 * data-simulation-lock-toggle) qui fige l'emplacement contre les
 * filtres et les changements accidentels, ainsi que le calcul des
 * synergies entre les champions sélectionnés au sein de chaque équipe
 * (voir computeSimulationTeamSynergies(), basé sur l'API existante
 * GET /api/synergies/?champion_id=), ainsi que le calcul des counters
 * entre les champions des deux équipes (voir
 * computeSimulationCounters(), basé sur l'API existante
 * GET /api/counters/?champion_id=), ainsi que l'analyse de la
 * composition de chaque équipe (voir computeSimulationTeamAnalysis() —
 * complétude, rôles manquants, difficulté moyenne — entièrement
 * calculée côté client, sans appel réseau supplémentaire), ainsi que
 * l'analyse de sa frontline (voir computeSimulationTeamFrontline() —
 * couverture des rôles Voie Baron et Jungle, également calculée côté
 * client), ainsi que l'analyse de son contrôle de foule (voir
 * computeSimulationTeamCrowdControl() — niveau de CC de chaque champion
 * sélectionné, via la colonne cc_level désormais exposée par
 * GET /api/champions/, et score d'équipe pondéré, également calculée
 * côté client), ainsi que l'analyse de son engage et de son disengage
 * (voir computeSimulationTeamEngageStat(), factorisée pour les deux —
 * niveau de chaque champion sélectionné via les colonnes engage_level
 * et disengage_level, désormais exposées par GET /api/champions/, et
 * score d'équipe pondéré, également calculée côté client), ainsi que
 * l'analyse Early Game / Late Game de chaque équipe (même fonction
 * computeSimulationTeamEngageStat() réutilisée avec les colonnes
 * early_game_level et late_game_level, désormais exposées par
 * GET /api/champions/), ainsi que le score global de chaque équipe
 * (voir computeSimulationTeamGlobalScore() — combine les scores déjà
 * calculés par les analyses ci-dessus, CC + engage + disengage + early
 * game + late game, en un seul total avec le détail par métrique),
 * ainsi que des recommandations de champions par équipe (voir
 * computeSimulationTeamRecommendations() — pour chaque rôle encore
 * vacant, jusqu'à 2 champions disponibles de ce rôle, en priorité ceux
 * qui renforcent la métrique la plus faible de l'équipe, entièrement
 * calculé côté client), ainsi que l'analyse finale une fois les 10
 * emplacements pourvus (voir computeSimulationFinalAnalysis() —
 * verdict global et détail par métrique entre les deux équipes,
 * reste sur un message d'attente tant que la composition n'est pas
 * complète). Aucune autre logique n'est câblée ici — pas de bouton
 * "Lancer la simulation" (absent de la page à ce stade), pas de calcul
 * de résultat de partie.
 *
 * Ce fichier n'est chargé que sur la page Simulation (voir
 * simulation.php) — contrairement à assets/js/news.js, chargé
 * globalement, il n'y a pas lieu d'exécuter ce code sur les autres
 * pages, qui n'ont pas les éléments [data-simulation-champion-select]
 * attendus ci-dessous.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

/**
 * Rôles Wild Rift, dans l'ordre des emplacements — mêmes clés que
 * $simulationRoles (pages/simulation.php) et l'énumération
 * getChampionRoles() côté API, utilisées ici pour retrouver les 5
 * <select> d'une équipe par leur ID (simulation-{team}-{role}).
 */
const SIMULATION_ROLES = ['baron', 'jungle', 'mid', 'dragon', 'support'];

/**
 * Libellés français des rôles, pour l'analyse de composition
 * ci-dessous (rôles manquants) — mêmes libellés que $simulationRoles
 * (pages/simulation.php).
 */
const SIMULATION_ROLE_LABELS = {
    baron: 'Voie Baron',
    jungle: 'Jungle',
    mid: 'Voie du Milieu',
    dragon: 'Voie Dragon',
    support: 'Support',
};

/**
 * Rôles traditionnellement frontline en Wild Rift (Voie Baron et
 * Jungle, généralement tenus par des tanks/bruisers qui engagent et
 * absorbent les dégâts en combat), utilisés pour l'analyse de frontline
 * ci-dessous. Pas de notion de classe (tank, mage, tireur...) dans les
 * données champions exposées par l'API (voir
 * api/champions/repository.php) : cette analyse s'appuie donc
 * uniquement sur le rôle/voie, comme le reste de cette page.
 */
const SIMULATION_FRONTLINE_ROLES = ['baron', 'jungle'];

/**
 * Libellés français des niveaux de CC (colonne cc_level, voir
 * getChampionCcLevels() côté API — api/champions/repository.php), pour
 * l'analyse de contrôle de foule ci-dessous.
 */
const SIMULATION_CC_LEVEL_LABELS = {
    faible: 'Faible',
    moyen: 'Moyen',
    fort: 'Fort',
};

/** Poids numérique de chaque niveau de CC, pour calculer un score d'équipe. */
const SIMULATION_CC_LEVEL_WEIGHTS = {
    faible: 1,
    moyen: 2,
    fort: 3,
};

/**
 * Libellés français des niveaux d'engage/disengage (colonnes
 * engage_level et disengage_level, voir getChampionEngageLevels() côté
 * API), pour l'analyse engage/disengage ci-dessous.
 */
const SIMULATION_ENGAGE_LEVEL_LABELS = {
    faible: 'Faible',
    moyen: 'Moyen',
    fort: 'Fort',
};

/** Poids numérique de chaque niveau d'engage/disengage, pour un score d'équipe. */
const SIMULATION_ENGAGE_LEVEL_WEIGHTS = {
    faible: 1,
    moyen: 2,
    fort: 3,
};

/**
 * Colonnes champion faible/moyen/fort combinées pour le score global
 * d'équipe (voir computeSimulationTeamGlobalScore() plus bas) — mêmes
 * colonnes que les analyses dédiées déjà présentes sur la page (CC,
 * engage, disengage, early game, late game), avec un libellé court pour
 * le détail affiché.
 */
const SIMULATION_GLOBAL_SCORE_FIELDS = [
    { field: 'cc_level', label: 'Contrôle de foule' },
    { field: 'engage_level', label: 'Engage' },
    { field: 'disengage_level', label: 'Disengage' },
    { field: 'early_game_level', label: 'Early game' },
    { field: 'late_game_level', label: 'Late game' },
];

/**
 * Récupère la liste complète des champions depuis l'API
 * (GET /api/champions/, sans filtre). Reprend l'enveloppe JSON standard
 * de l'API ({ success, data, meta }) — voir api/core/response.php : en
 * cas de succès, renvoie le tableau de champions (data) ; en cas
 * d'échec (HTTP ou réseau), le rejette avec une erreur dont le message
 * est toujours sûr à afficher tel quel.
 *
 * @returns {Promise<Array>} Champions (id, slug, name, title, role,
 *                            difficulty, image_url, dates).
 */
async function fetchSimulationChampions() {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/champions/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des champions.');
    }

    return payload.data;
}

/**
 * Peuple un <select> d'emplacement avec la liste des champions (une
 * <option> par champion, valeur = slug, libellé = nom affiché), en plus
 * de l'option par défaut "Choisir un champion" déjà présente dans le
 * balisage (pages/simulation.php) — jamais supprimée ni dupliquée ici.
 * Triée par nom, pour une liste facile à parcourir.
 *
 * @param {HTMLSelectElement} select
 * @param {Array} champions Voir fetchSimulationChampions().
 */
function populateSimulationChampionSelect(select, champions) {
    const sorted = [...champions].sort((a, b) => a.name.localeCompare(b.name, 'fr'));

    sorted.forEach((champion) => {
        const option = document.createElement('option');
        option.value = champion.slug;
        option.textContent = champion.name;
        select.appendChild(option);
    });
}

/**
 * Filtre une liste de champions par nom (recherche insensible à la
 * casse, sous-chaîne) et/ou par rôle, combinables. Terme et rôle vides
 * ou absents : renvoie la liste inchangée. Usage interne à ce fichier,
 * pour les filtres ci-dessous.
 *
 * @param {Array} champions Voir fetchSimulationChampions().
 * @param {string} term
 * @param {string} role
 * @returns {Array}
 */
function filterSimulationChampions(champions, term, role) {
    let filtered = champions;

    if (term) {
        const lower = term.toLowerCase();
        filtered = filtered.filter((champion) => champion.name.toLowerCase().includes(lower));
    }

    if (role) {
        filtered = filtered.filter((champion) => champion.role === role);
    }

    return filtered;
}

/**
 * Désactive, dans chaque emplacement, les options des champions déjà
 * choisis dans un AUTRE emplacement (10 emplacements au total, Blue et
 * Red Team confondues) — un même champion ne peut donc plus être
 * sélectionné deux fois. L'option actuellement choisie dans un
 * emplacement reste toujours activée dans CET emplacement (sinon
 * l'utilisateur ne pourrait plus la voir sélectionnée). L'option par
 * défaut ("Choisir un champion", valeur vide) n'est jamais concernée.
 * À appeler après tout peuplement ou reconstruction des options
 * (peuplement initial, filtres) ainsi qu'à chaque changement de
 * sélection.
 *
 * @param {NodeListOf<HTMLSelectElement>} selects
 */
function updateSimulationChampionAvailability(selects) {
    const chosen = new Set(
        Array.from(selects)
            .map((select) => select.value)
            .filter((value) => value !== '')
    );

    selects.forEach((select) => {
        Array.from(select.options).forEach((option) => {
            if (option.value === '') {
                return;
            }

            option.disabled = chosen.has(option.value) && option.value !== select.value;
        });
    });
}

/**
 * Renvoie le bouton de verrouillage associé à un <select> d'emplacement
 * (voir data-simulation-lock-toggle et data-target, pages/simulation.php),
 * ou null s'il n'existe pas.
 *
 * @param {HTMLSelectElement} select
 * @returns {HTMLButtonElement|null}
 */
function getSimulationLockButton(select) {
    return document.getElementById(`${select.id}-lock`);
}

/**
 * Synchronise l'état activé/désactivé du bouton de verrouillage d'un
 * emplacement avec son <select> : verrouillable uniquement si un
 * champion y est actuellement choisi. Usage interne à ce fichier.
 *
 * @param {HTMLSelectElement} select
 */
function syncSimulationLockButton(select) {
    const lockButton = getSimulationLockButton(select);

    if (lockButton && !select.disabled) {
        lockButton.disabled = select.value === '';
    }
}

/**
 * Récupère les synergies d'un champion depuis l'API
 * (GET /api/synergies/?champion_id=, voir api/synergies/index.php et
 * api/synergies/repository.php :: findSynergies()) — même endpoint que
 * assets/js/champion.js :: fetchChampionSynergies(), redéfini ici pour
 * la même raison que les autres fonctions de ce fichier (chargé
 * séparément de champion.js). Reprend l'enveloppe JSON standard de
 * l'API ({ success, data, meta }) — voir api/core/response.php : en cas
 * de succès, renvoie le tableau de synergies (data, potentiellement
 * vide) ; en cas d'échec (HTTP ou réseau), le rejette avec une erreur
 * dont le message est toujours sûr à afficher tel quel.
 *
 * @param {number} championId
 * @returns {Promise<Array>} Synergies (id, champion_id,
 *                            synergy_champion_id, explanation).
 */
async function fetchSimulationChampionSynergies(championId) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/synergies/?champion_id=${encodeURIComponent(championId)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des synergies.');
    }

    return payload.data;
}

/**
 * Retrouve le nom affiché d'un champion par son ID dans la liste
 * complète des champions (voir fetchSimulationChampions()). Renvoie un
 * repli lisible ("Champion #<id>") si l'ID est introuvable, plutôt que
 * de faire échouer l'affichage — ne devrait normalement pas arriver
 * puisque les IDs viennent de cette même liste.
 *
 * @param {Array} allChampions
 * @param {number} id
 * @returns {string}
 */
function getSimulationChampionName(allChampions, id) {
    const champion = allChampions.find((c) => c.id === id);
    return champion ? champion.name : `Champion #${id}`;
}

/**
 * Calcule et affiche les synergies entre les champions actuellement
 * sélectionnés dans une équipe (ses 5 emplacements, un par rôle) : pour
 * chaque paire de champions choisis, récupère (avec mise en cache
 * partagée entre les deux équipes, voir synergyCache) les synergies
 * connues de chacun, puis affiche chaque relation trouvée dans
 * #simulation-{teamSlug}-synergies. La relation champion → partenaire
 * n'est pas symétrique en base (voir database/schema.sql) : une paire
 * peut donc apparaître une ou deux fois (une fois par sens connu), avec
 * une explication propre à chaque sens.
 *
 * Nécessite moins de deux champions sélectionnés pour afficher un
 * message d'invite plutôt qu'un résultat vide, et n'affiche "aucune
 * synergie connue" que si des paires existent mais qu'aucune synergie
 * ne les relie.
 *
 * @param {string} teamSlug 'blue' ou 'red'.
 * @param {Array} allChampions Voir fetchSimulationChampions().
 * @param {Map<number, Array>} synergyCache championId → ses synergies,
 *                                           rempli au fur et à mesure
 *                                           pour éviter de refaire un
 *                                           appel réseau déjà fait.
 */
async function computeSimulationTeamSynergies(teamSlug, allChampions, synergyCache) {
    const container = document.getElementById(`simulation-${teamSlug}-synergies`);

    if (!container) {
        return;
    }

    const renderMessage = (message) => {
        container.innerHTML = '';
        const empty = document.createElement('p');
        empty.className = 'text-muted';
        empty.setAttribute('data-simulation-synergies-empty', '');
        empty.textContent = message;
        container.appendChild(empty);
    };

    // Champions actuellement sélectionnés dans cette équipe (slug résolu en ID).
    const selectedIds = [];
    SIMULATION_ROLES.forEach((role) => {
        const select = document.getElementById(`simulation-${teamSlug}-${role}`);
        if (!select || !select.value) {
            return;
        }

        const champion = allChampions.find((c) => c.slug === select.value);
        if (champion) {
            selectedIds.push(champion.id);
        }
    });

    if (selectedIds.length < 2) {
        renderMessage('Sélectionnez au moins deux champions pour voir leurs synergies.');
        return;
    }

    await Promise.all(
        selectedIds
            .filter((id) => !synergyCache.has(id))
            .map((id) => fetchSimulationChampionSynergies(id)
                .then((synergies) => {
                    synergyCache.set(id, synergies);
                })
                .catch(() => {
                    // Un échec ponctuel ne doit pas bloquer l'affichage des
                    // autres paires : ce champion est simplement considéré
                    // sans synergie connue.
                    synergyCache.set(id, []);
                }))
    );

    const pairs = [];
    for (let i = 0; i < selectedIds.length; i += 1) {
        for (let j = i + 1; j < selectedIds.length; j += 1) {
            const idA = selectedIds[i];
            const idB = selectedIds[j];

            const fromA = (synergyCache.get(idA) || []).find((s) => s.synergy_champion_id === idB);
            const fromB = (synergyCache.get(idB) || []).find((s) => s.synergy_champion_id === idA);

            if (fromA) {
                pairs.push({ from: idA, to: idB, explanation: fromA.explanation });
            }
            if (fromB) {
                pairs.push({ from: idB, to: idA, explanation: fromB.explanation });
            }
        }
    }

    if (pairs.length === 0) {
        renderMessage('Aucune synergie connue entre les champions sélectionnés.');
        return;
    }

    container.innerHTML = '';

    pairs.forEach((pair) => {
        const card = document.createElement('div');
        card.className = 'card';

        const title = document.createElement('h4');
        title.className = 'card__title';
        title.textContent = `${getSimulationChampionName(allChampions, pair.from)} + ${getSimulationChampionName(allChampions, pair.to)}`;
        card.appendChild(title);

        if (pair.explanation) {
            const explanation = document.createElement('p');
            explanation.className = 'text-muted';
            explanation.textContent = pair.explanation;
            card.appendChild(explanation);
        }

        container.appendChild(card);
    });
}

/**
 * Récupère les counters d'un champion depuis l'API
 * (GET /api/counters/?champion_id=, voir api/counters/index.php et
 * api/counters/repository.php :: findCounters()) — même principe que
 * fetchSimulationChampionSynergies() ci-dessus. Reprend l'enveloppe
 * JSON standard de l'API ({ success, data, meta }) — voir
 * api/core/response.php : en cas de succès, renvoie le tableau de
 * counters (data, potentiellement vide) ; en cas d'échec (HTTP ou
 * réseau), le rejette avec une erreur dont le message est toujours sûr
 * à afficher tel quel. Chaque entrée décrit, du point de vue du
 * champion contré (champion_id), un champion qui le contre
 * (counter_champion_id) ; difficulté et objets recommandés (voir
 * l'API) sont ignorés ici, seule l'explication est affichée.
 *
 * @param {number} championId
 * @returns {Promise<Array>} Counters (id, champion_id,
 *                            counter_champion_id, explanation,
 *                            difficulty, counter_items).
 */
async function fetchSimulationChampionCounters(championId) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/counters/?champion_id=${encodeURIComponent(championId)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des counters.');
    }

    return payload.data;
}

/**
 * Calcule et affiche les counters entre les champions actuellement
 * sélectionnés dans les deux équipes : pour chaque champion Blue Team
 * et chaque champion Red Team, récupère (avec mise en cache) leurs
 * counters connus et affiche chaque relation trouvée dans l'un ou
 * l'autre sens ("le champion X de l'équipe adverse contre le champion Y
 * de cette équipe") dans #simulation-counters. Contrairement aux
 * synergies (calculées au sein d'une même équipe), les counters sont
 * calculés uniquement entre les deux équipes : deux champions de la
 * même équipe ne s'affrontent jamais en jeu, donc jamais comparés ici.
 *
 * Nécessite au moins un champion sélectionné dans chaque équipe pour
 * afficher un message d'invite plutôt qu'un résultat vide, et n'affiche
 * "aucun counter connu" que si des paires existent mais qu'aucun
 * counter ne les relie.
 *
 * @param {Array} allChampions Voir fetchSimulationChampions().
 * @param {Map<number, Array>} counterCache championId → ses counters,
 *                                           rempli au fur et à mesure.
 */
async function computeSimulationCounters(allChampions, counterCache) {
    const container = document.getElementById('simulation-counters');

    if (!container) {
        return;
    }

    const renderMessage = (message) => {
        container.innerHTML = '';
        const empty = document.createElement('p');
        empty.className = 'text-muted';
        empty.setAttribute('data-simulation-counters-empty', '');
        empty.textContent = message;
        container.appendChild(empty);
    };

    const getTeamSelectedIds = (teamSlug) => {
        const ids = [];
        SIMULATION_ROLES.forEach((role) => {
            const select = document.getElementById(`simulation-${teamSlug}-${role}`);
            if (!select || !select.value) {
                return;
            }

            const champion = allChampions.find((c) => c.slug === select.value);
            if (champion) {
                ids.push(champion.id);
            }
        });
        return ids;
    };

    const blueIds = getTeamSelectedIds('blue');
    const redIds = getTeamSelectedIds('red');

    if (blueIds.length === 0 || redIds.length === 0) {
        renderMessage('Sélectionnez au moins un champion dans chaque équipe pour voir les counters.');
        return;
    }

    const allSelectedIds = [...blueIds, ...redIds];

    await Promise.all(
        allSelectedIds
            .filter((id) => !counterCache.has(id))
            .map((id) => fetchSimulationChampionCounters(id)
                .then((counters) => {
                    counterCache.set(id, counters);
                })
                .catch(() => {
                    // Un échec ponctuel ne doit pas bloquer l'affichage des
                    // autres paires : ce champion est simplement considéré
                    // sans counter connu.
                    counterCache.set(id, []);
                }))
    );

    const pairs = [];
    blueIds.forEach((blueId) => {
        redIds.forEach((redId) => {
            // Un champion Red qui contre ce champion Blue (point de vue
            // du champion contré = blueId).
            const redCountersBlue = (counterCache.get(blueId) || []).find((c) => c.counter_champion_id === redId);
            // Un champion Blue qui contre ce champion Red (point de vue
            // du champion contré = redId).
            const blueCountersRed = (counterCache.get(redId) || []).find((c) => c.counter_champion_id === blueId);

            if (redCountersBlue) {
                pairs.push({ counterer: redId, countered: blueId, explanation: redCountersBlue.explanation });
            }
            if (blueCountersRed) {
                pairs.push({ counterer: blueId, countered: redId, explanation: blueCountersRed.explanation });
            }
        });
    });

    if (pairs.length === 0) {
        renderMessage('Aucun counter connu entre les champions sélectionnés.');
        return;
    }

    container.innerHTML = '';

    pairs.forEach((pair) => {
        const card = document.createElement('div');
        card.className = 'card';

        const title = document.createElement('h4');
        title.className = 'card__title';
        title.textContent = `${getSimulationChampionName(allChampions, pair.counterer)} contre ${getSimulationChampionName(allChampions, pair.countered)}`;
        card.appendChild(title);

        if (pair.explanation) {
            const explanation = document.createElement('p');
            explanation.className = 'text-muted';
            explanation.textContent = pair.explanation;
            card.appendChild(explanation);
        }

        container.appendChild(card);
    });
}

/**
 * Calcule et affiche l'analyse de composition d'une équipe : nombre de
 * champions actuellement sélectionnés sur les 5 emplacements, rôles
 * encore sans champion (le cas échéant), et difficulté moyenne des
 * champions déjà choisis (échelle `difficulty` de l'API champions, 1 à
 * 5 — voir api/champions/repository.php). Entièrement calculé côté
 * client à partir des champions déjà chargés (allChampions) et de
 * l'état courant des 5 <select> de l'équipe : aucun appel réseau
 * supplémentaire, contrairement aux synergies et aux counters
 * ci-dessus.
 *
 * @param {string} teamSlug 'blue' ou 'red'.
 * @param {Array} allChampions Voir fetchSimulationChampions().
 */
function computeSimulationTeamAnalysis(teamSlug, allChampions) {
    const container = document.getElementById(`simulation-${teamSlug}-analysis`);

    if (!container) {
        return;
    }

    const missingRoles = [];
    const selectedChampions = [];

    SIMULATION_ROLES.forEach((role) => {
        const select = document.getElementById(`simulation-${teamSlug}-${role}`);

        if (!select || !select.value) {
            missingRoles.push(SIMULATION_ROLE_LABELS[role] || role);
            return;
        }

        const champion = allChampions.find((c) => c.slug === select.value);
        if (champion) {
            selectedChampions.push(champion);
        }
    });

    container.innerHTML = '';

    const completion = document.createElement('p');
    completion.textContent = `Composition : ${selectedChampions.length}/5 champions sélectionnés`;
    container.appendChild(completion);

    if (missingRoles.length > 0) {
        const missing = document.createElement('p');
        missing.className = 'text-muted';
        missing.textContent = `Rôles restants : ${missingRoles.join(', ')}`;
        container.appendChild(missing);
    }

    if (selectedChampions.length > 0) {
        const averageDifficulty = selectedChampions.reduce((sum, c) => sum + c.difficulty, 0) / selectedChampions.length;

        const difficulty = document.createElement('p');
        difficulty.className = 'text-muted';
        difficulty.textContent = `Difficulté moyenne : ${averageDifficulty.toFixed(1)} / 5`;
        container.appendChild(difficulty);
    }
}

/**
 * Calcule et affiche l'analyse de frontline d'une équipe : couverture
 * des rôles traditionnellement frontline (voir
 * SIMULATION_FRONTLINE_ROLES), avec le champion qui occupe chaque rôle
 * s'il est déjà sélectionné. Entièrement calculé côté client à partir
 * des champions déjà chargés (allChampions) et de l'état courant des
 * <select> concernés — aucun appel réseau supplémentaire, même principe
 * que computeSimulationTeamAnalysis() ci-dessus.
 *
 * @param {string} teamSlug 'blue' ou 'red'.
 * @param {Array} allChampions Voir fetchSimulationChampions().
 */
function computeSimulationTeamFrontline(teamSlug, allChampions) {
    const container = document.getElementById(`simulation-${teamSlug}-frontline`);

    if (!container) {
        return;
    }

    let covered = 0;
    container.innerHTML = '';

    SIMULATION_FRONTLINE_ROLES.forEach((role) => {
        const select = document.getElementById(`simulation-${teamSlug}-${role}`);
        const champion = select && select.value
            ? allChampions.find((c) => c.slug === select.value)
            : null;

        if (champion) {
            covered += 1;
        }

        const line = document.createElement('p');
        line.className = 'text-muted';
        line.textContent = `${SIMULATION_ROLE_LABELS[role] || role} : ${champion ? champion.name : 'non pourvu'}`;
        container.appendChild(line);
    });

    const summary = document.createElement('p');
    summary.textContent = `Frontline : ${covered}/${SIMULATION_FRONTLINE_ROLES.length} rôles couverts`;
    container.insertBefore(summary, container.firstChild);
}

/**
 * Calcule et affiche l'analyse du contrôle de foule (CC) d'une équipe :
 * niveau de CC (colonne cc_level, voir getChampionCcLevels() côté API)
 * de chaque champion déjà sélectionné, puis un score d'équipe (somme des
 * poids SIMULATION_CC_LEVEL_WEIGHTS) et une répartition faible/moyen/fort.
 * Entièrement calculé côté client à partir des champions déjà chargés
 * (allChampions), même principe que computeSimulationTeamFrontline()
 * ci-dessus — aucun appel réseau supplémentaire.
 *
 * @param {string} teamSlug 'blue' ou 'red'.
 * @param {Array} allChampions Voir fetchSimulationChampions().
 */
function computeSimulationTeamCrowdControl(teamSlug, allChampions) {
    const container = document.getElementById(`simulation-${teamSlug}-cc`);

    if (!container) {
        return;
    }

    const selectedChampions = SIMULATION_ROLES
        .map((role) => {
            const select = document.getElementById(`simulation-${teamSlug}-${role}`);
            return select && select.value
                ? allChampions.find((c) => c.slug === select.value)
                : null;
        })
        .filter((champion) => champion !== null);

    container.innerHTML = '';

    if (selectedChampions.length === 0) {
        const empty = document.createElement('p');
        empty.className = 'text-muted';
        empty.textContent = 'Sélectionnez au moins un champion pour voir le contrôle de foule.';
        container.appendChild(empty);
        return;
    }

    const counts = { faible: 0, moyen: 0, fort: 0 };
    let score = 0;

    selectedChampions.forEach((champion) => {
        const level = champion.cc_level in counts ? champion.cc_level : 'faible';
        counts[level] += 1;
        score += SIMULATION_CC_LEVEL_WEIGHTS[level] || 0;
    });

    const summary = document.createElement('p');
    summary.textContent = `Score CC : ${score} (sur ${selectedChampions.length * SIMULATION_CC_LEVEL_WEIGHTS.fort} max)`;
    container.appendChild(summary);

    const repartition = document.createElement('p');
    repartition.className = 'text-muted';
    repartition.textContent = `Répartition : ${counts.fort} fort, ${counts.moyen} moyen, ${counts.faible} faible`;
    container.appendChild(repartition);

    selectedChampions.forEach((champion) => {
        const level = champion.cc_level in counts ? champion.cc_level : 'faible';
        const line = document.createElement('p');
        line.className = 'text-muted';
        line.textContent = `${champion.name} : ${SIMULATION_CC_LEVEL_LABELS[level] || level}`;
        container.appendChild(line);
    });
}

/**
 * Calcule et affiche l'analyse d'un niveau faible/moyen/fort d'une
 * équipe, pour n'importe quelle colonne champion à cette échelle :
 * engage_level, disengage_level, early_game_level, late_game_level...
 * (selon $field/$containerSuffix/$scoreLabel) — niveau de chaque
 * champion déjà sélectionné, puis un score d'équipe (somme des poids
 * SIMULATION_ENGAGE_LEVEL_WEIGHTS) et une répartition faible/moyen/fort.
 * Nommée d'après son premier usage (engage/disengage) mais réutilisée
 * telle quelle pour Early Game / Late Game : la mécanique de calcul et
 * d'affichage est strictement identique, seule la colonne champion lue
 * et le conteneur ciblé changent. Entièrement calculé côté client, même
 * principe que computeSimulationTeamCrowdControl() ci-dessus — aucun
 * appel réseau supplémentaire.
 *
 * @param {string} teamSlug 'blue' ou 'red'.
 * @param {Array} allChampions Voir fetchSimulationChampions().
 * @param {string} field 'engage_level' ou 'disengage_level'.
 * @param {string} containerSuffix 'engage' ou 'disengage' (suffixe de
 *                                 l'ID du conteneur, ex. simulation-blue-engage).
 * @param {string} scoreLabel Libellé du score affiché (ex. "Score engage").
 */
function computeSimulationTeamEngageStat(teamSlug, allChampions, field, containerSuffix, scoreLabel) {
    const container = document.getElementById(`simulation-${teamSlug}-${containerSuffix}`);

    if (!container) {
        return;
    }

    const selectedChampions = SIMULATION_ROLES
        .map((role) => {
            const select = document.getElementById(`simulation-${teamSlug}-${role}`);
            return select && select.value
                ? allChampions.find((c) => c.slug === select.value)
                : null;
        })
        .filter((champion) => champion !== null);

    container.innerHTML = '';

    if (selectedChampions.length === 0) {
        const empty = document.createElement('p');
        empty.className = 'text-muted';
        empty.textContent = 'Sélectionnez au moins un champion pour voir cette analyse.';
        container.appendChild(empty);
        return;
    }

    const counts = { faible: 0, moyen: 0, fort: 0 };
    let score = 0;

    selectedChampions.forEach((champion) => {
        const level = champion[field] in counts ? champion[field] : 'faible';
        counts[level] += 1;
        score += SIMULATION_ENGAGE_LEVEL_WEIGHTS[level] || 0;
    });

    const summary = document.createElement('p');
    summary.textContent = `${scoreLabel} : ${score} (sur ${selectedChampions.length * SIMULATION_ENGAGE_LEVEL_WEIGHTS.fort} max)`;
    container.appendChild(summary);

    const repartition = document.createElement('p');
    repartition.className = 'text-muted';
    repartition.textContent = `Répartition : ${counts.fort} fort, ${counts.moyen} moyen, ${counts.faible} faible`;
    container.appendChild(repartition);

    selectedChampions.forEach((champion) => {
        const level = champion[field] in counts ? champion[field] : 'faible';
        const line = document.createElement('p');
        line.className = 'text-muted';
        line.textContent = `${champion.name} : ${SIMULATION_ENGAGE_LEVEL_LABELS[level] || level}`;
        container.appendChild(line);
    });
}

/**
 * Calcule et affiche le score global d'une équipe : combine les scores
 * déjà calculés par les analyses dédiées de la page (CC, engage,
 * disengage, early game, late game — voir SIMULATION_GLOBAL_SCORE_FIELDS)
 * en un seul total, plus le détail par métrique. Relit directement les
 * champions sélectionnés (mêmes <select> que les autres analyses) sans
 * dépendre du DOM déjà rendu par les autres fonctions, pour rester
 * indépendante de leur ordre d'appel — entièrement calculé côté client,
 * même principe que les autres analyses de cette page.
 *
 * @param {string} teamSlug 'blue' ou 'red'.
 * @param {Array} allChampions Voir fetchSimulationChampions().
 */
function computeSimulationTeamGlobalScore(teamSlug, allChampions) {
    const container = document.getElementById(`simulation-${teamSlug}-global-score`);

    if (!container) {
        return;
    }

    const selectedChampions = SIMULATION_ROLES
        .map((role) => {
            const select = document.getElementById(`simulation-${teamSlug}-${role}`);
            return select && select.value
                ? allChampions.find((c) => c.slug === select.value)
                : null;
        })
        .filter((champion) => champion !== null);

    container.innerHTML = '';

    if (selectedChampions.length === 0) {
        const empty = document.createElement('p');
        empty.className = 'text-muted';
        empty.textContent = 'Sélectionnez au moins un champion pour voir le score global.';
        container.appendChild(empty);
        return;
    }

    let total = 0;
    const maxPerMetric = selectedChampions.length * SIMULATION_ENGAGE_LEVEL_WEIGHTS.fort;
    const maxTotal = maxPerMetric * SIMULATION_GLOBAL_SCORE_FIELDS.length;
    const breakdown = [];

    SIMULATION_GLOBAL_SCORE_FIELDS.forEach(({ field, label }) => {
        let metricScore = 0;

        selectedChampions.forEach((champion) => {
            const level = champion[field] in SIMULATION_ENGAGE_LEVEL_WEIGHTS ? champion[field] : 'faible';
            metricScore += SIMULATION_ENGAGE_LEVEL_WEIGHTS[level] || 0;
        });

        total += metricScore;
        breakdown.push({ label, metricScore });
    });

    const summary = document.createElement('p');
    summary.textContent = `Score global : ${total} (sur ${maxTotal} max)`;
    container.appendChild(summary);

    breakdown.forEach(({ label, metricScore }) => {
        const line = document.createElement('p');
        line.className = 'text-muted';
        line.textContent = `${label} : ${metricScore} / ${maxPerMetric}`;
        container.appendChild(line);
    });
}

/**
 * Calcule et affiche des recommandations de champions pour une équipe :
 * pour chaque rôle encore vacant, propose jusqu'à 2 champions
 * disponibles (non déjà choisis dans l'un des 10 emplacements, voir
 * même logique que updateSimulationChampionAvailability()) de ce rôle,
 * en priorité ceux qui renforcent la métrique la plus faible de
 * l'équipe parmi CC / engage / disengage / early game / late game (voir
 * SIMULATION_GLOBAL_SCORE_FIELDS, même moyenne pondérée que
 * computeSimulationTeamGlobalScore()), chacun accompagné d'une courte
 * explication (rôle vacant comblé + métrique renforcée, ou seulement
 * le rôle vacant si aucune métrique n'est priorisée). Si l'équipe n'a pas encore de
 * champion sélectionné, aucune métrique n'est priorisée : les
 * candidats sont simplement triés par nom. Entièrement calculé côté
 * client à partir des champions déjà chargés — aucun appel réseau
 * supplémentaire.
 *
 * @param {string} teamSlug 'blue' ou 'red'.
 * @param {Array} allChampions Voir fetchSimulationChampions().
 * @param {NodeListOf<HTMLSelectElement>} selects Les 10 emplacements (voir updateSimulationChampionAvailability()).
 */
function computeSimulationTeamRecommendations(teamSlug, allChampions, selects) {
    const container = document.getElementById(`simulation-${teamSlug}-recommendations`);

    if (!container) {
        return;
    }

    const selectedChampions = SIMULATION_ROLES
        .map((role) => {
            const select = document.getElementById(`simulation-${teamSlug}-${role}`);
            return select && select.value
                ? allChampions.find((c) => c.slug === select.value)
                : null;
        });

    const missingRoles = SIMULATION_ROLES.filter((role, index) => selectedChampions[index] === null);

    container.innerHTML = '';

    if (missingRoles.length === 0) {
        const complete = document.createElement('p');
        complete.className = 'text-muted';
        complete.textContent = 'Équipe complète — plus de recommandation nécessaire.';
        container.appendChild(complete);
        return;
    }

    // Métrique la plus faible de l'équipe parmi les champions déjà
    // sélectionnés (moyenne pondérée, même échelle que
    // computeSimulationTeamGlobalScore()) ; null tant qu'aucun champion
    // n'est sélectionné, pour ne prioriser aucun candidat par défaut.
    const picked = selectedChampions.filter((champion) => champion !== null);
    let weakestField = null;

    if (picked.length > 0) {
        let weakestAverage = Infinity;

        SIMULATION_GLOBAL_SCORE_FIELDS.forEach(({ field }) => {
            const average = picked.reduce((sum, champion) => {
                const level = champion[field] in SIMULATION_ENGAGE_LEVEL_WEIGHTS ? champion[field] : 'faible';
                return sum + (SIMULATION_ENGAGE_LEVEL_WEIGHTS[level] || 0);
            }, 0) / picked.length;

            if (average < weakestAverage) {
                weakestAverage = average;
                weakestField = field;
            }
        });
    }

    const chosenSlugs = new Set(
        Array.from(selects)
            .map((select) => select.value)
            .filter((value) => value !== '')
    );

    missingRoles.forEach((role) => {
        const candidates = allChampions
            .filter((champion) => champion.role === role && !chosenSlugs.has(champion.slug))
            .sort((a, b) => {
                if (weakestField) {
                    const levelA = SIMULATION_ENGAGE_LEVEL_WEIGHTS[a[weakestField]] || 0;
                    const levelB = SIMULATION_ENGAGE_LEVEL_WEIGHTS[b[weakestField]] || 0;
                    if (levelB !== levelA) {
                        return levelB - levelA;
                    }
                }
                return a.name.localeCompare(b.name, 'fr');
            })
            .slice(0, 2);

        const roleLabel = document.createElement('p');
        roleLabel.textContent = `${SIMULATION_ROLE_LABELS[role] || role} :`;
        container.appendChild(roleLabel);

        if (candidates.length === 0) {
            const none = document.createElement('p');
            none.className = 'text-muted';
            none.textContent = 'Aucun champion disponible pour ce rôle.';
            container.appendChild(none);
            return;
        }

        candidates.forEach((champion) => {
            const name = document.createElement('p');
            name.textContent = champion.name;
            container.appendChild(name);

            const explanation = document.createElement('p');
            explanation.className = 'text-muted';

            if (weakestField) {
                const metricLabel = SIMULATION_GLOBAL_SCORE_FIELDS.find((m) => m.field === weakestField).label;
                const levelLabel = SIMULATION_ENGAGE_LEVEL_LABELS[champion[weakestField]] || champion[weakestField];
                explanation.textContent = `Comble ${SIMULATION_ROLE_LABELS[role] || role} (rôle encore vacant) et renforce votre point faible, le ${metricLabel.toLowerCase()} (niveau ${levelLabel.toLowerCase()} sur ce champion).`;
            } else {
                explanation.textContent = `Comble ${SIMULATION_ROLE_LABELS[role] || role}, rôle encore vacant dans l'équipe.`;
            }

            container.appendChild(explanation);
        });
    });
}

/**
 * Calcule et affiche l'analyse finale, une fois les 10 emplacements
 * (5 Blue Team + 5 Red Team) pourvus — contrairement aux autres
 * analyses de cette page, qui se mettent à jour dès la première
 * sélection, celle-ci reste sur son message d'attente
 * (data-simulation-final-analysis-empty, voir pages/simulation.php)
 * tant que la composition des deux équipes n'est pas complète.
 * Compare les deux équipes sur les mêmes métriques que
 * computeSimulationTeamGlobalScore() (CC, engage, disengage, early
 * game, late game), désigne l'équipe en tête pour chaque métrique et
 * un verdict global basé sur le score total pondéré (même échelle que
 * SIMULATION_ENGAGE_LEVEL_WEIGHTS). Entièrement calculé côté client à
 * partir des champions déjà chargés — aucun appel réseau supplémentaire.
 *
 * @param {Array} allChampions Voir fetchSimulationChampions().
 */
function computeSimulationFinalAnalysis(allChampions) {
    const container = document.getElementById('simulation-final-analysis');

    if (!container) {
        return;
    }

    const getTeamChampions = (teamSlug) => SIMULATION_ROLES
        .map((role) => {
            const select = document.getElementById(`simulation-${teamSlug}-${role}`);
            return select && select.value
                ? allChampions.find((c) => c.slug === select.value)
                : null;
        });

    const blueChampions = getTeamChampions('blue');
    const redChampions = getTeamChampions('red');
    const isComplete = (champions) => champions.every((champion) => champion !== null);

    container.innerHTML = '';

    if (!isComplete(blueChampions) || !isComplete(redChampions)) {
        const empty = document.createElement('p');
        empty.className = 'text-muted';
        empty.textContent = "Sélectionnez les 10 champions (5 par équipe) pour voir l'analyse finale.";
        container.appendChild(empty);
        return;
    }

    const teamScore = (champions, field) => champions.reduce((sum, champion) => {
        const level = champion[field] in SIMULATION_ENGAGE_LEVEL_WEIGHTS ? champion[field] : 'faible';
        return sum + (SIMULATION_ENGAGE_LEVEL_WEIGHTS[level] || 0);
    }, 0);

    let blueTotal = 0;
    let redTotal = 0;
    const metricLines = [];

    SIMULATION_GLOBAL_SCORE_FIELDS.forEach(({ field, label }) => {
        const blueScore = teamScore(blueChampions, field);
        const redScore = teamScore(redChampions, field);
        blueTotal += blueScore;
        redTotal += redScore;

        let leader = 'Égalité';
        if (blueScore > redScore) {
            leader = 'Équipe Bleue';
        } else if (redScore > blueScore) {
            leader = 'Équipe Rouge';
        }

        metricLines.push(`${label} : ${leader} (${blueScore} vs ${redScore})`);
    });

    const verdict = document.createElement('p');
    if (blueTotal === redTotal) {
        verdict.textContent = `Composition équilibrée : ${blueTotal} partout.`;
    } else {
        const favored = blueTotal > redTotal ? 'Équipe Bleue' : 'Équipe Rouge';
        verdict.textContent = `${favored} favorisée sur l'ensemble des métriques : ${blueTotal} contre ${redTotal}.`;
    }
    container.appendChild(verdict);

    metricLines.forEach((text) => {
        const line = document.createElement('p');
        line.className = 'text-muted';
        line.textContent = text;
        container.appendChild(line);
    });
}

/**
 * Point d'entrée : récupère une seule fois la liste des champions, puis
 * peuple les 10 emplacements de sélection (5 Blue Team + 5 Red Team,
 * voir [data-simulation-champion-select]), et câble les filtres
 * (#simulation-champion-search et #simulation-champion-role-filter,
 * combinables) pour affiner en direct les champions proposés dans ces
 * 10 emplacements. En cas d'échec, chaque emplacement reste sur sa
 * seule option par défaut ("Choisir un champion") et une erreur est
 * journalisée — pas de zone d'erreur dédiée à ce stade, la page ne
 * prévoit pas encore cet état.
 *
 * Empêche aussi la sélection d'un même champion dans plusieurs
 * emplacements : voir updateSimulationChampionAvailability(), appelée
 * après chaque peuplement/reconstruction des options et à chaque
 * changement de sélection.
 *
 * Câble également le bouton de verrouillage de chaque emplacement (voir
 * data-simulation-lock-toggle) : une fois un champion choisi, il peut
 * être verrouillé (le <select> devient désactivé, la sélection ne peut
 * plus être changée et n'est plus affectée par les filtres — voir plus
 * bas dans applyFilters()) puis déverrouillé pour la modifier à nouveau.
 */
document.addEventListener('DOMContentLoaded', () => {
    const selects = document.querySelectorAll('[data-simulation-champion-select]');

    if (selects.length === 0) {
        return;
    }

    let allChampions = [];
    const synergyCache = new Map();
    const counterCache = new Map();

    const recomputeSynergies = (teamSlug) => {
        computeSimulationTeamSynergies(teamSlug, allChampions, synergyCache).catch((err) => {
            console.error(`Impossible de calculer les synergies de l'équipe ${teamSlug} :`, err);
        });
    };

    const recomputeCounters = () => {
        computeSimulationCounters(allChampions, counterCache).catch((err) => {
            console.error('Impossible de calculer les counters entre les deux équipes :', err);
        });
    };

    const recomputeAnalysis = (teamSlug) => {
        computeSimulationTeamAnalysis(teamSlug, allChampions);
    };

    const recomputeFrontline = (teamSlug) => {
        computeSimulationTeamFrontline(teamSlug, allChampions);
    };

    const recomputeCrowdControl = (teamSlug) => {
        computeSimulationTeamCrowdControl(teamSlug, allChampions);
    };

    const recomputeEngage = (teamSlug) => {
        computeSimulationTeamEngageStat(teamSlug, allChampions, 'engage_level', 'engage', 'Score engage');
    };

    const recomputeDisengage = (teamSlug) => {
        computeSimulationTeamEngageStat(teamSlug, allChampions, 'disengage_level', 'disengage', 'Score disengage');
    };

    const recomputeEarlyGame = (teamSlug) => {
        computeSimulationTeamEngageStat(teamSlug, allChampions, 'early_game_level', 'early-game', 'Score early game');
    };

    const recomputeLateGame = (teamSlug) => {
        computeSimulationTeamEngageStat(teamSlug, allChampions, 'late_game_level', 'late-game', 'Score late game');
    };

    const recomputeGlobalScore = (teamSlug) => {
        computeSimulationTeamGlobalScore(teamSlug, allChampions);
    };

    const recomputeRecommendations = (teamSlug) => {
        computeSimulationTeamRecommendations(teamSlug, allChampions, selects);
    };

    const recomputeFinalAnalysis = () => {
        computeSimulationFinalAnalysis(allChampions);
    };

    fetchSimulationChampions()
        .then((champions) => {
            allChampions = champions;
            selects.forEach((select) => {
                populateSimulationChampionSelect(select, allChampions);
            });
            updateSimulationChampionAvailability(selects);
            recomputeSynergies('blue');
            recomputeSynergies('red');
            recomputeCounters();
            recomputeAnalysis('blue');
            recomputeAnalysis('red');
            recomputeFrontline('blue');
            recomputeFrontline('red');
            recomputeCrowdControl('blue');
            recomputeCrowdControl('red');
            recomputeEngage('blue');
            recomputeEngage('red');
            recomputeDisengage('blue');
            recomputeDisengage('red');
            recomputeEarlyGame('blue');
            recomputeEarlyGame('red');
            recomputeLateGame('blue');
            recomputeLateGame('red');
            recomputeGlobalScore('blue');
            recomputeGlobalScore('red');
            recomputeRecommendations('blue');
            recomputeRecommendations('red');
            recomputeFinalAnalysis();
        })
        .catch((err) => {
            console.error('Impossible de récupérer la liste des champions pour la simulation :', err);
        });

    selects.forEach((select) => {
        // L'ID de l'emplacement est "simulation-{team}-{role}" : le
        // deuxième segment donne l'équipe concernée par ce changement.
        const teamSlug = select.id.split('-')[1];

        select.addEventListener('change', () => {
            updateSimulationChampionAvailability(selects);
            syncSimulationLockButton(select);
            recomputeSynergies(teamSlug);
            recomputeCounters();
            recomputeAnalysis(teamSlug);
            recomputeFrontline(teamSlug);
            recomputeCrowdControl(teamSlug);
            recomputeEngage(teamSlug);
            recomputeDisengage(teamSlug);
            recomputeEarlyGame(teamSlug);
            recomputeLateGame(teamSlug);
            recomputeGlobalScore(teamSlug);
            recomputeRecommendations('blue');
            recomputeRecommendations('red');
            recomputeFinalAnalysis();
        });

        const lockButton = getSimulationLockButton(select);
        if (lockButton) {
            lockButton.addEventListener('click', () => {
                const wasLocked = select.disabled;
                select.disabled = !wasLocked;
                lockButton.textContent = select.disabled ? 'Déverrouiller' : 'Verrouiller';
            });
        }
    });

    const search = document.getElementById('simulation-champion-search');
    const roleFilter = document.getElementById('simulation-champion-role-filter');

    const applyFilters = () => {
        const filtered = filterSimulationChampions(
            allChampions,
            search ? search.value.trim() : '',
            roleFilter ? roleFilter.value : ''
        );

        selects.forEach((select) => {
            // Un emplacement verrouillé (select désactivé) garde sa
            // sélection telle quelle : ni reconstruit, ni affecté par
            // les filtres, tant qu'il n'est pas déverrouillé.
            if (select.disabled) {
                return;
            }

            const previousValue = select.value;
            select.innerHTML = '<option value="">Choisir un champion</option>';
            populateSimulationChampionSelect(select, filtered);

            // Conserve la sélection en cours si elle correspond
            // toujours aux filtres courants ; sinon, retombe sur
            // l'option par défaut plutôt que de garder une valeur qui
            // n'apparaît plus dans la liste affichée.
            const stillAvailable = Array.from(select.options).some((option) => option.value === previousValue);
            if (stillAvailable) {
                select.value = previousValue;
            }

            syncSimulationLockButton(select);
        });

        updateSimulationChampionAvailability(selects);
        recomputeSynergies('blue');
        recomputeSynergies('red');
        recomputeCounters();
        recomputeAnalysis('blue');
        recomputeAnalysis('red');
        recomputeFrontline('blue');
        recomputeFrontline('red');
        recomputeCrowdControl('blue');
        recomputeCrowdControl('red');
        recomputeEngage('blue');
        recomputeEngage('red');
        recomputeDisengage('blue');
        recomputeDisengage('red');
        recomputeEarlyGame('blue');
        recomputeEarlyGame('red');
        recomputeLateGame('blue');
        recomputeLateGame('red');
        recomputeGlobalScore('blue');
        recomputeGlobalScore('red');
        recomputeRecommendations('blue');
        recomputeRecommendations('red');
        recomputeFinalAnalysis();
    };

    if (search) {
        search.addEventListener('input', applyFilters);
    }

    if (roleFilter) {
        roleFilter.addEventListener('change', applyFilters);
    }
});
