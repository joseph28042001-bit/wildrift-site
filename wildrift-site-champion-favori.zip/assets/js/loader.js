/**
 * Écran de chargement : banderoles verticales de champions animées.
 * Affiché une fois par session (sessionStorage). Les portraits viennent
 * de Data Dragon (art de chargement) ; si une image est indisponible, la
 * carte garde son fond et son nom.
 */
(function () {
    'use strict';

    var root = document.documentElement;
    var loader = document.getElementById('wr-loader');
    if (!loader || !root.classList.contains('wr-loading')) return;

    var CDN = 'https://ddragon.leagueoflegends.com/cdn/img/champion/loading/';
    var CHAMPIONS = [
        ['Ahri', 'Ahri'], ['Jinx', 'Jinx'], ['Yasuo', 'Yasuo'], ['Lux', 'Lux'],
        ['Lee Sin', 'LeeSin'], ['Ezreal', 'Ezreal'], ['Darius', 'Darius'], ['Katarina', 'Katarina'],
        ['Thresh', 'Thresh'], ['Zed', 'Zed'], ['Vi', 'Vi'], ['Ashe', 'Ashe'],
        ['Garen', 'Garen'], ['Akali', 'Akali'], ['Leona', 'Leona'], ['Caitlyn', 'Caitlyn'],
        ['Jhin', 'Jhin'], ['Riven', 'Riven'], ['Morgana', 'Morgana'], ['Draven', 'Draven'],
        ['Irelia', 'Irelia'], ['Sett', 'Sett'], ['Kai\'Sa', 'Kaisa'], ['Ekko', 'Ekko'],
        ['Camille', 'Camille'], ['Samira', 'Samira'], ['Yone', 'Yone'], ['Nami', 'Nami'],
        ['Lucian', 'Lucian'], ['Fiora', 'Fiora'], ['Sylas', 'Sylas'], ['Senna', 'Senna'],
        ['Pyke', 'Pyke'], ['Gwen', 'Gwen'], ['Viego', 'Viego'], ['Teemo', 'Teemo'],
        ['Master Yi', 'MasterYi'], ['Vayne', 'Vayne'], ['Renekton', 'Renekton'], ['Diana', 'Diana'],
        ['Zeri', 'Zeri'], ['Blitzcrank', 'Blitzcrank'], ['Lulu', 'Lulu'], ['Nasus', 'Nasus']
    ];

    var COLS = window.innerWidth <= 768 ? 5 : 8;
    var PER_COL = 7;
    var MIN_MS = 2200;   // durée minimale d'affichage
    var MAX_MS = 7000;   // garde-fou : on ferme quoi qu'il arrive
    var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced) MIN_MS = 600;

    // Mélange déterministe léger pour varier les colonnes
    function pick(col) {
        var out = [];
        for (var i = 0; i < PER_COL; i++) {
            out.push(CHAMPIONS[(col * 5 + i * 7) % CHAMPIONS.length]);
        }
        return out;
    }

    var total = 0, done = 0, pageLoaded = false, startedAt = Date.now(), finished = false;
    var bar = null, label = null;

    function setProgress(value) {
        if (bar) bar.style.transform = 'scaleX(' + Math.min(1, value) + ')';
        if (label) label.textContent = value >= 1 ? 'Prêt' : 'Chargement ' + Math.round(value * 100) + '%';
    }
    function update() {
        var imgPart = total ? done / total : 1;
        setProgress(Math.min(0.97, imgPart * 0.85 + (pageLoaded ? 0.12 : 0)));
        if (total && done >= total && pageLoaded) schedule();
    }
    var scheduled = false;
    function schedule() {
        if (scheduled) return;
        scheduled = true;
        setTimeout(finish, Math.max(0, MIN_MS - (Date.now() - startedAt)));
    }

    function finish() {
        if (finished) return;
        finished = true;
        setProgress(1);
        try { sessionStorage.setItem('wrLoaderSeen', '1'); } catch (e) {}
        setTimeout(function () {
            loader.classList.add('is-leaving');
            setTimeout(function () {
                root.classList.remove('wr-loading');
                loader.parentNode && loader.parentNode.removeChild(loader);
            }, reduced ? 50 : 780);
        }, 220);
    }

    function tile(champ, loadDelay) {
        var el = document.createElement('div');
        el.className = 'wr-loader__tile';
        el.setAttribute('data-name', champ[0]);
        el.style.setProperty('--shine-delay', loadDelay + 's');
        var img = new Image();
        img.alt = '';
        img.decoding = 'async';
        el.appendChild(img);
        return { el: el, img: img, src: CDN + champ[1] + '_0.jpg' };
    }

    // Construction
    var stage = document.createElement('div');
    stage.className = 'wr-loader__stage';
    var pending = [];

    for (var c = 0; c < COLS; c++) {
        var col = document.createElement('div');
        col.className = 'wr-loader__col';
        col.setAttribute('data-dir', c % 2 ? 'down' : 'up');
        var track = document.createElement('div');
        track.className = 'wr-loader__track';
        track.style.setProperty('--col-duration', (22 + (c * 3) % 11) + 's');

        var list = pick(c);
        // Deux passes identiques = boucle sans coupure (translate -50 %)
        for (var pass = 0; pass < 2; pass++) {
            for (var i = 0; i < list.length; i++) {
                var t = tile(list[i], ((c + i) % 6) * 0.6);
                track.appendChild(t.el);
                if (pass === 0) pending.push(t); else t.img.src = t.src; // 2e passe : cache navigateur
                if (pass === 1) t.img.classList.add('is-loaded');
            }
        }
        col.appendChild(track);
        stage.appendChild(col);
    }
    loader.insertBefore(stage, loader.firstChild);

    total = pending.length;
    pending.forEach(function (t) {
        var settle = function () { done++; update(); };
        t.img.onload = function () { t.img.classList.add('is-loaded'); settle(); };
        t.img.onerror = function () { t.img.remove(); settle(); };
        t.img.src = t.src;
    });

    var bars = loader.querySelector('.wr-loader__bar-fill');
    bar = bars; label = loader.querySelector('.wr-loader__label');
    setProgress(0.05);

    if (document.readyState === 'complete') { pageLoaded = true; update(); }
    else window.addEventListener('load', function () { pageLoaded = true; update(); });

    setTimeout(finish, MAX_MS);

    // Échap ou clic : passer l'écran
    loader.addEventListener('click', finish);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') finish(); });
})();
