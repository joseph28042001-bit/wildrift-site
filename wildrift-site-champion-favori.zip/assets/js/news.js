/**
 * Wild Rift Platform — Actualités (news / articles).
 * Étape actuelle : récupération de la liste des articles, récupération
 * d'un article précis (par ID), recherche d'articles (par titre), filtre
 * par catégorie, récupération des articles récents, ainsi qu'une gestion
 * des erreurs commune et robuste pour ces appels, UNIQUEMENT.
 *
 * Ce fichier ne fait que consommer l'API existante (GET /api/news/,
 * GET /api/news/?search=, GET /api/news/?category=, GET /api/news/?limit=
 * et GET /api/news/?id=, voir api/news/index.php et
 * api/news/repository.php) via fetch() : il n'y a volontairement aucun
 * affichage/rendu HTML ici — ce sera l'objet d'une prochaine étape, une
 * fois les récupérations validées.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

/**
 * Erreur dédiée aux appels de l'API Actualités : porte toujours un code
 * machine-readable (`code`) en plus du message, pour permettre à un
 * appelant de distinguer les cas (ex. réagir différemment à 'not_found'
 * qu'à 'network_error'), sans avoir à analyser le texte du message.
 *
 * `code` reprend celui de l'enveloppe d'erreur de l'API quand il existe
 * (voir api/core/response.php : 'validation_error', 'not_found',
 * 'method_not_allowed', 'internal_error'...), ou l'un des codes suivants,
 * propres au client, pour les cas que l'API ne peut pas elle-même
 * signaler :
 *   - 'network_error'    : la requête n'a pas atteint le serveur (hors
 *                          ligne, DNS, CORS...) ;
 *   - 'invalid_response' : le serveur a répondu, mais le corps n'était
 *                          pas du JSON exploitable (page d'erreur HTML
 *                          d'hébergeur, timeout intermédiaire...) ;
 *   - 'unknown_error'     : réponse HTTP en échec sans enveloppe d'erreur
 *                          reconnaissable.
 */
class NewsApiError extends Error {
    constructor(code, message) {
        super(message);
        this.name = 'NewsApiError';
        this.code = code;
    }
}

/**
 * Effectue un GET JSON vers l'API Actualités et renvoie `data` en cas de
 * succès. Point d'entrée unique pour fetchNewsList()/fetchNewsById()/
 * fetchNewsSearch()/fetchNewsByCategory()/fetchRecentNews() ci-dessous :
 * centralise la gestion des erreurs pour que les cinq fonctions restent
 * cohérentes entre elles et ne dupliquent pas cette logique.
 *
 * Trois familles d'échec sont distinguées, chacune levant un
 * NewsApiError avec un `code` et un message toujours sûrs à afficher
 * (jamais de détail technique, voir la règle générale du projet dans
 * config/database.php) :
 *   1. la requête échoue avant même d'atteindre le serveur (fetch()
 *      rejette, ex. hors ligne) → 'network_error' ;
 *   2. le serveur répond, mais le corps n'est pas du JSON valide
 *      (ex. page d'erreur HTML d'un hébergeur mutualisé) → 'invalid_response' ;
 *   3. le serveur répond en JSON, mais avec success=false ou un code
 *      HTTP d'échec → le code d'erreur de l'API (voir api/core/response.php),
 *      ou 'unknown_error' si l'enveloppe est incomplète.
 *
 * @param {string} url URL complète de l'appel (déjà construite par l'appelant).
 * @returns {Promise<*>} Le contenu de `data` en cas de succès.
 */
async function newsApiRequest(url) {
    let response;
    try {
        response = await fetch(url, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new NewsApiError(
            'network_error',
            "Impossible de contacter le serveur. Vérifiez votre connexion et réessayez."
        );
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new NewsApiError(
            'invalid_response',
            'Le serveur a renvoyé une réponse inattendue.'
        );
    }

    if (!response.ok || !payload?.success) {
        const code = payload?.error?.code || 'unknown_error';
        const message = payload?.error?.message || 'Une erreur est survenue lors de la récupération des actualités.';
        throw new NewsApiError(code, message);
    }

    return payload.data;
}

/**
 * Récupère la liste des articles publiés depuis l'API.
 * Voir newsApiRequest() pour la gestion des erreurs (rejette toujours
 * avec un NewsApiError).
 *
 * @returns {Promise<Array>} Liste des articles (id, slug, title, excerpt,
 *                            category, image_url, published_at).
 */
async function fetchNewsList() {
    const base = window.API_BASE_URL || '/api';
    return newsApiRequest(`${base}/news/`);
}

/**
 * Récupère le détail d'un article précis depuis l'API (GET /api/news/?id=).
 * Voir newsApiRequest() pour la gestion des erreurs (rejette toujours
 * avec un NewsApiError — ex. code 'validation_error' si l'ID est invalide,
 * 'not_found' si l'article n'existe pas ou n'est pas publié).
 *
 * @param {number|string} id Identifiant de l'article.
 * @returns {Promise<Object>} L'article (id, slug, title, excerpt, category,
 *                             image_url, published_at, content, dates).
 */
async function fetchNewsById(id) {
    const base = window.API_BASE_URL || '/api';
    return newsApiRequest(`${base}/news/?id=${encodeURIComponent(id)}`);
}

/**
 * Recherche des articles publiés par titre depuis l'API
 * (GET /api/news/?search=). Voir newsApiRequest() pour la gestion des
 * erreurs (rejette toujours avec un NewsApiError).
 *
 * @param {string} query Terme recherché dans le titre des articles.
 * @returns {Promise<Array>} Articles correspondants, éventuellement vide
 *                            (mêmes colonnes que fetchNewsList()).
 */
async function fetchNewsSearch(query) {
    const base = window.API_BASE_URL || '/api';
    return newsApiRequest(`${base}/news/?search=${encodeURIComponent(query)}`);
}

/**
 * Filtre les articles publiés par catégorie depuis l'API
 * (GET /api/news/?category=). Voir newsApiRequest() pour la gestion des
 * erreurs (rejette toujours avec un NewsApiError — ex. code
 * 'validation_error' si la catégorie est hors énumération).
 *
 * @param {string} category Catégorie ('patch', 'esport', 'evenement' ou
 *                           'communaute' — voir getNewsCategories() côté
 *                           API, api/news/repository.php).
 * @returns {Promise<Array>} Articles correspondants, éventuellement vide
 *                            (mêmes colonnes que fetchNewsList()).
 */
async function fetchNewsByCategory(category) {
    const base = window.API_BASE_URL || '/api';
    return newsApiRequest(`${base}/news/?category=${encodeURIComponent(category)}`);
}

/**
 * Récupère les articles publiés les plus récents depuis l'API
 * (GET /api/news/?limit=). Voir newsApiRequest() pour la gestion des
 * erreurs (rejette toujours avec un NewsApiError — ex. code
 * 'validation_error' si la limite est hors bornes).
 *
 * @param {number} limit Nombre d'articles à récupérer (entre 1 et 20 côté
 *                        API — voir NEWS_MAX_RECENT_LIMIT, api/news/repository.php).
 * @returns {Promise<Array>} Articles les plus récents (mêmes colonnes que
 *                            fetchNewsList()).
 */
async function fetchRecentNews(limit) {
    const base = window.API_BASE_URL || '/api';
    return newsApiRequest(`${base}/news/?limit=${encodeURIComponent(limit)}`);
}

/**
 * Libellés français des catégories d'actualités (voir getNewsCategories()
 * côté API, api/news/repository.php) et classe de badge associée (voir
 * assets/css/style.css) — même logique que ITEM_CATEGORY_LABELS
 * (assets/js/items.js).
 */
const NEWS_CATEGORY_LABELS = {
    patch: 'Patch',
    esport: 'Esport',
    evenement: 'Événement',
    communaute: 'Communauté',
};

const NEWS_CATEGORY_BADGE_CLASSES = {
    patch: 'badge--teal',
    esport: 'badge--crimson',
    evenement: 'badge--brass',
    communaute: 'badge--verdant',
};

/**
 * Formate une date de publication (colonne `published_at`, format
 * ISO renvoyé par l'API) en date lisible française (ex. "9 septembre 2026").
 * Renvoie la valeur brute telle quelle si elle n'est pas une date valide,
 * plutôt que d'afficher "Invalid Date".
 */
function formatNewsDate(publishedAt) {
    const date = new Date(publishedAt);

    if (Number.isNaN(date.getTime())) {
        return publishedAt;
    }

    return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
}

/**
 * Construit la carte HTML d'un article (composant .card du design system
 * — voir assets/css/style.css et pages/styleguide.php pour le modèle
 * repris ici). N'insère aucune valeur non échappée : toutes les données
 * viennent de l'API, mais restent traitées comme non sûres côté
 * affichage (textContent, jamais innerHTML sur une valeur dynamique).
 */
function renderNewsCard(article) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = formatNewsDate(article.published_at);
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = article.title;
    card.appendChild(title);

    if (article.excerpt) {
        const excerpt = document.createElement('p');
        excerpt.textContent = article.excerpt;
        card.appendChild(excerpt);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const categoryBadge = document.createElement('span');
    const categoryBadgeClass = NEWS_CATEGORY_BADGE_CLASSES[article.category] || '';
    categoryBadge.className = categoryBadgeClass ? `badge ${categoryBadgeClass}` : 'badge';
    categoryBadge.textContent = NEWS_CATEGORY_LABELS[article.category] || article.category;
    foot.appendChild(categoryBadge);

    card.appendChild(foot);

    return card;
}

/**
 * Affiche la liste des articles dans #news-grid, un par un
 * (renderNewsCard() ci-dessus). Ne fait rien d'autre : la bascule de
 * l'état de chargement/erreur est gérée par l'appelant.
 */
function renderNewsList(articles) {
    const grid = document.getElementById('news-grid');
    grid.innerHTML = '';

    articles.forEach((article) => {
        grid.appendChild(renderNewsCard(article));
    });
}

/**
 * Journalise une erreur d'API Actualités de façon uniforme (code + message),
 * pour que chaque `.catch()` de la démonstration ci-dessous produise la
 * même forme de trace, plutôt que de ré-écrire ce détail à chaque appel.
 * Reste un simple console.error : aucun affichage utilisateur n'est ajouté
 * à cette étape (voir le reste du fichier).
 */
function logNewsApiError(prefix, error) {
    const code = error instanceof NewsApiError ? error.code : 'unexpected_error';
    console.error(`${prefix} [${code}] :`, error.message);
}

/**
 * Déclenche la récupération de la liste des articles (recherche par
 * titre et/ou filtre par catégorie si fournis, combinables — sinon
 * liste complète) et l'affiche dans #news-grid, en basculant l'état de
 * chargement/erreur. N'est utile que sur la page Actualités (voir
 * news.php/pages/news.php, où #news-search-form et #news-grid
 * existent) : appelée uniquement depuis le câblage de ce formulaire
 * ci-dessous, jamais au chargement initial de la page (déjà couvert par
 * la démonstration existante ci-dessous, qui affiche aussi la liste
 * complète via renderNewsList()).
 *
 * Construit directement l'URL (via newsApiRequest(), plutôt que
 * fetchNewsSearch()/fetchNewsByCategory() qui ne gèrent qu'un seul
 * critère chacune) pour permettre la combinaison des deux filtres —
 * même principe que fetchChampions()/fetchBuilds() (search + role
 * combinables).
 *
 * @param {string} [search] Terme recherché dans le titre des articles.
 *                          Omis ou vide : pas de filtre par titre.
 * @param {string} [category] Catégorie ('patch', 'esport', 'evenement'
 *                            ou 'communaute' — voir getNewsCategories()
 *                            côté API). Omis ou vide : pas de filtre
 *                            par catégorie.
 */
function loadNewsList(search, category) {
    const loading = document.getElementById('news-loading');
    const error = document.getElementById('news-error');

    if (loading) {
        loading.hidden = false;
    }
    if (error) {
        error.hidden = true;
    }

    const base = window.API_BASE_URL || '/api';
    const params = new URLSearchParams();
    if (search) {
        params.set('search', search);
    }
    if (category) {
        params.set('category', category);
    }
    const query = params.toString();

    newsApiRequest(`${base}/news/${query ? `?${query}` : ''}`)
        .then((articles) => {
            if (document.getElementById('news-grid')) {
                renderNewsList(articles);
            }
        })
        .catch((err) => {
            logNewsApiError('Impossible de récupérer les actualités', err);

            if (error) {
                error.textContent = err.message;
                error.hidden = false;
            }
        })
        .finally(() => {
            if (loading) {
                loading.hidden = true;
            }
        });
}

/**
 * Déclenche les récupérations dès le chargement de la page, pour valider
 * que les appels — et leur gestion des erreurs — fonctionnent de bout en
 * bout. Pas d'affichage à cette étape : les résultats sont seulement
 * journalisés en console.
 *
 * Pour l'article précis, aucune page de détail n'existe encore pour
 * fournir un ID : le premier article de la liste sert de démonstration.
 * Pour la recherche et le filtre par catégorie, faute de champ de
 * recherche ou de menu de catégories existants, le titre puis la
 * catégorie de ce même premier article servent de démonstration. Pour
 * les articles récents, la démonstration récupère les 3 plus récents.
 *
 * Sur la page Actualités (voir news.php/pages/news.php), les éléments
 * #news-loading/#news-error/#news-grid existent : la liste y est en plus
 * affichée (renderNewsList() ci-dessus) et l'état de chargement/erreur
 * basculé, même principe que sur les autres pages connectées à leur API
 * (voir assets/js/items.js, assets/js/runes.js...). Sur les autres
 * pages, ces éléments sont absents et ce bloc est ignoré : seule la
 * démonstration en console continue de s'exécuter, comportement
 * inchangé.
 */
document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('news-loading');
    const error = document.getElementById('news-error');

    fetchNewsList()
        .then((articles) => {
            console.log('Articles récupérés :', articles);

            if (document.getElementById('news-grid')) {
                renderNewsList(articles);
            }

            if (articles.length > 0) {
                fetchNewsById(articles[0].id)
                    .then((article) => {
                        console.log('Article récupéré :', article);
                    })
                    .catch((error) => {
                        logNewsApiError("Impossible de récupérer l'article", error);
                    });

                fetchNewsSearch(articles[0].title)
                    .then((results) => {
                        console.log('Résultats de recherche :', results);
                    })
                    .catch((error) => {
                        logNewsApiError('Impossible de rechercher des articles', error);
                    });

                fetchNewsByCategory(articles[0].category)
                    .then((results) => {
                        console.log('Articles filtrés par catégorie :', results);
                    })
                    .catch((error) => {
                        logNewsApiError('Impossible de filtrer par catégorie', error);
                    });
            }

            fetchRecentNews(3)
                .then((results) => {
                    console.log('Articles récents :', results);
                })
                .catch((error) => {
                    logNewsApiError('Impossible de récupérer les articles récents', error);
                });
        })
        .catch((err) => {
            logNewsApiError('Impossible de récupérer la liste des articles', err);

            if (error) {
                error.textContent = err.message;
                error.hidden = false;
            }
        })
        .finally(() => {
            if (loading) {
                loading.hidden = true;
            }
        });

    // --- Formulaire de recherche (#news-search-form, page Actualités
    // uniquement — absent des autres pages, où ce bloc ne fait rien) ---
    const form = document.getElementById('news-search-form');

    if (form) {
        const input = document.getElementById('news-search-input');
        const categoryFilter = document.getElementById('news-category-filter');
        const reset = document.getElementById('news-search-reset');

        form.addEventListener('submit', (event) => {
            event.preventDefault();
            loadNewsList(input.value.trim(), categoryFilter.value);
        });

        reset.addEventListener('click', () => {
            input.value = '';
            categoryFilter.value = '';
            loadNewsList();
        });
    }
});
