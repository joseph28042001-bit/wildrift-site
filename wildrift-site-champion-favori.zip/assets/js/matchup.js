/**
 * Wild Rift Platform — Page Matchup (détail).
 * Connecte la page pages/matchup.php à l'API existante (GET
 * /api/counters/?id=, voir api/counters/index.php et
 * api/counters/repository.php :: findCounterById()) : lit l'ID du
 * matchup dans l'URL (?id=, celui du counter, pas d'un champion),
 * récupère le matchup au chargement de la page et l'affiche.
 *
 * Ce fichier n'est chargé que sur la page Matchup (voir matchup.php) —
 * contrairement à assets/js/news.js, chargé globalement, il n'y a pas
 * lieu d'exécuter ce code sur les autres pages, qui n'ont pas les
 * éléments #matchup-* attendus ci-dessous.
 *
 * Les conseils pratiques du matchup (colonne `tips`, distincte de
 * `explanation`) sont affichés dans leur propre section (voir
 * renderMatchupTips() ci-dessous), séparée de "Analyse du matchup" —
 * sur le même principe qu'une section par concept que
 * assets/js/champion.js (Stats/Abilities/Builds/Counters/Synergies).
 *
 * Les objets recommandés (relation `counter_items`, déjà incluse dans
 * la réponse) sont répartis en deux sections selon la colonne
 * `situation` (voir database/schema.sql) : les objets de base
 * (`situation` absente) dans "Objets recommandés", les objets
 * situationnels (`situation` renseignée) dans leur propre section
 * "Recommandations d'objets situationnels", chaque carte affichant le
 * texte de `situation` — voir splitMatchupItemsBySituation(),
 * renderMatchupItems() et renderMatchupSituationalItems() ci-dessous.
 *
 * GET /api/counters/?id= renvoie `champion_id` et `counter_champion_id`
 * en ID bruts (voir COUNTER_SELECT_COLUMNS, repository.php) : ce
 * fichier résout donc chacun des deux en une fiche complète via un
 * appel séparé à GET /api/champions/?id= (voir fetchChampionDetail()
 * ci-dessous), pour afficher nom, rôle et image plutôt que des ID bruts
 * — même besoin que assets/js/counters.js, mais avec la fiche complète
 * plutôt que le seul nom (le détail d'un matchup a la place pour plus).
 *
 * Reprend volontairement les libellés/classes de rôle et de difficulté
 * de assets/js/champion.js et assets/js/counters.js (mêmes
 * CHAMPION_*_LABELS/BADGE_CLASSES, même COUNTER_DIFFICULTY_BADGE_CLASSES)
 * plutôt que de les importer : ce fichier n'est chargé que sur cette
 * page, séparément des deux autres. Idem pour les libellés/classes de
 * catégorie d'objet, repris de assets/js/items.js.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

const MATCHUP_ROLE_LABELS = {
    baron: 'Voie Baron',
    jungle: 'Jungle',
    mid: 'Voie du Milieu',
    dragon: 'Voie Dragon',
    support: 'Support',
};

const MATCHUP_ROLE_BADGE_CLASSES = {
    baron: 'badge--brass',
    jungle: 'badge--verdant',
    mid: 'badge--teal',
    dragon: 'badge--crimson',
    support: '',
};

/**
 * Classe de badge associée à chaque niveau de difficulté (colonne
 * `difficulty`, ENUM('facile', 'moyen', 'difficile') nullable — voir
 * database/schema.sql), reprise de assets/js/counters.js pour une
 * cohérence visuelle avec la page Counters.
 */
const MATCHUP_DIFFICULTY_BADGE_CLASSES = {
    facile: 'badge--verdant',
    moyen: 'badge--brass',
    difficile: 'badge--crimson',
};

/**
 * Libellés et classes de badge par catégorie d'objet, repris de
 * assets/js/items.js (ITEM_CATEGORY_LABELS/ITEM_CATEGORY_BADGE_CLASSES)
 * pour une cohérence visuelle avec la page Objets.
 */
const MATCHUP_ITEM_CATEGORY_LABELS = {
    attack: 'Attaque',
    magic: 'Magie',
    defense: 'Défense',
    boots: 'Bottes',
    jungle: 'Jungle',
    consumable: 'Consommable',
    enchantment: 'Enchantement',
};

const MATCHUP_ITEM_CATEGORY_BADGE_CLASSES = {
    attack: 'badge--crimson',
    magic: 'badge--teal',
    defense: 'badge--verdant',
    boots: 'badge--brass',
    jungle: 'badge--verdant',
    consumable: 'badge--brass',
    enchantment: 'badge--teal',
};

/**
 * Lit et valide l'ID de matchup depuis l'URL courante (?id=).
 * Validation minimale côté client (entier positif) : l'API revalide de
 * toute façon l'ID (voir apiValidateInt(), api/counters/index.php) et
 * renvoie une erreur explicite si besoin ; cette vérification évite
 * simplement un appel réseau inutile pour un cas manifestement invalide.
 * Même principe que getRequestedChampionId(), assets/js/champion.js.
 *
 * @returns {number} L'ID demandé.
 * @throws {Error} Si l'ID est absent ou n'est pas un entier positif.
 */
function getRequestedMatchupId() {
    const params = new URLSearchParams(window.location.search);
    const raw = params.get('id');

    if (!raw || !/^\d+$/.test(raw) || Number(raw) < 1) {
        throw new Error("Aucun matchup valide n'a été demandé.");
    }

    return Number(raw);
}

/**
 * Récupère un matchup depuis l'API (GET /api/counters/?id=). Reprend
 * l'enveloppe JSON standard de l'API ({ success, data, meta }) — voir
 * api/core/response.php : en cas de succès, renvoie le matchup (data) ;
 * en cas d'échec (HTTP, matchup introuvable ou réseau), le rejette avec
 * une erreur dont le message est toujours sûr à afficher tel quel.
 *
 * @param {number} id Identifiant du matchup (colonne `id`, counters).
 * @returns {Promise<Object>} Le matchup (id, champion_id,
 *                             counter_champion_id, explanation, tips,
 *                             difficulty, items).
 */
async function fetchMatchup(id) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/counters/?id=${encodeURIComponent(id)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération du matchup.');
    }

    return payload.data;
}

/**
 * Récupère la fiche d'un champion depuis l'API (GET /api/champions/?id=),
 * pour résoudre `champion_id`/`counter_champion_id` (voir en-tête). Même
 * appel que fetchChampionDetail(), assets/js/champion.js. En cas d'échec
 * (réseau, HTTP ou champion introuvable), rejette avec une erreur dont
 * le message est toujours sûr à afficher tel quel.
 *
 * @param {number} id Identifiant du champion.
 * @returns {Promise<Object>} Le champion (id, slug, name, title, role,
 *                             difficulty, image_url).
 */
async function fetchMatchupChampion(id) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/champions/?id=${encodeURIComponent(id)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération d\'un champion du matchup.');
    }

    return payload.data;
}

/**
 * Construit la carte HTML d'un des deux champions du matchup (composant
 * .card du design system, variante .card--champion — même modèle que
 * assets/js/champion.js::renderChampionDetail(), en plus compact et
 * cliquable vers la fiche complète du champion, champion.php?id=).
 *
 * @param {Object} champion Fiche du champion (voir fetchMatchupChampion()).
 * @param {string} roleLabel Rôle de ce champion dans le matchup affiché
 *                            ("Champion contré" ou "Champion qui contre").
 */
function renderMatchupChampionCard(champion, roleLabel) {
    const card = document.createElement('article');
    card.className = 'card card--champion';

    const link = document.createElement('a');
    link.href = `champion.php?id=${encodeURIComponent(champion.id)}`;

    if (champion.image_url) {
        const media = document.createElement('div');
        media.className = 'card__media';

        const image = document.createElement('img');
        image.src = champion.image_url;
        image.alt = champion.name;
        image.addEventListener('error', () => {
            image.remove();
        });

        media.appendChild(image);
        link.appendChild(media);
    }

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = roleLabel;
    link.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = champion.name;
    link.appendChild(title);

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const roleBadge = document.createElement('span');
    const roleBadgeClass = MATCHUP_ROLE_BADGE_CLASSES[champion.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = MATCHUP_ROLE_LABELS[champion.role] || champion.role;
    foot.appendChild(roleBadge);

    link.appendChild(foot);
    card.appendChild(link);

    return card;
}

/**
 * Remplit #matchup-title et #matchup-champions avec le titre du matchup
 * et les deux cartes de champion (renderMatchupChampionCard() ci-dessus).
 * L'ordre affiché reprend celui de assets/js/counters.js::renderCounterCard()
 * (le champion qui contre en premier dans le titre : "X contre Y").
 *
 * @param {Object} counterChampion Le champion qui contre (counter_champion_id).
 * @param {Object} champion Le champion contré (champion_id).
 */
function renderMatchupChampions(counterChampion, champion) {
    const title = document.getElementById('matchup-title');
    title.textContent = `${counterChampion.name} contre ${champion.name}`;

    const grid = document.getElementById('matchup-champions');
    grid.innerHTML = '';
    grid.appendChild(renderMatchupChampionCard(counterChampion, 'Champion qui contre'));
    grid.appendChild(renderMatchupChampionCard(champion, 'Champion contré'));

    document.getElementById('matchup-detail').hidden = false;
}

/**
 * Remplit la section "Analyse" (#matchup-explanation,
 * #matchup-difficulty-badge) avec les colonnes `explanation`/`difficulty`
 * du matchup — chacune facultative (voir database/schema.sql), masquée
 * si absente. Rend la section visible dans tous les cas : même si les
 * deux valeurs manquent, le titre "Analyse du matchup" reste pertinent
 * (le matchup existe, seule l'analyse écrite manque encore). Les
 * conseils pratiques (`tips`) sont traités séparément, voir
 * renderMatchupTips() ci-dessous.
 */
function renderMatchupAnalysis(counter) {
    const explanation = document.getElementById('matchup-explanation');
    if (counter.explanation) {
        explanation.textContent = counter.explanation;
        explanation.hidden = false;
    }

    if (counter.difficulty) {
        const foot = document.getElementById('matchup-difficulty-foot');
        const badge = document.getElementById('matchup-difficulty-badge');
        const badgeClass = MATCHUP_DIFFICULTY_BADGE_CLASSES[counter.difficulty] || '';
        badge.className = badgeClass ? `badge ${badgeClass}` : 'badge';
        badge.textContent = counter.difficulty;
        foot.hidden = false;
    }

    document.getElementById('matchup-analysis-section').hidden = false;
}

/**
 * Remplit la section "Conseils" (#matchup-tips) avec la colonne `tips`
 * du matchup (conseils pratiques : timing, objets, positionnement...,
 * distincts de `explanation` — voir api/counters/repository.php),
 * ou affiche #matchup-tips-empty si le matchup n'en a encore aucun
 * (colonne nullable). Section indépendante de "Analyse du matchup",
 * sur le même principe que les sections dédiées de
 * assets/js/champion.js (une fonction de rendu par section).
 */
function renderMatchupTips(counter) {
    const empty = document.getElementById('matchup-tips-empty');
    const card = document.getElementById('matchup-tips-card');

    if (counter.tips) {
        document.getElementById('matchup-tips').textContent = counter.tips;
        card.hidden = false;
    } else {
        empty.hidden = false;
    }

    document.getElementById('matchup-tips-section').hidden = false;
}

/**
 * Construit la carte HTML d'un objet recommandé (composant `.card` du
 * design system, même principe que assets/js/items.js::renderItemCard(),
 * avec en plus l'ordre d'achat conseillé lorsqu'il est renseigné —
 * colonne `purchase_order`, `counter_items`, voir findCounterItems(),
 * api/counters/repository.php).
 */
function renderMatchupItemCard(item) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = item.purchase_order
        ? `Objet #${item.purchase_order}`
        : 'Objet recommandé';
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = item.name;
    card.appendChild(title);

    const price = document.createElement('p');
    price.className = 'text-mono text-muted';
    price.style.fontSize = 'var(--text-xs)';
    price.textContent = `${item.price} po`;
    card.appendChild(price);

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const categoryBadge = document.createElement('span');
    const categoryBadgeClass = MATCHUP_ITEM_CATEGORY_BADGE_CLASSES[item.category] || '';
    categoryBadge.className = categoryBadgeClass ? `badge ${categoryBadgeClass}` : 'badge';
    categoryBadge.textContent = MATCHUP_ITEM_CATEGORY_LABELS[item.category] || item.category;
    foot.appendChild(categoryBadge);

    card.appendChild(foot);

    return card;
}

/**
 * Affiche les objets recommandés dans #matchup-items-grid, un par un
 * (renderMatchupItemCard() ci-dessus), ou le message
 * #matchup-items-empty si le matchup n'en a encore aucun. Ne reçoit que
 * les objets de base (sans `situation`) — voir
 * splitMatchupItemsBySituation() et le point d'entrée ci-dessous.
 */
function renderMatchupItems(items) {
    const grid = document.getElementById('matchup-items-grid');
    const empty = document.getElementById('matchup-items-empty');
    grid.innerHTML = '';

    if (!Array.isArray(items) || items.length === 0) {
        empty.hidden = false;
    } else {
        empty.hidden = true;
        items.forEach((item) => {
            grid.appendChild(renderMatchupItemCard(item));
        });
    }

    document.getElementById('matchup-items-section').hidden = false;
}

/**
 * Sépare les objets d'un matchup (voir findCounterItems(),
 * api/counters/repository.php) en deux tableaux selon la colonne
 * `situation` (nullable, voir database/schema.sql) : les objets de base
 * (sans `situation`) et les objets situationnels (avec `situation`).
 *
 * @param {Array} items Objets du matchup (voir fetchMatchup()).
 * @returns {{base: Array, situational: Array}}
 */
function splitMatchupItemsBySituation(items) {
    const source = Array.isArray(items) ? items : [];

    return {
        base: source.filter((item) => !item.situation),
        situational: source.filter((item) => Boolean(item.situation)),
    };
}

/**
 * Construit la carte HTML d'une recommandation d'objet situationnel —
 * même base que renderMatchupItemCard() (nom, prix, badge de catégorie),
 * avec en plus le texte de `situation` expliquant quand et pourquoi
 * acheter cet objet dans ce matchup précis (colonne
 * `counter_items.situation`, voir findCounterItems(),
 * api/counters/repository.php).
 */
function renderMatchupSituationalItemCard(item) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = 'Objet situationnel';
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = item.name;
    card.appendChild(title);

    const situation = document.createElement('p');
    situation.className = 'text-muted';
    situation.textContent = item.situation;
    card.appendChild(situation);

    const price = document.createElement('p');
    price.className = 'text-mono text-muted';
    price.style.fontSize = 'var(--text-xs)';
    price.textContent = `${item.price} po`;
    card.appendChild(price);

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const categoryBadge = document.createElement('span');
    const categoryBadgeClass = MATCHUP_ITEM_CATEGORY_BADGE_CLASSES[item.category] || '';
    categoryBadge.className = categoryBadgeClass ? `badge ${categoryBadgeClass}` : 'badge';
    categoryBadge.textContent = MATCHUP_ITEM_CATEGORY_LABELS[item.category] || item.category;
    foot.appendChild(categoryBadge);

    card.appendChild(foot);

    return card;
}

/**
 * Affiche les recommandations d'objets situationnels dans
 * #matchup-situational-items-grid, une par une
 * (renderMatchupSituationalItemCard() ci-dessus), ou le message
 * #matchup-situational-items-empty si le matchup n'en a encore aucune.
 * Ne reçoit que les objets situationnels (avec `situation`) — voir
 * splitMatchupItemsBySituation() et le point d'entrée ci-dessous.
 */
function renderMatchupSituationalItems(items) {
    const grid = document.getElementById('matchup-situational-items-grid');
    const empty = document.getElementById('matchup-situational-items-empty');
    grid.innerHTML = '';

    if (!Array.isArray(items) || items.length === 0) {
        empty.hidden = false;
    } else {
        empty.hidden = true;
        items.forEach((item) => {
            grid.appendChild(renderMatchupSituationalItemCard(item));
        });
    }

    document.getElementById('matchup-situational-items-section').hidden = false;
}

/**
 * Point d'entrée : déclenche la récupération au chargement de la page et
 * bascule entre les trois états possibles (chargement → succès ou
 * erreur). Le matchup est d'abord récupéré seul (GET /api/counters/?id=),
 * puis les deux champions qu'il référence sont résolus en parallèle
 * (Promise.all) — ils ne peuvent être demandés qu'une fois le matchup
 * connu, contrairement à assets/js/counters.js qui résout tous les
 * champions d'un coup via une seule requête à /api/champions/.
 */
document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('matchup-loading');
    const error = document.getElementById('matchup-error');

    let counter;

    Promise.resolve()
        .then(() => fetchMatchup(getRequestedMatchupId()))
        .then((fetchedCounter) => {
            counter = fetchedCounter;
            return Promise.all([
                fetchMatchupChampion(counter.counter_champion_id),
                fetchMatchupChampion(counter.champion_id),
            ]);
        })
        .then(([counterChampion, champion]) => {
            renderMatchupChampions(counterChampion, champion);
            renderMatchupAnalysis(counter);
            renderMatchupTips(counter);
            const { base, situational } = splitMatchupItemsBySituation(counter.items);
            renderMatchupItems(base);
            renderMatchupSituationalItems(situational);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
});
