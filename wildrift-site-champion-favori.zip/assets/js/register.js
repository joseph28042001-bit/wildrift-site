/**
 * Page Inscription — validation du formulaire côté navigateur uniquement.
 * Aucun appel réseau ici : la création du compte (vérification de
 * l'unicité du pseudo/email, hachage du mot de passe, insertion en
 * base) est traitée côté serveur dans une prochaine étape. Ce script se
 * contente d'empêcher l'envoi d'un formulaire manifestement invalide et
 * d'afficher les messages d'erreur du design system (voir .field.is-invalid
 * dans assets/css/style.css).
 */
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('register-form');
    if (!form) return;

    const pseudo = document.getElementById('register-pseudo');
    const email = document.getElementById('register-email');
    const password = document.getElementById('register-password');
    const passwordConfirm = document.getElementById('register-password-confirm');
    const terms = document.getElementById('register-terms');

    function setValidity(input, isValid) {
        const field = input.closest('.field');
        if (!field) return;
        field.classList.toggle('is-invalid', !isValid);
    }

    function validatePasswordMatch() {
        const matches = passwordConfirm.value === '' || passwordConfirm.value === password.value;
        passwordConfirm.setCustomValidity(matches ? '' : 'Les mots de passe ne correspondent pas.');
        return matches;
    }

    // Revalide en direct dès que l'un des deux champs de mot de passe change,
    // pour prévenir l'utilisateur avant même la tentative de soumission.
    [password, passwordConfirm].forEach((input) => {
        input.addEventListener('input', () => {
            const matches = validatePasswordMatch();
            setValidity(passwordConfirm, matches || passwordConfirm.value === '');
        });
    });

    [pseudo, email, password, terms].forEach((input) => {
        input.addEventListener('input', () => setValidity(input, input.checkValidity()));
    });

    form.addEventListener('submit', (event) => {
        const passwordsMatch = validatePasswordMatch();

        [pseudo, email, password, terms].forEach((input) => {
            setValidity(input, input.checkValidity());
        });
        setValidity(passwordConfirm, passwordConfirm.checkValidity() && passwordsMatch);

        if (!form.checkValidity() || !passwordsMatch) {
            event.preventDefault();
            form.reportValidity();
        }
    });
});
