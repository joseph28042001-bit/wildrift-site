/**
 * Wild Rift Platform — Administration : gestion des champions.
 * Connecte admin/pages/champions.php à l'API existante — désormais en
 * lecture ET en écriture (voir api/champions/index.php) :
 *
 *   - GET    /api/champions/          liste (déjà présent depuis l'étape
 *                                      précédente, logique reprise ici
 *                                      telle quelle)
 *   - POST   /api/champions/          création (#admin-champion-form)
 *   - PUT    /api/champions/?id=      modification (même formulaire,
 *                                      pré-rempli via "Modifier")
 *   - DELETE /api/champions/?id=      suppression (bouton "Supprimer"
 *                                      sur chaque carte, avec confirmation)
 *
 * Étape actuelle : gestion complète des champions eux-mêmes. Ne couvre
 * pas la gestion des capacités (champion_abilities) ni aucune autre
 * ressource — hors périmètre de cette étape.
 *
 * Ce fichier n'est chargé que sur la page admin Champions (voir
 * admin/champions.php).
 *
 * `window.API_BASE_URL` est défini directement dans admin/pages/champions.php
 * (via la fonction PHP asset('api')) : cette page admin n'inclut pas le
 * footer public (voir admin/includes/footer.php, qui ne le définit pas),
 * donc il est posé localement avant le chargement de ce fichier, plutôt
 * que globalement comme includes/components/footer.php le fait pour la
 * partie publique.
 */

const ADMIN_CHAMPIONS_API_BASE = window.API_BASE_URL || '/api';

const ADMIN_CHAMPION_ROLE_LABELS = {
    baron: 'Voie Baron',
    jungle: 'Jungle',
    mid: 'Voie du Milieu',
    dragon: 'Voie Dragon',
    support: 'Support',
};

const ADMIN_CHAMPION_ROLE_BADGE_CLASSES = {
    baron: 'badge--brass',
    jungle: 'badge--verdant',
    mid: 'badge--teal',
    dragon: 'badge--crimson',
    support: '',
};

/**
 * Cache local de la dernière liste récupérée (voir loadAdminChampions()),
 * indexée par ID. Sert uniquement à pré-remplir le formulaire de
 * modification sans refaire un appel réseau dédié — la liste vient de
 * toute façon d'être chargée en entier par GET /api/champions/.
 */
let adminChampionsCache = new Map();

/**
 * Récupère la liste complète des champions depuis l'API (identique à
 * l'étape précédente).
 *
 * @returns {Promise<Array>} Champions (id, slug, name, title, role,
 *                            difficulty, cc_level, engage_level,
 *                            disengage_level, early_game_level,
 *                            late_game_level, image_url).
 */
async function fetchAdminChampions() {
    let response;
    try {
        response = await fetch(`${ADMIN_CHAMPIONS_API_BASE}/champions/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des champions.');
    }

    return payload.data;
}

/**
 * Envoie une création (POST) ou une modification (PUT ?id=) au serveur.
 * $id vaut null pour une création. Reprend l'enveloppe JSON standard de
 * l'API ({ success, data } ou { success: false, error }, voir
 * api/core/response.php) ; rejette avec une erreur dont le message est
 * toujours sûr à afficher tel quel (y compris les erreurs de validation
 * 422, ex. slug déjà utilisé).
 *
 * @returns {Promise<Object>} Le champion créé/modifié tel que renvoyé par l'API.
 */
async function saveAdminChampion(id, payload) {
    const method = id === null ? 'POST' : 'PUT';
    const url = id === null
        ? `${ADMIN_CHAMPIONS_API_BASE}/champions/`
        : `${ADMIN_CHAMPIONS_API_BASE}/champions/?id=${encodeURIComponent(id)}`;

    let response;
    try {
        response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(payload),
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let responsePayload;
    try {
        responsePayload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !responsePayload?.success) {
        throw new Error(responsePayload?.error?.message || "Erreur lors de l'enregistrement du champion.");
    }

    return responsePayload.data;
}

/**
 * Supprime un champion (DELETE ?id=). Même principe de gestion d'erreur
 * que saveAdminChampion() ci-dessus.
 */
async function deleteAdminChampion(id) {
    let response;
    try {
        response = await fetch(`${ADMIN_CHAMPIONS_API_BASE}/champions/?id=${encodeURIComponent(id)}`, {
            method: 'DELETE',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la suppression du champion.');
    }
}

/**
 * Construit la carte HTML d'un champion pour l'espace d'administration
 * (composant .card du design system). Ajoute, par rapport à l'étape
 * précédente, deux boutons d'action ("Modifier" / "Supprimer") dans le
 * pied de carte, avec l'ID du champion en attribut data-id — récupéré
 * par délégation d'événement sur la grille (voir wireAdminChampionsGrid()).
 */
function renderAdminChampionCard(champion, index) {
    const card = document.createElement('article');
    card.className = 'card card--champion';
    card.style.setProperty('--card-index', index);

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = `Champion #${champion.id}`;
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = champion.name;
    card.appendChild(title);

    if (champion.title) {
        const subtitle = document.createElement('p');
        subtitle.textContent = champion.title;
        card.appendChild(subtitle);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const roleBadge = document.createElement('span');
    const roleBadgeClass = ADMIN_CHAMPION_ROLE_BADGE_CLASSES[champion.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = ADMIN_CHAMPION_ROLE_LABELS[champion.role] || champion.role;
    foot.appendChild(roleBadge);

    const difficulty = document.createElement('span');
    difficulty.className = 'text-mono text-muted';
    difficulty.style.fontSize = 'var(--text-xs)';
    difficulty.textContent = `Difficulté : ${champion.difficulty}`;
    foot.appendChild(difficulty);

    card.appendChild(foot);

    const actions = document.createElement('div');
    actions.className = 'stack';
    actions.style.flexDirection = 'row';
    actions.style.gap = 'var(--space-2)';
    actions.style.marginTop = 'var(--space-3)';

    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'btn btn--secondary btn--sm';
    editBtn.dataset.action = 'edit';
    editBtn.dataset.id = String(champion.id);
    editBtn.textContent = 'Modifier';
    actions.appendChild(editBtn);

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'btn btn--secondary btn--sm';
    deleteBtn.dataset.action = 'delete';
    deleteBtn.dataset.id = String(champion.id);
    deleteBtn.textContent = 'Supprimer';
    actions.appendChild(deleteBtn);

    card.appendChild(actions);

    return card;
}

/**
 * Affiche la liste des champions dans #admin-champions-grid, un par un,
 * et met à jour le cache local (adminChampionsCache) utilisé par le
 * formulaire de modification.
 */
function renderAdminChampions(champions) {
    const grid = document.getElementById('admin-champions-grid');
    grid.innerHTML = '';

    adminChampionsCache = new Map(champions.map((champion) => [String(champion.id), champion]));

    champions.forEach((champion, index) => {
        grid.appendChild(renderAdminChampionCard(champion, index));
    });
}

/**
 * Recharge la liste depuis l'API et la réaffiche — appelé après chaque
 * création, modification ou suppression réussie, pour que la grille
 * (et le cache) reflètent toujours l'état réel de la base.
 */
function reloadAdminChampions() {
    const loading = document.getElementById('admin-champions-loading');
    const error = document.getElementById('admin-champions-error');

    loading.hidden = false;
    error.hidden = true;

    return fetchAdminChampions()
        .then((champions) => {
            renderAdminChampions(champions);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Lit les valeurs actuelles du formulaire et les met en forme pour
 * l'API (POST/PUT) — mêmes clés que validateChampionPayload() côté
 * serveur (voir api/champions/index.php). La difficulté est convertie
 * en nombre ; title et image_url vides deviennent null (l'API les
 * traite déjà comme optionnels, mais autant rester explicite ici).
 */
function readAdminChampionFormPayload() {
    const title = document.getElementById('admin-champion-title').value.trim();
    const imageUrl = document.getElementById('admin-champion-image-url').value.trim();

    return {
        slug: document.getElementById('admin-champion-slug').value.trim(),
        name: document.getElementById('admin-champion-name').value.trim(),
        title: title === '' ? null : title,
        role: document.getElementById('admin-champion-role').value,
        difficulty: Number(document.getElementById('admin-champion-difficulty').value),
        cc_level: document.getElementById('admin-champion-cc-level').value,
        engage_level: document.getElementById('admin-champion-engage-level').value,
        disengage_level: document.getElementById('admin-champion-disengage-level').value,
        early_game_level: document.getElementById('admin-champion-early-game-level').value,
        late_game_level: document.getElementById('admin-champion-late-game-level').value,
        image_url: imageUrl === '' ? null : imageUrl,
    };
}

/**
 * Remet le formulaire à zéro et le bascule en mode "création" : champ ID
 * vidé, titre "Ajouter un champion", tous les champs réinitialisés.
 */
function resetAdminChampionForm() {
    const form = document.getElementById('admin-champion-form');
    form.reset();
    document.getElementById('admin-champion-form-id').value = '';
    document.getElementById('admin-champion-form-title').textContent = 'Ajouter un champion';
    document.getElementById('admin-champion-form-error').hidden = true;
}

/**
 * Pré-remplit le formulaire avec les valeurs d'un champion existant et
 * le bascule en mode "modification" — les valeurs viennent du cache
 * local (adminChampionsCache), déjà à jour depuis le dernier chargement
 * de la liste.
 */
function fillAdminChampionForm(champion) {
    document.getElementById('admin-champion-form-id').value = String(champion.id);
    document.getElementById('admin-champion-form-title').textContent = `Modifier ${champion.name}`;
    document.getElementById('admin-champion-form-error').hidden = true;

    document.getElementById('admin-champion-slug').value = champion.slug;
    document.getElementById('admin-champion-name').value = champion.name;
    document.getElementById('admin-champion-title').value = champion.title || '';
    document.getElementById('admin-champion-role').value = champion.role;
    document.getElementById('admin-champion-difficulty').value = champion.difficulty;
    document.getElementById('admin-champion-cc-level').value = champion.cc_level;
    document.getElementById('admin-champion-engage-level').value = champion.engage_level;
    document.getElementById('admin-champion-disengage-level').value = champion.disengage_level;
    document.getElementById('admin-champion-early-game-level').value = champion.early_game_level;
    document.getElementById('admin-champion-late-game-level').value = champion.late_game_level;
    document.getElementById('admin-champion-image-url').value = champion.image_url || '';
}

/**
 * Câble le bouton "Ajouter un champion", le bouton "Annuler" et la
 * soumission du formulaire (création ou modification selon
 * #admin-champion-form-id) — voir le commentaire d'en-tête pour la vue
 * d'ensemble des trois états (masqué / création / modification).
 */
function wireAdminChampionForm() {
    const section = document.getElementById('admin-champion-form-section');
    const form = document.getElementById('admin-champion-form');
    const addBtn = document.getElementById('admin-champion-add-btn');
    const cancelBtn = document.getElementById('admin-champion-form-cancel');
    const submitBtn = document.getElementById('admin-champion-form-submit');
    const errorEl = document.getElementById('admin-champion-form-error');

    addBtn.addEventListener('click', () => {
        resetAdminChampionForm();
        section.hidden = false;
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    cancelBtn.addEventListener('click', () => {
        section.hidden = true;
        resetAdminChampionForm();
    });

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const idValue = document.getElementById('admin-champion-form-id').value;
        const id = idValue === '' ? null : Number(idValue);
        const payload = readAdminChampionFormPayload();

        errorEl.hidden = true;
        submitBtn.disabled = true;

        saveAdminChampion(id, payload)
            .then(() => {
                section.hidden = true;
                resetAdminChampionForm();
                return reloadAdminChampions();
            })
            .catch((err) => {
                errorEl.textContent = err.message;
                errorEl.hidden = false;
            })
            .finally(() => {
                submitBtn.disabled = false;
            });
    });
}

/**
 * Câble les boutons "Modifier"/"Supprimer" par délégation d'événement
 * sur #admin-champions-grid (les cartes sont recréées à chaque
 * chargement/rechargement, un seul écouteur suffit donc plutôt que d'en
 * reposer un par carte à chaque rendu).
 */
function wireAdminChampionsGrid() {
    const grid = document.getElementById('admin-champions-grid');

    grid.addEventListener('click', (event) => {
        const button = event.target.closest('button[data-action]');
        if (!button) return;

        const id = button.dataset.id;

        if (button.dataset.action === 'edit') {
            const champion = adminChampionsCache.get(id);
            if (!champion) return;

            fillAdminChampionForm(champion);
            const section = document.getElementById('admin-champion-form-section');
            section.hidden = false;
            section.scrollIntoView({ behavior: 'smooth', block: 'start' });
            return;
        }

        if (button.dataset.action === 'delete') {
            const champion = adminChampionsCache.get(id);
            const name = champion ? champion.name : `#${id}`;

            const confirmed = window.confirm(
                `Supprimer ${name} ? Cette action supprime aussi ses capacités, ses builds, ses matchups, ses entrées de tier list et ses synergies. Cette action est irréversible.`
            );
            if (!confirmed) return;

            button.disabled = true;

            deleteAdminChampion(id)
                .then(() => reloadAdminChampions())
                .catch((err) => {
                    window.alert(err.message);
                    button.disabled = false;
                });
        }
    });
}

/**
 * Point d'entrée : câble le formulaire et la grille, puis déclenche le
 * premier chargement de la liste.
 */
document.addEventListener('DOMContentLoaded', () => {
    wireAdminChampionForm();
    wireAdminChampionsGrid();
    reloadAdminChampions();
});
