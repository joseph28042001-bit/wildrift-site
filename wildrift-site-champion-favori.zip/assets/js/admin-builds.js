/**
 * Wild Rift Platform — Administration : gestion des builds.
 * Connecte admin/pages/builds.php à l'API existante — en lecture ET en
 * écriture (voir api/builds/index.php) :
 *
 *   - GET    /api/builds/?page=   liste paginée (BUILD_PAGE_SIZE par
 *                                 page, voir api/builds/repository.php)
 *   - GET    /api/builds/?id=     détail d'un build (champion_id,
 *                                 description, source inclus — voir
 *                                 BUILD_DETAIL_SELECT_COLUMNS), utilisé
 *                                 uniquement pour pré-remplir le
 *                                 formulaire de modification, la liste
 *                                 n'exposant pas ces champs
 *   - POST   /api/builds/         création (#admin-build-form)
 *   - PUT    /api/builds/?id=     modification (même formulaire,
 *                                 pré-rempli via "Modifier")
 *   - DELETE /api/builds/?id=     suppression (bouton "Supprimer" sur
 *                                 chaque carte, avec confirmation)
 *   - GET    /api/champions/      peuple le <select> "Champion" du
 *                                 formulaire (voir populateAdminBuildChampionOptions())
 *
 * Même principe que assets/js/admin-champions.js, assets/js/admin-items.js
 * et assets/js/admin-runes.js, pagination et sélecteur de champion en
 * plus (voir admin/pages/builds.php). Étape actuelle : gestion complète
 * des builds eux-mêmes. Ne couvre pas la gestion de leurs objets
 * (build_items), runes (build_runes) ni ordre de compétences
 * (build_skill_order) — hors périmètre de cette étape.
 *
 * Ce fichier n'est chargé que sur la page admin Builds (voir
 * admin/builds.php).
 *
 * `window.API_BASE_URL` est défini directement dans admin/pages/builds.php
 * (via la fonction PHP asset('api')) : cette page admin n'inclut pas le
 * footer public (voir admin/includes/footer.php, qui ne le définit pas),
 * donc il est posé localement avant le chargement de ce fichier, plutôt
 * que globalement comme includes/components/footer.php le fait pour la
 * partie publique.
 */

const ADMIN_BUILDS_API_BASE = window.API_BASE_URL || '/api';

/**
 * Libellés français des rôles et classe de badge associée — repris tels
 * quels de ADMIN_CHAMPION_ROLE_LABELS/BADGE_CLASSES
 * (assets/js/admin-champions.js) : builds.role partage la même ENUM que
 * champions.role (voir getBuildRoles(), api/builds/repository.php).
 */
const ADMIN_BUILD_ROLE_LABELS = {
    baron: 'Voie Baron',
    jungle: 'Jungle',
    mid: 'Voie du Milieu',
    dragon: 'Voie Dragon',
    support: 'Support',
};

const ADMIN_BUILD_ROLE_BADGE_CLASSES = {
    baron: 'badge--brass',
    jungle: 'badge--verdant',
    mid: 'badge--teal',
    dragon: 'badge--crimson',
    support: '',
};

/**
 * État courant de la page affichée — nécessaire pour que les boutons
 * Précédent/Suivant sachent quelle page demander ensuite, et pour que
 * les actions (création/modification/suppression) rechargent la même
 * page plutôt que de revenir systématiquement à la page 1. Mis à jour
 * uniquement par reloadAdminBuilds() ci-dessous.
 */
const adminBuildsState = {
    page: 1,
};

/**
 * Récupère une page de builds depuis l'API (liste : id, nom, champion,
 * rôle, patch — pas champion_id/description/source, voir
 * BUILD_SELECT_COLUMNS dans api/builds/repository.php).
 *
 * @returns {Promise<{builds: Array, pagination: Object|null}>}
 */
async function fetchAdminBuilds(page) {
    const params = new URLSearchParams();
    if (page) {
        params.set('page', String(page));
    }
    const query = params.toString();

    let response;
    try {
        response = await fetch(`${ADMIN_BUILDS_API_BASE}/builds/${query ? `?${query}` : ''}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des builds.');
    }

    return {
        builds: payload.data,
        pagination: payload.meta?.pagination || null,
    };
}

/**
 * Récupère le détail complet d'un build (id, nom, champion, champion_id,
 * rôle, patch, description, source — voir BUILD_DETAIL_SELECT_COLUMNS,
 * api/builds/repository.php). Utilisé uniquement pour pré-remplir le
 * formulaire de modification : la liste (fetchAdminBuilds()) n'expose
 * pas champion_id/description/source.
 */
async function fetchAdminBuildDetail(id) {
    let response;
    try {
        response = await fetch(`${ADMIN_BUILDS_API_BASE}/builds/?id=${encodeURIComponent(id)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération du build.');
    }

    return payload.data;
}

/**
 * Récupère la liste complète des champions (GET /api/champions/) pour
 * peupler le <select> "Champion" du formulaire — voir
 * populateAdminBuildChampionOptions() ci-dessous.
 */
async function fetchAdminBuildChampions() {
    let response;
    try {
        response = await fetch(`${ADMIN_BUILDS_API_BASE}/champions/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des champions.');
    }

    return payload.data;
}

/**
 * Envoie une création (POST) ou une modification (PUT ?id=) au serveur.
 * $id vaut null pour une création. Même principe que saveAdminChampion()/
 * saveAdminItem()/saveAdminRune().
 *
 * @returns {Promise<Object>} Le build créé/modifié tel que renvoyé par l'API.
 */
async function saveAdminBuild(id, payload) {
    const method = id === null ? 'POST' : 'PUT';
    const url = id === null
        ? `${ADMIN_BUILDS_API_BASE}/builds/`
        : `${ADMIN_BUILDS_API_BASE}/builds/?id=${encodeURIComponent(id)}`;

    let response;
    try {
        response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(payload),
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let responsePayload;
    try {
        responsePayload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !responsePayload?.success) {
        throw new Error(responsePayload?.error?.message || "Erreur lors de l'enregistrement du build.");
    }

    return responsePayload.data;
}

/**
 * Supprime un build (DELETE ?id=). Même principe de gestion d'erreur
 * que saveAdminBuild() ci-dessus.
 */
async function deleteAdminBuild(id) {
    let response;
    try {
        response = await fetch(`${ADMIN_BUILDS_API_BASE}/builds/?id=${encodeURIComponent(id)}`, {
            method: 'DELETE',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la suppression du build.');
    }
}

/**
 * Peuple le <select> "Champion" du formulaire à partir de la liste
 * complète des champions (fetchAdminBuildChampions()), triés par nom.
 * Conserve la première option ("Choisir un champion") déjà présente
 * dans le HTML (voir admin/pages/builds.php).
 */
function populateAdminBuildChampionOptions(champions) {
    const select = document.getElementById('admin-build-champion');

    const sorted = [...champions].sort((a, b) => a.name.localeCompare(b.name, 'fr'));

    sorted.forEach((champion) => {
        const option = document.createElement('option');
        option.value = String(champion.id);
        option.textContent = champion.name;
        select.appendChild(option);
    });
}

/**
 * Construit la carte HTML d'un build pour l'espace d'administration
 * (composant .card du design system). Même principe que
 * renderAdminChampionCard()/renderAdminItemCard()/renderAdminRuneCard() :
 * deux boutons d'action ("Modifier" / "Supprimer") dans le pied de
 * carte, avec l'ID du build en attribut data-id.
 */
function renderAdminBuildCard(build, index) {
    const card = document.createElement('article');
    card.className = 'card';
    card.style.setProperty('--card-index', index);

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = build.champion;
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = build.name;
    card.appendChild(title);

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const roleBadge = document.createElement('span');
    const roleBadgeClass = ADMIN_BUILD_ROLE_BADGE_CLASSES[build.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = ADMIN_BUILD_ROLE_LABELS[build.role] || build.role;
    foot.appendChild(roleBadge);

    const patch = document.createElement('span');
    patch.className = 'text-mono text-muted';
    patch.style.fontSize = 'var(--text-xs)';
    patch.textContent = `Patch ${build.patch}`;
    foot.appendChild(patch);

    card.appendChild(foot);

    const actions = document.createElement('div');
    actions.className = 'stack';
    actions.style.flexDirection = 'row';
    actions.style.gap = 'var(--space-2)';
    actions.style.marginTop = 'var(--space-3)';

    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'btn btn--secondary btn--sm';
    editBtn.dataset.action = 'edit';
    editBtn.dataset.id = String(build.id);
    editBtn.textContent = 'Modifier';
    actions.appendChild(editBtn);

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'btn btn--secondary btn--sm';
    deleteBtn.dataset.action = 'delete';
    deleteBtn.dataset.id = String(build.id);
    deleteBtn.textContent = 'Supprimer';
    actions.appendChild(deleteBtn);

    card.appendChild(actions);

    return card;
}

/**
 * Affiche la liste des builds dans #admin-builds-grid, un par un.
 * Contrairement à admin-champions.js/admin-items.js/admin-runes.js, ne
 * tient pas de cache local indexé par ID : le détail nécessaire à
 * l'édition (champion_id, description, source) n'est de toute façon
 * pas dans la liste (voir fetchAdminBuilds()) et est récupéré à la
 * demande, sur clic "Modifier" (voir fetchAdminBuildDetail() et
 * wireAdminBuildsGrid()).
 */
function renderAdminBuilds(builds) {
    const grid = document.getElementById('admin-builds-grid');
    grid.innerHTML = '';

    builds.forEach((build, index) => {
        grid.appendChild(renderAdminBuildCard(build, index));
    });
}

/**
 * Affiche ou masque #admin-builds-pagination selon le bloc pagination
 * reçu, met à jour #admin-builds-page-info ("Page X / Y") et
 * active/désactive les boutons Précédent/Suivant en conséquence — même
 * principe que renderBuildsPagination() (assets/js/builds.js, page
 * publique).
 */
function renderAdminBuildsPagination(pagination) {
    const container = document.getElementById('admin-builds-pagination');

    if (!pagination || pagination.total_pages <= 1) {
        container.hidden = true;
        return;
    }

    const info = document.getElementById('admin-builds-page-info');
    info.textContent = `Page ${pagination.page} / ${pagination.total_pages}`;

    const prev = document.getElementById('admin-builds-page-prev');
    prev.disabled = pagination.page <= 1;

    const next = document.getElementById('admin-builds-page-next');
    next.disabled = pagination.page >= pagination.total_pages;

    container.hidden = false;
}

/**
 * Recharge la page de builds demandée depuis l'API et la réaffiche —
 * appelé au chargement, sur clic Précédent/Suivant, et après chaque
 * création, modification ou suppression réussie (auquel cas la même
 * page reste affichée, voir adminBuildsState.page). $page par défaut :
 * la page courante (adminBuildsState.page).
 */
function reloadAdminBuilds(page = adminBuildsState.page) {
    const loading = document.getElementById('admin-builds-loading');
    const error = document.getElementById('admin-builds-error');

    loading.hidden = false;
    error.hidden = true;

    return fetchAdminBuilds(page)
        .then(({ builds, pagination }) => {
            adminBuildsState.page = pagination ? pagination.page : 1;
            renderAdminBuilds(builds);
            renderAdminBuildsPagination(pagination);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Lit les valeurs actuelles du formulaire et les met en forme pour
 * l'API (POST/PUT) — mêmes clés que validateBuildPayload() côté
 * serveur (voir api/builds/index.php). champion_id est converti en
 * nombre ; description et source vides deviennent null.
 */
function readAdminBuildFormPayload() {
    const description = document.getElementById('admin-build-description').value.trim();
    const source = document.getElementById('admin-build-source').value.trim();

    return {
        champion_id: Number(document.getElementById('admin-build-champion').value),
        name: document.getElementById('admin-build-name').value.trim(),
        role: document.getElementById('admin-build-role').value,
        patch: document.getElementById('admin-build-patch').value.trim(),
        description: description === '' ? null : description,
        source: source === '' ? null : source,
    };
}

/**
 * Remet le formulaire à zéro et le bascule en mode "création" : champ ID
 * vidé, titre "Ajouter un build", tous les champs réinitialisés.
 */
function resetAdminBuildForm() {
    const form = document.getElementById('admin-build-form');
    form.reset();
    document.getElementById('admin-build-form-id').value = '';
    document.getElementById('admin-build-form-title').textContent = 'Ajouter un build';
    document.getElementById('admin-build-form-error').hidden = true;
}

/**
 * Pré-remplit le formulaire avec les valeurs d'un build existant et le
 * bascule en mode "modification". Contrairement à
 * fillAdminChampionForm()/fillAdminItemForm()/fillAdminRuneForm(), ne
 * lit pas un cache local : $build vient d'un appel dédié à
 * fetchAdminBuildDetail() (voir wireAdminBuildsGrid()), la liste
 * n'exposant pas champion_id/description/source.
 */
function fillAdminBuildForm(build) {
    document.getElementById('admin-build-form-id').value = String(build.id);
    document.getElementById('admin-build-form-title').textContent = `Modifier ${build.name}`;
    document.getElementById('admin-build-form-error').hidden = true;

    document.getElementById('admin-build-champion').value = String(build.champion_id);
    document.getElementById('admin-build-name').value = build.name;
    document.getElementById('admin-build-role').value = build.role;
    document.getElementById('admin-build-patch').value = build.patch;
    document.getElementById('admin-build-description').value = build.description || '';
    document.getElementById('admin-build-source').value = build.source || '';
}

/**
 * Câble le bouton "Ajouter un build", le bouton "Annuler" et la
 * soumission du formulaire (création ou modification selon
 * #admin-build-form-id) — voir le commentaire d'en-tête pour la vue
 * d'ensemble des trois états (masqué / création / modification).
 */
function wireAdminBuildForm() {
    const section = document.getElementById('admin-build-form-section');
    const form = document.getElementById('admin-build-form');
    const addBtn = document.getElementById('admin-build-add-btn');
    const cancelBtn = document.getElementById('admin-build-form-cancel');
    const submitBtn = document.getElementById('admin-build-form-submit');
    const errorEl = document.getElementById('admin-build-form-error');

    addBtn.addEventListener('click', () => {
        resetAdminBuildForm();
        section.hidden = false;
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    cancelBtn.addEventListener('click', () => {
        section.hidden = true;
        resetAdminBuildForm();
    });

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const idValue = document.getElementById('admin-build-form-id').value;
        const id = idValue === '' ? null : Number(idValue);
        const payload = readAdminBuildFormPayload();

        errorEl.hidden = true;
        submitBtn.disabled = true;

        saveAdminBuild(id, payload)
            .then(() => {
                section.hidden = true;
                resetAdminBuildForm();
                return reloadAdminBuilds(id === null ? 1 : adminBuildsState.page);
            })
            .catch((err) => {
                errorEl.textContent = err.message;
                errorEl.hidden = false;
            })
            .finally(() => {
                submitBtn.disabled = false;
            });
    });
}

/**
 * Câble les boutons "Modifier"/"Supprimer" par délégation d'événement
 * sur #admin-builds-grid (les cartes sont recréées à chaque
 * chargement/rechargement, un seul écouteur suffit donc plutôt que d'en
 * reposer un par carte à chaque rendu). "Modifier" récupère d'abord le
 * détail complet du build (fetchAdminBuildDetail()) avant de
 * pré-remplir le formulaire — voir fillAdminBuildForm().
 */
function wireAdminBuildsGrid() {
    const grid = document.getElementById('admin-builds-grid');

    grid.addEventListener('click', (event) => {
        const button = event.target.closest('button[data-action]');
        if (!button) return;

        const id = button.dataset.id;

        if (button.dataset.action === 'edit') {
            button.disabled = true;

            fetchAdminBuildDetail(id)
                .then((build) => {
                    fillAdminBuildForm(build);
                    const section = document.getElementById('admin-build-form-section');
                    section.hidden = false;
                    section.scrollIntoView({ behavior: 'smooth', block: 'start' });
                })
                .catch((err) => {
                    window.alert(err.message);
                })
                .finally(() => {
                    button.disabled = false;
                });
            return;
        }

        if (button.dataset.action === 'delete') {
            const confirmed = window.confirm(
                'Supprimer ce build ? Cette action supprime aussi ses objets, ses runes et son ordre de compétences associés. Cette action est irréversible.'
            );
            if (!confirmed) return;

            button.disabled = true;

            deleteAdminBuild(id)
                .then(() => reloadAdminBuilds())
                .catch((err) => {
                    window.alert(err.message);
                    button.disabled = false;
                });
        }
    });
}

/**
 * Câble les boutons Précédent/Suivant (#admin-builds-page-prev/
 * #admin-builds-page-next) pour naviguer entre les pages — même
 * principe que la page publique (assets/js/builds.js), sans recherche
 * ni filtre ici.
 */
function wireAdminBuildsPagination() {
    document.getElementById('admin-builds-page-prev').addEventListener('click', () => {
        reloadAdminBuilds(adminBuildsState.page - 1);
    });

    document.getElementById('admin-builds-page-next').addEventListener('click', () => {
        reloadAdminBuilds(adminBuildsState.page + 1);
    });
}

/**
 * Point d'entrée : peuple le sélecteur de champion, câble le
 * formulaire, la grille et la pagination, puis déclenche le premier
 * chargement de la liste (page 1).
 */
document.addEventListener('DOMContentLoaded', () => {
    fetchAdminBuildChampions()
        .then((champions) => {
            populateAdminBuildChampionOptions(champions);
        })
        .catch((err) => {
            // Le sélecteur de champion reste alors limité à l'option
            // "Choisir un champion" : création/modification resteront
            // bloquées par la validation required du <select>, mais le
            // reste de la page (liste, pagination, suppression) n'a pas
            // besoin de cette liste et continue de fonctionner.
            window.alert(err.message);
        });

    wireAdminBuildForm();
    wireAdminBuildsGrid();
    wireAdminBuildsPagination();
    reloadAdminBuilds(1);
});
