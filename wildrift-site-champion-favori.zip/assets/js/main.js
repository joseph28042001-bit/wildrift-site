/**
 * Wild Rift Platform — comportements du design system.
 * Vanilla JS, sans dépendance (le projet n'utilise pas de bundler).
 * Chaque composant se déclare via des attributs data-* dans le HTML et
 * s'initialise tout seul au chargement du DOM.
 */
document.addEventListener('DOMContentLoaded', () => {
    initNavToggle();
    initDropdowns();
    initTabs();
    initModals();
    initToasts();
    initLoadingButtons();
});

/* -------------------------------------------------------------------- */
/* Menu mobile (nav-toggle)                                             */
/* -------------------------------------------------------------------- */
function initNavToggle() {
    const toggle = document.querySelector('[data-nav-toggle]');
    const nav = document.querySelector('[data-nav]');
    const overlay = document.querySelector('[data-nav-overlay]');
    if (!toggle || !nav) return;

    function setOpen(open) {
        nav.setAttribute('data-open', String(open));
        toggle.setAttribute('aria-expanded', String(open));
        toggle.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
        overlay?.setAttribute('data-open', String(open));
        // Bloque le défilement du contenu derrière le tiroir tant qu'il
        // est ouvert (uniquement pertinent sur mobile, où le tiroir
        // recouvre l'écran — sans effet ailleurs, la nav n'y étant
        // jamais ouvrable via ce bouton, caché par le CSS).
        document.body.style.overflow = open ? 'hidden' : '';
        if (!open) toggle.focus();
    }

    toggle.addEventListener('click', () => {
        setOpen(nav.getAttribute('data-open') !== 'true');
    });

    overlay?.addEventListener('click', () => setOpen(false));

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && nav.getAttribute('data-open') === 'true') {
            setOpen(false);
        }
    });
}

/* -------------------------------------------------------------------- */
/* Menus déroulants (dropdown)                                          */
/* -------------------------------------------------------------------- */
function initDropdowns() {
    const dropdowns = document.querySelectorAll('[data-dropdown]');

    dropdowns.forEach((dropdown) => {
        const trigger = dropdown.querySelector('.dropdown__trigger');
        if (!trigger) return;

        trigger.addEventListener('click', (event) => {
            event.stopPropagation();
            const isOpen = dropdown.getAttribute('data-open') === 'true';
            closeAllDropdowns();
            dropdown.setAttribute('data-open', String(!isOpen));
        });
    });

    document.addEventListener('click', closeAllDropdowns);
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') closeAllDropdowns();
    });

    function closeAllDropdowns() {
        dropdowns.forEach((dropdown) => dropdown.setAttribute('data-open', 'false'));
    }
}

/* -------------------------------------------------------------------- */
/* Onglets (tabs)                                                       */
/* -------------------------------------------------------------------- */
function initTabs() {
    document.querySelectorAll('[data-tabs]').forEach((group) => {
        const tabs = Array.from(group.querySelectorAll('.tabs__tab'));
        const panels = Array.from(group.querySelectorAll('.tabs__panel'));

        tabs.forEach((tab, index) => {
            tab.addEventListener('click', () => activate(index));
        });

        function activate(index) {
            tabs.forEach((tab, i) => tab.setAttribute('aria-selected', String(i === index)));
            panels.forEach((panel, i) => { panel.hidden = i !== index; });
        }
    });
}

/* -------------------------------------------------------------------- */
/* Modales                                                              */
/* -------------------------------------------------------------------- */
function initModals() {
    document.querySelectorAll('[data-modal-open]').forEach((opener) => {
        opener.addEventListener('click', () => {
            const backdrop = document.getElementById(opener.getAttribute('data-modal-open'));
            openModal(backdrop);
        });
    });

    document.querySelectorAll('.modal-backdrop').forEach((backdrop) => {
        backdrop.querySelectorAll('[data-modal-close]').forEach((closer) => {
            closer.addEventListener('click', () => closeModal(backdrop));
        });
        backdrop.addEventListener('click', (event) => {
            if (event.target === backdrop) closeModal(backdrop);
        });
    });

    document.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape') return;
        document.querySelectorAll('.modal-backdrop[data-open="true"]').forEach(closeModal);
    });

    let lastFocused = null;

    function openModal(backdrop) {
        if (!backdrop) return;
        lastFocused = document.activeElement;
        backdrop.setAttribute('data-open', 'true');
        const focusTarget = backdrop.querySelector('.modal');
        if (focusTarget) focusTarget.setAttribute('tabindex', '-1');
        focusTarget?.focus();
    }

    function closeModal(backdrop) {
        backdrop.setAttribute('data-open', 'false');
        lastFocused?.focus();
    }
}

/* -------------------------------------------------------------------- */
/* Notifications (toasts)                                               */
/* -------------------------------------------------------------------- */
function initToasts() {
    let region = document.querySelector('.toast-region');
    if (!region) {
        region = document.createElement('div');
        region.className = 'toast-region';
        region.setAttribute('role', 'status');
        region.setAttribute('aria-live', 'polite');
        document.body.appendChild(region);
    }

    window.showToast = function showToast({ title, body, variant = 'brass', duration = 4200 }) {
        const toast = document.createElement('div');
        toast.className = `toast toast--${variant}`;
        toast.innerHTML = `
            <button type="button" class="toast__close" aria-label="Fermer la notification">&times;</button>
            ${title ? `<div class="toast__title">${title}</div>` : ''}
            ${body ? `<div class="toast__body">${body}</div>` : ''}
            <div class="toast__timer" style="animation-duration:${duration}ms"></div>
        `;
        region.appendChild(toast);

        const timer = setTimeout(() => dismiss(), duration);
        toast.querySelector('.toast__close').addEventListener('click', () => {
            clearTimeout(timer);
            dismiss();
        });

        function dismiss() {
            toast.classList.add('is-leaving');
            toast.addEventListener('animationend', () => toast.remove(), { once: true });
        }
    };

    // Câble tout élément [data-toast] pour déclencher une démo au clic
    document.querySelectorAll('[data-toast]').forEach((trigger) => {
        trigger.addEventListener('click', () => {
            window.showToast({
                title: trigger.getAttribute('data-toast-title') || 'Notification',
                body: trigger.getAttribute('data-toast-body') || '',
                variant: trigger.getAttribute('data-toast-variant') || 'brass',
            });
        });
    });
}

/* -------------------------------------------------------------------- */
/* Boutons à état de chargement (micro-interaction de démonstration)    */
/* -------------------------------------------------------------------- */
function initLoadingButtons() {
    document.querySelectorAll('[data-loading-demo]').forEach((button) => {
        button.addEventListener('click', () => {
            if (button.classList.contains('btn--loading')) return;
            button.classList.add('btn--loading');
            setTimeout(() => button.classList.remove('btn--loading'), 1600);
        });
    });
}

/* -------------------------------------------------------------------- */
/* Liens partagés                                                       */
/* -------------------------------------------------------------------- */

/**
 * URL de la page dédiée d'un champion — SOURCE UNIQUE de ce lien pour
 * tout le site. Toute carte ou tout lien qui pointe vers un champion
 * (page Champions : assets/js/champions.js ; page Accueil :
 * assets/js/home.js) doit passer par cette fonction plutôt que de
 * reconstruire l'URL à la main, pour que le clic mène toujours à la
 * même page, quel que soit l'endroit d'où il part.
 *
 * Cible : builds.php?champion=<slug> (voir builds.php, qui route ce
 * paramètre vers pages/champion-build.php). Lien direct en query string,
 * sans dépendre d'un .htaccess racine (compatible InfinityFree).
 *
 * Appelée uniquement à l'exécution (au rendu des cartes, après
 * DOMContentLoaded) : main.js est chargé globalement dans
 * includes/components/footer.php, donc déjà disponible sur toutes les
 * pages. `window.SITE_BASE_URL` est défini juste avant, au même endroit.
 *
 * @param {string} slug Slug du champion (colonne `champions.slug`,
 *                      renvoyé par GET /api/champions/ et
 *                      GET /api/builds/ sous champion_slug).
 * @returns {string} URL de la page du champion.
 */
function getChampionPageUrl(slug) {
    return `${window.SITE_BASE_URL}builds.php?champion=${encodeURIComponent(slug)}`;
}
