/**
 * Wild Rift Platform — Page Objets.
 * Connecte la page pages/items.php à l'API existante (GET /api/items/,
 * voir api/items/index.php et api/items/repository.php) : récupère les
 * objets au chargement de la page et les affiche sous forme de cartes.
 * Câble aussi le formulaire de recherche par nom et de filtre par
 * catégorie (#items-search-form) sur les paramètres ?search= et
 * ?category= déjà supportés par l'API (combinables), qui relancent
 * simplement la même récupération avec ces critères — même principe que
 * assets/js/champions.js.
 *
 * Ce fichier n'est chargé que sur la page Objets (voir items.php) —
 * contrairement à assets/js/news.js, chargé globalement, il n'y a pas
 * lieu d'exécuter ce code sur les autres pages, qui n'ont pas les
 * éléments #items-* attendus ci-dessous.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

/**
 * Libellés français des catégories d'objets (voir getItemCategories()
 * côté API, api/items/repository.php — 'enchantment' y figure aussi,
 * dans l'ENUM `category` de database/schema.sql, bien que
 * getItemCategories() ne le liste pas encore parmi les valeurs
 * acceptées par ?category= : sans incidence ici, la liste complète sans
 * filtre renvoie ces objets comme les autres — le select de filtre
 * (#items-category-filter, pages/items.php) n'en propose d'ailleurs pas
 * l'option, pour rester aligné avec les catégories que l'API accepte
 * réellement en filtre) et classe de badge associée (voir
 * assets/css/style.css) — 4 couleurs disponibles pour 7 catégories,
 * certaines en partagent une.
 */
const ITEM_CATEGORY_LABELS = {
    attack: 'Attaque',
    magic: 'Magie',
    defense: 'Défense',
    boots: 'Bottes',
    jungle: 'Jungle',
    consumable: 'Consommable',
    enchantment: 'Enchantement',
};

const ITEM_CATEGORY_BADGE_CLASSES = {
    attack: 'badge--crimson',
    magic: 'badge--teal',
    defense: 'badge--verdant',
    boots: 'badge--brass',
    jungle: 'badge--verdant',
    consumable: 'badge--brass',
    enchantment: 'badge--teal',
};

/**
 * Récupère la liste des objets depuis l'API, avec un terme de recherche
 * et un filtre par catégorie optionnels (GET /api/items/?search=&category=,
 * voir api/items/index.php et api/items/repository.php :: findItems() —
 * les deux filtres sont combinables côté API). Reprend l'enveloppe JSON
 * standard de l'API ({ success, data, meta }) — voir
 * api/core/response.php : en cas de succès, renvoie le tableau d'objets
 * (data) ; en cas d'échec (HTTP ou réseau), le rejette avec une erreur
 * dont le message est toujours sûr à afficher tel quel.
 *
 * @param {string} [search] Terme recherché dans le nom de l'objet.
 * @param {string} [category] Catégorie d'objet (voir getItemCategories()
 *                            côté API). Omis ou vide : pas de filtre par
 *                            catégorie.
 * @returns {Promise<Array>} Objets (id, slug, name, category, price,
 *                            description, image_url).
 */
async function fetchItems(search, category) {
    const base = window.API_BASE_URL || '/api';

    const params = new URLSearchParams();
    if (search) {
        params.set('search', search);
    }
    if (category) {
        params.set('category', category);
    }
    const query = params.toString();
    const url = `${base}/items/${query ? `?${query}` : ''}`;

    let response;
    try {
        response = await fetch(url, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des objets.');
    }

    return payload.data;
}

/**
 * Construit la carte HTML d'un objet (composant .card du design system —
 * voir assets/css/style.css et pages/styleguide.php pour le modèle repris
 * ici). N'insère aucune valeur non échappée : toutes les données viennent
 * de l'API, mais restent traitées comme non sûres côté affichage
 * (textContent, jamais innerHTML sur une valeur dynamique).
 */
function renderItemCard(item) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = 'Objet';
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = item.name;
    card.appendChild(title);

    if (item.description) {
        const description = document.createElement('p');
        description.textContent = item.description;
        card.appendChild(description);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const categoryBadge = document.createElement('span');
    const categoryBadgeClass = ITEM_CATEGORY_BADGE_CLASSES[item.category] || '';
    categoryBadge.className = categoryBadgeClass ? `badge ${categoryBadgeClass}` : 'badge';
    categoryBadge.textContent = ITEM_CATEGORY_LABELS[item.category] || item.category;
    foot.appendChild(categoryBadge);

    const price = document.createElement('span');
    price.className = 'text-mono text-muted';
    price.style.fontSize = 'var(--text-xs)';
    price.textContent = item.price !== null ? `${item.price.toLocaleString('fr-FR')} or` : 'Prix inconnu';
    foot.appendChild(price);

    card.appendChild(foot);

    return card;
}

/**
 * Affiche la liste des objets dans #items-grid, un par un
 * (renderItemCard() ci-dessus). Ne fait rien d'autre : la bascule de
 * l'état de chargement/erreur est gérée par l'appelant.
 */
function renderItems(items) {
    const grid = document.getElementById('items-grid');
    grid.innerHTML = '';

    items.forEach((item) => {
        grid.appendChild(renderItemCard(item));
    });
}

/**
 * Déclenche la récupération des objets (avec le terme de recherche et
 * la catégorie courants, s'il y en a) et bascule entre les trois états
 * possibles (chargement → succès ou erreur). Factorisé pour être
 * appelé aussi bien au chargement de la page qu'à chaque soumission du
 * formulaire de recherche/filtre ci-dessous — même principe que
 * loadChampions() (assets/js/champions.js).
 *
 * @param {string} [search] Terme recherché, voir fetchItems().
 * @param {string} [category] Catégorie filtrée, voir fetchItems().
 */
function loadItems(search, category) {
    const loading = document.getElementById('items-loading');
    const error = document.getElementById('items-error');

    loading.hidden = false;
    error.hidden = true;

    fetchItems(search, category)
        .then((items) => {
            renderItems(items);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Point d'entrée : déclenche la récupération initiale (sans filtre) au
 * chargement de la page, puis câble le formulaire de recherche/filtre
 * (#items-search-form) pour relancer la récupération avec le terme
 * et/ou la catégorie sélectionnés à chaque soumission, et le bouton de
 * réinitialisation (#items-search-reset) pour revenir à la liste
 * complète — même principe que assets/js/champions.js.
 */
document.addEventListener('DOMContentLoaded', () => {
    loadItems();

    const form = document.getElementById('items-search-form');
    const input = document.getElementById('items-search-input');
    const categoryFilter = document.getElementById('items-category-filter');
    const reset = document.getElementById('items-search-reset');

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        loadItems(input.value.trim(), categoryFilter.value);
    });

    reset.addEventListener('click', () => {
        input.value = '';
        categoryFilter.value = '';
        loadItems();
    });
});
