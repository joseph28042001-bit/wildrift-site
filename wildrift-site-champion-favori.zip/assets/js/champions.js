/**
 * Wild Rift Platform — Page Champions.
 * Connecte la page pages/champions.php à l'API existante
 * (GET /api/champions/, voir api/champions/index.php et
 * api/champions/repository.php) : récupère les champions au chargement
 * de la page et les affiche sous forme de cartes visuelles (photo du
 * champion quand l'API en fournit une, via le composant .card__media du
 * design system). Câble aussi le formulaire de recherche par nom et de
 * filtre par rôle
 * (#champions-search-form) sur les paramètres ?search= et ?role= déjà
 * supportés par l'API (combinables), qui relancent simplement la même
 * récupération avec ces critères.
 *
 * Ce fichier n'est chargé que sur la page Champions (voir champions.php) —
 * contrairement à assets/js/news.js, chargé globalement, il n'y a pas lieu
 * d'exécuter ce code sur les autres pages, qui n'ont pas les éléments
 * #champions-* attendus ci-dessous.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

/**
 * Libellés français des rôles Wild Rift (voir getChampionRoles() côté API,
 * api/champions/repository.php) et classe de badge associée (voir
 * assets/css/style.css) : chaque rôle a sa propre couleur, 'support'
 * reprend le badge neutre (pas de modificateur dédié dans le design
 * system actuel).
 */
const CHAMPION_ROLE_LABELS = {
    baron: 'Voie Baron',
    jungle: 'Jungle',
    mid: 'Voie du Milieu',
    dragon: 'Voie Dragon',
    support: 'Support',
};

const CHAMPION_ROLE_BADGE_CLASSES = {
    baron: 'badge--brass',
    jungle: 'badge--verdant',
    mid: 'badge--teal',
    dragon: 'badge--crimson',
    support: '',
};

/**
 * Récupère la liste complète des champions depuis l'API.
 * Reprend l'enveloppe JSON standard de l'API ({ success, data, meta }) —
 * voir api/core/response.php : en cas de succès, renvoie le tableau de
 * champions (data) ; en cas d'échec (HTTP ou réseau), le rejette avec
 * une erreur dont le message est toujours sûr à afficher tel quel.
 *
 * @returns {Promise<Array>} Champions (id, slug, name, title, role,
 *                            difficulty, image_url).
 */
/**
 * Récupère la liste des champions depuis l'API, avec un terme de
 * recherche et un filtre par rôle optionnels (GET
 * /api/champions/?search=&role=, voir api/champions/index.php et
 * api/champions/repository.php :: findChampions() — les deux filtres
 * sont combinables côté API). Reprend l'enveloppe JSON standard de
 * l'API ({ success, data, meta }) — voir api/core/response.php : en cas
 * de succès, renvoie le tableau de champions (data) ; en cas d'échec
 * (HTTP ou réseau), le rejette avec une erreur dont le message est
 * toujours sûr à afficher tel quel.
 *
 * @param {string} [search] Terme recherché dans le nom du champion.
 * @param {string} [role] Rôle Wild Rift (voir getChampionRoles() côté
 *                        API). Omis ou vide : pas de filtre par rôle.
 * @returns {Promise<Array>} Champions (id, slug, name, title, role,
 *                            difficulty, image_url).
 */
async function fetchChampions(search, role) {
    const base = window.API_BASE_URL || '/api';

    const params = new URLSearchParams();
    if (search) {
        params.set('search', search);
    }
    if (role) {
        params.set('role', role);
    }
    const query = params.toString();
    const url = `${base}/champions/${query ? `?${query}` : ''}`;

    let response;
    try {
        response = await fetch(url, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des champions.');
    }

    return payload.data;
}

/**
 * Construit la carte HTML d'un champion (composant .card du design
 * system — voir assets/css/style.css et pages/styleguide.php pour le
 * modèle repris ici). N'insère aucune valeur non échappée : toutes les
 * données viennent de l'API, mais restent traitées comme non sûres côté
 * affichage (textContent, jamais innerHTML sur une valeur dynamique).
 *
 * Navigation champion → build : la carte entière est un lien vers
 * builds.php?champion=<slug du champion>, ex. builds.php?champion=syndra
 * — builds.php (voir à la racine du projet) route déjà ce paramètre vers
 * pages/champion-build.php. L'URL est construite par
 * getChampionPageUrl() (assets/js/main.js), fonction partagée avec la
 * page Accueil (assets/js/home.js) pour que les deux mènent exactement
 * à la même page. Lien en query string directe plutôt qu'une
 * URL réécrite (/builds/<slug>) : aucun .htaccess racine n'est présent
 * dans cet export pour effectuer cette réécriture, et ce lien direct
 * fonctionne de façon fiable sans dépendre de mod_rewrite (compatible
 * hébergement mutualisé type InfinityFree). C'est pourquoi l'élément
 * racine est un <a> (mêmes classes .card .card--champion qu'auparavant)
 * plutôt qu'un <article> : aucun ajustement CSS n'est nécessaire, cette
 * carte étant un enfant direct de .grid (display: grid), qui blockifie
 * déjà tout enfant — le rendu est donc strictement identique à
 * l'<article> précédent.
 */
function renderChampionCard(champion, index) {
    const card = document.createElement('a');
    card.className = 'card card--champion';
    card.href = getChampionPageUrl(champion.slug);
    // Utilisé par assets/css/style.css (section 26) pour échelonner
    // l'animation d'entrée de chaque carte au chargement de la grille.
    card.style.setProperty('--card-index', index);

    // Visuel du champion (composant .card__media du design system — voir
    // assets/css/style.css section 7) : un fond en dégradé est déjà prévu
    // par ce composant pour les cas sans image, donc l'élément <img> n'est
    // ajouté que si l'API renvoie une image_url ; en cas d'échec de
    // chargement de l'image (URL cassée), il est retiré pour ne laisser
    // apparaître que ce fond de secours plutôt qu'une icône d'image brisée.
    if (champion.image_url) {
        const media = document.createElement('div');
        media.className = 'card__media';

        const image = document.createElement('img');
        image.src = champion.image_url;
        image.alt = champion.name;
        image.loading = 'lazy';
        image.addEventListener('error', () => {
            image.remove();
        });

        media.appendChild(image);
        card.appendChild(media);
    }

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = 'Champion';
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = champion.name;
    card.appendChild(title);

    if (champion.title) {
        const subtitle = document.createElement('p');
        subtitle.textContent = champion.title;
        card.appendChild(subtitle);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const roleBadge = document.createElement('span');
    const roleBadgeClass = CHAMPION_ROLE_BADGE_CLASSES[champion.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = CHAMPION_ROLE_LABELS[champion.role] || champion.role;
    foot.appendChild(roleBadge);

    const difficulty = document.createElement('span');
    difficulty.className = 'text-mono text-muted';
    difficulty.style.fontSize = 'var(--text-xs)';
    difficulty.textContent = `Difficulté : ${champion.difficulty}`;
    foot.appendChild(difficulty);

    card.appendChild(foot);

    return card;
}

/**
 * Affiche la liste des champions dans #champions-grid, un par un
 * (renderChampionCard() ci-dessus). Ne fait rien d'autre : la bascule de
 * l'état de chargement/erreur est gérée par l'appelant.
 */
function renderChampions(champions) {
    const grid = document.getElementById('champions-grid');
    grid.innerHTML = '';

    champions.forEach((champion, index) => {
        grid.appendChild(renderChampionCard(champion, index));
    });
}

/**
 * Déclenche la récupération des champions (avec le terme de recherche et
 * le rôle courants, s'il y en a) et bascule entre les trois états
 * possibles (chargement → succès ou erreur). Factorisé pour être appelé
 * aussi bien au chargement de la page qu'à chaque soumission du
 * formulaire de recherche/filtre ci-dessous.
 *
 * @param {string} [search] Terme recherché, voir fetchChampions().
 * @param {string} [role] Rôle filtré, voir fetchChampions().
 */
function loadChampions(search, role) {
    const loading = document.getElementById('champions-loading');
    const error = document.getElementById('champions-error');

    loading.hidden = false;
    error.hidden = true;

    fetchChampions(search, role)
        .then((champions) => {
            renderChampions(champions);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Point d'entrée : déclenche la récupération initiale (sans filtre) au
 * chargement de la page, puis câble le formulaire de recherche/filtre
 * (#champions-search-form) pour relancer la récupération avec le terme
 * et/ou le rôle sélectionnés à chaque soumission, et le bouton de
 * réinitialisation (#champions-search-reset) pour revenir à la liste
 * complète.
 */
document.addEventListener('DOMContentLoaded', () => {
    loadChampions();

    const form = document.getElementById('champions-search-form');
    const input = document.getElementById('champions-search-input');
    const roleFilter = document.getElementById('champions-role-filter');
    const reset = document.getElementById('champions-search-reset');

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        loadChampions(input.value.trim(), roleFilter.value);
    });

    reset.addEventListener('click', () => {
        input.value = '';
        roleFilter.value = '';
        loadChampions();
    });
});
