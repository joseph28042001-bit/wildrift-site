/**
 * Wild Rift Platform — Administration : tableau de bord.
 * Connecte admin/pages/dashboard.php aux API publiques déjà existantes
 * pour afficher un compteur par ressource (Champions, Objets, Builds,
 * Matchups, Runes, Tier List, Actualités, Patches) — chaque carte de
 * #admin-dashboard-stats (voir admin/pages/dashboard.php) est peuplée
 * indépendamment de sa propre requête, contrairement à
 * assets/js/admin-champions.js / admin-items.js (une seule liste, un
 * seul état de chargement/erreur global) : ici, l'échec d'une ressource
 * n'empêche pas l'affichage des compteurs déjà revenus pour les autres.
 *
 * Étape actuelle : uniquement la consultation des compteurs. Aucune
 * action de gestion n'est câblée ici — hors périmètre de cette étape.
 *
 * Ce fichier n'est chargé que sur le tableau de bord admin (voir
 * admin/index.php).
 *
 * `window.API_BASE_URL` est défini directement dans
 * admin/pages/dashboard.php (via la fonction PHP asset('api')) — même
 * principe que admin/pages/champions.php et admin/pages/items.php.
 */

const ADMIN_DASHBOARD_API_BASE = window.API_BASE_URL || '/api';

/**
 * Une entrée par carte de statistique : identifiant de l'élément à
 * remplir (voir admin/pages/dashboard.php), chemin de l'API à
 * interroger, et fonction extrayant le compteur de l'enveloppe JSON
 * standard de l'API ({ success, data, meta }, voir
 * api/core/response.php). La plupart des ressources ne sont pas
 * paginées : le compteur est alors simplement `data.length`. Les
 * builds font exception (BUILD_PAGE_SIZE par page — voir
 * api/builds/repository.php) : le total exact vient de
 * meta.pagination.total plutôt que de la longueur de la première page.
 */
const ADMIN_DASHBOARD_STATS = [
    {
        elementId: 'admin-dashboard-stat-champions',
        endpoint: '/champions/',
        extractCount: (payload) => payload.data.length,
    },
    {
        elementId: 'admin-dashboard-stat-items',
        endpoint: '/items/',
        extractCount: (payload) => payload.data.length,
    },
    {
        elementId: 'admin-dashboard-stat-builds',
        endpoint: '/builds/',
        extractCount: (payload) => payload.meta?.pagination?.total ?? payload.data.length,
    },
    {
        elementId: 'admin-dashboard-stat-counters',
        endpoint: '/counters/',
        extractCount: (payload) => payload.data.length,
    },
    {
        elementId: 'admin-dashboard-stat-runes',
        endpoint: '/runes/',
        extractCount: (payload) => payload.data.length,
    },
    {
        elementId: 'admin-dashboard-stat-tier-list',
        endpoint: '/tier-list/',
        extractCount: (payload) => payload.data.length,
    },
    {
        elementId: 'admin-dashboard-stat-news',
        endpoint: '/news/',
        extractCount: (payload) => payload.data.length,
    },
    {
        elementId: 'admin-dashboard-stat-patches',
        endpoint: '/patches/',
        extractCount: (payload) => payload.data.length,
    },
];

/**
 * Récupère et extrait un seul compteur. Reprend l'enveloppe JSON
 * standard de l'API ({ success, data, meta } ou
 * { success: false, error }), même principe que les autres pages
 * admin — mais rejette avec une erreur par ressource plutôt que
 * d'interrompre les autres requêtes en cours.
 *
 * @returns {Promise<number>}
 */
async function fetchDashboardStatCount(stat) {
    let response;
    try {
        response = await fetch(`${ADMIN_DASHBOARD_API_BASE}${stat.endpoint}`);
    } catch (err) {
        throw new Error('Serveur injoignable.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (err) {
        throw new Error('Réponse invalide.');
    }

    if (!response.ok || !payload.success) {
        const message = payload && payload.error && payload.error.message;
        throw new Error(message || 'Erreur.');
    }

    return stat.extractCount(payload);
}

/**
 * Affiche le résultat d'une carte de statistique : le compteur formaté
 * (séparateur de milliers en français) en cas de succès, ou un tiret
 * accompagné d'un message d'erreur discret en cas d'échec — jamais de
 * blocage global de la page pour l'échec d'une seule ressource.
 */
function renderDashboardStat(stat, result) {
    const element = document.getElementById(stat.elementId);
    if (!element) return;

    element.textContent = '';

    if (result.status === 'fulfilled') {
        element.textContent = result.value.toLocaleString('fr-FR');
        return;
    }

    element.textContent = '—';
    element.title = result.reason?.message || 'Erreur lors du chargement.';
    element.style.color = 'var(--color-crimson)';
}

/**
 * Point d'entrée : lance toutes les requêtes en parallèle
 * (Promise.allSettled, pas Promise.all) précisément pour qu'une
 * ressource indisponible n'empêche pas l'affichage des compteurs des
 * autres — voir le commentaire d'en-tête de ce fichier.
 */
document.addEventListener('DOMContentLoaded', () => {
    ADMIN_DASHBOARD_STATS.forEach(async (stat) => {
        const [result] = await Promise.allSettled([fetchDashboardStatCount(stat)]);
        renderDashboardStat(stat, result);
    });
});
