/**
 * Wild Rift Platform — Administration : publication/dépublication des articles.
 * Connecte admin/pages/news.php à l'API existante :
 *
 *   - GET   /api/news/?all=1   liste complète (brouillons inclus, voir
 *                               findAllNewsForAdmin(), api/news/repository.php)
 *   - PATCH /api/news/?id=     bascule l'état de publication d'un article
 *                               (corps JSON { "published": true|false })
 *
 * Étape actuelle : uniquement la publication/dépublication. Pas de
 * création, modification de contenu ni suppression d'article — hors
 * périmètre de cette étape.
 *
 * Ce fichier n'est chargé que sur la page admin Actualités (voir
 * admin/news.php).
 *
 * `window.API_BASE_URL` est défini directement dans admin/pages/news.php
 * (via la fonction PHP asset('api')) — même principe que
 * assets/js/admin-champions.js.
 */

const ADMIN_NEWS_API_BASE = window.API_BASE_URL || '/api';

// Même mapping catégorie → libellé/couleur que la page publique
// (assets/js/news.js), pour un affichage cohérent entre les deux.
const ADMIN_NEWS_CATEGORY_LABELS = {
    patch: 'Patch',
    esport: 'Esport',
    evenement: 'Événement',
    communaute: 'Communauté',
};

const ADMIN_NEWS_CATEGORY_BADGE_CLASSES = {
    patch: 'badge--teal',
    esport: 'badge--crimson',
    evenement: 'badge--brass',
    communaute: 'badge--verdant',
};

/**
 * Récupère tous les articles (publiés et brouillons) depuis l'API.
 *
 * @returns {Promise<Array>} Articles (id, slug, title, excerpt,
 *                            category, image_url, published_at).
 */
async function fetchAdminNews() {
    let response;
    try {
        response = await fetch(`${ADMIN_NEWS_API_BASE}/news/?all=1`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des articles.');
    }

    return payload.data;
}

/**
 * Publie ou dépublie un article (PATCH ?id=). Reprend l'enveloppe JSON
 * standard de l'API ({ success, data } ou { success: false, error },
 * voir api/core/response.php) ; rejette avec une erreur dont le message
 * est toujours sûr à afficher tel quel.
 *
 * @returns {Promise<Object>} L'article mis à jour tel que renvoyé par l'API.
 */
async function setAdminNewsPublishState(id, published) {
    let response;
    try {
        response = await fetch(`${ADMIN_NEWS_API_BASE}/news/?id=${encodeURIComponent(id)}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ published }),
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let responsePayload;
    try {
        responsePayload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !responsePayload?.success) {
        throw new Error(responsePayload?.error?.message || "Erreur lors de la mise à jour de l'article.");
    }

    return responsePayload.data;
}

/**
 * Construit la carte d'un article : titre, catégorie, état de
 * publication et le bouton qui bascule cet état.
 */
function renderAdminNewsItem(article) {
    const card = document.createElement('article');
    card.className = 'card';
    card.style.padding = 'var(--space-4)';

    const isPublished = Boolean(article.published_at);
    const categoryLabel = ADMIN_NEWS_CATEGORY_LABELS[article.category] || article.category;
    const categoryBadgeClass = ADMIN_NEWS_CATEGORY_BADGE_CLASSES[article.category] || '';

    const row = document.createElement('div');
    row.className = 'stack';
    row.style.flexDirection = 'row';
    row.style.alignItems = 'center';
    row.style.justifyContent = 'space-between';
    row.style.gap = 'var(--space-3)';
    row.style.flexWrap = 'wrap';

    const info = document.createElement('div');
    info.innerHTML = `
        <strong>${escapeAdminNewsHtml(article.title)}</strong>
        <div class="stack" style="flex-direction: row; gap: var(--space-2); margin-top: var(--space-2); align-items: center; flex-wrap: wrap;">
            <span class="badge ${categoryBadgeClass}">${escapeAdminNewsHtml(categoryLabel)}</span>
            <span class="badge ${isPublished ? 'badge--verdant' : ''}">${isPublished ? 'Publié' : 'Brouillon'}</span>
        </div>
    `;

    const toggleBtn = document.createElement('button');
    toggleBtn.type = 'button';
    toggleBtn.className = `btn btn--sm ${isPublished ? 'btn--secondary' : ''}`;
    toggleBtn.textContent = isPublished ? 'Dépublier' : 'Publier';
    toggleBtn.addEventListener('click', () => handleAdminNewsToggle(article.id, !isPublished, toggleBtn));

    row.appendChild(info);
    row.appendChild(toggleBtn);
    card.appendChild(row);

    return card;
}

/**
 * Échappe une chaîne pour une insertion sûre via innerHTML (titre/
 * catégorie viennent de l'API, jamais de saisie utilisateur directe ici,
 * mais on reste prudent).
 */
function escapeAdminNewsHtml(value) {
    const div = document.createElement('div');
    div.textContent = value ?? '';
    return div.innerHTML;
}

/**
 * Gère le clic sur le bouton Publier/Dépublier : désactive le bouton
 * pendant l'appel, puis recharge la liste complète pour refléter le
 * nouvel état.
 */
async function handleAdminNewsToggle(id, nextPublished, button) {
    const errorEl = document.getElementById('admin-news-error');
    errorEl.hidden = true;

    button.disabled = true;

    try {
        await setAdminNewsPublishState(id, nextPublished);
        await loadAdminNews();
    } catch (error) {
        errorEl.textContent = error.message;
        errorEl.hidden = false;
        button.disabled = false;
    }
}

/**
 * Charge et affiche la liste complète des articles.
 */
async function loadAdminNews() {
    const loadingEl = document.getElementById('admin-news-loading');
    const errorEl = document.getElementById('admin-news-error');
    const listEl = document.getElementById('admin-news-list');

    loadingEl.hidden = false;
    errorEl.hidden = true;
    listEl.innerHTML = '';

    try {
        const articles = await fetchAdminNews();

        if (articles.length === 0) {
            listEl.innerHTML = '<p class="text-muted">Aucun article enregistré.</p>';
        } else {
            articles.forEach((article) => {
                listEl.appendChild(renderAdminNewsItem(article));
            });
        }
    } catch (error) {
        errorEl.textContent = error.message;
        errorEl.hidden = false;
    } finally {
        loadingEl.hidden = true;
    }
}

document.addEventListener('DOMContentLoaded', loadAdminNews);
