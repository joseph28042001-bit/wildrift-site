/**
 * Wild Rift Platform — Page Champion (détail).
 * Connecte la page pages/champion.php à l'API existante
 * (GET /api/champions/?id=, voir api/champions/index.php et
 * api/champions/repository.php :: findChampionById()) : lit l'ID du
 * champion dans l'URL (?id=), récupère sa fiche au chargement de la
 * page et l'affiche.
 *
 * Ce fichier n'est chargé que sur la page Champion (voir champion.php) —
 * contrairement à assets/js/news.js, chargé globalement, il n'y a pas
 * lieu d'exécuter ce code sur les autres pages, qui n'ont pas les
 * éléments #champion-* attendus ci-dessous.
 *
 * Reprend volontairement les libellés/classes de rôle et le rendu visuel
 * de assets/js/champions.js (mêmes CHAMPION_ROLE_LABELS/BADGE_CLASSES,
 * même composant .card__media pour l'image) plutôt que de les importer :
 * ce fichier n'est chargé que sur cette page, séparément de champions.js.
 *
 * Affiche aussi les statistiques du champion (tier — voir
 * assets/css/style.css, badges S→D — patch, taux de
 * victoire/sélection/bannissement), une fois la fiche chargée, via une
 * seconde requête à GET /api/tier-list/?champion=<slug> (voir
 * api/tier-list/index.php et api/tier-list/repository.php) : le slug du
 * champion sert de clé de filtre, comme sur pages/tier-list.php/
 * assets/js/tier-list.js.
 *
 * Affiche également les capacités du champion (GET
 * /api/abilities/?champion=<slug>) et ses builds recommandés (GET
 * /api/builds/?champion=<slug>, filtre déjà pris en charge par la
 * ressource existante — voir api/builds/index.php), toujours par le
 * même slug, chacune dans sa propre section indépendante.
 *
 * Affiche les counters du champion (Matchups & counters), via
 * GET /api/counters/?champion_id=<id> (filtre déjà pris en charge par
 * la ressource existante — voir api/counters/index.php) : cette
 * connexion utilise l'ID du champion plutôt que son slug, l'API
 * /api/counters/ ne filtrant que par ID (voir
 * api/counters/repository.php).
 *
 * Affiche enfin les synergies d'équipe du champion, via GET
 * /api/synergies/?champion_id=<id> (filtre déjà pris en charge par la
 * ressource existante — voir api/synergies/index.php) : même principe
 * que les counters ci-dessus (filtre par ID, pas par slug), mais sans
 * difficulté ni objets recommandés associés.
 *
 * `window.API_BASE_URL` est défini dans includes/components/footer.php
 * (via la fonction PHP asset()) pour que ce fichier statique fonctionne
 * quel que soit le sous-dossier d'installation du site.
 */

const CHAMPION_DETAIL_ROLE_LABELS = {
    baron: 'Voie Baron',
    jungle: 'Jungle',
    mid: 'Voie du Milieu',
    dragon: 'Voie Dragon',
    support: 'Support',
};

const CHAMPION_DETAIL_ROLE_BADGE_CLASSES = {
    baron: 'badge--brass',
    jungle: 'badge--verdant',
    mid: 'badge--teal',
    dragon: 'badge--crimson',
    support: '',
};

/**
 * Classe de badge associée à chaque tier (S→D), reprise de
 * assets/js/tier-list.js::HOME_TIER_LIST_TIER_BADGE_CLASSES /
 * assets/js/home.js pour une cohérence visuelle avec la page Tier List.
 */
const CHAMPION_STATS_TIER_BADGE_CLASSES = {
    'S+': 'badge--crimson',
    S: 'badge--crimson',
    A: 'badge--brass',
    B: 'badge--teal',
    C: 'badge--verdant',
    D: '',
};

/**
 * Lit et valide l'ID de champion depuis l'URL courante (?id=).
 * Validation minimale côté client (entier positif) : l'API revalide de
 * toute façon l'ID (voir apiValidateInt(), api/champions/index.php) et
 * renvoie une erreur explicite si besoin ; cette vérification évite
 * simplement un appel réseau inutile pour un cas manifestement invalide.
 *
 * @returns {number} L'ID demandé.
 * @throws {Error} Si l'ID est absent ou n'est pas un entier positif.
 */
function getRequestedChampionId() {
    const params = new URLSearchParams(window.location.search);
    const raw = params.get('id');

    if (!raw || !/^\d+$/.test(raw) || Number(raw) < 1) {
        throw new Error("Aucun champion valide n'a été demandé.");
    }

    return Number(raw);
}

/**
 * Récupère la fiche d'un champion depuis l'API (GET /api/champions/?id=).
 * Reprend l'enveloppe JSON standard de l'API ({ success, data, meta }) —
 * voir api/core/response.php : en cas de succès, renvoie le champion
 * (data) ; en cas d'échec (HTTP, champion introuvable ou réseau), le
 * rejette avec une erreur dont le message est toujours sûr à afficher
 * tel quel (voir notFound(), ApiException, api/champions/index.php).
 *
 * @param {number} id Identifiant du champion.
 * @returns {Promise<Object>} Le champion (id, slug, name, title, role,
 *                             difficulty, image_url).
 */
async function fetchChampionDetail(id) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/champions/?id=${encodeURIComponent(id)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération du champion.');
    }

    return payload.data;
}

/**
 * Remplit #champion-detail avec la fiche du champion (composant .card du
 * design system, variante .card--champion — voir assets/js/champions.js
 * pour le modèle repris ici). Image (si fournie), nom, titre, rôle et
 * difficulté, dans le même ordre que les cartes de la liste.
 */
function renderChampionDetail(champion) {
    const detail = document.getElementById('champion-detail');
    detail.innerHTML = '';

    if (champion.image_url) {
        const media = document.createElement('div');
        media.className = 'card__media';

        const image = document.createElement('img');
        image.src = champion.image_url;
        image.alt = champion.name;
        image.addEventListener('error', () => {
            image.remove();
        });

        media.appendChild(image);
        detail.appendChild(media);
    }

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = 'Champion';
    detail.appendChild(eyebrow);

    const title = document.createElement('h1');
    title.className = 'card__title';
    title.textContent = champion.name;
    detail.appendChild(title);

    if (champion.title) {
        const subtitle = document.createElement('p');
        subtitle.textContent = champion.title;
        detail.appendChild(subtitle);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const roleBadge = document.createElement('span');
    const roleBadgeClass = CHAMPION_DETAIL_ROLE_BADGE_CLASSES[champion.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = CHAMPION_DETAIL_ROLE_LABELS[champion.role] || champion.role;
    foot.appendChild(roleBadge);

    const difficulty = document.createElement('span');
    difficulty.className = 'text-mono text-muted';
    difficulty.style.fontSize = 'var(--text-xs)';
    difficulty.textContent = `Difficulté : ${champion.difficulty}`;
    foot.appendChild(difficulty);

    detail.appendChild(foot);

    detail.hidden = false;
}

/**
 * Récupère les entrées de tier list associées à un champion, par son
 * slug (GET /api/tier-list/?champion=, voir api/tier-list/index.php et
 * api/tier-list/repository.php :: findTierList()). Reprend l'enveloppe
 * JSON standard de l'API : en cas de succès, renvoie le tableau
 * d'entrées (éventuellement vide, un champion peut n'avoir aucune
 * statistique renseignée) ; en cas d'échec (HTTP ou réseau), le rejette
 * avec une erreur dont le message est toujours sûr à afficher tel quel.
 *
 * Filtrée par défaut sur le patch actif du site (window.CURRENT_PATCH,
 * voir includes/components/header.php et config/patch.php), pour que
 * les statistiques affichées sur la fiche champion restent dans le
 * contexte du patch en cours.
 *
 * @param {string} slug Slug du champion (colonne `slug`, champions).
 * @returns {Promise<Array>} Entrées de tier list (id, champion, role,
 *                            tier, patch, win_rate, pick_rate, ban_rate).
 */
async function fetchChampionStats(slug) {
    const base = window.API_BASE_URL || '/api';

    const params = new URLSearchParams({ champion: slug });
    if (window.CURRENT_PATCH) {
        params.set('patch', window.CURRENT_PATCH);
    }

    let response;
    try {
        response = await fetch(`${base}/tier-list/?${params.toString()}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des statistiques.');
    }

    return payload.data;
}

/**
 * Formate un taux (win_rate/pick_rate/ban_rate) pour l'affichage (voir
 * assets/js/tier-list.js::formatRate(), logique identique).
 */
function formatChampionStatRate(rate) {
    return rate !== null ? `${rate.toFixed(1)} %` : 'N/A';
}

/**
 * Construit la carte HTML d'une entrée de statistiques (une par
 * rôle/patch — voir assets/js/tier-list.js::renderTierListCard(), modèle
 * repris ici à l'identique, sans le nom du champion : on est déjà sur sa
 * page).
 */
function renderChampionStatCard(entry) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = `Patch ${entry.patch}`;
    card.appendChild(eyebrow);

    const rates = document.createElement('p');
    rates.className = 'text-mono text-muted';
    rates.style.fontSize = 'var(--text-xs)';
    rates.textContent = `Victoire : ${formatChampionStatRate(entry.win_rate)} · Sélection : ${formatChampionStatRate(entry.pick_rate)} · Bannissement : ${formatChampionStatRate(entry.ban_rate)}`;
    card.appendChild(rates);

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const tierBadge = document.createElement('span');
    const tierBadgeClass = CHAMPION_STATS_TIER_BADGE_CLASSES[entry.tier] || '';
    tierBadge.className = tierBadgeClass ? `badge ${tierBadgeClass}` : 'badge';
    tierBadge.textContent = `Tier ${entry.tier}`;
    foot.appendChild(tierBadge);

    const roleBadge = document.createElement('span');
    const roleBadgeClass = CHAMPION_DETAIL_ROLE_BADGE_CLASSES[entry.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = CHAMPION_DETAIL_ROLE_LABELS[entry.role] || entry.role;
    foot.appendChild(roleBadge);

    card.appendChild(foot);

    return card;
}

/**
 * Affiche les statistiques dans #champion-stats-grid, une par une
 * (renderChampionStatCard() ci-dessus), ou le message #champion-stats-empty
 * si aucune entrée n'existe pour ce champion.
 */
function renderChampionStats(entries) {
    const grid = document.getElementById('champion-stats-grid');
    const empty = document.getElementById('champion-stats-empty');
    grid.innerHTML = '';

    if (entries.length === 0) {
        empty.hidden = false;
        return;
    }

    empty.hidden = true;
    entries.forEach((entry) => {
        grid.appendChild(renderChampionStatCard(entry));
    });
}

/**
 * Déclenche la récupération des statistiques du champion (par son slug)
 * et bascule entre les trois états possibles (chargement → succès ou
 * erreur). Appelée uniquement une fois la fiche du champion chargée
 * (voir le point d'entrée ci-dessous) : le slug n'est connu qu'à ce
 * moment-là.
 *
 * @param {string} slug Slug du champion, voir fetchChampionStats().
 */
function loadChampionStats(slug) {
    const loading = document.getElementById('champion-stats-loading');
    const error = document.getElementById('champion-stats-error');

    loading.hidden = false;

    fetchChampionStats(slug)
        .then((entries) => {
            renderChampionStats(entries);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Libellé affiché pour chaque emplacement de capacité (passive/Q/W/E/R),
 * voir CHAMPION_ABILITY_SLOT_LABELS ci-dessous.
 */
const CHAMPION_ABILITY_SLOT_LABELS = {
    passive: 'Passive',
    q: 'Sort Q',
    w: 'Sort W',
    e: 'Sort E',
    r: 'Ultimate (R)',
};

/**
 * Récupère les capacités d'un champion depuis l'API (GET
 * /api/abilities/?champion=, voir api/abilities/index.php et
 * api/abilities/repository.php :: findAbilities()), par son slug — même
 * principe que fetchChampionStats() ci-dessus. Reprend l'enveloppe JSON
 * standard de l'API : en cas de succès, renvoie le tableau de capacités
 * (déjà trié par l'API dans l'ordre naturel du kit — passive, q, w, e,
 * r) ; en cas d'échec (HTTP ou réseau), le rejette avec une erreur dont
 * le message est toujours sûr à afficher tel quel.
 *
 * @param {string} slug Slug du champion (colonne `slug`, champions).
 * @returns {Promise<Array>} Capacités (id, champion, slot, name,
 *                            description, image_url).
 */
async function fetchChampionAbilities(slug) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/abilities/?champion=${encodeURIComponent(slug)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des capacités.');
    }

    return payload.data;
}

/**
 * Construit la carte HTML d'une capacité : emplacement (badge), nom,
 * puis description (si renseignée) — même composant `.card` que
 * renderChampionStatCard() ci-dessus, sans badge de rôle (non pertinent
 * ici).
 */
function renderChampionAbilityCard(ability) {
    const card = document.createElement('article');
    card.className = 'card';

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = CHAMPION_ABILITY_SLOT_LABELS[ability.slot] || ability.slot;
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = ability.name;
    card.appendChild(title);

    if (ability.description) {
        const description = document.createElement('p');
        description.className = 'text-muted';
        description.textContent = ability.description;
        card.appendChild(description);
    }

    return card;
}

/**
 * Affiche les capacités dans #champion-abilities-grid, une par une
 * (renderChampionAbilityCard() ci-dessus), ou le message
 * #champion-abilities-empty si aucune capacité n'existe pour ce
 * champion.
 */
function renderChampionAbilities(abilities) {
    const grid = document.getElementById('champion-abilities-grid');
    const empty = document.getElementById('champion-abilities-empty');
    grid.innerHTML = '';

    if (abilities.length === 0) {
        empty.hidden = false;
        return;
    }

    empty.hidden = true;
    abilities.forEach((ability) => {
        grid.appendChild(renderChampionAbilityCard(ability));
    });
}

/**
 * Déclenche la récupération des capacités du champion (par son slug) et
 * bascule entre les trois états possibles (chargement → succès ou
 * erreur) — même principe que loadChampionStats() ci-dessus, connexion
 * indépendante.
 *
 * @param {string} slug Slug du champion, voir fetchChampionAbilities().
 */
function loadChampionAbilities(slug) {
    const loading = document.getElementById('champion-abilities-loading');
    const error = document.getElementById('champion-abilities-error');

    loading.hidden = false;

    fetchChampionAbilities(slug)
        .then((abilities) => {
            renderChampionAbilities(abilities);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Libellés français des rôles et classe de badge associée, repris tels
 * quels de BUILD_ROLE_LABELS/BUILD_ROLE_BADGE_CLASSES
 * (assets/js/builds.js) plutôt qu'importés : ce fichier n'est chargé
 * que sur cette page, séparément de builds.js — même choix que
 * CHAMPION_DETAIL_ROLE_LABELS/BADGE_CLASSES plus haut, qui reprennent
 * déjà champions.js pour la même raison. build.role est indépendant du
 * rôle par défaut du champion (champions.role, voir database/schema.sql) :
 * un même build peut donc afficher un rôle différent de celui de la
 * fiche champion ci-dessus.
 */
const CHAMPION_BUILD_ROLE_LABELS = {
    baron: 'Voie Baron',
    jungle: 'Jungle',
    mid: 'Voie du Milieu',
    dragon: 'Voie Dragon',
    support: 'Support',
};

const CHAMPION_BUILD_ROLE_BADGE_CLASSES = {
    baron: 'badge--brass',
    jungle: 'badge--verdant',
    mid: 'badge--teal',
    dragon: 'badge--crimson',
    support: '',
};

/**
 * Récupère les builds d'un champion depuis l'API (GET
 * /api/builds/?champion=, voir api/builds/index.php et
 * api/builds/repository.php :: findBuilds()), par son slug — même
 * principe que fetchChampionStats()/fetchChampionAbilities() ci-dessus.
 * Le filtre ?champion= est déjà pris en charge par la ressource
 * /api/builds/ existante (voir assets/js/builds.js, qui ne l'utilise
 * pas : la page Builds affiche la première page toutes ressources
 * confondues, sans filtre côté client) ; ici, en revanche, il s'agit
 * précisément du seul filtre nécessaire, sur la page d'un champion
 * donné. Peu de builds par champion à ce stade : pas de pagination
 * câblée ici (?page= reste à sa valeur par défaut côté API, page 1).
 * Reprend l'enveloppe JSON standard de l'API : en cas de succès,
 * renvoie le tableau de builds ; en cas d'échec (HTTP ou réseau), le
 * rejette avec une erreur dont le message est toujours sûr à afficher
 * tel quel.
 *
 * Filtrée par défaut sur le patch actif du site (window.CURRENT_PATCH,
 * voir includes/components/header.php et config/patch.php), pour que
 * les builds affichés sur la fiche champion restent dans le contexte
 * du patch en cours.
 *
 * @param {string} slug Slug du champion (colonne `slug`, champions).
 * @returns {Promise<Array>} Builds (id, name, champion, role, patch).
 */
async function fetchChampionBuilds(slug) {
    const base = window.API_BASE_URL || '/api';

    const params = new URLSearchParams({ champion: slug });
    if (window.CURRENT_PATCH) {
        params.set('patch', window.CURRENT_PATCH);
    }

    let response;
    try {
        response = await fetch(`${base}/builds/?${params.toString()}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des builds.');
    }

    return payload.data;
}

/**
 * Construit la carte HTML d'un build : rôle et patch en pied de carte,
 * nom en titre — même composant `.card` que renderBuildCard()
 * (assets/js/builds.js), sans l'eyebrow "champion" (déjà affiché en
 * haut de la page, ce serait redondant ici).
 */
function renderChampionBuildCard(build) {
    const card = document.createElement('article');
    card.className = 'card';

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = build.name;
    card.appendChild(title);

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const roleBadge = document.createElement('span');
    const roleBadgeClass = CHAMPION_BUILD_ROLE_BADGE_CLASSES[build.role] || '';
    roleBadge.className = roleBadgeClass ? `badge ${roleBadgeClass}` : 'badge';
    roleBadge.textContent = CHAMPION_BUILD_ROLE_LABELS[build.role] || build.role;
    foot.appendChild(roleBadge);

    const patch = document.createElement('span');
    patch.className = 'text-mono text-muted';
    patch.style.fontSize = 'var(--text-xs)';
    patch.textContent = `Patch ${build.patch}`;
    foot.appendChild(patch);

    card.appendChild(foot);

    return card;
}

/**
 * Affiche les builds dans #champion-builds-grid, un par un
 * (renderChampionBuildCard() ci-dessus), ou le message
 * #champion-builds-empty si aucun build n'existe pour ce champion.
 */
function renderChampionBuilds(builds) {
    const grid = document.getElementById('champion-builds-grid');
    const empty = document.getElementById('champion-builds-empty');
    grid.innerHTML = '';

    if (builds.length === 0) {
        empty.hidden = false;
        return;
    }

    empty.hidden = true;
    builds.forEach((build) => {
        grid.appendChild(renderChampionBuildCard(build));
    });
}

/**
 * Déclenche la récupération des builds du champion (par son slug) et
 * bascule entre les trois états possibles (chargement → succès ou
 * erreur) — même principe que loadChampionStats()/loadChampionAbilities()
 * ci-dessus, connexion indépendante.
 *
 * @param {string} slug Slug du champion, voir fetchChampionBuilds().
 */
function loadChampionBuilds(slug) {
    const loading = document.getElementById('champion-builds-loading');
    const error = document.getElementById('champion-builds-error');

    loading.hidden = false;

    fetchChampionBuilds(slug)
        .then((builds) => {
            renderChampionBuilds(builds);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Classe de badge associée à chaque niveau de difficulté d'un counter
 * (colonne `difficulty`, ENUM('facile', 'moyen', 'difficile') nullable
 * — voir database/schema.sql), reprise telle quelle de
 * COUNTER_DIFFICULTY_BADGE_CLASSES (assets/js/counters.js) : déjà en
 * français côté API, pas de table de libellés nécessaire ici.
 */
const CHAMPION_COUNTER_DIFFICULTY_BADGE_CLASSES = {
    facile: 'badge--verdant',
    moyen: 'badge--brass',
    difficile: 'badge--crimson',
};

/**
 * Récupère les counters d'un champion depuis l'API (GET
 * /api/counters/?champion_id=, voir api/counters/index.php et
 * api/counters/repository.php :: findCounters()), par son ID — cette
 * ressource ne filtre que par ID, pas par slug (contrairement à
 * /api/tier-list/, /api/abilities/ et /api/builds/ ci-dessus), d'où le
 * paramètre `championId` plutôt que `slug` ici. Le filtre
 * ?champion_id= est déjà pris en charge par la ressource /api/counters/
 * existante (voir assets/js/counters.js, qui ne l'utilise pas : la page
 * Counters affiche tous les counters, sans filtre). Reprend l'enveloppe
 * JSON standard de l'API : en cas de succès, renvoie le tableau de
 * counters (chacun avec ses objets recommandés, `items`) ; en cas
 * d'échec (HTTP ou réseau), le rejette avec une erreur dont le message
 * est toujours sûr à afficher tel quel.
 *
 * @param {number} championId ID du champion (colonne `id`, champions).
 * @returns {Promise<Array>} Counters (id, champion_id,
 *                            counter_champion_id, explanation, tips,
 *                            difficulty, items).
 */
async function fetchChampionCounters(championId) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/counters/?champion_id=${encodeURIComponent(championId)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des counters.');
    }

    return payload.data;
}

/**
 * Construit la carte HTML d'un counter : explication, conseils, objets
 * recommandés puis difficulté — même composant `.card` et même contenu
 * que renderCounterCard() (assets/js/counters.js), sans le champion
 * contré en titre (déjà affiché en haut de la page, ce serait
 * redondant) ni l'eyebrow "Matchup" (le titre de section l'indique
 * déjà). Comme sur assets/js/counters.js, `counter_champion_id` reste
 * un ID brut faute de résolution côté API (voir fetchChampionCounters()
 * ci-dessus) : affiché tel quel, sans appel supplémentaire à
 * /api/champions/.
 */
function renderChampionCounterCard(counter) {
    const card = document.createElement('article');
    card.className = 'card';

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = `Champion #${counter.counter_champion_id}`;
    card.appendChild(title);

    if (counter.explanation) {
        const explanation = document.createElement('p');
        explanation.textContent = counter.explanation;
        card.appendChild(explanation);
    }

    if (counter.tips) {
        const tips = document.createElement('p');
        tips.className = 'text-muted';
        tips.textContent = counter.tips;
        card.appendChild(tips);
    }

    if (Array.isArray(counter.items) && counter.items.length > 0) {
        const items = document.createElement('p');
        items.className = 'text-mono text-muted';
        items.style.fontSize = 'var(--text-xs)';
        items.textContent = `Objets recommandés : ${counter.items.map((item) => item.name).join(', ')}`;
        card.appendChild(items);
    }

    if (counter.difficulty) {
        const foot = document.createElement('div');
        foot.className = 'card__foot';

        const difficultyBadge = document.createElement('span');
        const difficultyBadgeClass = CHAMPION_COUNTER_DIFFICULTY_BADGE_CLASSES[counter.difficulty] || '';
        difficultyBadge.className = difficultyBadgeClass ? `badge ${difficultyBadgeClass}` : 'badge';
        difficultyBadge.textContent = counter.difficulty;
        foot.appendChild(difficultyBadge);

        card.appendChild(foot);
    }

    return card;
}

/**
 * Affiche les counters dans #champion-counters-grid, un par un
 * (renderChampionCounterCard() ci-dessus), ou le message
 * #champion-counters-empty si aucun counter n'existe pour ce champion.
 */
function renderChampionCounters(counters) {
    const grid = document.getElementById('champion-counters-grid');
    const empty = document.getElementById('champion-counters-empty');
    grid.innerHTML = '';

    if (counters.length === 0) {
        empty.hidden = false;
        return;
    }

    empty.hidden = true;
    counters.forEach((counter) => {
        grid.appendChild(renderChampionCounterCard(counter));
    });
}

/**
 * Déclenche la récupération des counters du champion (par son ID) et
 * bascule entre les trois états possibles (chargement → succès ou
 * erreur) — même principe que loadChampionStats()/loadChampionAbilities()/
 * loadChampionBuilds() ci-dessus, connexion indépendante.
 *
 * @param {number} championId ID du champion, voir fetchChampionCounters().
 */
function loadChampionCounters(championId) {
    const loading = document.getElementById('champion-counters-loading');
    const error = document.getElementById('champion-counters-error');

    loading.hidden = false;

    fetchChampionCounters(championId)
        .then((counters) => {
            renderChampionCounters(counters);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Récupère les synergies d'un champion depuis l'API (GET
 * /api/synergies/?champion_id=, voir api/synergies/index.php et
 * api/synergies/repository.php :: findSynergies()), par son ID — même
 * principe que fetchChampionCounters() ci-dessus, cette ressource ne
 * filtrant elle aussi que par ID, pas par slug. Reprend l'enveloppe
 * JSON standard de l'API : en cas de succès, renvoie le tableau de
 * synergies ; en cas d'échec (HTTP ou réseau), le rejette avec une
 * erreur dont le message est toujours sûr à afficher tel quel.
 *
 * @param {number} championId ID du champion (colonne `id`, champions).
 * @returns {Promise<Array>} Synergies (id, champion_id,
 *                            synergy_champion_id, explanation).
 */
async function fetchChampionSynergies(championId) {
    const base = window.API_BASE_URL || '/api';

    let response;
    try {
        response = await fetch(`${base}/synergies/?champion_id=${encodeURIComponent(championId)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des synergies.');
    }

    return payload.data;
}

/**
 * Construit la carte HTML d'une synergie : uniquement son explication
 * — même composant `.card` que renderChampionCounterCard() ci-dessus,
 * mais sans difficulté ni objets recommandés (une synergie n'a pas ces
 * champs, voir database/schema.sql). Comme pour les counters,
 * `synergy_champion_id` reste un ID brut faute de résolution côté API
 * (voir fetchChampionSynergies() ci-dessus) : affiché tel quel, sans
 * appel supplémentaire à /api/champions/.
 */
function renderChampionSynergyCard(synergy) {
    const card = document.createElement('article');
    card.className = 'card';

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = `Champion #${synergy.synergy_champion_id}`;
    card.appendChild(title);

    if (synergy.explanation) {
        const explanation = document.createElement('p');
        explanation.textContent = synergy.explanation;
        card.appendChild(explanation);
    }

    return card;
}

/**
 * Affiche les synergies dans #champion-synergies-grid, une par une
 * (renderChampionSynergyCard() ci-dessus), ou le message
 * #champion-synergies-empty si aucune synergie n'existe pour ce
 * champion.
 */
function renderChampionSynergies(synergies) {
    const grid = document.getElementById('champion-synergies-grid');
    const empty = document.getElementById('champion-synergies-empty');
    grid.innerHTML = '';

    if (synergies.length === 0) {
        empty.hidden = false;
        return;
    }

    empty.hidden = true;
    synergies.forEach((synergy) => {
        grid.appendChild(renderChampionSynergyCard(synergy));
    });
}

/**
 * Déclenche la récupération des synergies du champion (par son ID) et
 * bascule entre les trois états possibles (chargement → succès ou
 * erreur) — même principe que loadChampionCounters() ci-dessus,
 * connexion indépendante.
 *
 * @param {number} championId ID du champion, voir fetchChampionSynergies().
 */
function loadChampionSynergies(championId) {
    const loading = document.getElementById('champion-synergies-loading');
    const error = document.getElementById('champion-synergies-error');

    loading.hidden = false;

    fetchChampionSynergies(championId)
        .then((synergies) => {
            renderChampionSynergies(synergies);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Point d'entrée : lit l'ID demandé, déclenche la récupération et
 * bascule entre les trois états possibles (chargement → succès ou
 * erreur). Un ID absent/invalide est traité comme une erreur au même
 * titre qu'un échec réseau ou un champion introuvable : même zone
 * d'erreur, même comportement pour l'utilisateur.
 *
 * Une fois la fiche affichée, déclenche en plus le chargement de ses
 * statistiques (loadChampionStats() ci-dessus), de ses capacités
 * (loadChampionAbilities() ci-dessus), de ses builds
 * (loadChampionBuilds() ci-dessus), de ses counters
 * (loadChampionCounters() ci-dessus) et de ses synergies
 * (loadChampionSynergies() ci-dessus) — cinq connexions indépendantes
 * les unes des autres, les trois premières par le slug renvoyé par la
 * fiche, les deux dernières par son ID.
 */
document.addEventListener('DOMContentLoaded', () => {
    const loading = document.getElementById('champion-loading');
    const error = document.getElementById('champion-error');

    Promise.resolve()
        .then(() => getRequestedChampionId())
        .then((id) => fetchChampionDetail(id))
        .then((champion) => {
            renderChampionDetail(champion);
            loadChampionStats(champion.slug);
            loadChampionAbilities(champion.slug);
            loadChampionBuilds(champion.slug);
            loadChampionCounters(champion.id);
            loadChampionSynergies(champion.id);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
});
