/**
 * Wild Rift Platform — Administration : gestion des patches.
 * Connecte admin/pages/patches.php à l'API dédiée (voir api/patches/index.php) :
 *
 *   - GET   /api/patches/          liste complète (le patch actif en premier,
 *                                  voir findAllPatches(), includes/patches.php)
 *   - POST  /api/patches/          création (#admin-patch-form) — toujours
 *                                  inactif à la création
 *   - PUT   /api/patches/?id=      modification des informations (même
 *                                  formulaire, pré-rempli via "Modifier") —
 *                                  ne change jamais l'état actif/inactif
 *   - PATCH /api/patches/?id=      activation/désactivation (boutons
 *                                  "Activer"/"Désactiver" sur chaque carte),
 *                                  corps JSON {"is_active": true|false}
 *
 * Ce fichier n'est chargé que sur la page admin Patches (voir
 * admin/patches.php).
 *
 * `window.API_BASE_URL` est défini directement dans admin/pages/patches.php
 * (via la fonction PHP asset('api')) — même principe que
 * assets/js/admin-champions.js.
 */

const ADMIN_PATCHES_API_BASE = window.API_BASE_URL || '/api';

/**
 * Cache local de la dernière liste récupérée (voir loadAdminPatches()),
 * indexée par ID. Sert à pré-remplir le formulaire de modification et à
 * retrouver le libellé d'un patch (confirmations, résumé de l'état actif)
 * sans appel réseau supplémentaire.
 */
let adminPatchesCache = new Map();

/**
 * Récupère la liste complète des patches depuis l'API.
 *
 * @returns {Promise<Array>} Patches (id, version, is_active, release_date,
 *                            description).
 */
async function fetchAdminPatches() {
    let response;
    try {
        response = await fetch(`${ADMIN_PATCHES_API_BASE}/patches/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des patches.');
    }

    return payload.data;
}

/**
 * Envoie une création (POST) ou une modification (PUT ?id=) au serveur.
 * $id vaut null pour une création. Même principe que saveAdminChampion()
 * (assets/js/admin-champions.js) : enveloppe JSON standard de l'API,
 * message d'erreur toujours sûr à afficher tel quel (y compris les
 * erreurs de validation 422, ex. version déjà utilisée).
 *
 * @returns {Promise<Object>} Le patch créé/modifié tel que renvoyé par l'API.
 */
async function saveAdminPatch(id, payload) {
    const method = id === null ? 'POST' : 'PUT';
    const url = id === null
        ? `${ADMIN_PATCHES_API_BASE}/patches/`
        : `${ADMIN_PATCHES_API_BASE}/patches/?id=${encodeURIComponent(id)}`;

    let response;
    try {
        response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(payload),
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let responsePayload;
    try {
        responsePayload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !responsePayload?.success) {
        throw new Error(responsePayload?.error?.message || "Erreur lors de l'enregistrement du patch.");
    }

    return responsePayload.data;
}

/**
 * Active ou désactive un patch (PATCH ?id=, corps {"is_active": bool}).
 * Même principe de gestion d'erreur que saveAdminPatch() ci-dessus.
 *
 * @returns {Promise<Object>} Le patch mis à jour tel que renvoyé par l'API.
 */
async function setAdminPatchActiveState(id, isActive) {
    let response;
    try {
        response = await fetch(`${ADMIN_PATCHES_API_BASE}/patches/?id=${encodeURIComponent(id)}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ is_active: isActive }),
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || "Erreur lors du changement d'état du patch.");
    }

    return payload.data;
}

/**
 * Formate une date de sortie (colonne `release_date`, format ISO
 * AAAA-MM-JJ renvoyé par l'API, ou null) en date lisible française —
 * même principe que formatNewsDate() (assets/js/news.js). Renvoie
 * "Date de sortie inconnue" si absente.
 */
function formatAdminPatchReleaseDate(releaseDate) {
    if (!releaseDate) {
        return 'Date de sortie inconnue';
    }

    const date = new Date(releaseDate);

    if (Number.isNaN(date.getTime())) {
        return releaseDate;
    }

    return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
}

/**
 * Construit la carte HTML d'un patch (composant .card du design system).
 * Le pied de carte reprend le badge "Actif"/"Inactif" (voir
 * pages/styleguide.php pour le modèle badge--live repris ici pour l'état
 * actif) et la date de sortie ; les actions ("Modifier" et "Activer"/
 * "Désactiver" selon l'état actuel) suivent, avec l'ID du patch en
 * attribut data-id — récupéré par délégation d'événement sur la grille
 * (voir wireAdminPatchesGrid()).
 */
function renderAdminPatchCard(patch, index) {
    const card = document.createElement('article');
    card.className = 'card';
    card.style.setProperty('--card-index', index);

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = 'Patch';
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = patch.version;
    card.appendChild(title);

    if (patch.description) {
        const description = document.createElement('p');
        description.textContent = patch.description;
        card.appendChild(description);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const stateBadge = document.createElement('span');
    if (patch.is_active) {
        stateBadge.className = 'badge badge--verdant badge--live';
        const dot = document.createElement('span');
        dot.className = 'badge__dot';
        stateBadge.appendChild(dot);
        stateBadge.appendChild(document.createTextNode(' Actif'));
    } else {
        stateBadge.className = 'badge';
        stateBadge.textContent = 'Inactif';
    }
    foot.appendChild(stateBadge);

    const releaseDate = document.createElement('span');
    releaseDate.className = 'text-mono text-muted';
    releaseDate.style.fontSize = 'var(--text-xs)';
    releaseDate.textContent = formatAdminPatchReleaseDate(patch.release_date);
    foot.appendChild(releaseDate);

    card.appendChild(foot);

    const actions = document.createElement('div');
    actions.className = 'stack';
    actions.style.flexDirection = 'row';
    actions.style.flexWrap = 'wrap';
    actions.style.gap = 'var(--space-2)';
    actions.style.marginTop = 'var(--space-3)';

    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'btn btn--secondary btn--sm';
    editBtn.dataset.action = 'edit';
    editBtn.dataset.id = String(patch.id);
    editBtn.textContent = 'Modifier';
    actions.appendChild(editBtn);

    const toggleBtn = document.createElement('button');
    toggleBtn.type = 'button';
    toggleBtn.dataset.id = String(patch.id);
    if (patch.is_active) {
        toggleBtn.className = 'btn btn--secondary btn--sm';
        toggleBtn.dataset.action = 'deactivate';
        toggleBtn.textContent = 'Désactiver';
    } else {
        toggleBtn.className = 'btn btn--sm';
        toggleBtn.dataset.action = 'activate';
        toggleBtn.textContent = 'Activer';
    }
    actions.appendChild(toggleBtn);

    card.appendChild(actions);

    return card;
}

/**
 * Met à jour le rappel du patch actif (#admin-patches-active) en tête de
 * page, à partir de la liste tout juste chargée — plutôt que d'un appel
 * réseau dédié : findAllPatches() (includes/patches.php) renvoie déjà le
 * patch actif en premier s'il existe.
 */
function renderAdminPatchesActiveSummary(patches) {
    const summary = document.getElementById('admin-patches-active');
    const activePatch = patches.find((patch) => patch.is_active);

    summary.innerHTML = '';

    const label = document.createElement('span');
    label.className = 'text-muted';
    label.textContent = 'Patch actif : ';
    summary.appendChild(label);

    const value = document.createElement('span');
    value.className = 'text-teal';
    value.textContent = activePatch ? activePatch.version : 'Aucun';
    summary.appendChild(value);
}

/**
 * Affiche la liste des patches dans #admin-patches-grid, un par un, met
 * à jour le cache local (adminPatchesCache) utilisé par le formulaire de
 * modification et par les confirmations, et rafraîchit le rappel du
 * patch actif.
 */
function renderAdminPatches(patches) {
    const grid = document.getElementById('admin-patches-grid');
    grid.innerHTML = '';

    adminPatchesCache = new Map(patches.map((patch) => [String(patch.id), patch]));

    patches.forEach((patch, index) => {
        grid.appendChild(renderAdminPatchCard(patch, index));
    });

    renderAdminPatchesActiveSummary(patches);
}

/**
 * Recharge la liste depuis l'API et la réaffiche — appelé après chaque
 * création, modification, activation ou désactivation réussie, pour que
 * la grille (et le rappel du patch actif) reflètent toujours l'état réel
 * de la base.
 */
function reloadAdminPatches() {
    const loading = document.getElementById('admin-patches-loading');
    const error = document.getElementById('admin-patches-error');

    loading.hidden = false;
    error.hidden = true;

    return fetchAdminPatches()
        .then((patches) => {
            renderAdminPatches(patches);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Lit les valeurs actuelles du formulaire et les met en forme pour
 * l'API (POST/PUT) — mêmes clés que validatePatchPayload() côté serveur
 * (voir api/patches/index.php). release_date et description vides
 * deviennent null (l'API les traite déjà comme optionnelles, mais autant
 * rester explicite ici, même principe que readAdminChampionFormPayload(),
 * assets/js/admin-champions.js).
 */
function readAdminPatchFormPayload() {
    const releaseDate = document.getElementById('admin-patch-release-date').value.trim();
    const description = document.getElementById('admin-patch-description').value.trim();

    return {
        version: document.getElementById('admin-patch-version').value.trim(),
        release_date: releaseDate === '' ? null : releaseDate,
        description: description === '' ? null : description,
    };
}

/**
 * Remet le formulaire à zéro et le bascule en mode "création" : champ ID
 * vidé, titre "Ajouter un patch", tous les champs réinitialisés.
 */
function resetAdminPatchForm() {
    const form = document.getElementById('admin-patch-form');
    form.reset();
    document.getElementById('admin-patch-form-id').value = '';
    document.getElementById('admin-patch-form-title').textContent = 'Ajouter un patch';
    document.getElementById('admin-patch-form-error').hidden = true;
}

/**
 * Pré-remplit le formulaire avec les valeurs d'un patch existant et le
 * bascule en mode "modification" — les valeurs viennent du cache local
 * (adminPatchesCache), déjà à jour depuis le dernier chargement de la
 * liste. is_active n'a pas de champ dans ce formulaire (voir
 * admin/pages/patches.php) : l'activation/désactivation se fait
 * uniquement depuis les boutons de la carte.
 */
function fillAdminPatchForm(patch) {
    document.getElementById('admin-patch-form-id').value = String(patch.id);
    document.getElementById('admin-patch-form-title').textContent = `Modifier ${patch.version}`;
    document.getElementById('admin-patch-form-error').hidden = true;

    document.getElementById('admin-patch-version').value = patch.version;
    document.getElementById('admin-patch-release-date').value = patch.release_date || '';
    document.getElementById('admin-patch-description').value = patch.description || '';
}

/**
 * Câble le bouton "Ajouter un patch", le bouton "Annuler" et la
 * soumission du formulaire (création ou modification selon
 * #admin-patch-form-id) — même principe que wireAdminChampionForm()
 * (assets/js/admin-champions.js).
 */
function wireAdminPatchForm() {
    const section = document.getElementById('admin-patch-form-section');
    const form = document.getElementById('admin-patch-form');
    const addBtn = document.getElementById('admin-patch-add-btn');
    const cancelBtn = document.getElementById('admin-patch-form-cancel');
    const submitBtn = document.getElementById('admin-patch-form-submit');
    const errorEl = document.getElementById('admin-patch-form-error');

    addBtn.addEventListener('click', () => {
        resetAdminPatchForm();
        section.hidden = false;
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    cancelBtn.addEventListener('click', () => {
        section.hidden = true;
        resetAdminPatchForm();
    });

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const idValue = document.getElementById('admin-patch-form-id').value;
        const id = idValue === '' ? null : Number(idValue);
        const payload = readAdminPatchFormPayload();

        errorEl.hidden = true;
        submitBtn.disabled = true;

        saveAdminPatch(id, payload)
            .then(() => {
                section.hidden = true;
                resetAdminPatchForm();
                return reloadAdminPatches();
            })
            .catch((err) => {
                errorEl.textContent = err.message;
                errorEl.hidden = false;
            })
            .finally(() => {
                submitBtn.disabled = false;
            });
    });
}

/**
 * Câble les boutons "Modifier"/"Activer"/"Désactiver" par délégation
 * d'événement sur #admin-patches-grid (les cartes sont recréées à chaque
 * chargement/rechargement, un seul écouteur suffit donc plutôt que d'en
 * reposer un par carte à chaque rendu) — même principe que
 * wireAdminChampionsGrid() (assets/js/admin-champions.js). Activer un
 * patch déjà actif ou désactiver un patch déjà inactif n'est pas
 * possible depuis l'interface : le bouton affiché dépend déjà de l'état
 * courant (voir renderAdminPatchCard()).
 */
function wireAdminPatchesGrid() {
    const grid = document.getElementById('admin-patches-grid');

    grid.addEventListener('click', (event) => {
        const button = event.target.closest('button[data-action]');
        if (!button) return;

        const id = button.dataset.id;
        const patch = adminPatchesCache.get(id);

        if (button.dataset.action === 'edit') {
            if (!patch) return;

            fillAdminPatchForm(patch);
            const section = document.getElementById('admin-patch-form-section');
            section.hidden = false;
            section.scrollIntoView({ behavior: 'smooth', block: 'start' });
            return;
        }

        if (button.dataset.action === 'activate' || button.dataset.action === 'deactivate') {
            const isActive = button.dataset.action === 'activate';
            const version = patch ? patch.version : `#${id}`;

            if (isActive) {
                const confirmed = window.confirm(
                    `Activer le patch ${version} ? Le patch actuellement actif sera automatiquement désactivé.`
                );
                if (!confirmed) return;
            }

            button.disabled = true;

            setAdminPatchActiveState(id, isActive)
                .then(() => reloadAdminPatches())
                .catch((err) => {
                    window.alert(err.message);
                    button.disabled = false;
                });
        }
    });
}

/**
 * Point d'entrée : câble le formulaire et la grille, puis déclenche le
 * premier chargement de la liste.
 */
document.addEventListener('DOMContentLoaded', () => {
    wireAdminPatchForm();
    wireAdminPatchesGrid();
    reloadAdminPatches();
});
