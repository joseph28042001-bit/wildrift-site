/**
 * Wild Rift Platform — Administration : gestion des runes.
 * Connecte admin/pages/runes.php à l'API existante — en lecture ET en
 * écriture (voir api/runes/index.php) :
 *
 *   - GET    /api/runes/          liste
 *   - POST   /api/runes/          création (#admin-rune-form)
 *   - PUT    /api/runes/?id=      modification (même formulaire,
 *                                  pré-rempli via "Modifier")
 *   - DELETE /api/runes/?id=      suppression (bouton "Supprimer" sur
 *                                  chaque carte, avec confirmation)
 *
 * Même principe que assets/js/admin-champions.js et
 * assets/js/admin-items.js. Étape actuelle : gestion complète des
 * runes elles-mêmes. Ne couvre pas l'association d'une rune à un build
 * (build_runes) — hors périmètre de cette étape.
 *
 * Ce fichier n'est chargé que sur la page admin Runes (voir
 * admin/runes.php).
 *
 * `window.API_BASE_URL` est défini directement dans admin/pages/runes.php
 * (via la fonction PHP asset('api')) : cette page admin n'inclut pas le
 * footer public (voir admin/includes/footer.php, qui ne le définit pas),
 * donc il est posé localement avant le chargement de ce fichier, plutôt
 * que globalement comme includes/components/footer.php le fait pour la
 * partie publique.
 */

const ADMIN_RUNES_API_BASE = window.API_BASE_URL || '/api';

/**
 * Libellés français des arbres de runes et classe de badge associée.
 * Codés en dur ici plutôt que récupérés depuis GET /api/rune-trees/
 * (contrairement à assets/js/runes.js) — même choix que
 * ADMIN_CHAMPION_ROLE_LABELS/ADMIN_ITEM_CATEGORY_LABELS (respectivement
 * assets/js/admin-champions.js et assets/js/admin-items.js) : une page
 * admin autonome, sans dépendre d'un appel réseau supplémentaire.
 */
const ADMIN_RUNE_TREE_LABELS = {
    precision: 'Précision',
    domination: 'Domination',
    sorcery: 'Sorcellerie',
    resolve: 'Détermination',
    inspiration: 'Inspiration',
};

const ADMIN_RUNE_TREE_BADGE_CLASSES = {
    precision: 'badge--brass',
    domination: 'badge--crimson',
    sorcery: 'badge--teal',
    resolve: 'badge--verdant',
    inspiration: 'badge--verdant',
};

const ADMIN_RUNE_SLOT_LABELS = {
    keystone: 'Rune majeure',
    minor: 'Rune mineure',
};

/**
 * Cache local de la dernière liste récupérée (voir loadAdminRunes()),
 * indexée par ID. Sert uniquement à pré-remplir le formulaire de
 * modification sans refaire un appel réseau dédié — la liste vient de
 * toute façon d'être chargée en entier par GET /api/runes/. Même
 * principe que adminChampionsCache/adminItemsCache.
 */
let adminRunesCache = new Map();

/**
 * Récupère la liste complète des runes depuis l'API.
 *
 * @returns {Promise<Array>} Runes (id, slug, name, tree, slot,
 *                            description, image_url).
 */
async function fetchAdminRunes() {
    let response;
    try {
        response = await fetch(`${ADMIN_RUNES_API_BASE}/runes/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des runes.');
    }

    return payload.data;
}

/**
 * Envoie une création (POST) ou une modification (PUT ?id=) au serveur.
 * $id vaut null pour une création. Reprend l'enveloppe JSON standard de
 * l'API ({ success, data } ou { success: false, error }, voir
 * api/core/response.php) ; rejette avec une erreur dont le message est
 * toujours sûr à afficher tel quel (y compris les erreurs de validation
 * 422, ex. slug déjà utilisé). Même principe que saveAdminChampion()/
 * saveAdminItem().
 *
 * @returns {Promise<Object>} La rune créée/modifiée telle que renvoyée par l'API.
 */
async function saveAdminRune(id, payload) {
    const method = id === null ? 'POST' : 'PUT';
    const url = id === null
        ? `${ADMIN_RUNES_API_BASE}/runes/`
        : `${ADMIN_RUNES_API_BASE}/runes/?id=${encodeURIComponent(id)}`;

    let response;
    try {
        response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(payload),
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let responsePayload;
    try {
        responsePayload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !responsePayload?.success) {
        throw new Error(responsePayload?.error?.message || "Erreur lors de l'enregistrement de la rune.");
    }

    return responsePayload.data;
}

/**
 * Supprime une rune (DELETE ?id=). Même principe de gestion d'erreur
 * que saveAdminRune() ci-dessus.
 */
async function deleteAdminRune(id) {
    let response;
    try {
        response = await fetch(`${ADMIN_RUNES_API_BASE}/runes/?id=${encodeURIComponent(id)}`, {
            method: 'DELETE',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la suppression de la rune.');
    }
}

/**
 * Construit la carte HTML d'une rune pour l'espace d'administration
 * (composant .card du design system). Ajoute, par rapport à une simple
 * liste, deux boutons d'action ("Modifier" / "Supprimer") dans le pied
 * de carte, avec l'ID de la rune en attribut data-id — récupéré par
 * délégation d'événement sur la grille (voir wireAdminRunesGrid()).
 * Même principe que renderAdminChampionCard()/renderAdminItemCard().
 */
function renderAdminRuneCard(rune, index) {
    const card = document.createElement('article');
    card.className = 'card';
    card.style.setProperty('--card-index', index);

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = ADMIN_RUNE_SLOT_LABELS[rune.slot] || `Rune #${rune.id}`;
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = rune.name;
    card.appendChild(title);

    if (rune.description) {
        const description = document.createElement('p');
        description.textContent = rune.description;
        card.appendChild(description);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const treeBadge = document.createElement('span');
    const treeBadgeClass = ADMIN_RUNE_TREE_BADGE_CLASSES[rune.tree] || '';
    treeBadge.className = treeBadgeClass ? `badge ${treeBadgeClass}` : 'badge';
    treeBadge.textContent = ADMIN_RUNE_TREE_LABELS[rune.tree] || rune.tree;
    foot.appendChild(treeBadge);

    const id = document.createElement('span');
    id.className = 'text-mono text-muted';
    id.style.fontSize = 'var(--text-xs)';
    id.textContent = `#${rune.id}`;
    foot.appendChild(id);

    card.appendChild(foot);

    const actions = document.createElement('div');
    actions.className = 'stack';
    actions.style.flexDirection = 'row';
    actions.style.gap = 'var(--space-2)';
    actions.style.marginTop = 'var(--space-3)';

    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'btn btn--secondary btn--sm';
    editBtn.dataset.action = 'edit';
    editBtn.dataset.id = String(rune.id);
    editBtn.textContent = 'Modifier';
    actions.appendChild(editBtn);

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'btn btn--secondary btn--sm';
    deleteBtn.dataset.action = 'delete';
    deleteBtn.dataset.id = String(rune.id);
    deleteBtn.textContent = 'Supprimer';
    actions.appendChild(deleteBtn);

    card.appendChild(actions);

    return card;
}

/**
 * Affiche la liste des runes dans #admin-runes-grid, un par un, et met
 * à jour le cache local (adminRunesCache) utilisé par le formulaire de
 * modification.
 */
function renderAdminRunes(runes) {
    const grid = document.getElementById('admin-runes-grid');
    grid.innerHTML = '';

    adminRunesCache = new Map(runes.map((rune) => [String(rune.id), rune]));

    runes.forEach((rune, index) => {
        grid.appendChild(renderAdminRuneCard(rune, index));
    });
}

/**
 * Recharge la liste depuis l'API et la réaffiche — appelé après chaque
 * création, modification ou suppression réussie, pour que la grille
 * (et le cache) reflètent toujours l'état réel de la base.
 */
function reloadAdminRunes() {
    const loading = document.getElementById('admin-runes-loading');
    const error = document.getElementById('admin-runes-error');

    loading.hidden = false;
    error.hidden = true;

    return fetchAdminRunes()
        .then((runes) => {
            renderAdminRunes(runes);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Lit les valeurs actuelles du formulaire et les met en forme pour
 * l'API (POST/PUT) — mêmes clés que validateRunePayload() côté serveur
 * (voir api/runes/index.php). description et image_url vides deviennent
 * null (l'API les traite déjà comme optionnels, mais autant rester
 * explicite ici).
 */
function readAdminRuneFormPayload() {
    const description = document.getElementById('admin-rune-description').value.trim();
    const imageUrl = document.getElementById('admin-rune-image-url').value.trim();

    return {
        slug: document.getElementById('admin-rune-slug').value.trim(),
        name: document.getElementById('admin-rune-name').value.trim(),
        tree: document.getElementById('admin-rune-tree').value,
        slot: document.getElementById('admin-rune-slot').value,
        description: description === '' ? null : description,
        image_url: imageUrl === '' ? null : imageUrl,
    };
}

/**
 * Remet le formulaire à zéro et le bascule en mode "création" : champ ID
 * vidé, titre "Ajouter une rune", tous les champs réinitialisés (le
 * select "Emplacement" retombe sur "Mineure", son option par défaut).
 */
function resetAdminRuneForm() {
    const form = document.getElementById('admin-rune-form');
    form.reset();
    document.getElementById('admin-rune-form-id').value = '';
    document.getElementById('admin-rune-form-title').textContent = 'Ajouter une rune';
    document.getElementById('admin-rune-form-error').hidden = true;
}

/**
 * Pré-remplit le formulaire avec les valeurs d'une rune existante et le
 * bascule en mode "modification" — les valeurs viennent du cache local
 * (adminRunesCache), déjà à jour depuis le dernier chargement de la
 * liste.
 */
function fillAdminRuneForm(rune) {
    document.getElementById('admin-rune-form-id').value = String(rune.id);
    document.getElementById('admin-rune-form-title').textContent = `Modifier ${rune.name}`;
    document.getElementById('admin-rune-form-error').hidden = true;

    document.getElementById('admin-rune-slug').value = rune.slug;
    document.getElementById('admin-rune-name').value = rune.name;
    document.getElementById('admin-rune-tree').value = rune.tree;
    document.getElementById('admin-rune-slot').value = rune.slot;
    document.getElementById('admin-rune-description').value = rune.description || '';
    document.getElementById('admin-rune-image-url').value = rune.image_url || '';
}

/**
 * Câble le bouton "Ajouter une rune", le bouton "Annuler" et la
 * soumission du formulaire (création ou modification selon
 * #admin-rune-form-id) — voir le commentaire d'en-tête pour la vue
 * d'ensemble des trois états (masqué / création / modification).
 */
function wireAdminRuneForm() {
    const section = document.getElementById('admin-rune-form-section');
    const form = document.getElementById('admin-rune-form');
    const addBtn = document.getElementById('admin-rune-add-btn');
    const cancelBtn = document.getElementById('admin-rune-form-cancel');
    const submitBtn = document.getElementById('admin-rune-form-submit');
    const errorEl = document.getElementById('admin-rune-form-error');

    addBtn.addEventListener('click', () => {
        resetAdminRuneForm();
        section.hidden = false;
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    cancelBtn.addEventListener('click', () => {
        section.hidden = true;
        resetAdminRuneForm();
    });

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const idValue = document.getElementById('admin-rune-form-id').value;
        const id = idValue === '' ? null : Number(idValue);
        const payload = readAdminRuneFormPayload();

        errorEl.hidden = true;
        submitBtn.disabled = true;

        saveAdminRune(id, payload)
            .then(() => {
                section.hidden = true;
                resetAdminRuneForm();
                return reloadAdminRunes();
            })
            .catch((err) => {
                errorEl.textContent = err.message;
                errorEl.hidden = false;
            })
            .finally(() => {
                submitBtn.disabled = false;
            });
    });
}

/**
 * Câble les boutons "Modifier"/"Supprimer" par délégation d'événement
 * sur #admin-runes-grid (les cartes sont recréées à chaque
 * chargement/rechargement, un seul écouteur suffit donc plutôt que d'en
 * reposer un par carte à chaque rendu).
 */
function wireAdminRunesGrid() {
    const grid = document.getElementById('admin-runes-grid');

    grid.addEventListener('click', (event) => {
        const button = event.target.closest('button[data-action]');
        if (!button) return;

        const id = button.dataset.id;

        if (button.dataset.action === 'edit') {
            const rune = adminRunesCache.get(id);
            if (!rune) return;

            fillAdminRuneForm(rune);
            const section = document.getElementById('admin-rune-form-section');
            section.hidden = false;
            section.scrollIntoView({ behavior: 'smooth', block: 'start' });
            return;
        }

        if (button.dataset.action === 'delete') {
            const rune = adminRunesCache.get(id);
            const name = rune ? rune.name : `#${id}`;

            const confirmed = window.confirm(
                `Supprimer ${name} ? Cette action supprime aussi ses entrées de build associées. Cette action est irréversible.`
            );
            if (!confirmed) return;

            button.disabled = true;

            deleteAdminRune(id)
                .then(() => reloadAdminRunes())
                .catch((err) => {
                    window.alert(err.message);
                    button.disabled = false;
                });
        }
    });
}

/**
 * Point d'entrée : câble le formulaire et la grille, puis déclenche le
 * premier chargement de la liste.
 */
document.addEventListener('DOMContentLoaded', () => {
    wireAdminRuneForm();
    wireAdminRunesGrid();
    reloadAdminRunes();
});
