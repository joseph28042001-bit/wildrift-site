/**
 * Wild Rift Platform — Administration : gestion des objets.
 * Connecte admin/pages/items.php à l'API existante — désormais en
 * lecture ET en écriture (voir api/items/index.php) :
 *
 *   - GET    /api/items/          liste (déjà présent depuis l'étape
 *                                  précédente, logique reprise ici
 *                                  telle quelle)
 *   - POST   /api/items/          création (#admin-item-form)
 *   - PUT    /api/items/?id=      modification (même formulaire,
 *                                  pré-rempli via "Modifier")
 *   - DELETE /api/items/?id=      suppression (bouton "Supprimer" sur
 *                                  chaque carte, avec confirmation)
 *
 * Même principe que assets/js/admin-champions.js pour les champions.
 * Étape actuelle : gestion complète des objets eux-mêmes. Ne couvre pas
 * la gestion de la recette d'un objet (item_recipes) ni aucune autre
 * ressource — hors périmètre de cette étape.
 *
 * Ce fichier n'est chargé que sur la page admin Objets (voir
 * admin/items.php).
 *
 * `window.API_BASE_URL` est défini directement dans admin/pages/items.php
 * (via la fonction PHP asset('api')) : cette page admin n'inclut pas le
 * footer public (voir admin/includes/footer.php, qui ne le définit pas),
 * donc il est posé localement avant le chargement de ce fichier, plutôt
 * que globalement comme includes/components/footer.php le fait pour la
 * partie publique.
 */

const ADMIN_ITEMS_API_BASE = window.API_BASE_URL || '/api';

/**
 * Libellés français des catégories d'objets et classe de badge associée
 * — repris tels quels de ITEM_CATEGORY_LABELS/BADGE_CLASSES
 * (assets/js/items.js), même logique que
 * ADMIN_CHAMPION_ROLE_LABELS/BADGE_CLASSES (assets/js/admin-champions.js)
 * pour les champions.
 */
const ADMIN_ITEM_CATEGORY_LABELS = {
    attack: 'Attaque',
    magic: 'Magie',
    defense: 'Défense',
    boots: 'Bottes',
    jungle: 'Jungle',
    consumable: 'Consommable',
    enchantment: 'Enchantement',
};

const ADMIN_ITEM_CATEGORY_BADGE_CLASSES = {
    attack: 'badge--crimson',
    magic: 'badge--teal',
    defense: 'badge--verdant',
    boots: 'badge--brass',
    jungle: 'badge--verdant',
    consumable: 'badge--brass',
    enchantment: 'badge--teal',
};

/**
 * Cache local de la dernière liste récupérée (voir loadAdminItems()),
 * indexée par ID. Sert uniquement à pré-remplir le formulaire de
 * modification sans refaire un appel réseau dédié — la liste vient de
 * toute façon d'être chargée en entier par GET /api/items/. Même
 * principe que adminChampionsCache (assets/js/admin-champions.js).
 */
let adminItemsCache = new Map();

/**
 * Récupère la liste complète des objets depuis l'API (identique à
 * l'étape précédente).
 *
 * @returns {Promise<Array>} Objets (id, slug, name, category, price,
 *                            description, image_url).
 */
async function fetchAdminItems() {
    let response;
    try {
        response = await fetch(`${ADMIN_ITEMS_API_BASE}/items/`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || 'Erreur lors de la récupération des objets.');
    }

    return payload.data;
}

/**
 * Envoie une création (POST) ou une modification (PUT ?id=) au serveur.
 * $id vaut null pour une création. Reprend l'enveloppe JSON standard de
 * l'API ({ success, data } ou { success: false, error }, voir
 * api/core/response.php) ; rejette avec une erreur dont le message est
 * toujours sûr à afficher tel quel (y compris les erreurs de validation
 * 422, ex. slug déjà utilisé). Même principe que saveAdminChampion()
 * (assets/js/admin-champions.js).
 *
 * @returns {Promise<Object>} L'objet créé/modifié tel que renvoyé par l'API.
 */
async function saveAdminItem(id, payload) {
    const method = id === null ? 'POST' : 'PUT';
    const url = id === null
        ? `${ADMIN_ITEMS_API_BASE}/items/`
        : `${ADMIN_ITEMS_API_BASE}/items/?id=${encodeURIComponent(id)}`;

    let response;
    try {
        response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(payload),
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let responsePayload;
    try {
        responsePayload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !responsePayload?.success) {
        throw new Error(responsePayload?.error?.message || "Erreur lors de l'enregistrement de l'objet.");
    }

    return responsePayload.data;
}

/**
 * Supprime un objet (DELETE ?id=). Même principe de gestion d'erreur
 * que saveAdminItem() ci-dessus.
 */
async function deleteAdminItem(id) {
    let response;
    try {
        response = await fetch(`${ADMIN_ITEMS_API_BASE}/items/?id=${encodeURIComponent(id)}`, {
            method: 'DELETE',
            headers: { 'Accept': 'application/json' },
        });
    } catch (networkError) {
        throw new Error('Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.');
    }

    let payload;
    try {
        payload = await response.json();
    } catch (parseError) {
        throw new Error('Le serveur a renvoyé une réponse inattendue.');
    }

    if (!response.ok || !payload?.success) {
        throw new Error(payload?.error?.message || "Erreur lors de la suppression de l'objet.");
    }
}

/**
 * Construit la carte HTML d'un objet pour l'espace d'administration
 * (composant .card du design system). Ajoute, par rapport à l'étape
 * précédente, deux boutons d'action ("Modifier" / "Supprimer") dans le
 * pied de carte, avec l'ID de l'objet en attribut data-id — récupéré
 * par délégation d'événement sur la grille (voir wireAdminItemsGrid()).
 * Même principe que renderAdminChampionCard() (assets/js/admin-champions.js).
 */
function renderAdminItemCard(item, index) {
    const card = document.createElement('article');
    card.className = 'card';
    card.style.setProperty('--card-index', index);

    const eyebrow = document.createElement('div');
    eyebrow.className = 'card__eyebrow';
    eyebrow.textContent = `Objet #${item.id}`;
    card.appendChild(eyebrow);

    const title = document.createElement('h3');
    title.className = 'card__title';
    title.textContent = item.name;
    card.appendChild(title);

    if (item.description) {
        const description = document.createElement('p');
        description.textContent = item.description;
        card.appendChild(description);
    }

    const foot = document.createElement('div');
    foot.className = 'card__foot';

    const categoryBadge = document.createElement('span');
    const categoryBadgeClass = ADMIN_ITEM_CATEGORY_BADGE_CLASSES[item.category] || '';
    categoryBadge.className = categoryBadgeClass ? `badge ${categoryBadgeClass}` : 'badge';
    categoryBadge.textContent = ADMIN_ITEM_CATEGORY_LABELS[item.category] || item.category;
    foot.appendChild(categoryBadge);

    const price = document.createElement('span');
    price.className = 'text-mono text-muted';
    price.style.fontSize = 'var(--text-xs)';
    price.textContent = item.price !== null ? `${item.price.toLocaleString('fr-FR')} or` : 'Prix inconnu';
    foot.appendChild(price);

    card.appendChild(foot);

    const actions = document.createElement('div');
    actions.className = 'stack';
    actions.style.flexDirection = 'row';
    actions.style.gap = 'var(--space-2)';
    actions.style.marginTop = 'var(--space-3)';

    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'btn btn--secondary btn--sm';
    editBtn.dataset.action = 'edit';
    editBtn.dataset.id = String(item.id);
    editBtn.textContent = 'Modifier';
    actions.appendChild(editBtn);

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'btn btn--secondary btn--sm';
    deleteBtn.dataset.action = 'delete';
    deleteBtn.dataset.id = String(item.id);
    deleteBtn.textContent = 'Supprimer';
    actions.appendChild(deleteBtn);

    card.appendChild(actions);

    return card;
}

/**
 * Affiche la liste des objets dans #admin-items-grid, un par un, et met
 * à jour le cache local (adminItemsCache) utilisé par le formulaire de
 * modification.
 */
function renderAdminItems(items) {
    const grid = document.getElementById('admin-items-grid');
    grid.innerHTML = '';

    adminItemsCache = new Map(items.map((item) => [String(item.id), item]));

    items.forEach((item, index) => {
        grid.appendChild(renderAdminItemCard(item, index));
    });
}

/**
 * Recharge la liste depuis l'API et la réaffiche — appelé après chaque
 * création, modification ou suppression réussie, pour que la grille
 * (et le cache) reflètent toujours l'état réel de la base.
 */
function reloadAdminItems() {
    const loading = document.getElementById('admin-items-loading');
    const error = document.getElementById('admin-items-error');

    loading.hidden = false;
    error.hidden = true;

    return fetchAdminItems()
        .then((items) => {
            renderAdminItems(items);
        })
        .catch((err) => {
            error.textContent = err.message;
            error.hidden = false;
        })
        .finally(() => {
            loading.hidden = true;
        });
}

/**
 * Lit les valeurs actuelles du formulaire et les met en forme pour
 * l'API (POST/PUT) — mêmes clés que validateItemPayload() côté serveur
 * (voir api/items/index.php). Le prix est converti en nombre ; price,
 * description et image_url vides deviennent null (l'API les traite
 * déjà comme optionnels, mais autant rester explicite ici).
 */
function readAdminItemFormPayload() {
    const price = document.getElementById('admin-item-price').value.trim();
    const description = document.getElementById('admin-item-description').value.trim();
    const imageUrl = document.getElementById('admin-item-image-url').value.trim();

    return {
        slug: document.getElementById('admin-item-slug').value.trim(),
        name: document.getElementById('admin-item-name').value.trim(),
        category: document.getElementById('admin-item-category').value,
        price: price === '' ? null : Number(price),
        description: description === '' ? null : description,
        image_url: imageUrl === '' ? null : imageUrl,
    };
}

/**
 * Remet le formulaire à zéro et le bascule en mode "création" : champ ID
 * vidé, titre "Ajouter un objet", tous les champs réinitialisés.
 */
function resetAdminItemForm() {
    const form = document.getElementById('admin-item-form');
    form.reset();
    document.getElementById('admin-item-form-id').value = '';
    document.getElementById('admin-item-form-title').textContent = 'Ajouter un objet';
    document.getElementById('admin-item-form-error').hidden = true;
}

/**
 * Pré-remplit le formulaire avec les valeurs d'un objet existant et le
 * bascule en mode "modification" — les valeurs viennent du cache local
 * (adminItemsCache), déjà à jour depuis le dernier chargement de la
 * liste.
 */
function fillAdminItemForm(item) {
    document.getElementById('admin-item-form-id').value = String(item.id);
    document.getElementById('admin-item-form-title').textContent = `Modifier ${item.name}`;
    document.getElementById('admin-item-form-error').hidden = true;

    document.getElementById('admin-item-slug').value = item.slug;
    document.getElementById('admin-item-name').value = item.name;
    document.getElementById('admin-item-category').value = item.category;
    document.getElementById('admin-item-price').value = item.price !== null ? item.price : '';
    document.getElementById('admin-item-description').value = item.description || '';
    document.getElementById('admin-item-image-url').value = item.image_url || '';
}

/**
 * Câble le bouton "Ajouter un objet", le bouton "Annuler" et la
 * soumission du formulaire (création ou modification selon
 * #admin-item-form-id) — voir le commentaire d'en-tête pour la vue
 * d'ensemble des trois états (masqué / création / modification).
 */
function wireAdminItemForm() {
    const section = document.getElementById('admin-item-form-section');
    const form = document.getElementById('admin-item-form');
    const addBtn = document.getElementById('admin-item-add-btn');
    const cancelBtn = document.getElementById('admin-item-form-cancel');
    const submitBtn = document.getElementById('admin-item-form-submit');
    const errorEl = document.getElementById('admin-item-form-error');

    addBtn.addEventListener('click', () => {
        resetAdminItemForm();
        section.hidden = false;
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    cancelBtn.addEventListener('click', () => {
        section.hidden = true;
        resetAdminItemForm();
    });

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const idValue = document.getElementById('admin-item-form-id').value;
        const id = idValue === '' ? null : Number(idValue);
        const payload = readAdminItemFormPayload();

        errorEl.hidden = true;
        submitBtn.disabled = true;

        saveAdminItem(id, payload)
            .then(() => {
                section.hidden = true;
                resetAdminItemForm();
                return reloadAdminItems();
            })
            .catch((err) => {
                errorEl.textContent = err.message;
                errorEl.hidden = false;
            })
            .finally(() => {
                submitBtn.disabled = false;
            });
    });
}

/**
 * Câble les boutons "Modifier"/"Supprimer" par délégation d'événement
 * sur #admin-items-grid (les cartes sont recréées à chaque
 * chargement/rechargement, un seul écouteur suffit donc plutôt que d'en
 * reposer un par carte à chaque rendu).
 */
function wireAdminItemsGrid() {
    const grid = document.getElementById('admin-items-grid');

    grid.addEventListener('click', (event) => {
        const button = event.target.closest('button[data-action]');
        if (!button) return;

        const id = button.dataset.id;

        if (button.dataset.action === 'edit') {
            const item = adminItemsCache.get(id);
            if (!item) return;

            fillAdminItemForm(item);
            const section = document.getElementById('admin-item-form-section');
            section.hidden = false;
            section.scrollIntoView({ behavior: 'smooth', block: 'start' });
            return;
        }

        if (button.dataset.action === 'delete') {
            const item = adminItemsCache.get(id);
            const name = item ? item.name : `#${id}`;

            const confirmed = window.confirm(
                `Supprimer ${name} ? Cette action supprime aussi ses recettes (en tant que composant ou composé) et ses entrées de build. Cette action est irréversible.`
            );
            if (!confirmed) return;

            button.disabled = true;

            deleteAdminItem(id)
                .then(() => reloadAdminItems())
                .catch((err) => {
                    window.alert(err.message);
                    button.disabled = false;
                });
        }
    });
}

/**
 * Point d'entrée : câble le formulaire et la grille, puis déclenche le
 * premier chargement de la liste.
 */
document.addEventListener('DOMContentLoaded', () => {
    wireAdminItemForm();
    wireAdminItemsGrid();
    reloadAdminItems();
});
