<?php
/**
 * Point d'entrée de l'espace d'administration : liste des objets.
 * Rôle unique de ce fichier : initialiser, appliquer le layout admin et
 * charger le contenu de la page depuis admin/pages/items.php. Toute la
 * logique/contenu vit dans admin/pages/ — même principe que
 * admin/champions.php.
 *
 * Protégée : requireAdminSession() (voir admin/includes/auth.php) redirige
 * immédiatement vers admin/login.php si aucun compte admin n'est connecté
 * (ADMIN_SESSION_KEY absent de la session).
 */

require_once __DIR__ . '/includes/bootstrap.php';
requireAdminSession();

$pageTitle = 'Objets';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/pages/items.php';
require __DIR__ . '/includes/footer.php';
