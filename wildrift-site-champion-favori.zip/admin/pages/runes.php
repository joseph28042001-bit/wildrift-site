<?php
/**
 * Page d'administration : gestion des runes.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer admin) et l'initialisation restent dans
 * admin/runes.php.
 *
 * Même principe que admin/pages/champions.php et admin/pages/items.php :
 * la liste (connectée à GET /api/runes/, voir assets/js/admin-runes.js)
 * est complétée par une véritable gestion — un formulaire unique
 * (#admin-rune-form), réutilisé à la fois pour créer une rune
 * (POST /api/runes/) et pour en modifier une existante
 * (PUT /api/runes/?id=), plus un bouton de suppression
 * (DELETE /api/runes/?id=) sur chaque carte. Le formulaire est masqué
 * par défaut et affiché via le bouton "Ajouter une rune" ou via
 * "Modifier" sur une carte (qui le pré-remplit alors avec les valeurs
 * actuelles) — voir assets/js/admin-runes.js pour la bascule des trois
 * états (masqué / création / modification) et les appels réseau. Les
 * champs reprennent exactement les colonnes de la table `runes` (voir
 * database/schema.sql) : slug, name, tree, slot (par défaut 'minor'),
 * description (optionnel), image_url (optionnel).
 *
 * Hors périmètre de cette étape : toute authentification sur ces
 * actions (l'espace admin reste, comme avant, accessible sans connexion
 * — voir admin/login.php, dont la connexion effective n'est pas encore
 * câblée côté serveur) et l'association d'une rune à un build
 * (build_runes), non couverte par ce formulaire.
 */
?>
<section class="container placeholder-section">
    <h1>Runes</h1>
    <p>Liste de toutes les runes enregistrées sur la plateforme.</p>

    <button type="button" id="admin-rune-add-btn" class="btn btn--sm" style="margin-top: var(--space-4);">
        + Ajouter une rune
    </button>
</section>

<section class="container" id="admin-rune-form-section" hidden>
    <div class="card" style="padding: var(--space-6); max-width: 40rem;">
        <h2 id="admin-rune-form-title">Ajouter une rune</h2>

        <form id="admin-rune-form" novalidate>
            <input type="hidden" id="admin-rune-form-id" value="">

            <p id="admin-rune-form-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

            <div class="field">
                <label for="admin-rune-slug">Slug</label>
                <input
                    type="text"
                    id="admin-rune-slug"
                    class="input"
                    placeholder="Ex. electrocute"
                    pattern="[a-z0-9]+(-[a-z0-9]+)*"
                    maxlength="60"
                    required
                >
                <p class="field__hint">Minuscules, chiffres et tirets uniquement. Doit être unique.</p>
                <p class="field__error">Format invalide (ex. "electrocute").</p>
            </div>

            <div class="field">
                <label for="admin-rune-name">Nom</label>
                <input type="text" id="admin-rune-name" class="input" maxlength="60" required>
                <p class="field__error">Le nom est requis.</p>
            </div>

            <div class="field">
                <label for="admin-rune-tree">Arbre</label>
                <select id="admin-rune-tree" class="select" required>
                    <option value="">Choisir un arbre</option>
                    <option value="precision">Précision</option>
                    <option value="domination">Domination</option>
                    <option value="sorcery">Sorcellerie</option>
                    <option value="resolve">Détermination</option>
                    <option value="inspiration">Inspiration</option>
                </select>
                <p class="field__error">L'arbre est requis.</p>
            </div>

            <div class="field">
                <label for="admin-rune-slot">Emplacement</label>
                <select id="admin-rune-slot" class="select" required>
                    <option value="minor">Mineure</option>
                    <option value="keystone">Majeure (keystone)</option>
                </select>
                <p class="field__hint">Une seule rune majeure par arbre.</p>
            </div>

            <div class="field">
                <label for="admin-rune-description">Description</label>
                <input type="text" id="admin-rune-description" class="input" maxlength="255">
                <p class="field__hint">Optionnel.</p>
            </div>

            <div class="field">
                <label for="admin-rune-image-url">URL de l'image</label>
                <input type="url" id="admin-rune-image-url" class="input" placeholder="https://...">
                <p class="field__hint">Optionnel.</p>
            </div>

            <div class="stack" style="flex-direction: row; gap: var(--space-3); margin-top: var(--space-5);">
                <button type="submit" id="admin-rune-form-submit" class="btn btn--sm">Enregistrer</button>
                <button type="button" id="admin-rune-form-cancel" class="btn btn--secondary btn--sm">Annuler</button>
            </div>
        </form>
    </div>
</section>

<section class="container">
    <div id="admin-runes-loading" class="stack">
        <div class="spinner"></div>
        <span class="text-muted">Chargement des runes…</span>
    </div>

    <p id="admin-runes-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

    <div id="admin-runes-grid" class="grid"></div>
</section>

<script>
    // Base des appels API pour assets/js/admin-runes.js, qui ne peut
    // pas appeler directement la fonction PHP asset() — même principe
    // que admin/pages/champions.php et admin/pages/items.php.
    window.API_BASE_URL = <?= json_encode(asset('api')) ?>;
</script>
<script src="<?= asset('assets/js/admin-runes.js') ?>"></script>
