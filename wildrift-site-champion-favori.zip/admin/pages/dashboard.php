<?php
/**
 * Page d'administration : tableau de bord.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer admin) et l'initialisation restent dans
 * admin/index.php — même principe que admin/pages/champions.php et
 * admin/pages/items.php.
 *
 * Étape actuelle : une vue d'ensemble en lecture seule du contenu de la
 * plateforme, sous forme de cartes de statistiques (une par ressource :
 * Champions, Objets, Builds, Matchups, Runes, Tier List, Actualités,
 * Patches). Chaque carte est peuplée indépendamment par
 * assets/js/admin-dashboard.js, qui interroge les API publiques déjà
 * existantes (GET /api/champions/, /api/items/, /api/builds/,
 * /api/counters/, /api/runes/, /api/tier-list/, /api/news/, /api/patches/)
 * — les mêmes que celles utilisées par les pages publiques correspondantes
 * (Patches exceptée, sans équivalent public). Contrairement à
 * admin/pages/champions.php (une seule requête, un seul état de
 * chargement/erreur global), chaque carte gère son propre état ici :
 * l'échec d'une ressource (ex. Builds indisponible) n'empêche pas
 * l'affichage des autres compteurs déjà revenus.
 *
 * Les cartes Champions, Objets, Builds, Runes, Actualités et Patches
 * pointent vers une page de gestion (admin/champions.php, admin/items.php,
 * admin/builds.php, admin/runes.php, admin/news.php — cette dernière
 * limitée à la publication/dépublication, pas de création/modification
 * de contenu — et admin/patches.php, voir admin/pages/patches.php pour
 * la gestion complète : liste, création, modification,
 * activation/désactivation) : Matchups et Tier List n'ont pas encore de
 * page d'administration dédiée, donc leur carte affiche uniquement le
 * compteur, sans lien.
 *
 * Aucune action de gestion (création, modification, suppression) n'est
 * développée à cette étape, ni ici ni sur les autres pages admin.
 */
?>
<section class="container placeholder-section">
    <h1>Tableau de bord</h1>
    <p>Vue d'ensemble du contenu actuellement enregistré sur la plateforme.</p>
</section>

<section class="container">
    <div id="admin-dashboard-stats" class="grid">
        <article class="card" data-stat="champions">
            <div class="card__eyebrow">Champions</div>
            <div class="card__title" id="admin-dashboard-stat-champions" style="font-size: var(--text-xl); font-family: var(--font-display); color: var(--color-brass-bright);">
                <span class="spinner" aria-label="Chargement"></span>
            </div>
            <div class="card__foot">
                <a href="<?= asset('admin/champions.php') ?>" class="text-mono text-muted" style="font-size: var(--text-xs);">Gérer →</a>
            </div>
        </article>

        <article class="card" data-stat="items">
            <div class="card__eyebrow">Objets</div>
            <div class="card__title" id="admin-dashboard-stat-items" style="font-size: var(--text-xl); font-family: var(--font-display); color: var(--color-brass-bright);">
                <span class="spinner" aria-label="Chargement"></span>
            </div>
            <div class="card__foot">
                <a href="<?= asset('admin/items.php') ?>" class="text-mono text-muted" style="font-size: var(--text-xs);">Gérer →</a>
            </div>
        </article>

        <article class="card" data-stat="builds">
            <div class="card__eyebrow">Builds</div>
            <div class="card__title" id="admin-dashboard-stat-builds" style="font-size: var(--text-xl); font-family: var(--font-display); color: var(--color-brass-bright);">
                <span class="spinner" aria-label="Chargement"></span>
            </div>
            <div class="card__foot">
                <a href="<?= asset('admin/builds.php') ?>" class="text-mono text-muted" style="font-size: var(--text-xs);">Gérer →</a>
            </div>
        </article>

        <article class="card" data-stat="counters">
            <div class="card__eyebrow">Matchups</div>
            <div class="card__title" id="admin-dashboard-stat-counters" style="font-size: var(--text-xl); font-family: var(--font-display); color: var(--color-brass-bright);">
                <span class="spinner" aria-label="Chargement"></span>
            </div>
            <div class="card__foot">
                <span class="text-mono text-muted" style="font-size: var(--text-xs);">Lecture seule</span>
            </div>
        </article>

        <article class="card" data-stat="runes">
            <div class="card__eyebrow">Runes</div>
            <div class="card__title" id="admin-dashboard-stat-runes" style="font-size: var(--text-xl); font-family: var(--font-display); color: var(--color-brass-bright);">
                <span class="spinner" aria-label="Chargement"></span>
            </div>
            <div class="card__foot">
                <a href="<?= asset('admin/runes.php') ?>" class="text-mono text-muted" style="font-size: var(--text-xs);">Gérer →</a>
            </div>
        </article>

        <article class="card" data-stat="tier-list">
            <div class="card__eyebrow">Tier List</div>
            <div class="card__title" id="admin-dashboard-stat-tier-list" style="font-size: var(--text-xl); font-family: var(--font-display); color: var(--color-brass-bright);">
                <span class="spinner" aria-label="Chargement"></span>
            </div>
            <div class="card__foot">
                <span class="text-mono text-muted" style="font-size: var(--text-xs);">Lecture seule</span>
            </div>
        </article>

        <article class="card" data-stat="news">
            <div class="card__eyebrow">Actualités</div>
            <div class="card__title" id="admin-dashboard-stat-news" style="font-size: var(--text-xl); font-family: var(--font-display); color: var(--color-brass-bright);">
                <span class="spinner" aria-label="Chargement"></span>
            </div>
            <div class="card__foot">
                <a href="<?= asset('admin/news.php') ?>" class="text-mono text-muted" style="font-size: var(--text-xs);">Gérer →</a>
            </div>
        </article>

        <article class="card" data-stat="patches">
            <div class="card__eyebrow">Patches</div>
            <div class="card__title" id="admin-dashboard-stat-patches" style="font-size: var(--text-xl); font-family: var(--font-display); color: var(--color-brass-bright);">
                <span class="spinner" aria-label="Chargement"></span>
            </div>
            <div class="card__foot">
                <a href="<?= asset('admin/patches.php') ?>" class="text-mono text-muted" style="font-size: var(--text-xs);">Gérer →</a>
            </div>
        </article>
    </div>
</section>

<script>
    // Base des appels API pour assets/js/admin-dashboard.js, qui ne peut
    // pas appeler directement la fonction PHP asset() — même principe
    // que admin/pages/champions.php et admin/pages/items.php.
    window.API_BASE_URL = <?= json_encode(asset('api')) ?>;
</script>
<script src="<?= asset('assets/js/admin-dashboard.js') ?>"></script>
