<?php
/**
 * Page d'administration : gestion des patches.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer admin) et l'initialisation restent dans
 * admin/patches.php — même principe que admin/pages/champions.php et
 * admin/pages/news.php.
 *
 * Vue en trois parties, sur le modèle de admin/pages/champions.php :
 *   - un rappel du patch actuellement actif (#admin-patches-active),
 *     toujours visible, alimenté par GET /api/patches/ ;
 *   - un formulaire unique (#admin-patch-form), masqué par défaut,
 *     réutilisé pour créer un patch (POST /api/patches/) et pour
 *     modifier les informations d'un patch existant (PUT
 *     /api/patches/?id=) — version, date de sortie (optionnelle) et
 *     description (optionnelle). Un patch nouvellement créé est
 *     toujours inactif (voir insertPatch(), includes/patches.php) :
 *     ce formulaire ne touche jamais à l'activation ;
 *   - la liste de tous les patches (#admin-patches-grid), avec, sur
 *     chaque carte, "Modifier" et, selon l'état, "Activer" ou
 *     "Désactiver" (PATCH /api/patches/?id=, voir
 *     assets/js/admin-patches.js pour la bascule des trois états du
 *     formulaire et les appels réseau).
 *
 * Aucune suppression de patch à cette étape (voir api/patches/index.php) :
 * seuls Modifier/Activer/Désactiver figurent sur chaque carte.
 */
?>
<section class="container placeholder-section">
    <h1>Gestion des patches</h1>
    <p>Versions du jeu Wild Rift gérées par le site — le patch actif détermine les données affichées par défaut sur les pages publiques (Builds, Tier List, fiches champion).</p>

    <p id="admin-patches-active" class="text-mono" style="margin-top: var(--space-4); font-size: var(--text-md);">
        <span class="text-muted">Patch actif :</span> <span class="spinner" aria-label="Chargement"></span>
    </p>

    <button type="button" id="admin-patch-add-btn" class="btn btn--sm" style="margin-top: var(--space-4);">
        + Ajouter un patch
    </button>
</section>

<section class="container" id="admin-patch-form-section" hidden>
    <div class="card" style="padding: var(--space-6); max-width: 40rem;">
        <h2 id="admin-patch-form-title">Ajouter un patch</h2>

        <form id="admin-patch-form" novalidate>
            <input type="hidden" id="admin-patch-form-id" value="">

            <p id="admin-patch-form-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

            <div class="field">
                <label for="admin-patch-version">Version</label>
                <input
                    type="text"
                    id="admin-patch-version"
                    class="input"
                    placeholder="Ex. 7.3a"
                    maxlength="10"
                    required
                >
                <p class="field__hint">Numéro du patch tel qu'il est écrit dans le jeu (10 caractères maximum). Doit être unique.</p>
                <p class="field__error">La version est requise.</p>
            </div>

            <div class="field">
                <label for="admin-patch-release-date">Date de sortie</label>
                <input type="date" id="admin-patch-release-date" class="input">
                <p class="field__hint">Optionnelle.</p>
            </div>

            <div class="field">
                <label for="admin-patch-description">Description</label>
                <textarea id="admin-patch-description" class="textarea" maxlength="500"></textarea>
                <p class="field__hint">Optionnelle, 500 caractères maximum.</p>
            </div>

            <div class="stack" style="flex-direction: row; gap: var(--space-3); margin-top: var(--space-5);">
                <button type="submit" id="admin-patch-form-submit" class="btn btn--sm">Enregistrer</button>
                <button type="button" id="admin-patch-form-cancel" class="btn btn--secondary btn--sm">Annuler</button>
            </div>
        </form>
    </div>
</section>

<section class="container">
    <div id="admin-patches-loading" class="stack">
        <div class="spinner"></div>
        <span class="text-muted">Chargement des patches…</span>
    </div>

    <p id="admin-patches-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

    <div id="admin-patches-grid" class="grid"></div>
</section>

<script>
    // Base des appels API pour assets/js/admin-patches.js, qui ne peut
    // pas appeler directement la fonction PHP asset() — même principe
    // que admin/pages/champions.php.
    window.API_BASE_URL = <?= json_encode(asset('api')) ?>;
</script>
<script src="<?= asset('assets/js/admin-patches.js') ?>"></script>
