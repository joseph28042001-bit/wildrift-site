<?php
/**
 * Page d'administration : gestion des objets.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer admin) et l'initialisation restent dans
 * admin/items.php.
 *
 * Étape actuelle : la liste (déjà connectée à GET /api/items/, voir
 * assets/js/admin-items.js) est complétée par une véritable gestion —
 * un formulaire unique (#admin-item-form), réutilisé à la fois pour
 * créer un objet (POST /api/items/) et pour en modifier un existant
 * (PUT /api/items/?id=), plus un bouton de suppression
 * (DELETE /api/items/?id=) sur chaque carte. Le formulaire est masqué
 * par défaut et affiché via le bouton "Ajouter un objet" ou via
 * "Modifier" sur une carte (qui le pré-remplit alors avec les valeurs
 * actuelles) — voir assets/js/admin-items.js pour la bascule des trois
 * états (masqué / création / modification) et les appels réseau. Même
 * principe que admin/pages/champions.php pour les champions. Les
 * champs reprennent exactement les colonnes de la table `items` (voir
 * database/schema.sql) : slug, name, category, price (optionnel),
 * description (optionnel), image_url (optionnel).
 *
 * Hors périmètre de cette étape : toute authentification sur ces
 * actions (l'espace admin reste, comme avant, accessible sans connexion
 * — voir admin/login.php, dont la connexion effective n'est pas encore
 * câblée côté serveur) et la gestion de la recette d'un objet
 * (item_recipes), non couverte par ce formulaire.
 */
?>
<section class="container placeholder-section">
    <h1>Objets</h1>
    <p>Liste de tous les objets enregistrés sur la plateforme.</p>

    <button type="button" id="admin-item-add-btn" class="btn btn--sm" style="margin-top: var(--space-4);">
        + Ajouter un objet
    </button>
</section>

<section class="container" id="admin-item-form-section" hidden>
    <div class="card" style="padding: var(--space-6); max-width: 40rem;">
        <h2 id="admin-item-form-title">Ajouter un objet</h2>

        <form id="admin-item-form" novalidate>
            <input type="hidden" id="admin-item-form-id" value="">

            <p id="admin-item-form-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

            <div class="field">
                <label for="admin-item-slug">Slug</label>
                <input
                    type="text"
                    id="admin-item-slug"
                    class="input"
                    placeholder="Ex. infinity-edge"
                    pattern="[a-z0-9]+(-[a-z0-9]+)*"
                    maxlength="60"
                    required
                >
                <p class="field__hint">Minuscules, chiffres et tirets uniquement. Doit être unique.</p>
                <p class="field__error">Format invalide (ex. "infinity-edge").</p>
            </div>

            <div class="field">
                <label for="admin-item-name">Nom</label>
                <input type="text" id="admin-item-name" class="input" maxlength="60" required>
                <p class="field__error">Le nom est requis.</p>
            </div>

            <div class="field">
                <label for="admin-item-category">Catégorie</label>
                <select id="admin-item-category" class="select" required>
                    <option value="">Choisir une catégorie</option>
                    <option value="attack">Attaque</option>
                    <option value="magic">Magie</option>
                    <option value="defense">Défense</option>
                    <option value="boots">Bottes</option>
                    <option value="jungle">Jungle</option>
                    <option value="consumable">Consommable</option>
                    <option value="enchantment">Enchantement</option>
                </select>
                <p class="field__error">La catégorie est requise.</p>
            </div>

            <div class="field">
                <label for="admin-item-price">Prix (en or)</label>
                <input type="number" id="admin-item-price" class="input" min="0" max="65535" step="1">
                <p class="field__hint">Optionnel.</p>
            </div>

            <div class="field">
                <label for="admin-item-description">Description</label>
                <input type="text" id="admin-item-description" class="input" maxlength="255">
                <p class="field__hint">Optionnel.</p>
            </div>

            <div class="field">
                <label for="admin-item-image-url">URL de l'image</label>
                <input type="url" id="admin-item-image-url" class="input" placeholder="https://...">
                <p class="field__hint">Optionnel.</p>
            </div>

            <div class="stack" style="flex-direction: row; gap: var(--space-3); margin-top: var(--space-5);">
                <button type="submit" id="admin-item-form-submit" class="btn btn--sm">Enregistrer</button>
                <button type="button" id="admin-item-form-cancel" class="btn btn--secondary btn--sm">Annuler</button>
            </div>
        </form>
    </div>
</section>

<section class="container">
    <div id="admin-items-loading" class="stack">
        <div class="spinner"></div>
        <span class="text-muted">Chargement des objets…</span>
    </div>

    <p id="admin-items-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

    <div id="admin-items-grid" class="grid"></div>
</section>

<script>
    // Base des appels API pour assets/js/admin-items.js, qui ne peut
    // pas appeler directement la fonction PHP asset() — même principe
    // que admin/pages/champions.php.
    window.API_BASE_URL = <?= json_encode(asset('api')) ?>;
</script>
<script src="<?= asset('assets/js/admin-items.js') ?>"></script>
