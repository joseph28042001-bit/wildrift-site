<?php
/**
 * Page d'administration : Connexion.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer admin) et l'initialisation restent dans
 * admin/login.php — même principe que admin/pages/champions.php.
 *
 * Le formulaire de connexion (mot de passe seul, pas d'email) est
 * validé à la fois côté navigateur (attribut HTML natif + assets/js/
 * admin-login.js) et côté serveur (voir le traitement dans
 * admin/login.php, qui remplit $adminLoginErrors avant d'inclure ce
 * fichier) : comparaison avec ADMIN_PASSWORD (config/config.local.php)
 * via hash_equals(), limitation des tentatives
 * (SECURITY_MAX_LOGIN_ATTEMPTS) puis connexion effective via
 * ADMIN_SESSION_KEY et regenerateSessionId() (voir config/session.php)
 * en cas de succès, avec redirection vers admin/index.php.
 *
 * Une fois connecté, les autres pages admin (admin/index.php,
 * admin/champions.php, admin/items.php, etc.) sont protégées par
 * requireAdminSession() (voir admin/includes/auth.php).
 */
$adminLoginErrors ??= [];

$fieldHasError = static function (string $field) use ($adminLoginErrors): bool {
    return isset($adminLoginErrors[$field]);
};
?>
<section class="section" style="padding-top: var(--space-7);">
    <div class="container" style="max-width: 32rem;">
        <h1>Connexion administrateur</h1>
        <p class="text-muted" style="margin-bottom: var(--space-6);">
            Réservé aux membres de l'équipe pour gérer le contenu du site.
        </p>

        <?php if ($fieldHasError('global')): ?>
            <div style="padding: var(--space-4); border: 1px solid var(--color-crimson); border-radius: var(--radius-md, 8px); color: var(--color-crimson); margin-bottom: var(--space-6);">
                <?= e($adminLoginErrors['global']) ?>
            </div>
        <?php endif; ?>

        <form id="admin-login-form" action="<?= asset('admin/login.php') ?>" method="post" novalidate>
            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

            <div class="field<?= $fieldHasError('password') ? ' is-invalid' : '' ?>">
                <label for="admin-login-password">Mot de passe</label>
                <input
                    type="password"
                    id="admin-login-password"
                    name="password"
                    class="input"
                    autocomplete="current-password"
                    required
                >
                <p class="field__error">Saisis ton mot de passe.</p>
            </div>

            <button type="submit" class="btn btn--block">Se connecter</button>
        </form>
    </div>
</section>

<script src="<?= asset('assets/js/admin-login.js') ?>"></script>
