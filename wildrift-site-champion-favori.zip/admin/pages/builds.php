<?php
/**
 * Page d'administration : gestion des builds.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer admin) et l'initialisation restent dans
 * admin/builds.php.
 *
 * Même principe que admin/pages/champions.php, admin/pages/items.php et
 * admin/pages/runes.php : un formulaire unique (#admin-build-form),
 * réutilisé à la fois pour créer un build (POST /api/builds/) et pour
 * en modifier un existant (PUT /api/builds/?id=), plus un bouton de
 * suppression (DELETE /api/builds/?id=) sur chaque carte. Le
 * formulaire est masqué par défaut et affiché via le bouton "Ajouter un
 * build" ou via "Modifier" sur une carte (qui le pré-remplit alors avec
 * les valeurs actuelles) — voir assets/js/admin-builds.js pour la
 * bascule des trois états (masqué / création / modification) et les
 * appels réseau.
 *
 * Différence avec les trois pages précédentes : un build référence un
 * champion (colonne champion_id, voir database/schema.sql) — le champ
 * "Champion" du formulaire est donc un <select>, peuplé dynamiquement
 * depuis GET /api/champions/ au chargement de la page (voir
 * assets/js/admin-builds.js), plutôt qu'une liste fixe d'options comme
 * "Rôle" ci-dessous. La liste elle-même reste, comme sur la page
 * publique Builds (pages/builds.php), paginée (GET /api/builds/?page=,
 * BUILD_PAGE_SIZE résultats par page — voir api/builds/repository.php)
 * : les contrôles Précédent/Suivant ci-dessous naviguent entre les
 * pages, sans recherche ni filtre (hors périmètre de cette étape,
 * contrairement à la page publique).
 *
 * Hors périmètre de cette étape : toute authentification sur ces
 * actions (l'espace admin reste, comme avant, accessible sans connexion
 * — voir admin/login.php, dont la connexion effective n'est pas encore
 * câblée côté serveur) et la gestion des objets (build_items), des
 * runes (build_runes) et de l'ordre des compétences
 * (build_skill_order) d'un build, non couverte par ce formulaire.
 */
?>
<section class="container placeholder-section">
    <h1>Builds</h1>
    <p>Liste de tous les builds enregistrés sur la plateforme.</p>

    <button type="button" id="admin-build-add-btn" class="btn btn--sm" style="margin-top: var(--space-4);">
        + Ajouter un build
    </button>
</section>

<section class="container" id="admin-build-form-section" hidden>
    <div class="card" style="padding: var(--space-6); max-width: 40rem;">
        <h2 id="admin-build-form-title">Ajouter un build</h2>

        <form id="admin-build-form" novalidate>
            <input type="hidden" id="admin-build-form-id" value="">

            <p id="admin-build-form-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

            <div class="field">
                <label for="admin-build-champion">Champion</label>
                <select id="admin-build-champion" class="select" required>
                    <option value="">Choisir un champion</option>
                </select>
                <p class="field__error">Le champion est requis.</p>
            </div>

            <div class="field">
                <label for="admin-build-name">Nom du build</label>
                <input type="text" id="admin-build-name" class="input" maxlength="80" required>
                <p class="field__hint">Doit être unique pour ce champion.</p>
                <p class="field__error">Le nom est requis.</p>
            </div>

            <div class="field">
                <label for="admin-build-role">Rôle</label>
                <select id="admin-build-role" class="select" required>
                    <option value="">Choisir un rôle</option>
                    <option value="baron">Voie Baron</option>
                    <option value="jungle">Jungle</option>
                    <option value="mid">Voie du Milieu</option>
                    <option value="dragon">Voie Dragon</option>
                    <option value="support">Support</option>
                </select>
                <p class="field__error">Le rôle est requis.</p>
            </div>

            <div class="field">
                <label for="admin-build-patch">Patch</label>
                <input type="text" id="admin-build-patch" class="input" placeholder="Ex. 5.2" maxlength="10" required>
                <p class="field__error">Le patch est requis.</p>
            </div>

            <div class="field">
                <label for="admin-build-description">Description</label>
                <textarea id="admin-build-description" class="textarea" maxlength="500"></textarea>
                <p class="field__hint">Optionnel.</p>
            </div>

            <div class="field">
                <label for="admin-build-source">Source</label>
                <input type="text" id="admin-build-source" class="input" placeholder="Ex. nom du créateur ou URL" maxlength="255">
                <p class="field__hint">Optionnel.</p>
            </div>

            <div class="stack" style="flex-direction: row; gap: var(--space-3); margin-top: var(--space-5);">
                <button type="submit" id="admin-build-form-submit" class="btn btn--sm">Enregistrer</button>
                <button type="button" id="admin-build-form-cancel" class="btn btn--secondary btn--sm">Annuler</button>
            </div>
        </form>
    </div>
</section>

<section class="container">
    <div id="admin-builds-loading" class="stack">
        <div class="spinner"></div>
        <span class="text-muted">Chargement des builds…</span>
    </div>

    <p id="admin-builds-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

    <div id="admin-builds-grid" class="grid"></div>

    <div id="admin-builds-pagination" class="stack" style="flex-direction: row; align-items: center; justify-content: center; gap: var(--space-3); margin-top: var(--space-6);" hidden>
        <button type="button" id="admin-builds-page-prev" class="btn btn--secondary btn--sm">Précédent</button>
        <span id="admin-builds-page-info" class="text-mono text-muted" style="font-size: var(--text-sm);"></span>
        <button type="button" id="admin-builds-page-next" class="btn btn--secondary btn--sm">Suivant</button>
    </div>
</section>

<script>
    // Base des appels API pour assets/js/admin-builds.js, qui ne peut
    // pas appeler directement la fonction PHP asset() — même principe
    // que admin/pages/champions.php, admin/pages/items.php et
    // admin/pages/runes.php.
    window.API_BASE_URL = <?= json_encode(asset('api')) ?>;
</script>
<script src="<?= asset('assets/js/admin-builds.js') ?>"></script>
