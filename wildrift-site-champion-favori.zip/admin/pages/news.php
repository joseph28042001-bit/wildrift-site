<?php
/**
 * Page d'administration : publication/dépublication des articles.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer admin) et l'initialisation restent dans
 * admin/news.php — même principe que admin/pages/champions.php.
 *
 * Étape actuelle : la liste de TOUS les articles (brouillons inclus,
 * via GET /api/news/?all=1, voir findAllNewsForAdmin() dans
 * api/news/repository.php) avec, pour chacun, un unique bouton qui
 * bascule son état de publication (PATCH /api/news/?id=, voir
 * assets/js/admin-news.js). Aucune création, modification de contenu
 * (titre, texte, catégorie...) ni suppression d'article n'est
 * développée ici — hors périmètre de cette étape.
 */
?>
<section class="container placeholder-section">
    <h1>Actualités</h1>
    <p>Publiez ou dépubliez un article. Les brouillons (non publiés) sont affichés en premier.</p>
</section>

<section class="container">
    <div id="admin-news-loading" class="stack">
        <div class="spinner"></div>
        <span class="text-muted">Chargement des articles…</span>
    </div>

    <p id="admin-news-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

    <div id="admin-news-list" class="stack"></div>
</section>

<script>
    // Base des appels API pour assets/js/admin-news.js, qui ne peut pas
    // appeler directement la fonction PHP asset() — même principe que
    // admin/pages/champions.php.
    window.API_BASE_URL = <?= json_encode(asset('api')) ?>;
</script>
<script src="<?= asset('assets/js/admin-news.js') ?>"></script>
