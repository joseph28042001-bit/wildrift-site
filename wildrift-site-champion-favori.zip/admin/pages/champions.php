<?php
/**
 * Page d'administration : gestion des champions.
 * Contient uniquement le contenu de la page ; le routage, le layout
 * (header/footer admin) et l'initialisation restent dans
 * admin/champions.php.
 *
 * Étape actuelle : la liste (déjà connectée à GET /api/champions/, voir
 * assets/js/admin-champions.js) est complétée par une véritable gestion
 * — un formulaire unique (#admin-champion-form), réutilisé à la fois
 * pour créer un champion (POST /api/champions/) et pour en modifier un
 * existant (PUT /api/champions/?id=), plus un bouton de suppression
 * (DELETE /api/champions/?id=) sur chaque carte. Le formulaire est
 * masqué par défaut et affiché via le bouton "Ajouter un champion" ou
 * via "Modifier" sur une carte (qui le pré-remplit alors avec les
 * valeurs actuelles) — voir assets/js/admin-champions.js pour la bascule
 * des trois états (masqué / création / modification) et les appels
 * réseau. Les champs reprennent exactement les colonnes de la table
 * `champions` (voir database/schema.sql) : slug, name, title (optionnel),
 * role, difficulty, cc_level, engage_level, disengage_level,
 * early_game_level, late_game_level, image_url (optionnel).
 *
 * Hors périmètre de cette étape : toute authentification sur ces
 * actions (l'espace admin reste, comme avant, accessible sans connexion
 * — voir admin/login.php, dont la connexion effective n'est pas encore
 * câblée côté serveur) et la gestion des capacités d'un champion
 * (champion_abilities), non couverte par ce formulaire.
 */
?>
<section class="container placeholder-section">
    <h1>Champions</h1>
    <p>Liste de tous les champions enregistrés sur la plateforme.</p>

    <button type="button" id="admin-champion-add-btn" class="btn btn--sm" style="margin-top: var(--space-4);">
        + Ajouter un champion
    </button>
</section>

<section class="container" id="admin-champion-form-section" hidden>
    <div class="card" style="padding: var(--space-6); max-width: 40rem;">
        <h2 id="admin-champion-form-title">Ajouter un champion</h2>

        <form id="admin-champion-form" novalidate>
            <input type="hidden" id="admin-champion-form-id" value="">

            <p id="admin-champion-form-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

            <div class="field">
                <label for="admin-champion-slug">Slug</label>
                <input
                    type="text"
                    id="admin-champion-slug"
                    class="input"
                    placeholder="Ex. lee-sin"
                    pattern="[a-z0-9]+(-[a-z0-9]+)*"
                    maxlength="60"
                    required
                >
                <p class="field__hint">Minuscules, chiffres et tirets uniquement. Doit être unique.</p>
                <p class="field__error">Format invalide (ex. "lee-sin").</p>
            </div>

            <div class="field">
                <label for="admin-champion-name">Nom</label>
                <input type="text" id="admin-champion-name" class="input" maxlength="60" required>
                <p class="field__error">Le nom est requis.</p>
            </div>

            <div class="field">
                <label for="admin-champion-title">Titre</label>
                <input type="text" id="admin-champion-title" class="input" placeholder="Ex. Le moine aveugle" maxlength="120">
                <p class="field__hint">Optionnel.</p>
            </div>

            <div class="field">
                <label for="admin-champion-role">Rôle</label>
                <select id="admin-champion-role" class="select" required>
                    <option value="">Choisir un rôle</option>
                    <option value="baron">Voie Baron</option>
                    <option value="jungle">Jungle</option>
                    <option value="mid">Voie du Milieu</option>
                    <option value="dragon">Voie Dragon</option>
                    <option value="support">Support</option>
                </select>
                <p class="field__error">Le rôle est requis.</p>
            </div>

            <div class="field">
                <label for="admin-champion-difficulty">Difficulté (1 à 5)</label>
                <input type="number" id="admin-champion-difficulty" class="input" min="1" max="5" step="1" required>
                <p class="field__error">Choisis une difficulté entre 1 et 5.</p>
            </div>

            <div class="field">
                <label for="admin-champion-cc-level">Niveau de contrôle de foule (CC)</label>
                <select id="admin-champion-cc-level" class="select" required>
                    <option value="">Choisir un niveau</option>
                    <option value="faible">Faible</option>
                    <option value="moyen">Moyen</option>
                    <option value="fort">Fort</option>
                </select>
                <p class="field__error">Ce niveau est requis.</p>
            </div>

            <div class="field">
                <label for="admin-champion-engage-level">Potentiel d'engagement</label>
                <select id="admin-champion-engage-level" class="select" required>
                    <option value="">Choisir un niveau</option>
                    <option value="faible">Faible</option>
                    <option value="moyen">Moyen</option>
                    <option value="fort">Fort</option>
                </select>
                <p class="field__error">Ce niveau est requis.</p>
            </div>

            <div class="field">
                <label for="admin-champion-disengage-level">Potentiel de disengage</label>
                <select id="admin-champion-disengage-level" class="select" required>
                    <option value="">Choisir un niveau</option>
                    <option value="faible">Faible</option>
                    <option value="moyen">Moyen</option>
                    <option value="fort">Fort</option>
                </select>
                <p class="field__error">Ce niveau est requis.</p>
            </div>

            <div class="field">
                <label for="admin-champion-early-game-level">Puissance en early game</label>
                <select id="admin-champion-early-game-level" class="select" required>
                    <option value="">Choisir un niveau</option>
                    <option value="faible">Faible</option>
                    <option value="moyen">Moyen</option>
                    <option value="fort">Fort</option>
                </select>
                <p class="field__error">Ce niveau est requis.</p>
            </div>

            <div class="field">
                <label for="admin-champion-late-game-level">Puissance en late game</label>
                <select id="admin-champion-late-game-level" class="select" required>
                    <option value="">Choisir un niveau</option>
                    <option value="faible">Faible</option>
                    <option value="moyen">Moyen</option>
                    <option value="fort">Fort</option>
                </select>
                <p class="field__error">Ce niveau est requis.</p>
            </div>

            <div class="field">
                <label for="admin-champion-image-url">URL de l'image</label>
                <input type="url" id="admin-champion-image-url" class="input" placeholder="https://...">
                <p class="field__hint">Optionnel.</p>
            </div>

            <div class="stack" style="flex-direction: row; gap: var(--space-3); margin-top: var(--space-5);">
                <button type="submit" id="admin-champion-form-submit" class="btn btn--sm">Enregistrer</button>
                <button type="button" id="admin-champion-form-cancel" class="btn btn--secondary btn--sm">Annuler</button>
            </div>
        </form>
    </div>
</section>

<section class="container">
    <div id="admin-champions-loading" class="stack">
        <div class="spinner"></div>
        <span class="text-muted">Chargement des champions…</span>
    </div>

    <p id="admin-champions-error" class="text-mono" style="color: var(--color-crimson);" hidden></p>

    <div id="admin-champions-grid" class="grid"></div>
</section>

<script>
    // Base des appels API pour assets/js/admin-champions.js, qui ne peut
    // pas appeler directement la fonction PHP asset() — même principe
    // que includes/components/footer.php (partie publique), non inclus
    // ici (voir admin/includes/footer.php).
    window.API_BASE_URL = <?= json_encode(asset('api')) ?>;
</script>
<script src="<?= asset('assets/js/admin-champions.js') ?>"></script>
