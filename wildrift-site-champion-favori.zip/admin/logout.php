<?php
/**
 * Action d'administration : Déconnexion.
 * Même principe que logout.php (déconnexion publique) mais dédiée à
 * l'espace admin — jusqu'ici absente, alors que l'espace admin dispose
 * d'une vraie connexion (voir admin/login.php, table `admins`) depuis
 * l'étape correspondante.
 *
 * Ce fichier ne charge aucun layout ni contenu : la déconnexion est une
 * action, pas une page à afficher.
 *
 * N'agit que sur une requête POST accompagnée d'un jeton CSRF valide
 * (voir csrfToken()/verifyCsrfToken() dans config/security.php) : une
 * simple requête GET (lien, image, requête forgée) ne déclenche donc
 * aucune déconnexion.
 *
 * Détruit la session en cours dans son intégralité (destroySession(),
 * voir config/session.php) — données côté serveur vidées, cookie de
 * session expiré côté navigateur — puis redirige vers la page de
 * connexion admin. Contrairement à requireAdminSession() (voir
 * admin/includes/auth.php), n'exige pas de session admin active avant
 * d'agir : une requête de déconnexion sur une session déjà expirée reste
 * sans risque (destroySession() est sans effet si aucune session n'est
 * active) et redirige simplement vers la connexion.
 */

require_once __DIR__ . '/includes/bootstrap.php';

$submittedToken = $_POST['csrf_token'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrfToken($submittedToken)) {
    destroySession();
}

redirect('admin/login.php');
