<?php
/**
 * Point d'entrée de l'espace d'administration.
 * Rôle unique : initialiser, appliquer le layout admin et charger
 * le contenu de la page depuis admin/pages/.
 *
 * Protégée : requireAdminSession() (voir admin/includes/auth.php) redirige
 * immédiatement vers admin/login.php si aucun compte admin n'est connecté
 * (ADMIN_SESSION_KEY absent de la session).
 */

require_once __DIR__ . '/includes/bootstrap.php';
requireAdminSession();

$pageTitle = 'Tableau de bord';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/pages/dashboard.php';
require __DIR__ . '/includes/footer.php';
