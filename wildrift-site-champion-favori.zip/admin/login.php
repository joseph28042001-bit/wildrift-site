<?php
/**
 * Point d'entrée de l'espace d'administration : connexion.
 * Rôle unique de ce fichier : initialiser, appliquer le layout admin et
 * charger le contenu de la page depuis admin/pages/login.php. Toute la
 * logique/contenu vit dans admin/pages/ — même principe que
 * admin/index.php (tableau de bord) et admin/champions.php.
 *
 * Traitement serveur de la connexion administrateur (voir
 * admin/pages/login.php pour le contenu affiché) :
 * - Un seul mot de passe, défini par ADMIN_PASSWORD (voir
 *   config/config.local.php) — pas d'email, pas de table `admins`.
 *   Comparaison avec hash_equals() (résistante aux attaques par
 *   mesure de temps), même si le mot de passe est stocké en clair
 *   dans la config plutôt que hashé.
 * - Limite les tentatives échouées via un compteur en session, sous
 *   des clés dédiées ('admin_login_attempts'/'admin_login_lockout_until',
 *   distinctes de celles de login.php) pour ne pas partager le même
 *   compteur qu'un éventuel compte public connecté dans le même
 *   navigateur.
 * - En cas de succès : régénère l'identifiant de session
 *   (regenerateSessionId(), protection contre la fixation de session)
 *   avant d'ouvrir la session administrateur (ADMIN_SESSION_KEY, voir
 *   config/session.php), puis redirige vers admin/index.php.
 *
 * Les autres pages admin (admin/index.php, admin/champions.php,
 * admin/items.php, etc.) sont protégées par requireAdminSession() (voir
 * admin/includes/auth.php) — jamais appelée ici : cette page-ci reste
 * volontairement accessible sans connexion, sous peine de redirection
 * infinie vers elle-même.
 *
 * scripts/create-admin.php et la table `admins` ne sont plus utilisés
 * par ce flux (conservés dans le projet mais inactifs) : la seule
 * source de vérité est désormais ADMIN_PASSWORD (config/config.local.php).
 */

require_once __DIR__ . '/includes/bootstrap.php';

if (!defined('ADMIN_LOGIN_LOCKOUT_SECONDS')) {
    define('ADMIN_LOGIN_LOCKOUT_SECONDS', 15 * 60);
}

$adminLoginErrors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lockoutUntil = (int) ($_SESSION['admin_login_lockout_until'] ?? 0);

    if ($lockoutUntil > time()) {
        $minutesLeft = (int) ceil(($lockoutUntil - time()) / 60);
        $adminLoginErrors['global'] = sprintf(
            'Trop de tentatives échouées. Réessaie dans %d minute%s.',
            $minutesLeft,
            $minutesLeft > 1 ? 's' : ''
        );
    } elseif (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        $adminLoginErrors['global'] = 'Ta session a expiré ou la requête est invalide. Merci de réessayer.';
    } else {
        $password = (string) ($_POST['password'] ?? '');

        if ($password === '') {
            $adminLoginErrors['password'] = 'Saisis le mot de passe.';
        } elseif (!hash_equals(ADMIN_PASSWORD, $password)) {
            $adminLoginErrors['global'] = 'Mot de passe incorrect.';

            $attempts = (int) ($_SESSION['admin_login_attempts'] ?? 0) + 1;

            if ($attempts >= SECURITY_MAX_LOGIN_ATTEMPTS) {
                $_SESSION['admin_login_lockout_until'] = time() + ADMIN_LOGIN_LOCKOUT_SECONDS;
                $_SESSION['admin_login_attempts'] = 0;
            } else {
                $_SESSION['admin_login_attempts'] = $attempts;
            }
        } else {
            unset($_SESSION['admin_login_attempts'], $_SESSION['admin_login_lockout_until']);

            regenerateSessionId();
            $_SESSION[ADMIN_SESSION_KEY] = 1;

            redirect('admin/index.php');
        }
    }
}

$pageTitle = 'Connexion administrateur';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/pages/login.php';
require __DIR__ . '/includes/footer.php';
