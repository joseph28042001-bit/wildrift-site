<?php
/**
 * Bootstrap de l'espace d'administration.
 * Charge le bootstrap public puis prépare le contexte propre à l'admin.
 */

require_once __DIR__ . '/../../includes/bootstrap.php';

// Protection des pages admin (voir requireAdminSession(), auth.php) :
// chargée ici pour être disponible partout dans l'espace admin, mais
// PAS appelée depuis ce bootstrap (voir le commentaire d'en-tête de
// auth.php — admin/login.php partage ce même bootstrap et ne doit
// jamais être protégé). Chaque point d'entrée qui le nécessite
// l'appelle lui-même, juste après avoir chargé ce bootstrap.
require_once __DIR__ . '/auth.php';

// Régénère périodiquement l'identifiant de session d'un compte admin
// connecté (voir maybeRegenerateAdminSession(), config/session.php) :
// sans effet tant qu'aucun admin n'est connecté (ADMIN_SESSION_KEY
// absent), donc sûr à appeler sur chaque page admin, y compris la page
// de connexion elle-même.
maybeRegenerateAdminSession();
