    </main>
    <footer class="site-footer">
        <div class="container">
            <p>&copy; <?= date('Y') ?> <?= e(APP_NAME) ?> — Espace d'administration.</p>
        </div>
    </footer>
</body>
</html>
