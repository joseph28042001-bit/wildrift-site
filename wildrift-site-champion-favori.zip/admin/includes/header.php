<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? e($pageTitle) . ' — ' : '' ?>Administration — <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= asset('assets/css/style.css') ?>">
    <script>window.CURRENT_PATCH = <?= json_encode(CURRENT_PATCH) ?>;</script>
</head>
<body class="admin-body">
    <header class="site-header">
        <div class="container site-header__inner">
            <a href="<?= asset('admin/') ?>" class="site-header__brand">Administration</a>
            <nav class="site-header__nav">
                <a href="<?= asset('admin/champions.php') ?>"<?= ($pageTitle ?? '') === 'Champions' ? ' aria-current="page"' : '' ?>>Champions</a>
                <a href="<?= asset('admin/items.php') ?>"<?= ($pageTitle ?? '') === 'Objets' ? ' aria-current="page"' : '' ?>>Objets</a>
                <a href="<?= asset('admin/builds.php') ?>"<?= ($pageTitle ?? '') === 'Builds' ? ' aria-current="page"' : '' ?>>Builds</a>
                <a href="<?= asset('admin/runes.php') ?>"<?= ($pageTitle ?? '') === 'Runes' ? ' aria-current="page"' : '' ?>>Runes</a>
                <a href="<?= asset('admin/news.php') ?>"<?= ($pageTitle ?? '') === 'Actualités' ? ' aria-current="page"' : '' ?>>Actualités</a>
                <a href="<?= asset('admin/patches.php') ?>"<?= ($pageTitle ?? '') === 'Patches' ? ' aria-current="page"' : '' ?>>Patches</a>
                <a href="<?= asset('') ?>">Retour au site</a>
                <?php if (!empty($_SESSION[ADMIN_SESSION_KEY])): ?>
                <form action="<?= asset('admin/logout.php') ?>" method="post" class="site-header__logout">
                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                    <button type="submit">Déconnexion</button>
                </form>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <main class="site-main">
