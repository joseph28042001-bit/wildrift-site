<?php
/**
 * Protection des pages de l'espace d'administration.
 * ------------------------------------------------------
 * Fonction réutilisable (voir requireAdminSession() ci-dessous), à
 * appeler en tête de chaque point d'entrée admin/*.php qui doit être
 * réservé aux comptes connectés — c'est-à-dire tous, à une seule
 * exception : admin/login.php lui-même. L'appeler là créerait une
 * redirection infinie (la page de connexion redirigerait vers
 * elle-même).
 *
 * Dépend de admin/includes/bootstrap.php, qui charge ce fichier (session
 * démarrée, ADMIN_SESSION_KEY défini — voir config/environment.php,
 * redirect() défini — voir includes/functions.php) : requireAdminSession()
 * ne doit donc jamais être appelée avant lui.
 */

/**
 * Vérifie qu'un compte administrateur est connecté (ADMIN_SESSION_KEY,
 * rempli par admin/login.php après un password_verify() réussi contre
 * la table `admins`) ; sinon redirige immédiatement vers la page de
 * connexion admin et arrête l'exécution (voir redirect(),
 * includes/functions.php) — la page appelante ne s'exécute pas plus loin.
 */
function requireAdminSession(): void
{
    if (empty($_SESSION[ADMIN_SESSION_KEY])) {
        redirect('admin/login.php');
    }
}
