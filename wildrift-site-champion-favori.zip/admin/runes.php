<?php
/**
 * Point d'entrée de l'espace d'administration : liste des runes.
 * Rôle unique de ce fichier : initialiser, appliquer le layout admin et
 * charger le contenu de la page depuis admin/pages/runes.php. Toute la
 * logique/contenu vit dans admin/pages/ — même principe que
 * admin/champions.php et admin/items.php.
 *
 * Protégée : requireAdminSession() (voir admin/includes/auth.php) redirige
 * immédiatement vers admin/login.php si aucun compte admin n'est connecté
 * (ADMIN_SESSION_KEY absent de la session).
 */

require_once __DIR__ . '/includes/bootstrap.php';
requireAdminSession();

$pageTitle = 'Runes';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/pages/runes.php';
require __DIR__ . '/includes/footer.php';
