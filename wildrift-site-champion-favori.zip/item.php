<?php
/**
 * Point d'entrée public : Objet (détail).
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/item.php. Toute la logique/contenu vit dans pages/ — même
 * principe que champion.php (fiche détaillée d'un champion).
 *
 * Accessible via item.php?id=5 (voir GET /api/items/?id=,
 * api/items/index.php). L'ID n'est pas validé ici : c'est
 * assets/js/item.js qui le lit depuis l'URL et gère les cas absents ou
 * invalides (voir ce fichier).
 *
 * Étape actuelle : uniquement la page de détail elle-même. Aucune carte
 * de la liste des objets (pages/items.php) ne pointe encore vers cette
 * page — hors périmètre de cette étape.
 */

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Objet';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/item.php';
require __DIR__ . '/includes/components/footer.php';
