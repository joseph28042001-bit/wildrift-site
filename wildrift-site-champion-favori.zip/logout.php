<?php
/**
 * Action publique : Déconnexion.
 * Contrairement aux autres points d'entrée (voir register.php,
 * login.php), ce fichier ne charge aucun layout ni contenu : la
 * déconnexion est une action, pas une page à afficher. Détruit la
 * session en cours (voir destroySession() dans config/session.php) puis
 * redirige vers l'accueil.
 *
 * N'agit que sur une requête POST accompagnée d'un jeton CSRF valide
 * (voir csrfToken()/verifyCsrfToken() dans config/security.php) : une
 * simple requête GET (lien, image, requête forgée) ne déclenche donc
 * aucune déconnexion, redirige simplement vers l'accueil sans effet.
 *
 * Hors périmètre de cette étape : aucun lien ou bouton "Déconnexion"
 * n'est encore ajouté au header, au footer ou à la page Profil — cela
 * dépend de la connexion effective des comptes via SESSION_USER_KEY,
 * elle-même pas encore développée (voir pages/login.php et
 * pages/register.php).
 */

require_once __DIR__ . '/includes/bootstrap.php';

$submittedToken = $_POST['csrf_token'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrfToken($submittedToken)) {
    destroySession();
}

redirect('');
