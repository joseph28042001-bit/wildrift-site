<?php
/**
 * Point d'entrée public : Matchup (détail).
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/matchup.php. Toute la logique/contenu vit dans pages/.
 *
 * Accessible via matchup.php?id=7 (voir GET /api/counters/?id=,
 * api/counters/index.php) — l'ID est celui du counter lui-même (colonne
 * `id` de la table `counters`), pas celui d'un champion. Même principe
 * que champion.php?id=/build.php?id=/item.php?id=/rune.php?id=. L'ID
 * n'est pas validé ici : c'est assets/js/matchup.js qui le lit depuis
 * l'URL et gère les cas absents ou invalides (voir ce fichier).
 *
 * Étape actuelle : uniquement la page de détail elle-même. Aucune carte
 * de la liste des matchups (pages/counters.php) ni de la section
 * Counters d'un champion (pages/champion.php) ne pointe encore vers
 * cette page — hors périmètre de cette étape (même limite que
 * champion.php à sa propre étape de création).
 */

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'Matchup';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/matchup.php';
require __DIR__ . '/includes/components/footer.php';
