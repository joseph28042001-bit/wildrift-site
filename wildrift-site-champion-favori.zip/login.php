<?php
/**
 * Point d'entrée public : Connexion.
 * Rôle unique de ce fichier : initialiser l'application, définir le
 * layout (header/footer) et charger le contenu de la page depuis
 * pages/login.php. Toute la logique/contenu vit dans pages/.
 */

require_once __DIR__ . '/includes/bootstrap.php';

/**
 * Traitement serveur de la connexion (voir pages/login.php pour le
 * contenu affiché). Reste dans ce point d'entrée, comme le traitement
 * de l'inscription reste dans register.php (voir pages/register.php).
 *
 * - Vérifie les identifiants contre `users` (password_verify() sur
 *   password_hash, jamais de comparaison en clair).
 * - Limite les tentatives échouées via un compteur en session
 *   (SECURITY_MAX_LOGIN_ATTEMPTS, voir config/environment.php) : pas de
 *   nouvelle table, le blocage temporaire se réinitialise avec la session.
 * - En cas de succès : régénère l'identifiant de session
 *   (regenerateSessionId(), protection contre la fixation de session)
 *   avant d'ouvrir la session utilisateur (SESSION_USER_KEY, voir
 *   config/session.php), puis redirige vers profile.php (qui attend déjà
 *   cette clé de session pour s'afficher).
 * - Case "Rester connecté" : prolonge la durée de vie du cookie de
 *   session plutôt que d'introduire un jeton persistant séparé (pas de
 *   nouvelle table) — reste une session PHP classique, juste plus longue.
 */
if (!defined('LOGIN_LOCKOUT_SECONDS')) {
    define('LOGIN_LOCKOUT_SECONDS', 15 * 60);
}

$loginErrors = [];
$oldEmail = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lockoutUntil = (int) ($_SESSION['login_lockout_until'] ?? 0);

    if ($lockoutUntil > time()) {
        $minutesLeft = (int) ceil(($lockoutUntil - time()) / 60);
        $loginErrors['global'] = sprintf(
            'Trop de tentatives échouées. Réessaie dans %d minute%s.',
            $minutesLeft,
            $minutesLeft > 1 ? 's' : ''
        );
    } elseif (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        $loginErrors['global'] = 'Ta session a expiré ou la requête est invalide. Merci de réessayer.';
    } else {
        $email = trim((string) ($_POST['email'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $remember = isset($_POST['remember']);

        $oldEmail = $email;

        if ($email === '' || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            $loginErrors['email'] = 'Saisis une adresse email valide.';
        }

        if ($password === '') {
            $loginErrors['password'] = 'Saisis ton mot de passe.';
        }

        if (empty($loginErrors)) {
            try {
                $user = dbFetchOne(
                    'SELECT id, password_hash FROM users WHERE email = :email LIMIT 1',
                    ['email' => $email]
                );
            } catch (DatabaseException $exception) {
                $loginErrors['global'] = $exception->getMessage();
                $user = null;
            }

            if (empty($loginErrors)) {
                if ($user === null || !password_verify($password, $user['password_hash'])) {
                    // Message volontairement générique : ne révèle pas si
                    // c'est l'email ou le mot de passe qui est incorrect.
                    $loginErrors['global'] = 'Email ou mot de passe incorrect.';

                    $attempts = (int) ($_SESSION['login_attempts'] ?? 0) + 1;

                    if ($attempts >= SECURITY_MAX_LOGIN_ATTEMPTS) {
                        $_SESSION['login_lockout_until'] = time() + LOGIN_LOCKOUT_SECONDS;
                        $_SESSION['login_attempts'] = 0;
                    } else {
                        $_SESSION['login_attempts'] = $attempts;
                    }
                } else {
                    unset($_SESSION['login_attempts'], $_SESSION['login_lockout_until']);

                    if ($remember) {
                        // Prolonge à la fois le cookie ET la durée de vie
                        // côté serveur (session.gc_maxlifetime) : sans ce
                        // second réglage, le garbage collector PHP peut
                        // supprimer les données de session bien avant
                        // l'expiration du cookie (toujours à
                        // SESSION_LIFETIME_MINUTES par défaut, soit 2h),
                        // déconnectant silencieusement le compte malgré
                        // "Rester connecté".
                        $rememberLifetimeSeconds = 30 * 24 * 60 * 60;

                        session_set_cookie_params([
                            'lifetime' => $rememberLifetimeSeconds,
                            'path'     => BASE_URL,
                            'domain'   => '',
                            'secure'   => SESSION_COOKIE_SECURE,
                            'httponly' => true,
                            'samesite' => 'Lax',
                        ]);
                        ini_set('session.gc_maxlifetime', (string) $rememberLifetimeSeconds);
                    }

                    regenerateSessionId();
                    $_SESSION[SESSION_USER_KEY] = (int) $user['id'];

                    redirect('profile.php');
                }
            }
        }
    }
}

$pageTitle = 'Connexion';
require __DIR__ . '/includes/components/header.php';
require __DIR__ . '/pages/login.php';
require __DIR__ . '/includes/components/footer.php';
